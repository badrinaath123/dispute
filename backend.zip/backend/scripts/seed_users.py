"""
Seed default tenant + one test user per persona.
Run: python scripts/seed_users.py
"""
import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from packages.persistence.sqlite.database import init_db, AsyncSessionLocal
from packages.persistence.sqlite.models import TenantModel, UserModel
from packages.security.auth import hash_password
import uuid


TENANT_ID = "tenant-demo-001"

USERS = [
    {
        "user_id": "user-analyst-001",
        "username": "analyst",
        "email": "analyst@dispute.local",
        "password": "Analyst@123!",
        "roles": ["issuer_analyst"],
    },
    {
        "user_id": "user-merchant-001",
        "username": "merchant_analyst",
        "email": "merchant@dispute.local",
        "password": "MerchantAnalyst@123!",
        "roles": ["merchant_analyst"],
    },
    {
        "user_id": "user-admin-001",
        "username": "admin",
        "email": "admin@dispute.local",
        "password": "Admin@12345!",
        "roles": ["admin"],
    },
]


async def seed():
    await init_db()
    async with AsyncSessionLocal() as db:
        # Tenant
        from sqlalchemy import select
        existing = await db.execute(
            select(TenantModel).where(TenantModel.tenant_id == TENANT_ID)
        )
        if not existing.scalar_one_or_none():
            tenant = TenantModel(
                tenant_id=TENANT_ID,
                name="Demo Issuer Bank",
                config={
                    "dispute_types": ["MERCHANDISE_NOT_RECEIVED", "UNAUTHORIZED_TRANSACTION"],
                    "network": "VISA",
                },
            )
            db.add(tenant)
            print(f"Created tenant: {TENANT_ID}")

        for u in USERS:
            existing_user = await db.execute(
                select(UserModel).where(UserModel.username == u["username"])
            )
            if not existing_user.scalar_one_or_none():
                user = UserModel(
                    user_id=u["user_id"],
                    tenant_id=TENANT_ID,
                    username=u["username"],
                    email=u["email"],
                    password_hash=hash_password(u["password"]),
                    roles=u["roles"],
                    is_active=True,
                )
                db.add(user)
                print(f"  Created user: {u['username']} ({u['roles']})")

        await db.commit()

    print("\nSeed complete.")
    print("\nTest credentials:")
    for u in USERS:
        print(f"  {u['username']:15} / {u['password']:20} roles={u['roles']}")


if __name__ == "__main__":
    asyncio.run(seed())
