"""
Hard reset — drops and recreates database and FAISS index.
Use between demo runs to start fresh.
WARNING: destroys all data.
"""
import asyncio
import os
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./data/dispute_system.db")


async def reset() -> None:
    data_dir = Path("./data")

    # Remove DB
    db_path = data_dir / "dispute_system.db"
    if db_path.exists():
        db_path.unlink()
        print(f"Removed: {db_path}")

    # Remove FAISS
    faiss_dir = data_dir / "faiss"
    if faiss_dir.exists():
        shutil.rmtree(faiss_dir)
        print(f"Removed: {faiss_dir}")

    # Re-seed
    print("\nRe-seeding…")
    import importlib.util
    spec = importlib.util.spec_from_file_location("seed_demo", Path(__file__).parent / "seed_demo.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    await mod.seed()


if __name__ == "__main__":
    confirm = input("This destroys all data. Type YES to continue: ")
    if confirm.strip() == "YES":
        asyncio.run(reset())
    else:
        print("Aborted.")
