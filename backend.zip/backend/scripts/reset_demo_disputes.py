"""
Resets the demo dataset to exactly 3 disputes, each fully populated in the new
case-detail contract shape (cardholder/transaction/dispute/evidence — see
README §24) with real, openable evidence PDFs. Wipes every existing dispute
and everything hanging off it (evidence, hypotheses, recommendations,
actions, approvals, audit events, agent runs, claims) first — but leaves
tenants/users/admin config untouched.

The 3 cases are freshly created (status OPEN, no hypotheses/recommendations
yet) so "Analyse Case" can be run on them from a clean state, same as any
real new case.

Run once from the repo root: python scripts/reset_demo_disputes.py
"""
import asyncio
import hashlib
import os
import shutil
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./data/dispute_system.db")

from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from sqlalchemy import delete

from packages.persistence.sqlite.database import AsyncSessionLocal
from packages.persistence.sqlite.models import (
    ActionModel, AgentRunModel, ApprovalModel, AuditEventModel, ClaimModel,
    ContradictionModel, DisputeModel, EvidenceGapModel, EvidenceModel,
    HypothesisModel, IdempotencyKeyModel, ProvenanceModel, RecommendationModel,
    TimelineEventModel,
)

REPO_ROOT = Path(__file__).resolve().parent.parent
STORAGE_ROOT = REPO_ROOT / "storage" / "disputes"
TENANT_ID = "tenant-demo-001"
NOW = datetime.utcnow()

styles = getSampleStyleSheet()
styles.add(ParagraphStyle("DocTitle", parent=styles["Title"], fontSize=16, spaceAfter=4))
styles.add(ParagraphStyle("DocSub", parent=styles["Normal"], fontSize=9, textColor=colors.grey, spaceAfter=14))
styles.add(ParagraphStyle("Body", parent=styles["Normal"], fontSize=10, leading=15, spaceAfter=8))
styles.add(ParagraphStyle("Note", parent=styles["Normal"], fontSize=8, textColor=colors.HexColor("#c50f1f"), spaceBefore=20))
styles.add(ParagraphStyle("KV", parent=styles["Normal"], fontSize=10))


def kv_table(rows: list[tuple[str, str]]) -> Table:
    data = [[Paragraph(f"<b>{k}</b>", styles["KV"]), Paragraph(v, styles["KV"])] for k, v in rows]
    t = Table(data, colWidths=[2.0 * inch, 4.2 * inch])
    t.setStyle(TableStyle([
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, colors.HexColor("#e8e8e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def doc_flowables(title: str, rows: list[tuple[str, str]], body: str) -> list:
    return [
        Paragraph(title, styles["DocTitle"]),
        Paragraph("SAMPLE DOCUMENT — generated for demonstration purposes only", styles["DocSub"]),
        kv_table(rows),
        Spacer(1, 10),
        Paragraph(body, styles["Body"]),
        Paragraph("Sample document — not a real record.", styles["Note"]),
    ]


CASES = [
    {
        "dispute_type": "REFUND_NOT_PROCESSED",
        "priority": "MEDIUM",
        "transaction_reference": "MYN-884210",
        "cardholder_claim": (
            "I am disputing a charge of Rs 3,299.00 from 18 March 2026. I returned the item "
            "to Myntra on 25 March 2026, but the refund has not been processed and credited to my card."
        ),
        "metadata": {
            "customer_id": "CUST-MYN-30112", "customer_name": "Ravi Shankar",
            "masked_card_number": "****1234", "authentication_status": "AUTHENTICATED",
            "merchant_name": "Myntra", "merchant_id": "MYNTRA-001", "merchant_category_code": "5691",
            "transaction_channel": "ECOMMERCE", "currency": "INR",
            "transaction_id": "TXN-MYN-884210", "amount_disputed": "3299.00",
            "transaction_date": "2026-03-18", "posting_date": "2026-03-19",
            "return_date": "2026-03-25", "expected_refund_amount": "3299.00",
            "expected_refund_date": "2026-04-01", "merchant_contacted": True,
            "merchant_contact_date": "2026-03-28",
            "merchant_response": "Merchant stated that the refund was processed on their end, but no credit has been received on the cardholder's statement.",
            "refund_reference_number": "REF-MYN-928371",
        },
        "documents": [
            {
                "document_id": "DOC-001", "document_type": "ORDER_INVOICE", "file_name": "order_invoice.pdf",
                "flowables": doc_flowables("MYNTRA — Order Invoice", [
                    ("Order ID", "MYN-ORD-884210"), ("Order Date", "18 Mar 2026"),
                    ("Customer", "Ravi Shankar"), ("Item", "Cotton Casual Shirt — Size M"),
                    ("Order Total", "Rs 3,299.00"), ("Payment Method", "Card ****1234"),
                ], "This invoice confirms the order details for the disputed transaction."),
            },
            {
                "document_id": "DOC-002", "document_type": "REFUND_CONFIRMATION", "file_name": "refund_confirmation.pdf",
                "flowables": doc_flowables("MYNTRA — Refund Confirmation", [
                    ("Order ID", "MYN-ORD-884210"), ("Refund Reference", "REF-928371"),
                    ("Refund Amount", "Rs 3,299.00"), ("Refund Initiated", "29 Mar 2026"),
                    ("Merchant-Side Status", "PROCESSED"),
                ], "Merchant records show this refund was processed to the original payment method on "
                   "29 Mar 2026. If the credit has not appeared on the cardholder's statement, this may "
                   "indicate a delay on the issuing side — the discrepancy this dispute is investigating."),
            },
        ],
    },
    {
        "dispute_type": "UNAUTHORIZED_TRANSACTION",
        "priority": "HIGH",
        "transaction_reference": "AMZ-551029",
        "cardholder_claim": (
            "I see a charge on my card for a purchase I never made. I still have my card in my "
            "possession and have not shared my card details with anyone."
        ),
        "metadata": {
            "customer_id": "CUST-AMZ-88213", "customer_name": "Priya Nair",
            "masked_card_number": "****5678", "authentication_status": "NOT_AUTHENTICATED",
            "merchant_name": "Amazon India", "merchant_id": "AMAZON-IN-001", "merchant_category_code": "5999",
            "transaction_channel": "ECOMMERCE", "currency": "INR",
            "transaction_id": "TXN-AMZ-551029", "amount_disputed": "4599.00",
            "transaction_date": "2026-03-20", "posting_date": "2026-03-20",
            "merchant_contacted": False,
        },
        "documents": [
            {
                "document_id": "DOC-001", "document_type": "TRANSACTION_RECEIPT", "file_name": "transaction_receipt.pdf",
                "flowables": doc_flowables("Amazon India — Transaction Receipt", [
                    ("Order ID", "AMZ-ORD-551029"), ("Transaction Date", "20 Mar 2026"),
                    ("Amount", "Rs 4,599.00"), ("Card Used", "****5678"),
                    ("Delivery Address", "Sector 21, Noida, UP 201301"),
                ], "Merchant transaction record for the disputed order. Note the delivery address does "
                   "not match the cardholder's registered billing address on file."),
            },
            {
                "document_id": "DOC-002", "document_type": "AUTHENTICATION_LOG", "file_name": "authentication_log.pdf",
                "flowables": doc_flowables("Issuer — Cardholder Authentication Log", [
                    ("Transaction ID", "TXN-AMZ-551029"), ("Auth Method", "3DS / OTP"),
                    ("OTP Result", "NOT VERIFIED"), ("Risk Score", "HIGH"),
                    ("Liability Shift", "NO"),
                ], "The authentication log shows the OTP step was not successfully verified for this "
                   "transaction, and liability did not shift to the merchant."),
            },
        ],
    },
    {
        "dispute_type": "MERCHANDISE_NOT_RECEIVED",
        "priority": "MEDIUM",
        "transaction_reference": "CRM-227781",
        "cardholder_claim": (
            "I ordered a laptop bag from Croma but it was never delivered. The tracking shows "
            "delivered, but I never received the package."
        ),
        "metadata": {
            "customer_id": "CUST-CRM-51940", "customer_name": "Arjun Mehta",
            "masked_card_number": "****9021", "authentication_status": "AUTHENTICATED",
            "merchant_name": "Croma Electronics", "merchant_id": "CROMA-001", "merchant_category_code": "5732",
            "transaction_channel": "ECOMMERCE", "currency": "INR",
            "transaction_id": "TXN-CRM-227781", "amount_disputed": "2999.00",
            "transaction_date": "2026-03-10", "posting_date": "2026-03-11",
            "merchant_contacted": True, "merchant_contact_date": "2026-03-22",
            "merchant_response": "Merchant stated the courier confirmed delivery with a signature at the doorstep.",
        },
        "documents": [
            {
                "document_id": "DOC-001", "document_type": "ORDER_INVOICE", "file_name": "order_invoice.pdf",
                "flowables": doc_flowables("Croma Electronics — Order Invoice", [
                    ("Order ID", "CRM-ORD-227781"), ("Order Date", "10 Mar 2026"),
                    ("Customer", "Arjun Mehta"), ("Item", "Laptop Bag — 15.6 inch"),
                    ("Order Total", "Rs 2,999.00"),
                ], "This invoice confirms the order details for the disputed transaction."),
            },
            {
                "document_id": "DOC-002", "document_type": "SHIPPING_TRACKING", "file_name": "shipping_tracking.pdf",
                "flowables": doc_flowables("Courier — Shipment Tracking", [
                    ("Tracking ID", "CRM-TRK-88452"), ("Status", "DELIVERED"),
                    ("Delivered On", "13 Mar 2026, 15:42"), ("Signed By", "\"R. Mehta\" (unverified)"),
                    ("Delivery Address", "Whitefield, Bengaluru, KA 560066"),
                ], "Courier status shows the package marked delivered with a signature, but the "
                   "signee name does not match the cardholder and was not independently verified."),
            },
        ],
    },
]


def build_pdf(path: Path, flowables: list) -> None:
    doc = SimpleDocTemplate(str(path), pagesize=LETTER,
                             topMargin=0.9 * inch, bottomMargin=0.9 * inch,
                             leftMargin=0.9 * inch, rightMargin=0.9 * inch)
    doc.build(flowables)


async def main() -> None:
    async with AsyncSessionLocal() as session:
        print("Wiping existing dispute data…")
        for model in [
            IdempotencyKeyModel, ApprovalModel, ActionModel, AgentRunModel, AuditEventModel,
            RecommendationModel, EvidenceGapModel, ContradictionModel, HypothesisModel,
            TimelineEventModel, ProvenanceModel, EvidenceModel, DisputeModel, ClaimModel,
        ]:
            await session.execute(delete(model))
        await session.commit()

        if STORAGE_ROOT.exists():
            shutil.rmtree(STORAGE_ROOT)
        STORAGE_ROOT.mkdir(parents=True, exist_ok=True)

        print("Creating 3 fresh disputes…\n")
        created = []
        for i, case in enumerate(CASES):
            dispute_id = str(uuid.uuid4())
            dispute_dir = STORAGE_ROOT / dispute_id
            dispute_dir.mkdir(parents=True, exist_ok=True)

            session.add(DisputeModel(
                dispute_id=dispute_id,
                tenant_id=TENANT_ID,
                status="OPEN",
                dispute_type=case["dispute_type"],
                lifecycle_stage="INTAKE",
                priority=case["priority"],
                current_state_version=1,
                deadline=NOW + timedelta(days=14),
                transaction_reference=case["transaction_reference"],
                cardholder_claim=case["cardholder_claim"],
                metadata_=case["metadata"],
                created_at=NOW,
                updated_at=NOW,
            ))

            for doc in case["documents"]:
                stored_name = f"{doc['document_id']}_{doc['file_name']}"
                file_path = dispute_dir / stored_name
                build_pdf(file_path, doc["flowables"])
                content_hash = hashlib.sha256(file_path.read_bytes()).hexdigest()

                evidence_id = str(uuid.uuid4())
                session.add(EvidenceModel(
                    evidence_id=evidence_id,
                    case_id=dispute_id,
                    tenant_id=TENANT_ID,
                    source_type="DOCUMENT",
                    source_system="DOCUMENT_STORAGE",
                    source_record_id=doc["document_id"],
                    evidence_type=doc["document_type"],
                    version=1,
                    normalized_content={
                        "documentId": doc["document_id"],
                        "documentType": doc["document_type"],
                        "fileName": doc["file_name"],
                    },
                    content_reference=f"{dispute_id}/{stored_name}",
                    event_time=NOW,
                    received_time=NOW,
                    effective_time=NOW,
                    content_hash=content_hash,
                    materiality="MEDIUM",
                    quality="VERIFIED",
                    is_current=True,
                    created_at=NOW,
                ))
                session.add(ProvenanceModel(
                    provenance_id=str(uuid.uuid4()),
                    evidence_id=evidence_id,
                    source_type="DOCUMENT",
                    source_system="DOCUMENT_STORAGE",
                    source_record_id=doc["document_id"],
                    retrieval_method="SEED_SCRIPT",
                    retrieved_by="system",
                    retrieved_at=NOW,
                    verified=True,
                    chain_of_custody=[{"actor": "reset_demo_disputes.py", "action": "SEEDED", "at": NOW.isoformat()}],
                ))

            created.append((dispute_id, case["dispute_type"], case["metadata"]["merchant_name"]))
            print(f"  {i + 1}. {dispute_id}  {case['dispute_type']:<26} {case['metadata']['merchant_name']}")

        await session.commit()
        print(f"\nDone. {len(created)} disputes, {sum(len(c['documents']) for c in CASES)} evidence documents.")


if __name__ == "__main__":
    asyncio.run(main())
