"""
National Finals inject — sends merchant V2 evidence (wrong delivery address).
This triggers:
  1. Evidence supersedes V1
  2. Recommendation marked STALE
  3. SSE EVIDENCE_CHANGED event fires to all connected frontends
  4. UI shows stale banner + "⚡ New evidence changed recommendation"
  5. Analyst must re-run agent → new recommendation with updated confidence

Run DURING the live demo after the agent has produced V1 recommendation.
"""
import asyncio
import hashlib
import json
import os
import sys
import uuid
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./data/dispute_system.db")

DISPUTE_ID = "dispute-national-finals-001"
TENANT_ID = "tenant-demo-001"

V2_CONTENT = {
    "order_id": "ORD-9988",
    "tracking_number": "1Z999AA10123456784",
    "carrier": "UPS",
    "delivered_at": "2026-08-15T14:22:00Z",
    "delivery_address": "456 Unknown St, Dallas TX 75201",  # DIFFERENT ADDRESS — key inject
    "signature_obtained": False,
    "shipping_label_scan": "LABEL_SCAN_ORD9988_V2",
    "label_vs_order_mismatch": True,
    "note": "Corrected record — shipping label shows address different from order destination",
    "evidence_version": 2,
}


def _hash(content: dict) -> str:
    return hashlib.sha256(json.dumps(content, sort_keys=True).encode()).hexdigest()


async def inject() -> None:
    from packages.persistence.sqlite.database import init_db, AsyncSessionLocal
    from packages.persistence.sqlite.models import (
        EvidenceModel, ProvenanceModel, RecommendationModel, AuditEventModel
    )
    from sqlalchemy import select

    await init_db()

    now = datetime.utcnow()
    content_hash = _hash(V2_CONTENT)

    async with AsyncSessionLocal() as db:
        # Find V1 delivery confirmation
        result = await db.execute(
            select(EvidenceModel).where(
                EvidenceModel.case_id == DISPUTE_ID,
                EvidenceModel.evidence_type == "DELIVERY_CONFIRMATION",
                EvidenceModel.is_current == True,
            )
        )
        v1 = result.scalar_one_or_none()
        if not v1:
            print("ERROR: V1 delivery confirmation not found. Run seed_demo.py first.")
            return

        new_ev_id = str(uuid.uuid4())

        # Supersede V1
        v1.is_current = False
        v1.superseded_by = new_ev_id

        # Create V2
        v2 = EvidenceModel(
            evidence_id=new_ev_id,
            case_id=DISPUTE_ID,
            tenant_id=TENANT_ID,
            source_type="MERCHANT",
            source_system="ElectroShop-OMS",
            source_record_id="ORD-9988-DELIVERY-V1",  # same record_id = new version
            evidence_type="DELIVERY_CONFIRMATION",
            version=2,
            previous_version_id=v1.evidence_id,
            normalized_content=V2_CONTENT,
            event_time=v1.event_time,
            received_time=now,
            effective_time=now,
            content_hash=content_hash,
            materiality="HIGH",
            quality="UNVERIFIED",
            is_current=True,
            created_at=now,
        )
        db.add(v2)

        db.add(ProvenanceModel(
            provenance_id=str(uuid.uuid4()),
            evidence_id=new_ev_id,
            source_type="MERCHANT",
            source_system="ElectroShop-OMS",
            source_record_id="ORD-9988-DELIVERY-V1",
            retrieval_method="LATE_EVIDENCE_INJECT",
            retrieved_by="inject_script",
            retrieved_at=now,
            verified=False,
            chain_of_custody=[{
                "actor": "inject_evidence.py",
                "action": "INJECTED",
                "at": now.isoformat(),
                "note": "National Finals demo inject — corrected shipping address",
            }],
        ))

        # Mark recommendation STALE
        rec_result = await db.execute(
            select(RecommendationModel).where(
                RecommendationModel.case_id == DISPUTE_ID,
                RecommendationModel.is_current == True,
                RecommendationModel.is_stale == False,
            )
        )
        rec = rec_result.scalar_one_or_none()
        if rec:
            rec.is_stale = True
            rec.stale_reason = (
                "HIGH materiality evidence v2 received: merchant delivery confirmation "
                "corrected — address differs from order destination."
            )
            print(f"  Marked recommendation STALE: {rec.recommendation_id[:12]}…")

        # Audit event
        db.add(AuditEventModel(
            audit_id=str(uuid.uuid4()),
            timestamp=now,
            actor_id="inject_script",
            actor_type="SYSTEM",
            tenant_id=TENANT_ID,
            case_id=DISPUTE_ID,
            event_type="EVIDENCE_CHANGED",
            evidence_refs=[new_ev_id],
            metadata_={
                "evidence_type": "DELIVERY_CONFIRMATION",
                "version": 2,
                "materiality": "HIGH",
                "inject": "NATIONAL_FINALS",
            },
        ))

        await db.commit()

    print("\nInject complete.")
    print(f"  New evidence ID: {new_ev_id[:12]}…")
    print(f"  Delivery address now: {V2_CONTENT['delivery_address']}")
    print(f"\nFrontends subscribed via SSE will receive EVIDENCE_CHANGED event.")
    print("Analyst should re-run agent to see updated recommendation.")


if __name__ == "__main__":
    asyncio.run(inject())
