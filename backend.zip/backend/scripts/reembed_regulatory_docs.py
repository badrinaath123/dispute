"""
One-off maintenance script: re-embed already-uploaded regulatory documents with the
current embedding model, reusing their existing document_id/network/doc_type — used
after switching the embedding backend (e.g. local sentence-transformers -> remote
text-embedding-3-large), since the two vector spaces are incompatible and the FAISS
index was wiped. Reads the PDFs already stored under data/regulatory_docs/ (kept
on disk specifically for this) rather than requiring a manual re-upload.
"""
import asyncio
import os
import sys
from pathlib import Path

os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")  # faiss/torch OpenMP DLL conflict on Windows

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dotenv import load_dotenv
load_dotenv()  # must run before any module reads os.getenv() for LITELLM_* config

from packages.persistence.sqlite.database import AsyncSessionLocal, init_db
from packages.persistence.sqlite.models import RegulatoryDocumentModel
from packages.intelligence import faiss_index, pdf_ingest
from sqlalchemy import select


async def main():
    await init_db()
    faiss_index.initialize_all()

    async with AsyncSessionLocal() as db:
        result = await db.execute(select(RegulatoryDocumentModel))
        docs = result.scalars().all()

        for doc in docs:
            print(f"Re-embedding {doc.filename} ({doc.network}/{doc.doc_type})...")
            doc.status = "PROCESSING"
            doc.chunks_indexed = 0
            await db.commit()

            # Idempotent: drop any chunks already indexed for this document_id first,
            # so re-running this script (e.g. after an interrupted prior run) never
            # duplicates a document's vectors.
            faiss_index.remove_regulatory_document(doc.document_id)

            try:
                page_total = pdf_ingest.page_count(doc.file_path)
                chunks = pdf_ingest.extract_chunks(doc.file_path)
                if not chunks:
                    doc.status = "FAILED"
                    doc.error = "No extractable text found on re-embed."
                    await db.commit()
                    print(f"  FAILED — no extractable text")
                    continue

                indexed = faiss_index.add_regulatory_chunks(
                    doc.document_id, doc.filename, chunks, doc.network, doc.doc_type,
                )
                doc.status = "READY"
                doc.page_count = page_total
                doc.chunks_indexed = indexed
                doc.error = None
                await db.commit()
                print(f"  READY — {page_total} pages, {indexed} chunks")
            except Exception as exc:
                doc.status = "FAILED"
                doc.error = str(exc)[:500]
                await db.commit()
                print(f"  FAILED — {exc}")

    print("\nDone. Final stats:", faiss_index.collection_stats())


if __name__ == "__main__":
    asyncio.run(main())
