"""
One-time migration: moves the evidence-requirement checklist that used to be
hardcoded in packages/intelligence/scheme_rules.py into the admin-editable
EvidenceRequirementModel table (Admin -> Evidence Requirements). Idempotent —
skips if the table already has rows, so it's safe to run more than once.

Run once from the repo root: python scripts/seed_evidence_requirements.py
"""
import asyncio
import os
import sys
import uuid
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./data/dispute_system.db")

from sqlalchemy import select

from packages.persistence.sqlite.database import init_db, AsyncSessionLocal
from packages.persistence.sqlite.models import EvidenceRequirementModel

NOW = datetime.utcnow()

# (dispute_type, evidence_type, description, is_required, sort_order)
DATA = [
    ("UNAUTHORIZED_TRANSACTION", "TRANSACTION_RECEIPT", "Transaction receipt showing channel and AVS/CVV match", True, 10),
    ("UNAUTHORIZED_TRANSACTION", "AUTHENTICATION_LOG", "Cardholder authentication result (3DS/chip & PIN) with liability-shift indicator", True, 20),

    ("DUPLICATE_TRANSACTION", "TRANSACTION_RECEIPT", "Transaction receipts for both the original and the duplicate charge", True, 10),

    ("MERCHANDISE_NOT_RECEIVED", "ORDER_INVOICE", "Order invoice / proof of purchase", True, 10),
    ("MERCHANDISE_NOT_RECEIVED", "SHIPPING_TRACKING", "Proof of shipment and delivery status via carrier tracking", True, 20),

    ("MERCHANDISE_NOT_AS_DESCRIBED", "ORDER_INVOICE", "Order invoice showing what was ordered/described", True, 10),
    ("MERCHANDISE_NOT_AS_DESCRIBED", "MERCHANT_COMMUNICATION", "Merchant's response to the complaint, and any description/photos of the item received", True, 20),

    ("REFUND_NOT_PROCESSED", "RETURN_CONFIRMATION", "Proof the merchant received the returned item", True, 10),
    ("REFUND_NOT_PROCESSED", "REFUND_CONFIRMATION", "Merchant's refund confirmation or statement of refund status", True, 20),
    ("REFUND_NOT_PROCESSED", "ORDER_INVOICE", "Original order invoice / transaction record", False, 30),

    ("SUBSCRIPTION_CANCELLATION", "CANCELLATION_CONFIRMATION", "Proof the cardholder submitted a cancellation request before the renewal date", True, 10),
    ("SUBSCRIPTION_CANCELLATION", "MERCHANT_COMMUNICATION", "Merchant communication acknowledging (or disputing) the cancellation", True, 20),
    ("SUBSCRIPTION_CANCELLATION", "SUBSCRIPTION_AGREEMENT", "The subscription agreement / merchant's cancellation & refund policy", False, 30),
    ("SUBSCRIPTION_CANCELLATION", "TRANSACTION_RECEIPT", "Transaction record for the disputed renewal charge", False, 40),

    ("CASH_WITHDRAWAL_DISPUTE", "TRANSACTION_RECEIPT", "ATM/transaction receipt for the disputed withdrawal", True, 10),
    ("CASH_WITHDRAWAL_DISPUTE", "AUTHENTICATION_LOG", "PIN/authentication verification log for the transaction", True, 20),

    ("PROCESSING_ERROR", "TRANSACTION_RECEIPT", "Transaction receipt showing the amount actually charged vs. the amount authorized", True, 10),
    ("PROCESSING_ERROR", "MERCHANT_COMMUNICATION", "Merchant communication acknowledging the processing error, if any", False, 20),
]


async def main() -> None:
    await init_db()
    async with AsyncSessionLocal() as db:
        existing = await db.execute(select(EvidenceRequirementModel))
        if existing.scalars().first():
            print("Evidence requirements already seeded — skipping.")
            return

        for dispute_type, evidence_type, description, is_required, sort_order in DATA:
            db.add(EvidenceRequirementModel(
                requirement_id=str(uuid.uuid4()),
                dispute_type=dispute_type,
                evidence_type=evidence_type,
                description=description,
                is_required=is_required,
                sort_order=sort_order,
                is_active=True,
                created_at=NOW,
                updated_at=NOW,
                created_by="system",
            ))
        await db.commit()
        print(f"Seeded {len(DATA)} evidence requirements across "
              f"{len(set(d for d, *_ in DATA))} dispute types.")


if __name__ == "__main__":
    asyncio.run(main())
