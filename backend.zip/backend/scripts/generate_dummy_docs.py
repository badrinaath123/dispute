"""
Generates two ILLUSTRATIVE/SYNTHESIZED reference PDFs for the Knowledge Base:
  1. Internal Dispute Operations Handbook (SOPs, internal policies, merchant policies)
  2. Regulatory Reference Guide — Regulation Z & Related U.S. Consumer Protections

Both are clearly and repeatedly labeled as illustrative/synthesized-for-demonstration —
NOT a real company's internal policy and NOT the official CFPB regulatory text. This
mirrors how packages/intelligence/regulatory_corpus.py's platform_policy passages are
already honestly labeled as this platform's own synthesized content, never presented as
licensed/official text. See README §21.9 for the corresponding documentation.
"""
from pathlib import Path

from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, HRFlowable,
)

OUT_DIR = Path(__file__).resolve().parent / "generated_docs"
OUT_DIR.mkdir(exist_ok=True)

styles = getSampleStyleSheet()
styles.add(ParagraphStyle("DocTitle", parent=styles["Title"], fontSize=22, spaceAfter=6))
styles.add(ParagraphStyle("DocSubtitle", parent=styles["Normal"], fontSize=12, alignment=TA_CENTER,
                           textColor=colors.HexColor("#4f46e5"), spaceAfter=4))
styles.add(ParagraphStyle("Disclaimer", parent=styles["Normal"], fontSize=9.5, alignment=TA_CENTER,
                           textColor=colors.HexColor("#c50f1f"), spaceAfter=2, leading=13))
styles.add(ParagraphStyle("H1", parent=styles["Heading1"], fontSize=16, spaceBefore=18, spaceAfter=8,
                           textColor=colors.HexColor("#1e1b4b")))
styles.add(ParagraphStyle("H2", parent=styles["Heading2"], fontSize=13, spaceBefore=12, spaceAfter=6,
                           textColor=colors.HexColor("#4338ca")))
styles.add(ParagraphStyle("Body", parent=styles["Normal"], fontSize=10, alignment=TA_JUSTIFY, leading=14,
                           spaceAfter=8))
styles.add(ParagraphStyle("BulletItem", parent=styles["Normal"], fontSize=10, leading=14, leftIndent=16,
                           spaceAfter=4))
styles.add(ParagraphStyle("Small", parent=styles["Normal"], fontSize=8.5, textColor=colors.grey))


def cover_page(title: str, subtitle: str, disclaimer_lines: list[str], meta: list[tuple[str, str]]) -> list:
    flow = [Spacer(1, 1.4 * inch), Paragraph(title, styles["DocTitle"]),
            Paragraph(subtitle, styles["DocSubtitle"]), Spacer(1, 0.3 * inch)]
    box_data = [[Paragraph(line, styles["Disclaimer"])] for line in disclaimer_lines]
    box = Table(box_data, colWidths=[6.2 * inch])
    box.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#c50f1f")),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#fef4f4")),
        ("TOPPADDING", (0, 0), (-1, -1), 10), ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
        ("LEFTPADDING", (0, 0), (-1, -1), 14), ("RIGHTPADDING", (0, 0), (-1, -1), 14),
    ]))
    flow += [box, Spacer(1, 0.5 * inch)]
    meta_data = [[Paragraph(f"<b>{k}</b>", styles["Small"]), Paragraph(v, styles["Small"])] for k, v in meta]
    meta_table = Table(meta_data, colWidths=[1.8 * inch, 4.4 * inch])
    meta_table.setStyle(TableStyle([
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, colors.HexColor("#e8e8e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    flow += [meta_table, PageBreak()]
    return flow


def h1(text): return Paragraph(text, styles["H1"])
def h2(text): return Paragraph(text, styles["H2"])
def p(text): return Paragraph(text, styles["Body"])
def bullets(items): return [Paragraph(f"&bull;&nbsp;&nbsp;{t}", styles["BulletItem"]) for t in items]
def rule(): return HRFlowable(width="100%", thickness=0.6, color=colors.HexColor("#e8e8e8"), spaceAfter=10, spaceBefore=2)


# ════════════════════════════════════════════════════════════════════════════════
# DOCUMENT 1 — Internal Dispute Operations Handbook
# ════════════════════════════════════════════════════════════════════════════════

def build_internal_handbook():
    flow = cover_page(
        "Internal Dispute Operations Handbook",
        "Standard Operating Procedures &nbsp;&middot;&nbsp; Internal Policies &nbsp;&middot;&nbsp; Merchant Policies",
        [
            "ILLUSTRATIVE DOCUMENT — SYNTHESIZED FOR PLATFORM DEMONSTRATION",
            "This is not a real company's internal policy. It was written to populate the Dispute "
            "Intelligence Platform's Knowledge Base with realistic, well-structured content for "
            "retrieval-grounded features (reason-code suggestion, representment drafting, case Q&A). "
            "Do not treat any procedure, timeline, or figure below as an actual operational policy.",
        ],
        [
            ("Document type:", "Internal Operations Handbook (illustrative)"),
            ("Version:", "1.0 (demonstration)"),
            ("Applies to:", "Issuer Analyst, Merchant Analyst, and Admin personas"),
            ("Classification:", "Internal — Illustrative Only"),
        ],
    )

    # ── 1. Purpose & Scope ──────────────────────────────────────────────
    flow += [h1("1. Purpose & Scope")]
    flow += [p(
        "This handbook describes how dispute cases are expected to be handled from intake through "
        "resolution on the Dispute Intelligence Platform. It consolidates standard operating "
        "procedures (SOPs), internal governance policies, and merchant-facing policy requirements "
        "into a single reference so that any team member — issuer-side analyst, merchant-side "
        "analyst, or platform administrator — can find the guidance relevant to their role without "
        "consulting multiple sources."
    )]
    flow += [p(
        "This handbook applies to every dispute case regardless of card network, dispute type, or "
        "channel of intake. Where a specific card network's rules (Visa, Mastercard) impose a "
        "stricter or more specific requirement than what is described here, the network rule takes "
        "precedence for anything submitted to that network; this handbook governs internal handling "
        "and record-keeping in all cases."
    )]

    # ── 2. Roles & Responsibilities ─────────────────────────────────────
    flow += [h1("2. Roles & Responsibilities")]
    flow += [h2("2.1 Issuer Analyst")]
    flow += [p(
        "Front-line owner of issuer-side investigation. Responsible for reviewing the cardholder's "
        "claim, ensuring evidence is collected and correctly classified, running the platform's "
        "automated investigation, reviewing the resulting hypotheses and recommendation, and "
        "proposing the next action. An Issuer Analyst may propose a CLASS_C (consequential) action "
        "but may not approve their own proposal — see §4.3, Segregation of Duties."
    )]
    flow += [h2("2.2 Merchant Analyst")]
    flow += [p(
        "Front-line owner of the merchant's response to a dispute raised against their own "
        "transactions. Responsible for reviewing the platform's pre-formed recommendation, "
        "confirming or supplementing supporting evidence, and submitting a timely response "
        "(challenge or acceptance) in line with the merchant response SLA in §5.2."
    )]
    flow += [h2("2.3 Administrator")]
    flow += [p(
        "Back-office role responsible for platform configuration — dispute statuses, resolution "
        "outcomes, roles and permissions, user accounts, and system integrations. The Administrator "
        "is also the approver of record for CLASS_C actions raised by either the issuer or merchant "
        "side, satisfying the platform's maker-checker requirement without needing to be a case "
        "owner. The Administrator does not investigate individual cases."
    )]

    # ── 3. Standard Operating Procedures ────────────────────────────────
    flow += [h1("3. Standard Operating Procedures")]

    flow += [h2("3.1 Intake & Triage SOP")]
    flow += [p("Every new dispute is triaged on intake according to the following illustrative service levels:")]
    triage_data = [
        ["Priority", "Trigger", "Target first action"],
        ["HIGH", "High-value transaction, approaching deadline, or repeat cardholder complaint", "Same business day"],
        ["MEDIUM", "Standard dispute, no unusual risk indicators", "Within 2 business days"],
        ["LOW", "Low-value transaction, ample time to deadline", "Within 5 business days"],
    ]
    triage_table = Table(triage_data, colWidths=[1.0 * inch, 3.6 * inch, 1.6 * inch])
    triage_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2ff")),
        ("FONTSIZE", (0, 0), (-1, -1), 9), ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e8e8e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    flow += [triage_table, Spacer(1, 10)]

    flow += [h2("3.2 Evidence Collection SOP")]
    flow += [p(
        "Evidence should be requested and ingested as early in the case lifecycle as possible. Each "
        "evidence record must specify a source type, source system, and retrieval method so that "
        "provenance is always reconstructable. Do not delete or overwrite an existing evidence "
        "record to correct it — ingest a new version so the correction itself is preserved in the "
        "evidence history."
    )]
    flow += bullets([
        "Confirm the evidence type matches one of the platform's recognized categories before ingest.",
        "Where a scheme-specific evidence requirement exists (see the Regulatory Reference Guide and "
        "the card network's own rulebook), prioritize collecting that evidence first.",
        "Flag any evidence that appears to duplicate an existing record for review rather than "
        "assuming it is safe to ignore — a near-duplicate may indicate the same underlying "
        "transaction is being investigated under more than one case.",
    ])

    flow += [h2("3.3 Investigation & Recommendation SOP")]
    flow += [p(
        "Once sufficient evidence exists, the automated investigation should be run to produce "
        "hypotheses, identify evidence gaps, and generate a recommendation. The recommendation is "
        "an input to the analyst's decision, not a replacement for it — an analyst reviewing a "
        "recommendation should read the uncertainty statement and the specific evidence cited before "
        "acting on it, and should not approve or execute an action the underlying evidence does not "
        "actually support."
    )]

    flow += [h2("3.4 Approval & Maker-Checker SOP")]
    flow += [p(
        "Any consequential (CLASS_C) action — for example, submitting a formal chargeback — requires "
        "approval from someone other than the person who proposed it. The approver must confirm that "
        "the case's evidence state has not materially changed since the recommendation they are "
        "approving was generated; if it has, the approval must be treated as stale and the case "
        "re-reviewed against the current evidence before any action proceeds, never approved against "
        "outdated information."
    )]

    flow += [h2("3.5 Escalation SOP")]
    flow += [p(
        "A case should be escalated to a supervising reviewer or compliance contact when any of the "
        "following apply: the disputed amount exceeds an internally defined high-value threshold, the "
        "case involves a suspected pattern of fraud across multiple cardholders or merchants, the "
        "case has been re-opened more than once, or a network deadline is within 24 hours with "
        "evidence still outstanding."
    )]

    flow += [h2("3.6 Stale-Approval Re-Review SOP")]
    flow += [p(
        "When new material evidence arrives after a case has already been approved for action, the "
        "existing approval is invalidated automatically by the platform. The case owner must treat "
        "this exactly as a new case requiring re-review — read what changed, why the recommendation "
        "changed if it did, and re-approve deliberately. A stale approval must never be silently "
        "re-confirmed without reviewing the new evidence."
    )]

    flow += [h2("3.7 Multi-Transaction Claim Handling SOP")]
    flow += [p(
        "When a single cardholder intake covers more than one unrecognized or disputed transaction, "
        "each transaction is investigated as its own sub-case — its own merchant, its own evidence, "
        "its own recommendation — under one shared claim. Do not force multiple unrelated "
        "transactions into a single case record, and do not split a genuinely single transaction "
        "into multiple cases."
    )]

    flow += [h2("3.8 Pre-Dispute Alert Resolution SOP")]
    flow += [p(
        "A pre-dispute alert represents an opportunity to resolve a cardholder's complaint before it "
        "becomes a formal chargeback. Where the underlying issue is genuinely resolvable (for "
        "example, a straightforward refund), it should be resolved at this stage rather than allowed "
        "to escalate, since a formal chargeback carries a network fee that a pre-dispute resolution "
        "avoids entirely."
    )]

    flow += [h2("3.9 Documentation & Record-Keeping SOP")]
    flow += [p(
        "Every decision — approve, reject, override — must be recorded with a reason. Every "
        "system-generated action must be traceable to the specific evidence, run, and model version "
        "that produced it. Records should never be edited after the fact; corrections are made by "
        "adding a new record that supersedes the old one, preserving the full history."
    )]

    flow += [h2("3.10 Quality Assurance & Sampling SOP")]
    flow += [p(
        "A sample of closed cases should be periodically reviewed against this handbook to confirm "
        "SOPs were followed — evidence properly sourced, approvals properly segregated, deadlines "
        "met. Findings from this review feed back into training and, where a systemic issue is "
        "found, into a revision of this handbook."
    )]

    # ── 4. Internal Policies ────────────────────────────────────────────
    flow += [h1("4. Internal Policies")]

    flow += [h2("4.1 Evidence Integrity & Retention Policy")]
    flow += [p(
        "Evidence records and their full version history are retained for the lifetime of the case "
        "plus an illustrative minimum retention period thereafter, to support later audit or "
        "regulatory inquiry. Evidence must never be altered in place; every correction produces a "
        "new version and the prior version is marked superseded, never deleted."
    )]

    flow += [h2("4.2 Data Privacy & Access Control Policy")]
    flow += [p(
        "Access to case data is scoped by role and by tenant. An analyst should only access cases "
        "within their own scope of responsibility. Cardholder personal data within evidence records "
        "should be handled under the same confidentiality standard as any other regulated personal "
        "financial information."
    )]

    flow += [h2("4.3 Conflict of Interest / Segregation of Duties Policy")]
    flow += [p(
        "The person who proposes a consequential action must not be the same person who approves it. "
        "This applies regardless of seniority — a supervisor may not approve their own proposal "
        "either. This policy exists specifically to prevent a single point of failure from "
        "authorizing action against evidence that was never independently checked."
    )]

    flow += [h2("4.4 Vendor & Third-Party Evidence Source Policy")]
    flow += [p(
        "Evidence sourced from a third-party system (a shipping carrier, a payment gateway, an "
        "authentication provider) should record which system it came from and when it was retrieved. "
        "A vendor integration that has not been verified as reliable should have its evidence marked "
        "accordingly rather than treated as equivalent to a directly-verified internal record."
    )]

    flow += [h2("4.5 Audit & Compliance Review Policy")]
    flow += [p(
        "The full audit trail for any case must be reproducible on demand — who did what, when, "
        "against which version of the evidence, and why. Compliance review access to this trail "
        "should never require reconstructing it manually from disparate systems; it is expected to "
        "be a single, replayable record."
    )]

    flow += [h2("4.6 AI / Automation Use Policy")]
    flow += [p(
        "Any AI-generated output used in a dispute case — a suggested hypothesis, a recommendation, "
        "a drafted response, a reason-code suggestion — must be traceable to the specific evidence or "
        "reference passage that grounds it, and must never be presented to a human reviewer as a "
        "fact if it is actually an inference. A human retains final decision authority on every "
        "consequential action; AI output is an input to that decision, never a substitute for it."
    )]

    # ── 5. Merchant Policies ────────────────────────────────────────────
    flow += [h1("5. Merchant Policies")]

    flow += [h2("5.1 Merchant Onboarding & Evidence Readiness Requirements")]
    flow += [p(
        "A merchant should be able to produce, on request, proof of shipment/delivery for physical "
        "goods, proof of service delivery for services, and a record of any communication with the "
        "cardholder regarding the disputed transaction. Merchants unable to consistently produce this "
        "evidence should be flagged for a readiness review before onboarding is considered complete."
    )]

    flow += [h2("5.2 Merchant Response SLA Policy")]
    response_sla = [
        ["Dispute value", "Target response time"],
        ["Below an illustrative low-value threshold", "5 business days"],
        ["Standard value", "3 business days"],
        ["High value / approaching network deadline", "1 business day"],
    ]
    sla_table = Table(response_sla, colWidths=[3.3 * inch, 2.9 * inch])
    sla_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2ff")),
        ("FONTSIZE", (0, 0), (-1, -1), 9), ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e8e8e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    flow += [sla_table, Spacer(1, 10)]

    flow += [h2("5.3 Merchant Refund & Cancellation Policy Requirements")]
    flow += [p(
        "A merchant's refund and cancellation policy must be disclosed to the cardholder at or before "
        "the time of purchase. A dispute citing a refund the merchant's own disclosed policy already "
        "entitled the cardholder to should be resolved in the cardholder's favor without contest, "
        "since contesting it would misrepresent the merchant's own terms."
    )]

    flow += [h2("5.4 Merchant Risk Tiering Policy")]
    flow += [p(
        "Merchants are illustratively tiered by historical dispute rate and win rate. A merchant in a "
        "higher-risk tier should have their evidence submissions reviewed with additional scrutiny, "
        "and may be required to provide enhanced evidence (for example, signed delivery confirmation "
        "rather than tracking number alone) before a challenge is submitted on their behalf."
    )]

    flow += [h2("5.5 Merchant Dispute Fee Schedule (Illustrative)")]
    fee_data = [
        ["Stage", "Illustrative fee to merchant"],
        ["Pre-dispute alert resolved before chargeback", "None"],
        ["Formal chargeback filed", "Network-dependent representment fee"],
        ["Chargeback lost after representment", "Chargeback amount plus a per-case processing fee"],
    ]
    fee_table = Table(fee_data, colWidths=[3.3 * inch, 2.9 * inch])
    fee_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2ff")),
        ("FONTSIZE", (0, 0), (-1, -1), 9), ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e8e8e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    flow += [fee_table, Spacer(1, 10)]
    flow += [p(
        "Figures in this schedule are illustrative placeholders for demonstration only and do not "
        "represent any real fee arrangement."
    )]

    flow += [h2("5.6 Merchant Repeat-Offender / Excessive Chargeback Policy")]
    flow += [p(
        "A merchant whose chargeback rate exceeds an illustratively defined threshold over a rolling "
        "period should be referred for a risk review, which may result in enhanced monitoring, a "
        "reserve requirement, or — in a persistent, unresolved case — offboarding, consistent with "
        "card network merchant-monitoring program requirements referenced in the Regulatory Reference "
        "Guide."
    )]

    # ── 6. Glossary ──────────────────────────────────────────────────────
    flow += [h1("6. Appendix A — Glossary of Terms")]
    glossary = [
        ("Representment", "A merchant's formal response contesting a chargeback, submitted with supporting evidence."),
        ("Pre-arbitration", "A network-mediated stage after representment where the issuer may re-contest a lost representment."),
        ("Maker-checker", "A control requiring the person who proposes an action and the person who approves it to be different individuals."),
        ("Stale approval", "An approval whose underlying evidence has materially changed since it was granted, invalidating it."),
        ("Evidence gap", "A specific piece of missing evidence identified as necessary to support or refute a hypothesis."),
    ]
    for term, definition in glossary:
        flow += [p(f"<b>{term}</b> — {definition}")]

    flow += [h1("7. Appendix B — Illustrative Escalation Contact Matrix")]
    contacts = [
        ["Escalation type", "Illustrative contact"],
        ["High-value case review", "Dispute Operations Lead (fictional)"],
        ["Suspected fraud pattern", "Fraud & Risk Team (fictional)"],
        ["Compliance / regulatory question", "Compliance Office (fictional)"],
        ["Platform/system issue", "Platform Administrator"],
    ]
    contact_table = Table(contacts, colWidths=[3.0 * inch, 3.2 * inch])
    contact_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2ff")),
        ("FONTSIZE", (0, 0), (-1, -1), 9), ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e8e8e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    flow += [contact_table]

    return flow


# ════════════════════════════════════════════════════════════════════════════════
# DOCUMENT 2 — Regulatory Reference Guide (Reg Z & related)
# ════════════════════════════════════════════════════════════════════════════════

def build_reg_z_guide():
    flow = cover_page(
        "Regulatory Reference Guide",
        "Regulation Z (Truth in Lending Act) &amp; Related U.S. Consumer Credit Protections",
        [
            "ILLUSTRATIVE SUMMARY — SYNTHESIZED FOR PLATFORM DEMONSTRATION",
            "This is an educational summary written to populate the Dispute Intelligence Platform's "
            "Knowledge Base with realistic, well-structured reference content. It is NOT the official "
            "regulatory text, NOT legal advice, and must not be relied upon as authoritative. For the "
            "actual requirements, consult 12 CFR Part 1026 (Regulation Z) and the Fair Credit Billing "
            "Act as published by the Consumer Financial Protection Bureau.",
        ],
        [
            ("Document type:", "Regulatory Reference Guide (illustrative)"),
            ("Covers:", "Regulation Z billing-error rights; brief FCBA and Reg E comparison"),
            ("Jurisdiction:", "United States (illustrative — for demonstration only)"),
            ("Classification:", "Reference — Illustrative Only, Not Legal Advice"),
        ],
    )

    flow += [h1("1. Purpose & Disclaimer")]
    flow += [p(
        "This guide summarizes, at a general and illustrative level, the kind of consumer billing-"
        "error protections that U.S. federal law provides for credit card transactions, so that this "
        "platform's regulatory-grounding features have realistic reference material distinct from "
        "card-network rules. It intentionally does not reproduce the actual regulatory text. Anyone "
        "relying on this platform for a real compliance determination must consult qualified counsel "
        "and the official regulation."
    )]

    flow += [h1("2. Overview — Truth in Lending Act and Regulation Z")]
    flow += [p(
        "The Truth in Lending Act (TILA) is implemented through Regulation Z, which governs how "
        "open-end credit — including credit cards — must be disclosed and administered, including a "
        "cardholder's right to dispute a billing error directly with their card issuer. This is a "
        "distinct legal basis from a card network's own chargeback rules: a cardholder's Regulation Z "
        "rights exist regardless of what a specific network's operating rules say, and an issuer must "
        "satisfy both."
    )]

    flow += [h1("3. Billing Error Rights (Illustrative Summary)")]
    flow += [h2("3.1 What Counts as a Billing Error")]
    flow += [p(
        "A billing error, in general terms, includes a charge the cardholder did not authorize, a "
        "charge that doesn't match the amount actually agreed to, a charge for goods or services not "
        "accepted or not delivered as agreed, and computational or accounting errors on the "
        "statement. The specific categories and their precise definitions are set out in the actual "
        "regulation, not reproduced in full here."
    )]

    flow += [h2("3.2 Cardholder Notice Requirements")]
    flow += [p(
        "A cardholder generally must notify their card issuer of a suspected billing error in writing "
        "within a limited window after the statement containing the error was sent — illustratively "
        "referenced here as a 60-day window, consistent with the general shape of Regulation Z's "
        "notice period. The notice should identify the cardholder, the account, the amount in "
        "question, and the reason the cardholder believes it is an error."
    )]

    flow += [h2("3.3 Issuer Acknowledgment Requirement")]
    flow += [p(
        "Upon receiving a qualifying notice, the issuer is generally expected to acknowledge it in "
        "writing within a short window (illustratively referenced as 30 days), unless the matter is "
        "resolved within that window by correcting the account."
    )]

    flow += [h2("3.4 Investigation Timeline")]
    flow += [p(
        "The issuer is generally expected to complete its investigation and either correct the error "
        "or explain why it believes the bill was correct within a bounded period after receiving the "
        "notice — illustratively referenced as within two complete billing cycles, and in any case not "
        "exceeding roughly 90 days. This is the kind of deadline that this platform's eligibility "
        "check (see §21.5 of the platform README) is a simplified, illustrative stand-in for — the "
        "real deadline is set by the regulation and by the specific facts of the case, not by this "
        "document."
    )]

    flow += [h2("3.5 Provisional Credit During Investigation")]
    flow += [p(
        "Depending on the type of error alleged, an issuer may be expected to provisionally credit "
        "the disputed amount to the cardholder's account while the investigation is ongoing, so the "
        "cardholder is not required to pay a disputed amount or accrue finance charges on it before "
        "the matter is resolved."
    )]

    flow += [h2("3.6 Restricted Collection Actions During Dispute")]
    flow += [p(
        "While a qualifying dispute is open, an issuer is generally restricted from taking certain "
        "collection actions against the cardholder on the disputed amount — for example, treating it "
        "as delinquent or reporting it as such to a credit bureau — until the dispute is resolved."
    )]

    flow += [h2("3.7 Resolution and Correction")]
    flow += [p(
        "If the issuer determines a billing error did occur, the correction must be reflected on the "
        "cardholder's account along with any associated finance charges. If the issuer determines no "
        "billing error occurred, it must explain its reasoning to the cardholder and, if applicable, "
        "specify the amount owed and when payment is due."
    )]

    flow += [h1("4. Relationship to Card Network Rules")]
    flow += [p(
        "Regulation Z billing-error rights and a card network's own chargeback rules (see the "
        "platform's Mastercard and Visa reference documents) are not the same thing and are not "
        "mutually exclusive — an issuer must satisfy both. A case can be fully compliant with a card "
        "network's chargeback conditions and still fail to satisfy Regulation Z's notice, "
        "acknowledgment, and investigation-timeline requirements, or vice versa. This platform models "
        "them as separate reference sources for exactly this reason: the network-scoped "
        "regulatory-grounding search (README §21.3) intentionally treats network rules and this "
        "general federal-law reference as distinct, retrievable sources rather than merging them."
    )]

    flow += [h1("5. Fair Credit Billing Act (FCBA)")]
    flow += [p(
        "The FCBA is the underlying statute that Regulation Z's billing-error procedures implement "
        "for open-end credit, and is also the general source of the cardholder liability limit for "
        "unauthorized use of a credit card, commonly referenced at an illustrative cap well below the "
        "full transaction amount. As with the rest of this guide, the specific figures and conditions "
        "should be confirmed against the official statute and implementing regulation, not this "
        "document."
    )]

    flow += [h1("6. Regulation E — Brief Comparison for Debit Transactions")]
    flow += [p(
        "Regulation E (implementing the Electronic Fund Transfer Act) governs debit card and other "
        "electronic-transfer disputes and is a materially different regime from Regulation Z — "
        "different notice windows, different investigation timelines, and different cardholder "
        "liability tiers depending on how quickly the cardholder reports an unauthorized "
        "transaction. A platform handling both credit and debit disputes should not assume Regulation "
        "Z's timelines apply to a debit-funded transaction without checking which regime actually "
        "governs it."
    )]

    flow += [h1("7. Record-Keeping & Documentation Expectations")]
    flow += [p(
        "An issuer should be able to reconstruct, for any billing-error dispute, when the cardholder's "
        "notice was received, when it was acknowledged, what investigation steps were taken and when, "
        "and the basis for the final determination. This maps directly onto this platform's own "
        "audit-trail design (README §5.9, §16) — every state change already carries a timestamp, "
        "actor, and reason, which is the same shape of record this kind of regulatory review would "
        "expect to see."
    )]

    flow += [h1("8. Common Compliance Pitfalls (Illustrative)")]
    flow += bullets([
        "Treating a card network's representment deadline as the only deadline that matters, and "
        "missing the separate federal billing-error investigation timeline running in parallel.",
        "Reporting a disputed amount as delinquent to a credit bureau while a qualifying dispute is "
        "still open.",
        "Failing to send a written acknowledgment even when the issue is resolved quickly.",
        "Not distinguishing a Regulation Z credit-card dispute from a Regulation E debit-transaction "
        "dispute, and applying the wrong timeline or liability rule as a result.",
    ])

    flow += [h1("9. Appendix — Illustrative Timeline Summary")]
    timeline = [
        ["Step", "Illustrative timing"],
        ["Cardholder sends written notice of billing error", "Within ~60 days of the statement"],
        ["Issuer acknowledges receipt", "Within ~30 days of notice (unless already resolved)"],
        ["Issuer completes investigation and responds", "Within ~2 billing cycles, generally not exceeding ~90 days"],
    ]
    timeline_table = Table(timeline, colWidths=[3.4 * inch, 2.8 * inch])
    timeline_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eef2ff")),
        ("FONTSIZE", (0, 0), (-1, -1), 9), ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e8e8e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    flow += [timeline_table, Spacer(1, 10)]
    flow += [p("All timings above are illustrative approximations for demonstration and must not be relied upon as the actual regulatory deadlines.")]

    flow += [h1("10. Appendix — Glossary")]
    glossary = [
        ("Billing error", "A defined category of statement inaccuracy a cardholder may formally dispute under Regulation Z."),
        ("Provisional credit", "A temporary credit to a cardholder's account while a billing-error investigation is open."),
        ("TILA", "Truth in Lending Act — the underlying statute Regulation Z implements."),
        ("FCBA", "Fair Credit Billing Act — source of billing-error procedures and credit-card liability limits."),
        ("Reg E", "Regulation E — the separate regime governing electronic fund transfers, including debit cards."),
    ]
    for term, definition in glossary:
        flow += [p(f"<b>{term}</b> — {definition}")]

    return flow


def make_pdf(filename: str, flow: list):
    path = OUT_DIR / filename
    doc = SimpleDocTemplate(
        str(path), pagesize=LETTER,
        topMargin=0.9 * inch, bottomMargin=0.8 * inch, leftMargin=0.9 * inch, rightMargin=0.9 * inch,
        title=filename,
    )
    doc.build(flow)
    print(f"Wrote {path} ({path.stat().st_size:,} bytes)")


if __name__ == "__main__":
    make_pdf("internal-dispute-operations-handbook.pdf", build_internal_handbook())
    make_pdf("regulatory-reference-guide-reg-z.pdf", build_reg_z_guide())
