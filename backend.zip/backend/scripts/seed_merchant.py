"""
Merchant Dispute Intelligence Platform — Demo Seed Script
Seeds 6 merchant dispute scenarios with full rich data:
  DSP-MER-001  Unauthorized — Strong Challenge (auth + device + delivery)
  DSP-MER-002  Refund Not Processed — Accept (clearly owed)
  DSP-MER-003  Merchandise Not Received — Evidence Gap (no delivery proof)
  DSP-MER-004  Merchandise Not Received — Contradiction (tracking vs. customer)
  DSP-MER-005  Unauthorized — High Value + Recommendation Change demo
  DSP-MER-006  Pre-Dispute Alert — Resolve before chargeback

Run before presenting the Merchant module.
"""
import asyncio
import hashlib
import json
import os
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./data/dispute_system.db")

from packages.persistence.sqlite.database import init_db, AsyncSessionLocal
from packages.persistence.sqlite.models import (
    TenantModel, UserModel, DisputeModel, EvidenceModel,
    ProvenanceModel, TimelineEventModel, HypothesisModel,
    ContradictionModel, EvidenceGapModel, RecommendationModel,
)
from packages.security.auth import hash_password
from sqlalchemy import select as sa_select

TENANT_ID = "tenant-demo-001"
NOW = datetime(2026, 8, 31, 9, 0, 0)


def _uuid() -> str:
    return str(uuid.uuid4())


def _hash(content: dict) -> str:
    return hashlib.sha256(json.dumps(content, sort_keys=True).encode()).hexdigest()


def _dt(days_ago: float = 0, hours_ago: float = 0) -> datetime:
    return NOW - timedelta(days=days_ago, hours=hours_ago)


MERCHANT_PERSONAS = [
    ("merchant_analyst",  "MerchantAnalyst@123!",  ["merchant_analyst"]),
]


# ── Evidence factory ───────────────────────────────────────────────────────────

def make_evidence(dispute_id: str, source_type: str, source_system: str, record_id: str,
                  evidence_type: str, content: dict, event_time: datetime,
                  materiality: str = "HIGH", quality: str = "VERIFIED") -> tuple:
    ev_id = _uuid()
    ev = EvidenceModel(
        evidence_id=ev_id,
        case_id=dispute_id,
        tenant_id=TENANT_ID,
        source_type=source_type,
        source_system=source_system,
        source_record_id=record_id,
        evidence_type=evidence_type,
        version=1,
        normalized_content=content,
        event_time=event_time,
        received_time=NOW,
        effective_time=NOW,
        content_hash=_hash(content),
        materiality=materiality,
        quality=quality,
        is_current=True,
        created_at=NOW,
    )
    prov = ProvenanceModel(
        provenance_id=_uuid(),
        evidence_id=ev_id,
        source_type=source_type,
        source_system=source_system,
        source_record_id=record_id,
        retrieval_method="SEED_SCRIPT",
        retrieved_by="system",
        retrieved_at=NOW,
        verified=True,
        chain_of_custody=[{"actor": "seed_merchant.py", "action": "SEEDED", "at": NOW.isoformat()}],
    )
    return ev_id, ev, prov


def make_timeline(dispute_id: str, event_type: str, event_time: datetime, actor: str,
                  description: str, is_disputed: bool = False,
                  confidence: float = 1.0) -> TimelineEventModel:
    return TimelineEventModel(
        event_id=_uuid(),
        case_id=dispute_id,
        event_type=event_type,
        event_time=event_time,
        recorded_time=NOW,
        actor=actor,
        description=description,
        is_disputed=is_disputed,
        confidence=confidence,
        created_at=NOW,
    )


async def ensure_user(db, username: str, password: str, roles: list) -> None:
    existing = (await db.execute(sa_select(UserModel).where(UserModel.username == username))).scalar_one_or_none()
    if not existing:
        db.add(UserModel(
            user_id=_uuid(),
            tenant_id=TENANT_ID,
            username=username,
            email=f"{username}@merchant.demo",
            password_hash=hash_password(password),
            roles=roles,
            is_active=True,
            created_at=NOW,
        ))
        print(f"  Created user: {username} ({roles[0]})")


async def dispute_exists(db, dispute_id: str) -> bool:
    return (await db.get(DisputeModel, dispute_id)) is not None


# ══════════════════════════════════════════════════════════════════════════════
# SCENARIO 1 — Unauthorized Transaction: Strong Challenge
# ══════════════════════════════════════════════════════════════════════════════

async def seed_scenario_1(db) -> None:
    DID = "dsp-mer-001-unauth-challenge"
    if await dispute_exists(db, DID):
        print(f"  Skipping DSP-MER-001 (already exists)")
        return

    deadline = NOW + timedelta(hours=3, minutes=12)
    db.add(DisputeModel(
        dispute_id=DID,
        tenant_id=TENANT_ID,
        status="UNDER_INVESTIGATION",
        dispute_type="UNAUTHORIZED_TRANSACTION",
        lifecycle_stage="INVESTIGATION",
        priority="HIGH",
        current_state_version=3,
        deadline=deadline,
        transaction_reference="TXN-MER-001-FLIP",
        cardholder_claim=(
            "I did not make this purchase. I never visited the Flipkart website on that day and "
            "my card was in my wallet the entire time. Someone must have stolen my card details. "
            "Please reverse this transaction immediately."
        ),
        metadata_={
            "amount": 48500,
            "amount_disputed": 48500,
            "currency": "INR",
            "merchant_name": "Flipkart Electronics",
            "merchant": "Flipkart Electronics",
            "merchant_category": "5732",
            "network": "VISA",
            "reason_code": "10.4",
            "customer_name": "Rahul Sharma",
            "order_id": "FK-ORD-29482",
            "channel": "online",
            "source": "CHARGEBACK",
            "work_status": "UNDER_REVIEW",
            "dispute_stage": "REPRESENTMENT",
            "outcome": "PENDING",
            "sla_state": "AT_RISK",
            "assignment": "merchant_analyst",
        },
        created_at=_dt(days_ago=2),
        updated_at=_dt(hours_ago=1),
    ))

    # Evidence items
    e1_id, e1, p1 = make_evidence(DID, "AUTHENTICATION_SYSTEM", "3DS-VISA-Gateway", "AUTH-TXN-MER-001",
        "AUTHENTICATION_LOG", {
            "transaction_id": "TXN-MER-001-FLIP",
            "method": "3DS2",
            "result": "AUTHENTICATED",
            "eci": "05",
            "liability_shift": True,
            "device_id": "DEV-a8f3c1b-7e2d",
            "device_fingerprint": "9af3c1b7e2d4a5f8",
            "ip_address": "103.27.9.142",
            "ip_country": "IN",
            "ip_city": "Chennai",
            "risk_score": 18,
            "risk_level": "LOW",
            "cardholder_authenticated": True,
            "timestamp": _dt(days_ago=5).isoformat(),
            "acs_transaction_id": "ACS-88291-VISA",
        }, _dt(days_ago=5), "HIGH")

    e2_id, e2, p2 = make_evidence(DID, "PAYMENT_GATEWAY", "Razorpay-PG", "TXN-MER-001-RAZORPAY",
        "TRANSACTION_RECEIPT", {
            "transaction_id": "TXN-MER-001-FLIP",
            "amount": 48500,
            "currency": "INR",
            "auth_code": "AUTH-776321",
            "approval_code": "AP-2281",
            "channel": "CNP",
            "card_last_four": "4721",
            "avs_result": "Y",
            "cvv_result": "M",
            "posted_at": _dt(days_ago=5).isoformat(),
            "settlement_date": _dt(days_ago=4).isoformat(),
        }, _dt(days_ago=5), "HIGH")

    e3_id, e3, p3 = make_evidence(DID, "MERCHANT", "Flipkart-OMS", "FK-ORD-29482-DELIVERY",
        "DELIVERY_CONFIRMATION", {
            "order_id": "FK-ORD-29482",
            "items": [{"sku": "LAP-DELL-I5-13", "description": "Dell Inspiron 15 Laptop", "qty": 1, "price": 48500}],
            "tracking_number": "DELHIVERY-9283747291",
            "carrier": "Delhivery",
            "shipped_at": _dt(days_ago=4).isoformat(),
            "delivered_at": _dt(days_ago=3).isoformat(),
            "delivery_address": "42-A, OMR Road, Perungudi, Chennai, Tamil Nadu 600096",
            "recipient_name": "Rahul Sharma",
            "signature_obtained": True,
            "otp_verified": True,
            "delivery_photo": "proof-42-OMR-Road-Chennai.jpg",
        }, _dt(days_ago=3), "HIGH")

    e4_id, e4, p4 = make_evidence(DID, "MERCHANT", "Flipkart-OMS", "FK-ORD-29482-ORDER",
        "ORDER_RECORD", {
            "order_id": "FK-ORD-29482",
            "placed_at": _dt(days_ago=5).isoformat(),
            "customer_id": "CUST-FK-882911",
            "customer_email": "rahul.sharma@gmail.com",
            "shipping_address": "42-A, OMR Road, Perungudi, Chennai, Tamil Nadu 600096",
            "billing_address": "42-A, OMR Road, Perungudi, Chennai, Tamil Nadu 600096",
            "address_match": True,
            "device_used": "DEV-a8f3c1b-7e2d",
            "browser": "Chrome 127 / Windows 11",
            "items": [{"sku": "LAP-DELL-I5-13", "description": "Dell Inspiron 15 Laptop", "qty": 1}],
            "order_status": "DELIVERED",
        }, _dt(days_ago=5, hours_ago=0.1), "MEDIUM")

    e5_id, e5, p5 = make_evidence(DID, "MERCHANT", "Flipkart-CRM", "FK-SUPPORT-88291",
        "COMMUNICATION_LOG", {
            "ticket_id": "FK-SUPPORT-88291",
            "contact_date": _dt(days_ago=1).isoformat(),
            "channel": "CHAT",
            "customer_query": "I received the laptop but I don't want it anymore. Can I return it?",
            "resolution": "Return request initiated",
            "note": "Customer contacted support about return — not about non-delivery.",
        }, _dt(days_ago=1), "MEDIUM")

    for obj in [e1, p1, e2, p2, e3, p3, e4, p4, e5, p5]:
        db.add(obj)

    # Timeline
    for ev in [
        make_timeline(DID, "ORDER_PLACED", _dt(days_ago=5, hours_ago=0.1), "Customer",
                      "Order FK-ORD-29482 placed for Dell Inspiron 15 Laptop (₹48,500)"),
        make_timeline(DID, "PAYMENT_AUTHORISED", _dt(days_ago=5), "Payment Gateway",
                      "Transaction authorised via 3DS2. Device verified. Risk score: 18 (LOW)."),
        make_timeline(DID, "ORDER_CONFIRMED", _dt(days_ago=5), "Flipkart OMS",
                      "Order confirmed. Fulfillment initiated."),
        make_timeline(DID, "ITEM_SHIPPED", _dt(days_ago=4), "Delhivery",
                      "Shipped via Delhivery. Tracking: DELHIVERY-9283747291"),
        make_timeline(DID, "ITEM_DELIVERED", _dt(days_ago=3), "Delhivery",
                      "Delivered to 42-A OMR Road, Chennai. OTP verified. Signature obtained.", confidence=1.0),
        make_timeline(DID, "CUSTOMER_SUPPORT_CONTACT", _dt(days_ago=1), "Customer",
                      "Customer contacted support asking about laptop return — not claiming non-receipt.",
                      is_disputed=False),
        make_timeline(DID, "DISPUTE_FILED", NOW - timedelta(hours=6), "Card Network",
                      "Chargeback filed: Unauthorized Transaction (Reason 10.4)"),
    ]:
        db.add(ev)

    # Hypothesis
    hyp_id = _uuid()
    db.add(HypothesisModel(
        hypothesis_id=hyp_id,
        case_id=DID,
        description="Transaction was authorised by the legitimate cardholder. 3DS2 authentication succeeded with device match, low fraud risk, and delivery was confirmed with OTP and signature. Customer's claim of non-authorisation is inconsistent with post-delivery support contact requesting a return.",
        status="ACTIVE",
        supporting_evidence_ids=[e1_id, e2_id, e3_id, e4_id, e5_id],
        weakening_evidence_ids=[],
        neutral_evidence_ids=[],
        unresolved_questions=[],
        confidence_descriptor="HIGH",
        confidence_score=0.91,
        created_by="ai-agent",
        version=1,
        reasoning=(
            "Authentication: 3DS2 with ECI 05 shifts liability to issuer. Device ID matches customer's registered device. "
            "IP from Chennai matches delivery address. Risk score 18 is well within normal range. "
            "Delivery: OTP verification + signature + delivery photo constitute strong proof. "
            "Behaviour: Customer contacted support requesting RETURN (not non-receipt), strongly indicating actual possession."
        ),
        last_evaluated_at=NOW,
        created_at=_dt(hours_ago=2),
    ))

    # Recommendation
    db.add(RecommendationModel(
        recommendation_id=_uuid(),
        case_id=DID,
        version=1,
        content=(
            "Challenge this chargeback. The evidence strongly supports the merchant's position:\n\n"
            "1. Authentication: 3DS2 completed successfully (ECI 05), shifting liability to the issuer.\n"
            "2. Device verification: Transaction originated from the customer's registered device.\n"
            "3. Delivery: Confirmed delivered with OTP verification and signature. Delivery photo available.\n"
            "4. Behaviour: Customer contacted support requesting a return, not reporting non-receipt — "
            "inconsistent with an unauthorised transaction claim.\n\n"
            "Recommend filing representment with authentication record, delivery confirmation, "
            "and the customer support log showing return request."
        ),
        recommendation_type="CHALLENGE",
        confidence_descriptor="HIGH",
        confidence_score=0.91,
        supporting_evidence_ids=[e1_id, e2_id, e3_id, e4_id, e5_id],
        active_hypotheses=[hyp_id],
        contradictions=[],
        evidence_gaps=[],
        uncertainty_statement="Confidence is high given 3DS2 liability shift and confirmed delivery with OTP.",
        requires_approval=False,
        model_version="claude-3-5-sonnet-20241022",
        is_current=True,
        is_stale=False,
        evidence_state_version=3,
        created_at=_dt(hours_ago=2),
    ))

    print("  Seeded DSP-MER-001: Unauthorized — Strong Challenge")


# ══════════════════════════════════════════════════════════════════════════════
# SCENARIO 2 — Refund Not Processed: Accept
# ══════════════════════════════════════════════════════════════════════════════

async def seed_scenario_2(db) -> None:
    DID = "dsp-mer-002-refund-accept"
    if await dispute_exists(db, DID):
        print(f"  Skipping DSP-MER-002 (already exists)")
        return

    deadline = NOW + timedelta(hours=18)
    db.add(DisputeModel(
        dispute_id=DID,
        tenant_id=TENANT_ID,
        status="UNDER_INVESTIGATION",
        dispute_type="REFUND_NOT_PROCESSED",
        lifecycle_stage="INVESTIGATION",
        priority="MEDIUM",
        current_state_version=2,
        deadline=deadline,
        transaction_reference="TXN-MER-002-MEES",
        cardholder_claim=(
            "I cancelled my order on 20 August and was told I would receive a refund within "
            "5-7 business days. It has been 11 days and I still haven't received any refund. "
            "I would like my money back."
        ),
        metadata_={
            "amount": 12800,
            "amount_disputed": 12800,
            "currency": "INR",
            "merchant_name": "Meesho Fashion",
            "merchant": "Meesho Fashion",
            "merchant_category": "5621",
            "network": "MASTERCARD",
            "reason_code": "4853",
            "customer_name": "Priya Nair",
            "order_id": "MEES-ORD-77291",
            "channel": "mobile_app",
            "source": "CHARGEBACK",
            "work_status": "UNDER_REVIEW",
            "dispute_stage": "FIRST_RESPONSE",
            "outcome": "PENDING",
            "sla_state": "ON_TRACK",
            "assignment": "merchant_analyst",
        },
        created_at=_dt(days_ago=1),
        updated_at=_dt(hours_ago=3),
    ))

    e1_id, e1, p1 = make_evidence(DID, "MERCHANT", "Meesho-OMS", "MEES-ORD-77291-CANCEL",
        "ORDER_RECORD", {
            "order_id": "MEES-ORD-77291",
            "placed_at": _dt(days_ago=12).isoformat(),
            "cancelled_at": _dt(days_ago=11).isoformat(),
            "cancellation_reason": "Customer requested cancellation before dispatch",
            "items": [{"sku": "DRESS-KURTI-L-RED", "description": "Ethnic Kurti Set (L)", "qty": 2, "price": 6400}],
            "fulfillment_status": "NOT_DISPATCHED",
            "cancellation_policy": "Full refund for cancellations before dispatch",
        }, _dt(days_ago=11), "HIGH")

    e2_id, e2, p2 = make_evidence(DID, "MERCHANT", "Meesho-Payments", "REFUND-77291-APPROVE",
        "REFUND_RECORD", {
            "refund_id": "REF-77291-001",
            "order_id": "MEES-ORD-77291",
            "amount": 12800,
            "currency": "INR",
            "approved_at": _dt(days_ago=11).isoformat(),
            "approved_by": "system_auto_refund",
            "reason": "Order cancelled before dispatch",
            "status": "APPROVED",
            "expected_credit_date": _dt(days_ago=4).isoformat(),
            "processing_system": "BatchRefundProcessor",
            "batch_id": "BATCH-2026-08-20-C",
            "batch_status": "FAILED",
            "failure_reason": "Batch processing error — refund not executed",
        }, _dt(days_ago=11), "HIGH")

    e3_id, e3, p3 = make_evidence(DID, "MERCHANT", "Meesho-CRM", "MEES-COMM-77291",
        "COMMUNICATION_LOG", {
            "communication_id": "MEES-COMM-77291",
            "channel": "SMS + EMAIL",
            "sent_at": _dt(days_ago=11).isoformat(),
            "content": "Your order MEES-ORD-77291 has been cancelled. Refund of ₹12,800 will be credited to your original payment method within 5-7 business days.",
            "customer_acknowledged": True,
        }, _dt(days_ago=11), "MEDIUM")

    e4_id, e4, p4 = make_evidence(DID, "PAYMENT_GATEWAY", "Paytm-PG", "TXN-MER-002-MEES-ORIG",
        "TRANSACTION_RECEIPT", {
            "transaction_id": "TXN-MER-002-MEES",
            "amount": 12800,
            "currency": "INR",
            "auth_code": "AUTH-559211",
            "posted_at": _dt(days_ago=12).isoformat(),
            "card_last_four": "8812",
            "refund_status": "NOT_INITIATED",
        }, _dt(days_ago=12), "HIGH")

    for obj in [e1, p1, e2, p2, e3, p3, e4, p4]:
        db.add(obj)

    for ev in [
        make_timeline(DID, "ORDER_PLACED", _dt(days_ago=12), "Customer",
                      "Order MEES-ORD-77291 placed. 2x Ethnic Kurti Set (₹12,800)"),
        make_timeline(DID, "ORDER_CANCELLED", _dt(days_ago=11), "Customer",
                      "Customer cancelled order before dispatch. Refund automatically approved."),
        make_timeline(DID, "REFUND_APPROVED", _dt(days_ago=11), "Meesho System",
                      "Refund of ₹12,800 approved. Expected in 5-7 business days."),
        make_timeline(DID, "REFUND_FAILED", _dt(days_ago=4), "Meesho Batch Processor",
                      "Batch refund job BATCH-2026-08-20-C failed. Refund NOT executed.",
                      is_disputed=False),
        make_timeline(DID, "CUSTOMER_SUPPORT_CONTACT", _dt(days_ago=2), "Customer",
                      "Customer followed up requesting refund status."),
        make_timeline(DID, "DISPUTE_FILED", _dt(days_ago=1), "Card Network",
                      "Chargeback filed: Credit Not Processed (Reason 4853)"),
    ]:
        db.add(ev)

    hyp_id = _uuid()
    db.add(HypothesisModel(
        hypothesis_id=hyp_id,
        case_id=DID,
        description="Customer's claim is valid. The refund was approved by Meesho's system but a batch processing failure prevented it from being executed. The customer cancelled before dispatch, is entitled to a full refund per policy, and has been waiting 11 days beyond the promised timeline.",
        status="ACTIVE",
        supporting_evidence_ids=[e1_id, e2_id, e3_id],
        weakening_evidence_ids=[],
        neutral_evidence_ids=[e4_id],
        unresolved_questions=[],
        confidence_descriptor="HIGH",
        confidence_score=0.97,
        created_by="ai-agent",
        version=1,
        reasoning=(
            "The refund obligation is clear: customer cancelled before dispatch (per policy = full refund). "
            "Internal records confirm refund was approved (REF-77291-001) but batch job failed. "
            "Customer was promised ₹12,800 within 5-7 days. 11 days have elapsed. "
            "There is no legitimate basis to contest this chargeback."
        ),
        last_evaluated_at=NOW,
        created_at=_dt(hours_ago=5),
    ))

    db.add(RecommendationModel(
        recommendation_id=_uuid(),
        case_id=DID,
        version=1,
        content=(
            "Accept this chargeback immediately.\n\n"
            "The customer's claim is fully valid:\n"
            "1. Cancellation was before dispatch — full refund is owed per policy.\n"
            "2. Refund was approved internally (REF-77291-001) but never executed due to a batch processing failure.\n"
            "3. Customer was promised a refund within 5-7 days — 11 days have passed.\n\n"
            "Contesting this chargeback would be both incorrect and damaging to merchant reputation. "
            "Accept the chargeback and fix the batch processing issue to prevent recurrence."
        ),
        recommendation_type="ACCEPT",
        confidence_descriptor="HIGH",
        confidence_score=0.97,
        supporting_evidence_ids=[e1_id, e2_id, e3_id],
        active_hypotheses=[hyp_id],
        uncertainty_statement="No material uncertainty — the refund obligation is clear and the processing failure is documented.",
        requires_approval=False,
        model_version="claude-3-5-sonnet-20241022",
        is_current=True,
        is_stale=False,
        evidence_state_version=2,
        created_at=_dt(hours_ago=5),
    ))

    print("  Seeded DSP-MER-002: Refund Not Processed — Accept")


# ══════════════════════════════════════════════════════════════════════════════
# SCENARIO 3 — Merchandise Not Received: Evidence Gap
# ══════════════════════════════════════════════════════════════════════════════

async def seed_scenario_3(db) -> None:
    DID = "dsp-mer-003-mnr-gap"
    if await dispute_exists(db, DID):
        print(f"  Skipping DSP-MER-003 (already exists)")
        return

    deadline = NOW + timedelta(hours=26)
    db.add(DisputeModel(
        dispute_id=DID,
        tenant_id=TENANT_ID,
        status="OPEN",
        dispute_type="MERCHANDISE_NOT_RECEIVED",
        lifecycle_stage="INVESTIGATION",
        priority="MEDIUM",
        current_state_version=1,
        deadline=deadline,
        transaction_reference="TXN-MER-003-AMZ",
        cardholder_claim=(
            "I ordered a product from Amazon India 10 days ago. The tracking page shows "
            "'Out for Delivery' for the last 5 days and nothing has arrived. "
            "I have not received my order."
        ),
        metadata_={
            "amount": 8500,
            "amount_disputed": 8500,
            "currency": "INR",
            "merchant_name": "Amazon India",
            "merchant": "Amazon India",
            "merchant_category": "5999",
            "network": "VISA",
            "reason_code": "13.1",
            "customer_name": "Kiran Patel",
            "order_id": "AMZ-ORD-D09-1827",
            "channel": "online",
            "source": "CHARGEBACK",
            "work_status": "EVIDENCE_NEEDED",
            "dispute_stage": "FIRST_RESPONSE",
            "outcome": "PENDING",
            "sla_state": "ON_TRACK",
            "assignment": "merchant_analyst",
        },
        created_at=_dt(days_ago=0, hours_ago=12),
        updated_at=_dt(hours_ago=4),
    ))

    e1_id, e1, p1 = make_evidence(DID, "MERCHANT", "Amazon-OMS", "AMZ-ORD-D09-1827",
        "ORDER_RECORD", {
            "order_id": "AMZ-ORD-D09-1827",
            "placed_at": _dt(days_ago=10).isoformat(),
            "items": [{"asin": "B09X8P8NK1", "description": "boAt Airdopes 141 Bluetooth Earbuds", "qty": 1, "price": 8500}],
            "order_status": "SHIPPED",
            "shipping_address": "Plot 7, Satellite Road, Ahmedabad, Gujarat 380015",
        }, _dt(days_ago=10), "HIGH")

    e2_id, e2, p2 = make_evidence(DID, "MERCHANT", "Amazon-Logistics", "AMZ-SHIP-9283",
        "SHIPPING_RECORD", {
            "shipment_id": "AMZ-SHIP-9283",
            "order_id": "AMZ-ORD-D09-1827",
            "carrier": "Amazon Logistics",
            "tracking_number": "AMZL-IND-9283747",
            "shipped_at": _dt(days_ago=8).isoformat(),
            "expected_delivery": _dt(days_ago=5).isoformat(),
            "last_tracking_event": "OUT_FOR_DELIVERY",
            "last_tracking_update": _dt(days_ago=5).isoformat(),
            "delivery_status": "UNKNOWN",
            "note": "Tracking stalled. Last event 5 days ago: Out for Delivery. No delivery scan received.",
        }, _dt(days_ago=8), "HIGH")

    e3_id, e3, p3 = make_evidence(DID, "PAYMENT_GATEWAY", "Amazon-Pay", "TXN-MER-003-AMZ-ORIG",
        "TRANSACTION_RECEIPT", {
            "transaction_id": "TXN-MER-003-AMZ",
            "amount": 8500,
            "currency": "INR",
            "auth_code": "AUTH-442981",
            "posted_at": _dt(days_ago=10).isoformat(),
            "card_last_four": "2291",
        }, _dt(days_ago=10), "MEDIUM")

    for obj in [e1, p1, e2, p2, e3, p3]:
        db.add(obj)

    for ev in [
        make_timeline(DID, "ORDER_PLACED", _dt(days_ago=10), "Customer",
                      "Order AMZ-ORD-D09-1827 placed. boAt Airdopes 141 (₹8,500)"),
        make_timeline(DID, "ITEM_SHIPPED", _dt(days_ago=8), "Amazon Logistics",
                      "Shipped via Amazon Logistics. Tracking: AMZL-IND-9283747"),
        make_timeline(DID, "TRACKING_STALLED", _dt(days_ago=5), "Amazon Logistics",
                      "Last tracking event: Out for Delivery. No further updates received.",
                      is_disputed=False, confidence=0.9),
        make_timeline(DID, "CUSTOMER_SUPPORT_CONTACT", _dt(days_ago=2), "Customer",
                      "Customer contacted support. Tracking showed Out for Delivery for 3 days."),
        make_timeline(DID, "DISPUTE_FILED", _dt(hours_ago=12), "Card Network",
                      "Chargeback filed: Merchandise Not Received (Reason 13.1)"),
    ]:
        db.add(ev)

    hyp_id = _uuid()
    db.add(HypothesisModel(
        hypothesis_id=hyp_id,
        case_id=DID,
        description="Delivery status is uncertain. Shipment was dispatched but tracking stalled 5 days ago at 'Out for Delivery'. No delivery confirmation, signature, or OTP record exists. Cannot confirm delivery or non-delivery without carrier investigation.",
        status="ACTIVE",
        supporting_evidence_ids=[e1_id, e2_id],
        weakening_evidence_ids=[],
        neutral_evidence_ids=[e3_id],
        unresolved_questions=[
            "Was the package actually delivered?",
            "Does the carrier have a delivery scan or proof of delivery?",
            "Was a delivery attempt made? Was a redelivery notice left?",
        ],
        confidence_descriptor="LOW",
        confidence_score=0.35,
        created_by="ai-agent",
        version=1,
        reasoning=(
            "Evidence is incomplete. Shipment was dispatched, tracking went to 'Out for Delivery' and stopped. "
            "No proof of delivery (signature, OTP, photo) exists in merchant systems. "
            "Cannot mount a defence without delivery confirmation."
        ),
        last_evaluated_at=NOW,
        created_at=_dt(hours_ago=4),
    ))

    gap_id = _uuid()
    db.add(EvidenceGapModel(
        gap_id=gap_id,
        case_id=DID,
        gap_type="MISSING_EVIDENCE",
        description="Delivery confirmation is missing. The carrier has no delivery scan, OTP, signature, or photo on record. This is critical — without proof of delivery, the merchant cannot challenge this dispute.",
        materiality="HIGH",
        expected_source="Amazon Logistics / Carrier API",
        expected_evidence_type="DELIVERY_CONFIRMATION",
        status="OPEN",
        created_at=_dt(hours_ago=4),
    ))

    db.add(RecommendationModel(
        recommendation_id=_uuid(),
        case_id=DID,
        version=1,
        content=(
            "Do not respond yet — obtain delivery evidence first.\n\n"
            "The shipment tracking stalled 5 days ago at 'Out for Delivery'. "
            "No delivery confirmation, OTP, signature, or delivery photo exists.\n\n"
            "Immediate actions required:\n"
            "1. Contact Amazon Logistics carrier operations for a delivery scan or proof of delivery.\n"
            "2. Request GPS/photo evidence from the delivery agent.\n"
            "3. If delivery cannot be confirmed, consider accepting the dispute to avoid escalation.\n\n"
            "Filing a representment without delivery evidence will almost certainly fail."
        ),
        recommendation_type="INSUFFICIENT_EVIDENCE",
        confidence_descriptor="HIGH",
        confidence_score=0.88,
        supporting_evidence_ids=[e1_id, e2_id],
        active_hypotheses=[hyp_id],
        evidence_gaps=[gap_id],
        uncertainty_statement="Cannot determine outcome until delivery status is confirmed.",
        requires_approval=False,
        model_version="claude-3-5-sonnet-20241022",
        is_current=True,
        is_stale=False,
        evidence_state_version=1,
        created_at=_dt(hours_ago=4),
    ))

    print("  Seeded DSP-MER-003: Merchandise Not Received — Evidence Gap")


# ══════════════════════════════════════════════════════════════════════════════
# SCENARIO 4 — Merchandise Not Received: Contradiction
# ══════════════════════════════════════════════════════════════════════════════

async def seed_scenario_4(db) -> None:
    DID = "dsp-mer-004-mnr-contradiction"
    if await dispute_exists(db, DID):
        print(f"  Skipping DSP-MER-004 (already exists)")
        return

    deadline = NOW + timedelta(hours=12)
    db.add(DisputeModel(
        dispute_id=DID,
        tenant_id=TENANT_ID,
        status="UNDER_INVESTIGATION",
        dispute_type="MERCHANDISE_NOT_RECEIVED",
        lifecycle_stage="INVESTIGATION",
        priority="HIGH",
        current_state_version=2,
        deadline=deadline,
        transaction_reference="TXN-MER-004-NYK",
        cardholder_claim=(
            "I have not received my order from Nykaa. The tracking says delivered but "
            "there was nothing at my door and my building security confirms no package arrived. "
            "I am disputing this charge."
        ),
        metadata_={
            "amount": 23999,
            "amount_disputed": 23999,
            "currency": "INR",
            "merchant_name": "Nykaa Beauty",
            "merchant": "Nykaa Beauty",
            "merchant_category": "5912",
            "network": "VISA",
            "reason_code": "13.1",
            "customer_name": "Ananya Singh",
            "order_id": "NYK-ORD-28812",
            "channel": "mobile_app",
            "source": "CHARGEBACK",
            "work_status": "UNDER_REVIEW",
            "dispute_stage": "REPRESENTMENT",
            "outcome": "PENDING",
            "sla_state": "AT_RISK",
            "assignment": "merchant_analyst",
        },
        created_at=_dt(days_ago=2),
        updated_at=_dt(hours_ago=2),
    ))

    e1_id, e1, p1 = make_evidence(DID, "MERCHANT", "Nykaa-OMS", "NYK-ORD-28812",
        "ORDER_RECORD", {
            "order_id": "NYK-ORD-28812",
            "placed_at": _dt(days_ago=7).isoformat(),
            "items": [{"sku": "NK-GIFT-SET-PREMIUM", "description": "Nykaa Premium Skincare Gift Set", "qty": 1, "price": 23999}],
            "order_status": "DELIVERED",
        }, _dt(days_ago=7), "MEDIUM")

    e2_id, e2, p2 = make_evidence(DID, "MERCHANT", "Bluedart-API", "BD-AWB-92817263",
        "DELIVERY_CONFIRMATION", {
            "awb_number": "BD-AWB-92817263",
            "carrier": "Bluedart",
            "order_id": "NYK-ORD-28812",
            "delivered_at": _dt(days_ago=4).isoformat(),
            "delivery_address": "Flat 404, Prestige Towers, Koramangala, Bengaluru 560034",
            "delivery_scan": "DELIVERED",
            "delivery_type": "CONTACTLESS",
            "signature_obtained": False,
            "pod_photo": None,
            "note": "Contactless delivery. Package left at door. No signature collected per merchant delivery policy.",
        }, _dt(days_ago=4), "HIGH")

    e3_id, e3, p3 = make_evidence(DID, "CARDHOLDER", "Dispute-System", "CLAIM-NYK-28812",
        "CARDHOLDER_STATEMENT", {
            "statement": "I was home on the delivery date. No package arrived. My building security log shows no delivery to my flat number. I checked with all floors and no one has my package.",
            "submitted_at": _dt(days_ago=2).isoformat(),
            "supporting_detail": "Building security log dated same day shows no external delivery.",
        }, _dt(days_ago=2), "HIGH", "UNVERIFIED")

    for obj in [e1, p1, e2, p2, e3, p3]:
        db.add(obj)

    for ev in [
        make_timeline(DID, "ORDER_PLACED", _dt(days_ago=7), "Customer",
                      "Order NYK-ORD-28812. Nykaa Premium Skincare Gift Set (₹23,999)"),
        make_timeline(DID, "ITEM_SHIPPED", _dt(days_ago=6), "Bluedart",
                      "Shipped via Bluedart. AWB: BD-AWB-92817263"),
        make_timeline(DID, "ITEM_DELIVERED", _dt(days_ago=4), "Bluedart",
                      "Carrier scan: Delivered. Contactless delivery, no signature.",
                      is_disputed=True, confidence=0.7),
        make_timeline(DID, "CUSTOMER_DISPUTE_CLAIM", _dt(days_ago=2), "Customer",
                      "Customer filed dispute: package not received. Claims building security log supports this."),
        make_timeline(DID, "DISPUTE_FILED", _dt(days_ago=2), "Card Network",
                      "Chargeback filed: Merchandise Not Received (Reason 13.1)"),
    ]:
        db.add(ev)

    hyp_id = _uuid()
    db.add(HypothesisModel(
        hypothesis_id=hyp_id,
        case_id=DID,
        description="Delivery status is actively disputed. Bluedart tracking confirms delivery but no signature or photo proof was collected (contactless policy). Customer claims non-receipt supported by building security log. The contradiction between carrier record and customer claim cannot be resolved without additional evidence.",
        status="ACTIVE",
        supporting_evidence_ids=[e1_id, e2_id],
        weakening_evidence_ids=[e3_id],
        neutral_evidence_ids=[],
        unresolved_questions=[
            "Was a delivery photo taken?",
            "Can Bluedart provide GPS coordinates of delivery?",
            "Can the building security log be obtained as evidence?",
            "Are there CCTV records at the delivery location?",
        ],
        confidence_descriptor="LOW",
        confidence_score=0.42,
        created_by="ai-agent",
        version=1,
        reasoning=(
            "Carrier scan exists (supports merchant) but is contactless with no signature or photo (weakens merchant). "
            "Customer has a credible counter-claim with reference to building security. "
            "This case is genuinely ambiguous and requires additional investigation before a response decision."
        ),
        last_evaluated_at=NOW,
        created_at=_dt(hours_ago=3),
    ))

    # Contradiction
    db.add(ContradictionModel(
        contradiction_id=_uuid(),
        case_id=DID,
        description=(
            "Merchant carrier system (Bluedart) shows 'DELIVERED' on "
            f"{_dt(days_ago=4).strftime('%d %b %Y')} at customer address. "
            "Customer states they were home and no package arrived; references building security log "
            "confirming no external delivery to their flat."
        ),
        evidence_a_id=e2_id,
        evidence_b_id=e3_id,
        conflict_type="DELIVERY_STATUS_CONFLICT",
        materiality="HIGH",
        status="OPEN",
        created_at=_dt(hours_ago=3),
    ))

    db.add(EvidenceGapModel(
        gap_id=_uuid(),
        case_id=DID,
        gap_type="MISSING_EVIDENCE",
        description="Delivery photo or GPS proof of delivery is missing. Contactless delivery was used without collecting any physical confirmation. This is the critical gap that prevents a strong representment.",
        materiality="HIGH",
        expected_source="Bluedart Carrier Operations",
        expected_evidence_type="DELIVERY_PHOTO_OR_GPS",
        status="OPEN",
        created_at=_dt(hours_ago=3),
    ))

    db.add(RecommendationModel(
        recommendation_id=_uuid(),
        case_id=DID,
        version=1,
        content=(
            "Investigate the delivery before deciding.\n\n"
            "There is a direct contradiction between carrier records and the customer's claim:\n"
            "- Carrier: Delivered (contactless, no signature)\n"
            "- Customer: Not received (references building security log)\n\n"
            "Immediate steps:\n"
            "1. Contact Bluedart operations for GPS delivery coordinates and any available photo.\n"
            "2. Request delivery agent statement.\n"
            "3. If Bluedart provides GPS/photo proof: Challenge the chargeback.\n"
            "4. If no additional proof available: Accept — contesting without delivery evidence will likely fail.\n\n"
            "SLA is at risk (12h remaining). Prioritise the carrier investigation immediately."
        ),
        recommendation_type="INVESTIGATE",
        confidence_descriptor="MEDIUM",
        confidence_score=0.55,
        supporting_evidence_ids=[e1_id, e2_id],
        active_hypotheses=[hyp_id],
        uncertainty_statement="Resolution depends on carrier's ability to provide delivery proof within the SLA window.",
        requires_approval=False,
        model_version="claude-3-5-sonnet-20241022",
        is_current=True,
        is_stale=False,
        evidence_state_version=2,
        created_at=_dt(hours_ago=3),
    ))

    print("  Seeded DSP-MER-004: Merchandise Not Received — Contradiction")


# ══════════════════════════════════════════════════════════════════════════════
# SCENARIO 5 — High Value Unauthorized: Recommendation Changed
# ══════════════════════════════════════════════════════════════════════════════

async def seed_scenario_5(db) -> None:
    DID = "dsp-mer-005-highval-changed"
    if await dispute_exists(db, DID):
        print(f"  Skipping DSP-MER-005 (already exists)")
        return

    deadline = NOW + timedelta(hours=48)
    db.add(DisputeModel(
        dispute_id=DID,
        tenant_id=TENANT_ID,
        status="UNDER_INVESTIGATION",
        dispute_type="UNAUTHORIZED_TRANSACTION",
        lifecycle_stage="INVESTIGATION",
        priority="HIGH",
        current_state_version=4,
        deadline=deadline,
        transaction_reference="TXN-MER-005-CROMA",
        cardholder_claim=(
            "A transaction of ₹1,89,500 was charged to my card without my authorisation. "
            "I have never purchased anything of this value from Croma and this is clearly fraud. "
            "I am demanding an immediate reversal."
        ),
        metadata_={
            "amount": 189500,
            "amount_disputed": 189500,
            "currency": "INR",
            "merchant_name": "Croma Electronics",
            "merchant": "Croma Electronics",
            "merchant_category": "5732",
            "network": "VISA",
            "reason_code": "10.4",
            "customer_name": "Vikram Mehta",
            "order_id": "CROMA-ORD-11829",
            "channel": "in_store",
            "source": "CHARGEBACK",
            "work_status": "UNDER_REVIEW",
            "dispute_stage": "REPRESENTMENT",
            "outcome": "PENDING",
            "sla_state": "ON_TRACK",
            "assignment": "merchant_analyst",
            "requires_manager_approval": True,
            "recommendation_changed": True,
            "recommendation_change_reason": "Full 3DS authentication record retrieved from payment gateway",
        },
        created_at=_dt(days_ago=3),
        updated_at=_dt(hours_ago=1),
    ))

    e1_id, e1, p1 = make_evidence(DID, "MERCHANT", "Croma-POS", "CROMA-POS-TXN-005",
        "TRANSACTION_RECEIPT", {
            "transaction_id": "TXN-MER-005-CROMA",
            "amount": 189500,
            "currency": "INR",
            "auth_code": "AUTH-991122",
            "terminal_id": "POS-CROMA-ANDHERI-007",
            "store_location": "Croma Store, Andheri West, Mumbai",
            "channel": "IN_STORE_EMI",
            "card_present": True,
            "chip_used": True,
            "pin_entered": True,
            "posted_at": _dt(days_ago=10).isoformat(),
            "items": [{"sku": "SONY-TV-65-OLED", "description": "Sony 65-inch OLED 4K TV", "qty": 1, "price": 189500}],
        }, _dt(days_ago=10), "HIGH")

    e2_id, e2, p2 = make_evidence(DID, "PAYMENT_GATEWAY", "HDFC-POS-Network", "AUTH-991122-HDFC",
        "AUTHENTICATION_LOG", {
            "transaction_id": "TXN-MER-005-CROMA",
            "auth_type": "CHIP_AND_PIN",
            "chip_verified": True,
            "pin_verified": True,
            "card_present": True,
            "fallback_used": False,
            "eci": "07",
            "risk_score": 12,
            "risk_level": "VERY_LOW",
            "timestamp": _dt(days_ago=10).isoformat(),
            "auth_result": "APPROVED",
            "notes": "In-store Chip & PIN transaction. Strong cardholder verification. Liability with cardholder.",
        }, _dt(days_ago=10), "HIGH")

    e3_id, e3, p3 = make_evidence(DID, "MERCHANT", "Croma-CRM", "CROMA-CUST-VIKRAM-HIST",
        "ORDER_RECORD", {
            "customer_id": "CUST-CROMA-881291",
            "customer_name": "Vikram Mehta",
            "previous_purchases": [
                {"date": _dt(days_ago=180).isoformat(), "amount": 45000, "item": "Samsung Refrigerator", "store": "Croma Andheri"},
                {"date": _dt(days_ago=90).isoformat(), "amount": 28000, "item": "LG Washing Machine", "store": "Croma Andheri"},
            ],
            "store_visits": 4,
            "loyalty_member": True,
            "loyalty_id": "CROMA-CLUB-882111",
        }, _dt(days_ago=10), "MEDIUM")

    for obj in [e1, p1, e2, p2, e3, p3]:
        db.add(obj)

    for ev in [
        make_timeline(DID, "IN_STORE_PURCHASE", _dt(days_ago=10), "Customer",
                      "In-store purchase at Croma Andheri. Sony 65\" OLED TV (₹1,89,500). Chip & PIN used."),
        make_timeline(DID, "PAYMENT_AUTHORISED", _dt(days_ago=10), "HDFC POS Network",
                      "Transaction authorised. Chip & PIN verified. Risk score: 12 (VERY LOW)."),
        make_timeline(DID, "DISPUTE_FILED", _dt(days_ago=3), "Card Network",
                      "Chargeback filed: Unauthorized Transaction (Reason 10.4)"),
        make_timeline(DID, "AI_INVESTIGATION", _dt(days_ago=3), "AI Agent",
                      "Initial assessment: Evidence was incomplete. Recommendation: Accept pending full auth record."),
        make_timeline(DID, "EVIDENCE_RETRIEVED", _dt(hours_ago=4), "System",
                      "Full Chip & PIN authentication record retrieved from HDFC POS network."),
        make_timeline(DID, "RECOMMENDATION_CHANGED", _dt(hours_ago=2), "AI Agent",
                      "NEW INFORMATION: Chip & PIN authentication confirmed. Recommendation changed from Accept to Challenge.",
                      is_disputed=False),
    ]:
        db.add(ev)

    # Version 1 recommendation (now stale)
    rec1_id = _uuid()
    db.add(RecommendationModel(
        recommendation_id=rec1_id,
        case_id=DID,
        version=1,
        content="Accept this chargeback pending retrieval of the complete authentication record. Current evidence does not conclusively prove cardholder was present.",
        recommendation_type="ACCEPT",
        confidence_descriptor="LOW",
        confidence_score=0.42,
        requires_approval=False,
        model_version="claude-3-5-sonnet-20241022",
        is_current=False,
        is_stale=True,
        stale_reason="Full Chip & PIN authentication record subsequently retrieved — materially changes the assessment.",
        evidence_state_version=2,
        created_at=_dt(days_ago=3),
    ))

    hyp_id = _uuid()
    db.add(HypothesisModel(
        hypothesis_id=hyp_id,
        case_id=DID,
        description="The transaction was made by the cardholder in person using their physical card with Chip & PIN verification. The Chip & PIN authentication record confirms cardholder presence. The customer is a loyalty member with prior purchase history at the same store. The unauthorized claim is inconsistent with in-store Chip & PIN.",
        status="ACTIVE",
        supporting_evidence_ids=[e1_id, e2_id, e3_id],
        weakening_evidence_ids=[],
        neutral_evidence_ids=[],
        unresolved_questions=[],
        confidence_descriptor="HIGH",
        confidence_score=0.89,
        created_by="ai-agent",
        version=2,
        reasoning=(
            "Chip & PIN is one of the strongest authentication methods. Cardholder physically presented card and entered PIN. "
            "Liability for Chip & PIN transactions rests with the cardholder (not the merchant). "
            "Customer's purchase history at same store and loyalty membership further supports legitimate transaction."
        ),
        last_evaluated_at=_dt(hours_ago=2),
        created_at=_dt(hours_ago=2),
    ))

    # Version 2 recommendation (current — changed)
    db.add(RecommendationModel(
        recommendation_id=_uuid(),
        case_id=DID,
        version=2,
        content=(
            "RECOMMENDATION UPDATED — Challenge this chargeback.\n\n"
            "New information retrieved: Full Chip & PIN authentication record from HDFC POS network.\n\n"
            "Why this changes the recommendation:\n"
            "Previous: Authentication record was incomplete — recommendation was Accept.\n"
            "Now: Chip & PIN authentication confirmed. Cardholder physically present. PIN entered.\n\n"
            "Key evidence:\n"
            "1. Chip & PIN: Cardholder physically present with card. PIN verified by HDFC.\n"
            "2. In-store transaction: Card present. No CNP risk.\n"
            "3. Customer history: Loyalty member, 4 prior Croma visits, previous high-value purchases.\n\n"
            "File representment with Chip & PIN authentication record. "
            "Manager approval required (amount > ₹1,00,000)."
        ),
        recommendation_type="CHALLENGE",
        confidence_descriptor="HIGH",
        confidence_score=0.89,
        supporting_evidence_ids=[e1_id, e2_id, e3_id],
        active_hypotheses=[hyp_id],
        change_reason="Full Chip & PIN authentication record retrieved — this is conclusive cardholder presence evidence.",
        previous_recommendation_id=rec1_id,
        uncertainty_statement="High confidence given Chip & PIN verification. Liability shift applies.",
        requires_approval=True,
        model_version="claude-3-5-sonnet-20241022",
        is_current=True,
        is_stale=False,
        evidence_state_version=4,
        created_at=_dt(hours_ago=2),
    ))

    print("  Seeded DSP-MER-005: High Value — Recommendation Changed (Accept -> Challenge)")


# ══════════════════════════════════════════════════════════════════════════════
# SCENARIO 6 — Pre-Dispute Alert: Resolve Before Chargeback
# ══════════════════════════════════════════════════════════════════════════════

async def seed_scenario_6(db) -> None:
    DID = "dsp-mer-006-predispute"
    if await dispute_exists(db, DID):
        print(f"  Skipping DSP-MER-006 (already exists)")
        return

    deadline = NOW + timedelta(hours=72)
    db.add(DisputeModel(
        dispute_id=DID,
        tenant_id=TENANT_ID,
        status="OPEN",
        dispute_type="REFUND_NOT_PROCESSED",
        lifecycle_stage="INTAKE",
        priority="LOW",
        current_state_version=1,
        deadline=deadline,
        transaction_reference="TXN-MER-006-SWG",
        cardholder_claim=(
            "I received completely wrong items in my grocery order from Swiggy Instamart. "
            "I ordered fruits and vegetables but received biscuits and chips. "
            "I would like a full refund or replacement."
        ),
        metadata_={
            "amount": 4200,
            "amount_disputed": 4200,
            "currency": "INR",
            "merchant_name": "Swiggy Instamart",
            "merchant": "Swiggy Instamart",
            "merchant_category": "5411",
            "network": "RUPAY",
            "reason_code": "PRE-DISPUTE",
            "customer_name": "Rina Kapoor",
            "order_id": "SWG-ORD-INS-88201",
            "channel": "mobile_app",
            "source": "CUSTOMER_COMPLAINT",
            "is_pre_dispute": True,
            "work_status": "ACTION_REQUIRED",
            "dispute_stage": "PRE_DISPUTE",
            "outcome": "PENDING",
            "sla_state": "ON_TRACK",
            "resolution_window_hours": 48,
        },
        created_at=_dt(hours_ago=6),
        updated_at=_dt(hours_ago=2),
    ))

    e1_id, e1, p1 = make_evidence(DID, "MERCHANT", "Swiggy-OMS", "SWG-ORD-INS-88201",
        "ORDER_RECORD", {
            "order_id": "SWG-ORD-INS-88201",
            "placed_at": _dt(hours_ago=8).isoformat(),
            "items_ordered": [
                {"item": "Bananas (1 dozen)", "qty": 1, "price": 80},
                {"item": "Tomatoes (1 kg)", "qty": 2, "price": 120},
                {"item": "Spinach (250g)", "qty": 1, "price": 60},
                {"item": "Apple Juice 1L", "qty": 2, "price": 340},
                {"item": "Milk 2L", "qty": 2, "price": 200},
            ],
            "items_delivered": [
                {"item": "Hide & Seek Biscuits 200g", "qty": 3, "price": 150},
                {"item": "Lay's Chips 120g", "qty": 4, "price": 140},
            ],
            "picker_id": "PICKER-SW-8821",
            "picker_error_confirmed": True,
            "error_type": "WRONG_ITEMS_PICKED",
        }, _dt(hours_ago=8), "HIGH")

    e2_id, e2, p2 = make_evidence(DID, "MERCHANT", "Swiggy-CRM", "SWG-COMP-88201",
        "COMMUNICATION_LOG", {
            "complaint_id": "SWG-COMP-88201",
            "channel": "IN_APP",
            "submitted_at": _dt(hours_ago=6).isoformat(),
            "complaint": "Received completely wrong items. Ordered fresh produce but got snacks.",
            "photos_attached": True,
            "resolution_offered": "Replacement or refund within 24h",
        }, _dt(hours_ago=6), "HIGH")

    for obj in [e1, p1, e2, p2]:
        db.add(obj)

    for ev in [
        make_timeline(DID, "ORDER_PLACED", _dt(hours_ago=8), "Customer",
                      "Grocery order placed (₹4,200). Fresh produce items selected."),
        make_timeline(DID, "ORDER_FULFILLED", _dt(hours_ago=7), "Swiggy Picker",
                      "WRONG ITEMS PICKED. Picker error confirmed in warehouse system.",
                      is_disputed=False),
        make_timeline(DID, "ORDER_DELIVERED", _dt(hours_ago=6), "Swiggy Delivery",
                      "Delivered wrong items: biscuits and chips instead of fresh produce."),
        make_timeline(DID, "CUSTOMER_COMPLAINT", _dt(hours_ago=6), "Customer",
                      "Customer raised in-app complaint with photos. Wrong items received."),
        make_timeline(DID, "PRE_DISPUTE_ALERT", _dt(hours_ago=2), "System",
                      "Pre-dispute alert generated. Customer complaint pattern suggests chargeback risk."),
    ]:
        db.add(ev)

    db.add(RecommendationModel(
        recommendation_id=_uuid(),
        case_id=DID,
        version=1,
        content=(
            "Resolve this complaint immediately — before it becomes a chargeback.\n\n"
            "The merchant is clearly at fault: picker error confirmed in the warehouse system. "
            "Customer ordered fresh produce and received snacks.\n\n"
            "Recommended action:\n"
            "1. Issue full refund of ₹4,200 within 2 hours.\n"
            "2. OR offer immediate replacement delivery.\n"
            "3. Send apology communication to customer.\n\n"
            "If resolved within 24h, the probability of a chargeback drops significantly. "
            "The ₹4,200 dispute cost plus ₹750 chargeback fee (₹4,950 total exposure) "
            "is easily avoided by immediate refund."
        ),
        recommendation_type="RESOLVE_PRE_DISPUTE",
        confidence_descriptor="HIGH",
        confidence_score=0.99,
        supporting_evidence_ids=[e1_id, e2_id],
        uncertainty_statement="The merchant error is clearly established. Resolution is straightforward.",
        requires_approval=False,
        model_version="claude-3-5-sonnet-20241022",
        is_current=True,
        is_stale=False,
        evidence_state_version=1,
        created_at=_dt(hours_ago=2),
    ))

    print("  Seeded DSP-MER-006: Pre-Dispute Alert — Resolve Before Chargeback")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

async def seed() -> None:
    print("Initialising database…")
    await init_db()

    async with AsyncSessionLocal() as db:
        # Ensure tenant exists
        existing_tenant = await db.get(TenantModel, TENANT_ID)
        if not existing_tenant:
            db.add(TenantModel(
                tenant_id=TENANT_ID,
                name="National Finals Demo Tenant",
                config={"network": "VISA"},
            ))
            await db.flush()
            print(f"  Created tenant: {TENANT_ID}")

        # Merchant personas
        print("\nCreating merchant users…")
        for username, password, roles in MERCHANT_PERSONAS:
            await ensure_user(db, username, password, roles)

        # 6 dispute scenarios
        print("\nSeeding merchant dispute scenarios…")
        await seed_scenario_1(db)
        await seed_scenario_2(db)
        await seed_scenario_3(db)
        await seed_scenario_4(db)
        await seed_scenario_5(db)
        await seed_scenario_6(db)

        await db.commit()

    print("\n" + "=" * 60)
    print("  Merchant Demo Seed Complete")
    print("=" * 60)
    print("\n  Merchant Login Credentials:")
    print("  -----------------------------")
    print("  Analyst:    merchant_analyst  / MerchantAnalyst@123!")
    print("\n  Dispute Scenarios:")
    print("  -----------------------------")
    print("  DSP-MER-001  Unauthorized — Strong Challenge (Rs.48,500)")
    print("  DSP-MER-002  Refund Not Processed — Accept (Rs.12,800)")
    print("  DSP-MER-003  Merchandise Not Received — Evidence Gap (Rs.8,500)")
    print("  DSP-MER-004  Merchandise Not Received — Contradiction (Rs.23,999)")
    print("  DSP-MER-005  Unauthorized — Rec Changed Accept->Challenge (Rs.1,89,500)")
    print("  DSP-MER-006  Pre-Dispute Alert — Resolve Before Chargeback (Rs.4,200)")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(seed())
