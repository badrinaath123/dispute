"""
One-off seed: attaches 4 synthetic evidence documents to the existing Myntra
"refund not processed" demo dispute (transaction_reference MYN-884210) so the
issuer-analyst Evidence section has real, openable files to demonstrate
against — per the documentId -> storage-file mapping described in README §24.

Does NOT create a new dispute, a new table, or a new database: it patches the
existing DisputeModel row's metadata (additive merge, same pattern as the
PATCH /disputes/{id} endpoint) and adds EvidenceModel rows with
source_type="DOCUMENT", exactly like any other evidence record already
supported by GET/POST /disputes/{id}/evidence.

Run once from the repo root: python scripts/seed_myntra_documents.py
"""
import asyncio
import hashlib
import os
import sys
import uuid
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./data/dispute_system.db")

from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from sqlalchemy import select

from packages.persistence.sqlite.database import AsyncSessionLocal
from packages.persistence.sqlite.models import DisputeModel, EvidenceModel, ProvenanceModel

REPO_ROOT = Path(__file__).resolve().parent.parent
STORAGE_ROOT = REPO_ROOT / "storage" / "disputes"
TENANT_ID = "tenant-demo-001"
NOW = datetime.utcnow()

styles = getSampleStyleSheet()
styles.add(ParagraphStyle("DocTitle", parent=styles["Title"], fontSize=16, spaceAfter=4))
styles.add(ParagraphStyle("DocSub", parent=styles["Normal"], fontSize=9, textColor=colors.grey, spaceAfter=14))
styles.add(ParagraphStyle("Body", parent=styles["Normal"], fontSize=10, leading=15, spaceAfter=8))
styles.add(ParagraphStyle("Note", parent=styles["Normal"], fontSize=8, textColor=colors.HexColor("#c50f1f"), spaceBefore=20))

EXTRA_METADATA = {
    "customer_id": "CUST-MYN-30112",
    "masked_card_number": "****1234",
    "authentication_status": "AUTHENTICATED",
    "transaction_id": "TXN-MYN-884210",
    "merchant_id": "MYNTRA-001",
    "merchant_category_code": "5691",
    "transaction_channel": "ECOMMERCE",
    "currency": "INR",
    "transaction_date": "2026-03-18",
    "posting_date": "2026-03-19",
    "return_date": "2026-03-25",
    "expected_refund_amount": "3299.00",
    "expected_refund_date": "2026-04-01",
    "merchant_contacted": True,
    "merchant_contact_date": "2026-03-28",
    "merchant_response": "Merchant stated that the refund was processed on their end, but no credit has been received on the cardholder's statement.",
    "refund_reference_number": "REF-MYN-928371",
}

DOCUMENTS = [
    {
        "document_id": "DOC-001",
        "document_type": "ORDER_INVOICE",
        "file_name": "order_invoice.pdf",
        "build": lambda: [
            Paragraph("MYNTRA — Order Invoice", styles["DocTitle"]),
            Paragraph("SAMPLE DOCUMENT — generated for demonstration purposes only", styles["DocSub"]),
            _kv_table([
                ("Order ID", "MYN-ORD-884210"), ("Order Date", "18 Mar 2026"),
                ("Customer", "Ravi Shankar"), ("Delivery Address", "MG Road, Bengaluru, KA 560001"),
                ("Item", "Cotton Casual Shirt — Size M"), ("Quantity", "1"),
                ("Item Price", "Rs 3,299.00"), ("Payment Method", "Card ****1234"),
                ("Order Total", "Rs 3,299.00"),
            ]),
            Paragraph("Thank you for shopping with Myntra. This invoice confirms the order details above.", styles["Body"]),
            Paragraph("Sample document — not a real Myntra invoice.", styles["Note"]),
        ],
    },
    {
        "document_id": "DOC-002",
        "document_type": "RETURN_CONFIRMATION",
        "file_name": "return_confirmation.pdf",
        "build": lambda: [
            Paragraph("MYNTRA — Return Confirmation", styles["DocTitle"]),
            Paragraph("SAMPLE DOCUMENT — generated for demonstration purposes only", styles["DocSub"]),
            _kv_table([
                ("Order ID", "MYN-ORD-884210"), ("Return Initiated", "25 Mar 2026"),
                ("Return Reason", "Size did not fit"), ("Pickup Status", "Picked up — 26 Mar 2026"),
                ("Item Received At Warehouse", "28 Mar 2026"), ("Item Condition", "Unused, tags attached — Passed QC"),
                ("Return Tracking ID", "MYN-RTN-559213"),
            ]),
            Paragraph("The returned item has been received and inspected. It has passed quality checks and is eligible for a full refund.", styles["Body"]),
            Paragraph("Sample document — not a real Myntra record.", styles["Note"]),
        ],
    },
    {
        "document_id": "DOC-003",
        "document_type": "REFUND_CONFIRMATION",
        "file_name": "refund_confirmation.pdf",
        "build": lambda: [
            Paragraph("MYNTRA — Refund Confirmation", styles["DocTitle"]),
            Paragraph("SAMPLE DOCUMENT — generated for demonstration purposes only", styles["DocSub"]),
            _kv_table([
                ("Order ID", "MYN-ORD-884210"), ("Refund Reference", "REF-928371"),
                ("Refund Amount", "Rs 3,299.00"), ("Refund Initiated", "29 Mar 2026"),
                ("Refund Method", "Original payment method — Card ****1234"),
                ("Merchant-Side Status", "PROCESSED"),
            ]),
            Paragraph("Our records show this refund was processed to the original payment method on 29 Mar 2026. "
                      "If the credit has not appeared on the cardholder's statement, this may indicate a delay or "
                      "failure on the issuing bank's side — the discrepancy this dispute is investigating.", styles["Body"]),
            Paragraph("Sample document — not a real Myntra record.", styles["Note"]),
        ],
    },
    {
        "document_id": "DOC-004",
        "document_type": "MERCHANT_COMMUNICATION",
        "file_name": "merchant_email.pdf",
        "build": lambda: [
            Paragraph("Email — Myntra Customer Support", styles["DocTitle"]),
            Paragraph("SAMPLE DOCUMENT — generated for demonstration purposes only", styles["DocSub"]),
            _kv_table([
                ("From", "support@myntra-support.example"), ("To", "ravi.shankar@example.com"),
                ("Date", "28 Mar 2026, 14:32"), ("Subject", "Re: Refund status for order MYN-ORD-884210"),
            ]),
            Spacer(1, 10),
            Paragraph(
                "Dear Ravi,<br/><br/>"
                "Thank you for reaching out about your refund. We've checked our records and can confirm the refund "
                "of Rs 3,299.00 for order MYN-ORD-884210 was processed on our end on 29 Mar 2026 "
                "(reference REF-928371).<br/><br/>"
                "Refunds to the original payment method can take 5-7 business days to reflect, depending on your "
                "card issuer. If it still hasn't appeared after that window, we'd recommend following up with your "
                "bank directly, as the funds have already left our system.<br/><br/>"
                "Regards,<br/>Myntra Customer Support",
                styles["Body"]),
            Paragraph("Sample document — not a real email.", styles["Note"]),
        ],
    },
]


def _kv_table(rows: list[tuple[str, str]]) -> Table:
    data = [[Paragraph(f"<b>{k}</b>", getSampleStyleSheet()["Normal"]), Paragraph(v, getSampleStyleSheet()["Normal"])] for k, v in rows]
    t = Table(data, colWidths=[2.0 * inch, 4.2 * inch])
    t.setStyle(TableStyle([
        ("LINEBELOW", (0, 0), (-1, -1), 0.4, colors.HexColor("#e8e8e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def _generate_pdf(path: Path, flowables: list) -> None:
    doc = SimpleDocTemplate(str(path), pagesize=LETTER,
                             topMargin=0.9 * inch, bottomMargin=0.9 * inch,
                             leftMargin=0.9 * inch, rightMargin=0.9 * inch)
    doc.build(flowables)


async def main() -> None:
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(DisputeModel).where(
                DisputeModel.transaction_reference == "MYN-884210",
                DisputeModel.tenant_id == TENANT_ID,
            )
        )
        dispute = result.scalar_one_or_none()
        if not dispute:
            print("Myntra demo dispute (MYN-884210) not found — nothing to seed.")
            return

        dispute_dir = STORAGE_ROOT / dispute.dispute_id
        dispute_dir.mkdir(parents=True, exist_ok=True)

        # Idempotent: clear any document-evidence rows from a previous run of
        # this script before re-inserting, so re-running never duplicates or
        # hits the (case_id, source_type, source_record_id, version) unique
        # constraint.
        existing = await session.execute(
            select(EvidenceModel).where(
                EvidenceModel.case_id == dispute.dispute_id,
                EvidenceModel.source_system == "DOCUMENT_STORAGE",
            )
        )
        for row in existing.scalars().all():
            prov = await session.execute(
                select(ProvenanceModel).where(ProvenanceModel.evidence_id == row.evidence_id)
            )
            for p in prov.scalars().all():
                await session.delete(p)
            await session.delete(row)
        await session.flush()

        # Reset to a clean OPEN state and merge in the extra case-detail fields
        # (additive — existing merchant_name/customer_name/amount_disputed kept).
        dispute.status = "OPEN"
        dispute.lifecycle_stage = "INTAKE"
        dispute.metadata_ = {**(dispute.metadata_ or {}), **EXTRA_METADATA}
        dispute.updated_at = NOW
        dispute.current_state_version = dispute.current_state_version + 1

        created = []
        for spec in DOCUMENTS:
            stored_name = f"{spec['document_id']}_{spec['file_name']}"
            file_path = dispute_dir / stored_name
            _generate_pdf(file_path, spec["build"]())
            content_hash = hashlib.sha256(file_path.read_bytes()).hexdigest()

            evidence_id = str(uuid.uuid4())
            session.add(EvidenceModel(
                evidence_id=evidence_id,
                case_id=dispute.dispute_id,
                tenant_id=TENANT_ID,
                source_type="DOCUMENT",
                source_system="DOCUMENT_STORAGE",
                source_record_id=spec["document_id"],
                evidence_type=spec["document_type"],
                version=1,
                normalized_content={
                    "documentId": spec["document_id"],
                    "documentType": spec["document_type"],
                    "fileName": spec["file_name"],
                },
                content_reference=f"{dispute.dispute_id}/{stored_name}",
                event_time=NOW,
                received_time=NOW,
                effective_time=NOW,
                content_hash=content_hash,
                materiality="MEDIUM",
                quality="VERIFIED",
                is_current=True,
                created_at=NOW,
            ))
            session.add(ProvenanceModel(
                provenance_id=str(uuid.uuid4()),
                evidence_id=evidence_id,
                source_type="DOCUMENT",
                source_system="DOCUMENT_STORAGE",
                source_record_id=spec["document_id"],
                retrieval_method="SEED_SCRIPT",
                retrieved_by="system",
                retrieved_at=NOW,
                verified=True,
                chain_of_custody=[{"actor": "seed_myntra_documents.py", "action": "SEEDED", "at": NOW.isoformat()}],
            ))
            created.append(stored_name)

        await session.commit()

        print(f"Dispute (caseId): {dispute.dispute_id}")
        print(f"Storage folder:   {dispute_dir}")
        print("Documents created:")
        for name in created:
            print(f"  - {name}")


if __name__ == "__main__":
    asyncio.run(main())
