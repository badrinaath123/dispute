"""Seed admin configuration: statuses, outcomes, roles.
Idempotent — skips if admin_status_config table already has rows.
Run: python scripts/seed_admin.py
"""
import asyncio
import sys
import os
import uuid
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import select
from packages.persistence.sqlite.database import init_db, AsyncSessionLocal
from packages.persistence.sqlite.models import (
    StatusConfigModel, OutcomeConfigModel, RoleConfigModel, EvidenceRequirementModel,
)


# ── Status data ───────────────────────────────────────────────────────────────

STATUS_DATA = [
    dict(code="NEW",                 display_name="New",                 color="info",    category="WORKFLOW", sort_order=10,  is_initial=True,  is_terminal=False,
         description="Case has been created and is awaiting processing"),
    dict(code="UNDER_REVIEW",        display_name="Under Review",        color="info",    category="WORKFLOW", sort_order=20,  is_initial=False, is_terminal=False,
         description="Case is being investigated/reviewed"),
    dict(code="DISPUTE_RAISED",      display_name="Dispute Raised",      color="warning", category="WORKFLOW", sort_order=30,  is_initial=False, is_terminal=False,
         description="Dispute has been formally initiated"),
    dict(code="CHARGEBACK",          display_name="Chargeback",          color="error",   category="WORKFLOW", sort_order=35,  is_initial=False, is_terminal=False,
         description="Issuer has formally charged the transaction back to the merchant; awaiting merchant response"),
    dict(code="EVIDENCE_COLLECTION", display_name="Evidence Collection", color="warning", category="WORKFLOW", sort_order=40,  is_initial=False, is_terminal=False,
         description="Required evidence is being gathered"),
    dict(code="EVIDENCE_READY",      display_name="Evidence Ready",      color="success", category="WORKFLOW", sort_order=50,  is_initial=False, is_terminal=False,
         description="Evidence package has been completed and validated"),
    dict(code="SUBMITTED",           display_name="Submitted",           color="info",    category="WORKFLOW", sort_order=60,  is_initial=False, is_terminal=False,
         description="Dispute/evidence has been submitted to the relevant party/network"),
    dict(code="REPRESENTMENT",       display_name="Representment",       color="warning", category="WORKFLOW", sort_order=70,  is_initial=False, is_terminal=False,
         description="Counter-response/representment is being handled"),
    dict(code="PRE_ARBITRATION",     display_name="Pre-Arbitration",     color="error",   category="WORKFLOW", sort_order=80,  is_initial=False, is_terminal=False,
         description="Case has escalated toward pre-arbitration"),
    dict(code="ARBITRATION",         display_name="Arbitration",         color="error",   category="WORKFLOW", sort_order=90,  is_initial=False, is_terminal=False,
         description="Case is in network arbitration"),
    dict(code="RESOLVED",            display_name="Resolved",            color="success", category="TERMINAL", sort_order=100, is_initial=False, is_terminal=True,
         description="Final resolution has been recorded"),
    dict(code="CANCELLED",           display_name="Cancelled",           color="neutral", category="TERMINAL", sort_order=110, is_initial=False, is_terminal=True,
         description="Case has been cancelled or withdrawn"),
    dict(code="EXPIRED",             display_name="Expired",             color="error",   category="TERMINAL", sort_order=120, is_initial=False, is_terminal=True,
         description="Case has reached a deadline without required action"),
]

# ── Outcome data ──────────────────────────────────────────────────────────────

OUTCOME_DATA = [
    dict(code="PENDING",            display_name="Pending",            color="neutral", sort_order=10,
         description="No final outcome yet"),
    dict(code="CUSTOMER_WON",       display_name="Customer Won",       color="success", sort_order=20,
         description="Customer/cardholder prevailed"),
    dict(code="MERCHANT_WON",       display_name="Merchant Won",       color="error",   sort_order=30,
         description="Merchant prevailed"),
    dict(code="ISSUER_WON",         display_name="Issuer Won",         color="info",    sort_order=40,
         description="Issuer prevailed"),
    dict(code="ACQUIRER_WON",       display_name="Acquirer Won",       color="info",    sort_order=50,
         description="Acquirer prevailed"),
    dict(code="PARTIALLY_RESOLVED", display_name="Partially Resolved", color="warning", sort_order=60,
         description="Liability/outcome was split"),
    dict(code="ACCEPTED",           display_name="Accepted",           color="success", sort_order=70,
         description="Opposing party accepted the dispute/liability"),
    dict(code="REJECTED",           display_name="Rejected",           color="error",   sort_order=80,
         description="Dispute/claim was rejected"),
    dict(code="WITHDRAWN",          display_name="Withdrawn",          color="neutral", sort_order=90,
         description="Dispute was withdrawn"),
]

# ── Evidence requirement data (packages/intelligence/scheme_rules.py's
#    dispute-type fallback checklist — now admin-editable, see README §26) ─────

EVIDENCE_REQUIREMENT_DATA = [
    # (dispute_type, evidence_type, description, is_required, sort_order)
    ("UNAUTHORIZED_TRANSACTION", "TRANSACTION_RECEIPT", "Transaction receipt showing channel and AVS/CVV match", True, 10),
    ("UNAUTHORIZED_TRANSACTION", "AUTHENTICATION_LOG", "Cardholder authentication result (3DS/chip & PIN) with liability-shift indicator", True, 20),
    ("DUPLICATE_TRANSACTION", "TRANSACTION_RECEIPT", "Transaction receipts for both the original and the duplicate charge", True, 10),
    ("MERCHANDISE_NOT_RECEIVED", "ORDER_INVOICE", "Order invoice / proof of purchase", True, 10),
    ("MERCHANDISE_NOT_RECEIVED", "SHIPPING_TRACKING", "Proof of shipment and delivery status via carrier tracking", True, 20),
    ("MERCHANDISE_NOT_AS_DESCRIBED", "ORDER_INVOICE", "Order invoice showing what was ordered/described", True, 10),
    ("MERCHANDISE_NOT_AS_DESCRIBED", "MERCHANT_COMMUNICATION", "Merchant's response to the complaint, and any description/photos of the item received", True, 20),
    ("REFUND_NOT_PROCESSED", "RETURN_CONFIRMATION", "Proof the merchant received the returned item", True, 10),
    ("REFUND_NOT_PROCESSED", "REFUND_CONFIRMATION", "Merchant's refund confirmation or statement of refund status", True, 20),
    ("REFUND_NOT_PROCESSED", "ORDER_INVOICE", "Original order invoice / transaction record", False, 30),
    ("SUBSCRIPTION_CANCELLATION", "CANCELLATION_CONFIRMATION", "Proof the cardholder submitted a cancellation request before the renewal date", True, 10),
    ("SUBSCRIPTION_CANCELLATION", "MERCHANT_COMMUNICATION", "Merchant communication acknowledging (or disputing) the cancellation", True, 20),
    ("SUBSCRIPTION_CANCELLATION", "SUBSCRIPTION_AGREEMENT", "The subscription agreement / merchant's cancellation & refund policy", False, 30),
    ("SUBSCRIPTION_CANCELLATION", "TRANSACTION_RECEIPT", "Transaction record for the disputed renewal charge", False, 40),
    ("CASH_WITHDRAWAL_DISPUTE", "TRANSACTION_RECEIPT", "ATM/transaction receipt for the disputed withdrawal", True, 10),
    ("CASH_WITHDRAWAL_DISPUTE", "AUTHENTICATION_LOG", "PIN/authentication verification log for the transaction", True, 20),
    ("PROCESSING_ERROR", "TRANSACTION_RECEIPT", "Transaction receipt showing the amount actually charged vs. the amount authorized", True, 10),
    ("PROCESSING_ERROR", "MERCHANT_COMMUNICATION", "Merchant communication acknowledging the processing error, if any", False, 20),
]

# ── Role data ─────────────────────────────────────────────────────────────────

ROLE_DATA = [
    dict(
        code="SYSTEM_ADMINISTRATOR",
        display_name="System Administrator",
        description="Full platform configuration, user management, and all operational access",
        permissions=[
            "dispute:read", "dispute:create", "dispute:update",
            "evidence:read", "evidence:ingest",
            "hypothesis:read", "contradiction:read",
            "recommendation:read", "recommendation:override",
            "action:propose", "action:read", "action:approve",
            "approval:read", "approval:create",
            "audit:read", "audit:replay",
            "agent:trigger", "agent:trace:read",
            "tenant:manage", "user:manage", "config:manage",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline", "hypotheses",
            "next-best-action", "approval-workspace", "agent-activity",
            "audit", "audit-replay",
            "admin-statuses", "admin-outcomes", "admin-roles",
        ],
    ),
    dict(
        code="DISPUTE_MANAGER",
        display_name="Dispute Manager",
        description="Oversee dispute operations, assign and reassign cases, manage queues",
        permissions=[
            "dispute:read", "dispute:create", "dispute:update",
            "evidence:read", "evidence:ingest",
            "hypothesis:read", "contradiction:read",
            "recommendation:read", "recommendation:override",
            "action:propose", "action:read", "action:approve",
            "approval:read", "approval:create",
            "audit:read", "audit:replay",
            "agent:trigger", "agent:trace:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline", "hypotheses",
            "next-best-action", "approval-workspace", "agent-activity",
            "audit", "audit-replay",
        ],
    ),
    dict(
        code="ISSUER_ANALYST",
        display_name="Issuer Analyst",
        description="Review and investigate disputes from the issuer side",
        permissions=[
            "dispute:read", "dispute:create",
            "evidence:read", "evidence:ingest",
            "hypothesis:read", "contradiction:read",
            "recommendation:read",
            "action:propose", "action:read",
            "approval:read",
            "audit:read",
            "agent:trigger", "agent:trace:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline", "hypotheses",
            "next-best-action", "agent-activity", "audit",
        ],
    ),
    dict(
        code="SENIOR_INVESTIGATOR",
        display_name="Senior Investigator",
        description="Deep investigation authority with liability decision capability",
        permissions=[
            "dispute:read", "dispute:create", "dispute:update",
            "evidence:read", "evidence:ingest",
            "hypothesis:read", "contradiction:read",
            "recommendation:read", "recommendation:override",
            "action:propose", "action:read", "action:approve",
            "approval:read", "approval:create",
            "audit:read", "audit:replay",
            "agent:trigger", "agent:trace:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline", "hypotheses",
            "next-best-action", "approval-workspace", "agent-activity",
            "audit", "audit-replay",
        ],
    ),
    dict(
        code="ISSUER_SUPERVISOR",
        display_name="Issuer Supervisor",
        description="Supervisor oversight with full approval and override authority",
        permissions=[
            "dispute:read", "dispute:create", "dispute:update",
            "evidence:read", "evidence:ingest",
            "hypothesis:read", "contradiction:read",
            "recommendation:read", "recommendation:override",
            "action:propose", "action:read", "action:approve",
            "approval:read", "approval:create",
            "audit:read", "audit:replay",
            "agent:trigger", "agent:trace:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline", "hypotheses",
            "next-best-action", "approval-workspace", "agent-activity",
            "audit", "audit-replay",
        ],
    ),
    dict(
        code="FRAUD_ANALYST",
        display_name="Fraud Analyst",
        description="Specialized fraud case investigation and pattern detection",
        permissions=[
            "dispute:read", "dispute:create",
            "evidence:read", "evidence:ingest",
            "hypothesis:read", "contradiction:read",
            "recommendation:read",
            "action:propose", "action:read",
            "approval:read",
            "audit:read",
            "agent:trigger", "agent:trace:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline", "hypotheses",
            "agent-activity", "audit",
        ],
    ),
    dict(
        code="MERCHANT_ANALYST",
        display_name="Merchant Analyst",
        description="Handle merchant-side dispute responses and representments",
        permissions=[
            "dispute:read",
            "evidence:read", "evidence:ingest",
            "audit:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer",
        ],
    ),
    dict(
        code="NETWORK_OPERATOR",
        display_name="Network Operator",
        description="Interface with card networks (Visa/MC/Amex) for arbitration and submission",
        permissions=[
            "dispute:read",
            "evidence:read", "evidence:ingest",
            "hypothesis:read",
            "audit:read",
            "agent:trace:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline",
            "hypotheses", "audit",
        ],
    ),
    dict(
        code="COMPLIANCE_AUDITOR",
        display_name="Compliance Auditor",
        description="Regulatory compliance oversight — full read access and audit trail review",
        permissions=[
            "dispute:read",
            "evidence:read",
            "hypothesis:read", "contradiction:read",
            "recommendation:read",
            "action:read",
            "approval:read",
            "audit:read", "audit:replay",
            "agent:trace:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline", "hypotheses",
            "recommendations", "approval-workspace", "agent-activity",
            "audit", "audit-replay",
        ],
    ),
    dict(
        code="QUALITY_ASSURANCE",
        display_name="Quality Assurance",
        description="Review case quality, validate decisions and SLA compliance",
        permissions=[
            "dispute:read",
            "evidence:read",
            "hypothesis:read", "contradiction:read",
            "recommendation:read",
            "action:read",
            "approval:read",
            "audit:read",
            "agent:trace:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline", "hypotheses",
            "audit",
        ],
    ),
    dict(
        code="READ_ONLY",
        display_name="Read-Only Viewer",
        description="View-only access across all case data — no write operations",
        permissions=[
            "dispute:read",
            "evidence:read",
            "hypothesis:read", "contradiction:read",
            "recommendation:read",
            "action:read",
            "approval:read",
            "audit:read",
            "agent:trace:read",
        ],
        allowed_screens=[
            "dispute-command-center", "evidence-explorer", "timeline", "hypotheses",
        ],
    ),
]


async def seed_admin():
    await init_db()
    async with AsyncSessionLocal() as db:
        # Check if already seeded
        existing = await db.execute(select(StatusConfigModel))
        if existing.scalars().first():
            print("Admin config already seeded — skipping.")
            return

        # Statuses
        for s in STATUS_DATA:
            db.add(StatusConfigModel(
                status_id=str(uuid.uuid4()),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                created_by="system",
                **s,
            ))
        print(f"  Seeded {len(STATUS_DATA)} statuses")

        # Outcomes
        for o in OUTCOME_DATA:
            db.add(OutcomeConfigModel(
                outcome_id=str(uuid.uuid4()),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                created_by="system",
                **o,
            ))
        print(f"  Seeded {len(OUTCOME_DATA)} outcomes")

        # Roles
        for r in ROLE_DATA:
            db.add(RoleConfigModel(
                role_id=str(uuid.uuid4()),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                created_by="system",
                **r,
            ))
        print(f"  Seeded {len(ROLE_DATA)} roles")

        # Evidence requirements
        for dispute_type, evidence_type, description, is_required, sort_order in EVIDENCE_REQUIREMENT_DATA:
            db.add(EvidenceRequirementModel(
                requirement_id=str(uuid.uuid4()),
                dispute_type=dispute_type,
                evidence_type=evidence_type,
                description=description,
                is_required=is_required,
                sort_order=sort_order,
                is_active=True,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                created_by="system",
            ))
        print(f"  Seeded {len(EVIDENCE_REQUIREMENT_DATA)} evidence requirements")

        await db.commit()

    print("\nAdmin seed complete.")


if __name__ == "__main__":
    asyncio.run(seed_admin())
