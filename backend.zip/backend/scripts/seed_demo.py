"""
Seed the demo scenario for the National Finals.
Creates dispute DEMO-001 with V1 evidence (merchant claims delivered).
Run BEFORE the presentation.
"""
import asyncio
import hashlib
import json
import os
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite:///./data/dispute_system.db")

from packages.persistence.sqlite.database import init_db, AsyncSessionLocal
from packages.persistence.sqlite.models import (
    TenantModel, UserModel, DisputeModel, EvidenceModel,
    ProvenanceModel, TimelineEventModel,
)
from packages.security.auth import hash_password


TENANT_ID = "tenant-demo-001"
DISPUTE_ID = "dispute-national-finals-001"
TXN_REF = "TXN-DEMO-001"

PERSONAS = [
    ("analyst",     "Analyst@123!",     ["issuer_analyst"]),
    ("admin",       "Admin@12345!",     ["admin"]),
]


def _hash(content: dict) -> str:
    return hashlib.sha256(json.dumps(content, sort_keys=True).encode()).hexdigest()


async def seed() -> None:
    print("Initialising database…")
    await init_db()

    async with AsyncSessionLocal() as db:
        # ── Tenant ─────────────────────────────────────────────────────────────
        existing_tenant = await db.get(TenantModel, TENANT_ID)
        if not existing_tenant:
            db.add(TenantModel(
                tenant_id=TENANT_ID,
                name="National Finals Demo Tenant",
                config={"network": "VISA"},
            ))

        # ── Users ──────────────────────────────────────────────────────────────
        now = datetime.utcnow()
        for username, password, roles in PERSONAS:
            existing = (await db.execute(
                __import__("sqlalchemy", fromlist=["select"]).select(UserModel)
                .where(UserModel.username == username)
            )).scalar_one_or_none()
            if not existing:
                db.add(UserModel(
                    user_id=str(uuid.uuid4()),
                    tenant_id=TENANT_ID,
                    username=username,
                    email=f"{username}@demo.local",
                    password_hash=hash_password(password),
                    roles=roles,
                    is_active=True,
                    created_at=now,
                ))
                print(f"  Created user: {username} ({roles[0]})")

        # ── Dispute ────────────────────────────────────────────────────────────
        existing_dispute = await db.get(DisputeModel, DISPUTE_ID)
        if not existing_dispute:
            deadline = now + timedelta(days=14)
            db.add(DisputeModel(
                dispute_id=DISPUTE_ID,
                tenant_id=TENANT_ID,
                status="UNDER_INVESTIGATION",
                dispute_type="MERCHANDISE_NOT_RECEIVED",
                lifecycle_stage="INVESTIGATION",
                priority="HIGH",
                current_state_version=1,
                deadline=deadline,
                transaction_reference=TXN_REF,
                cardholder_claim=(
                    "I never received the item I ordered. The merchant claims it was delivered "
                    "but I was home all day and found no package. My neighbour also saw nothing. "
                    "I am requesting a full chargeback."
                ),
                metadata_={
                    "amount": 1249.99,
                    "currency": "USD",
                    "merchant": "ElectroShop Direct",
                    "network": "VISA",
                    "reason_code": "13.1",
                },
                created_at=now,
                updated_at=now,
            ))
            print(f"  Created dispute: {DISPUTE_ID}")

        # ── Evidence V1 ────────────────────────────────────────────────────────
        ev_checks = [
            {
                "source_type": "ISSUER",
                "source_system": "CoreBanking",
                "source_record_id": f"TXN-{TXN_REF}-ISSUER",
                "evidence_type": "TRANSACTION_RECEIPT",
                "normalized_content": {
                    "transaction_id": TXN_REF,
                    "amount": 1249.99,
                    "currency": "USD",
                    "posted_at": "2026-08-14T19:45:00Z",
                    "auth_code": "AUTH-882211",
                    "channel": "CNP",
                    "merchant_category": "5732",
                },
                "event_time": datetime(2026, 8, 14, 19, 45, 0),
                "materiality": "HIGH",
            },
            {
                "source_type": "MERCHANT",
                "source_system": "ElectroShop-OMS",
                "source_record_id": f"ORD-9988-DELIVERY-V1",
                "evidence_type": "DELIVERY_CONFIRMATION",
                "normalized_content": {
                    "order_id": "ORD-9988",
                    "tracking_number": "1Z999AA10123456784",
                    "carrier": "UPS",
                    "delivered_at": "2026-08-15T14:22:00Z",
                    "delivery_address": "123 Cardholder Ave, Austin TX 78701",
                    "signature_obtained": True,
                    "evidence_version": 1,
                },
                "event_time": datetime(2026, 8, 15, 14, 22, 0),
                "materiality": "HIGH",
            },
            {
                "source_type": "AUTHENTICATION_SYSTEM",
                "source_system": "3DS-Gateway",
                "source_record_id": f"AUTH-{TXN_REF}",
                "evidence_type": "AUTHENTICATION_LOG",
                "normalized_content": {
                    "transaction_id": TXN_REF,
                    "method": "3DS2",
                    "result": "AUTHENTICATED",
                    "eci": "05",
                    "device_id": "DEV-9f3a21b",
                    "ip_address": "203.0.113.45",
                    "ip_country": "US",
                    "risk_score": 28,
                    "timestamp": "2026-08-14T19:44:55Z",
                },
                "event_time": datetime(2026, 8, 14, 19, 44, 55),
                "materiality": "MEDIUM",
            },
            {
                "source_type": "CARDHOLDER",
                "source_system": "CustomerCare",
                "source_record_id": "CLAIM-2026-08-28-001",
                "evidence_type": "CARDHOLDER_STATEMENT",
                "normalized_content": {
                    "statement": "I never received the package. I was home all day on Aug 15.",
                    "witness": "Neighbour at 125 Cardholder Ave",
                    "submitted_at": "2026-08-28T09:15:00Z",
                },
                "event_time": datetime(2026, 8, 28, 9, 15, 0),
                "materiality": "MEDIUM",
            },
        ]

        for ev_data in ev_checks:
            content = ev_data["normalized_content"]
            content_hash = _hash(content)
            from sqlalchemy import select as sa_select
            existing_ev = (await db.execute(
                sa_select(EvidenceModel).where(
                    EvidenceModel.case_id == DISPUTE_ID,
                    EvidenceModel.source_record_id == ev_data["source_record_id"],
                )
            )).scalar_one_or_none()
            if not existing_ev:
                ev_id = str(uuid.uuid4())
                db.add(EvidenceModel(
                    evidence_id=ev_id,
                    case_id=DISPUTE_ID,
                    tenant_id=TENANT_ID,
                    source_type=ev_data["source_type"],
                    source_system=ev_data["source_system"],
                    source_record_id=ev_data["source_record_id"],
                    evidence_type=ev_data["evidence_type"],
                    version=1,
                    normalized_content=content,
                    event_time=ev_data["event_time"],
                    received_time=now,
                    effective_time=now,
                    content_hash=content_hash,
                    materiality=ev_data["materiality"],
                    quality="VERIFIED",
                    is_current=True,
                    created_at=now,
                ))
                db.add(ProvenanceModel(
                    provenance_id=str(uuid.uuid4()),
                    evidence_id=ev_id,
                    source_type=ev_data["source_type"],
                    source_system=ev_data["source_system"],
                    source_record_id=ev_data["source_record_id"],
                    retrieval_method="SEED_SCRIPT",
                    retrieved_by="system",
                    retrieved_at=now,
                    verified=True,
                    chain_of_custody=[{"actor": "seed_demo.py", "action": "SEEDED", "at": now.isoformat()}],
                ))
                print(f"  Created evidence: {ev_data['evidence_type']} ({ev_data['source_type']})")

        await db.commit()

    print("\nDemo seed complete.")
    print(f"  Dispute ID: {DISPUTE_ID}")
    print(f"  Login: analyst / Analyst@123!")
    print(f"\nTo trigger the inject during demo:")
    print(f"  python scripts/inject_evidence.py")


if __name__ == "__main__":
    asyncio.run(seed())
