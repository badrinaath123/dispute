import os
import httpx
import tiktoken

from pdfminer.high_level import extract_text
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma


# ============================================================
# 1. TIKTOKEN OFFLINE CACHE
# ============================================================

TIKTOKEN_CACHE_DIR = "./token"
os.environ["TIKTOKEN_CACHE_DIR"] = TIKTOKEN_CACHE_DIR

# Test that the local tokenizer cache is working
encoding = tiktoken.get_encoding("cl100k_base")

print("Tiktoken loaded successfully.")


# ============================================================
# 2. TCS GENAI CONFIGURATION
# ============================================================
BASE_URL = "https://genailab.tcs.in"

API_KEY = "sk-KUIa3glQ4fXF4P6_YpV-lQ"


# ============================================================
# 3. HTTP CLIENT / SSL
# ============================================================

http_client = httpx.Client(
    verify=False
)


# ============================================================
# 4. LLM
# ============================================================

llm = ChatOpenAI(
    base_url=BASE_URL,
    model="azure/genailab-maas-gpt-4.1",
    api_key=API_KEY,
    http_client=http_client,
    temperature=0
)



# ============================================================
# 5. EMBEDDING MODEL
# ============================================================

embedding_model = OpenAIEmbeddings(
    base_url=BASE_URL,
    model="azure/genailab-maas-text-embedding-3-large",
    api_key=API_KEY,
    http_client=http_client
)


# ============================================================
# 6. CREATE VECTOR DATABASE FROM PDF
# ============================================================

def create_vector_db(pdf_path):

    print("Extracting PDF text...")

    raw_text = extract_text(pdf_path)

    if not raw_text.strip():
        raise ValueError("No readable text found in PDF.")

    print("Splitting document into chunks...")

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )

    chunks = text_splitter.split_text(raw_text)

    print(f"Number of chunks: {len(chunks)}")

    print("Creating embeddings...")

    vector_db = Chroma.from_texts(
        texts=chunks,
        embedding=embedding_model,
        persist_directory="./chroma_index"
    )

    print("Vector database created.")

    return vector_db


# ============================================================
# 7. RAG FUNCTION
# ============================================================

def ask_rag(vector_db, question):

    # --------------------------------------------------------
    # Retrieve relevant chunks
    # --------------------------------------------------------

    retriever = vector_db.as_retriever(
        search_type="similarity",
        search_kwargs={"k": 5}
    )

    documents = retriever.invoke(question)

    if not documents:
        return "No relevant information found."


    # --------------------------------------------------------
    # Prepare retrieved context
    # --------------------------------------------------------

    context = "\n\n".join(
        document.page_content
        for document in documents
    )


    # --------------------------------------------------------
    # RAG prompt
    # --------------------------------------------------------

    prompt = f"""
You are a helpful document question-answering assistant.

Answer the user's question using ONLY the context
retrieved from the document.

If the answer is not present in the context,
say that the information is not available in the document.

Context:
--------------------
{context}
--------------------

Question:
{question}

Answer:
"""


    # --------------------------------------------------------
    # Invoke LLM
    # --------------------------------------------------------

    response = llm.invoke(prompt)

    return response.content


# ============================================================
# 8. MAIN
# ============================================================

if __name__ == "__main__":

    pdf_path = "sample.pdf"

    # Create vector database
    vector_db = create_vector_db(pdf_path)

    # Ask question
    question = """
    Summarize the key topics discussed in this document.
    Include the important points and conclusion.
    """

    answer = ask_rag(
        vector_db,
        question
    )

    print("\n================================")
    print("RAG ANSWER")
    print("================================\n")

    print(answer)