from langchain_openai import ChatOpenAI # type: ignore
import httpx

client = httpx.Client(verify=False)


llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="genailab-maas-Opus-4.6",
    api_key="sk-Dummy", # Replace with your Litellm API key
    http_client=client
)

print(llm.invoke("Give me the meaning of life").content)
