# Backend Deployment Guide

## Overview

- **Runtime:** Python 3.11, FastAPI, Uvicorn
- **Port:** 8000 (internal only — not exposed to host)
- **Dependencies:** Defined in `pyproject.toml`
- **Data:** SQLite database + FAISS indices stored in `data/`, uploaded files in `storage/`

---

## Environment Configuration

The backend uses two env files layered on top of each other:

```
.env            ← base config (app settings, feature flags, DB path, etc.)
server.env      ← deployment overrides (LLM keys, model names, CORS, secrets)
```

`server.env` is loaded after `.env` so its values always win for duplicate keys.

### Step 1 — Create server.env

```bash
cp server.env.example server.env
```

Edit `server.env` and fill in these values for your server:

| Variable           | Description                                      |
|--------------------|--------------------------------------------------|
| `LITELLM_BASE_URL` | Your LiteLLM proxy URL                           |
| `LITELLM_API_KEY`  | API key for the proxy                            |
| `LLM_MODEL`        | Chat model name (e.g. `azure/gpt-4o`)            |
| `EMBED_MODEL`      | Embedding model name                             |
| `GEMINI_MODEL`     | Vision model (default `gemini-2.5-flash`)        |
| `CORS_ORIGINS`     | Frontend URL e.g. `http://192.168.1.10`          |
| `API_SECRET_KEY`   | Random 32+ char string — run `openssl rand -hex 32` |
| `JWT_SECRET_KEY`   | Another random 32+ char string                   |

> All other settings (agent limits, feature flags, DB path, etc.) are already
> configured in `.env` and do not need to change between deployments.

---

## Build the Image

Run from the **project root** (`dispute_system/`):

```bash
podman build -t dispute-backend:latest ./backend
```

---

## Create Volumes (first time only)

```bash
podman volume create dispute-data     # SQLite DB + FAISS indices
podman volume create dispute-storage  # Uploaded dispute documents
```

---

## Create Network (first time only)

```bash
podman network create dispute-net
```

---

## Run the Container

```bash
podman run -d \
  --name api \
  --network dispute-net \
  --env-file ./backend/.env \
  --env-file ./backend/server.env \
  -v dispute-data:/app/data:Z \
  -v dispute-storage:/app/storage:Z \
  dispute-backend:latest
```

> **Note on `:Z`** — Required on RHEL / Fedora / CentOS for SELinux volume relabelling.
> On Ubuntu or Debian, remove `:Z` if you get permission errors on the volume mount.

> **Container is named `api`** — the frontend nginx config proxies to `http://api:8000`.
> Do not change this name unless you also update `frontend/nginx.conf`.

---

## First-Time Database Setup

Run these once after the container starts for the first time:

```bash
podman exec api python scripts/seed_admin.py
podman exec api python scripts/seed_demo.py
podman exec api python scripts/seed_merchant.py
podman exec api python scripts/seed_evidence_requirements.py
```

---

## Health Check

```bash
curl http://localhost:8000/api/v1/health
# Expected: {"status": "ok", ...}
```

> Port 8000 is only accessible from within the `dispute-net` network.
> To test it from the host machine, add `-p 8000:8000` to the run command temporarily.

---

## Logs

```bash
podman logs api          # print all logs
podman logs -f api       # follow live logs
podman logs --tail 100 api
```

---

## Stop / Remove

```bash
podman stop api
podman rm api
```

---

## Rebuild and Redeploy (after code changes)

```bash
podman stop api && podman rm api
podman build -t dispute-backend:latest ./backend
podman run -d \
  --name api \
  --network dispute-net \
  --env-file ./backend/.env \
  --env-file ./backend/server.env \
  -v dispute-data:/app/data:Z \
  -v dispute-storage:/app/storage:Z \
  dispute-backend:latest
```

Data in volumes is preserved across rebuilds.

---

## Changing LLM Settings

Only edit `server.env`, then restart the container. No rebuild needed.

```bash
nano server.env          # update LITELLM_BASE_URL / LITELLM_API_KEY / LLM_MODEL
podman restart api
```

If you change `CORS_ORIGINS` in `server.env`, restart is enough — no rebuild.

---

## Optional — Mock Server

Use this if real external APIs (Merchant / Issuer / Carrier / Auth / Network) are
not yet available on the deployment server.

```bash
podman run -d \
  --name mock \
  --network dispute-net \
  --env-file ./backend/.env \
  dispute-backend:latest \
  uvicorn mock_server.main:app --host 0.0.0.0 --port 8100
```

Ensure these are set in `server.env` (or already in `.env`):

```
MERCHANT_API_URL=http://mock:8100/merchant
ISSUER_API_URL=http://mock:8100/issuer
CARRIER_API_URL=http://mock:8100/carrier
AUTH_API_URL=http://mock:8100/auth-system
NETWORK_API_URL=http://mock:8100/network
```

---

## Auto-Start on Reboot (systemd)

```bash
mkdir -p ~/.config/systemd/user
podman generate systemd --name api --files --new
mv container-api.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now container-api.service
loginctl enable-linger $USER
```
