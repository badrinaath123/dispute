import os
# Windows-specific: faiss-cpu and torch (a langchain-openai/tiktoken transitive dep)
# each bundle their own OpenMP runtime DLL (libomp140 vs libiomp5md); loading both in
# one process trips OpenMP error #15 ("Initializing libomp140.x86_64.dll, but found
# libiomp5md.dll already initialized") and aborts the process the first time FAISS
# actually runs a search. This is the standard, widely-used workaround for that known
# conflict — must be set before those libraries are imported anywhere.
os.environ.setdefault("KMP_DUPLICATE_LIB_OK", "TRUE")

from dotenv import load_dotenv
load_dotenv()  # must run before any module reads os.getenv()
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from packages.observability.logging import configure_logging, get_logger
from packages.persistence.sqlite.database import init_db
from apps.api.middleware import CorrelationMiddleware, SecurityHeadersMiddleware
from apps.api.routes.v1 import health, auth, disputes, evidence, actions, approvals, audit, agents, details, admin, claims, platform

configure_logging()
logger = get_logger("api.main")

CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("api_starting", version="1.0.0")
    await init_db()
    logger.info("database_initialized")
    from scripts.seed_admin import seed_admin
    await seed_admin()
    logger.info("admin_config_seeded")
    from packages.intelligence import faiss_index
    faiss_index.initialize_all()
    logger.info("vector_store_initialized", **faiss_index.collection_stats())
    yield
    logger.info("api_shutting_down")


app = FastAPI(
    title="Dispute Intelligence Platform",
    description="Evidence-centric, stateful, human-governed dispute resolution system",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

# ── Middleware (order matters: outermost added last) ──────────────────────────
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(CorrelationMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Correlation-ID"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
PREFIX = "/api/v1"
app.include_router(health.router, prefix=PREFIX, tags=["Health"])
app.include_router(auth.router, prefix=PREFIX, tags=["Auth"])
app.include_router(disputes.router, prefix=PREFIX, tags=["Disputes"])
app.include_router(claims.router, prefix=PREFIX, tags=["Claims"])
app.include_router(evidence.router, prefix=PREFIX, tags=["Evidence"])
app.include_router(actions.router, prefix=PREFIX, tags=["Actions"])
app.include_router(approvals.router, prefix=PREFIX, tags=["Approvals"])
app.include_router(audit.router, prefix=PREFIX, tags=["Audit"])
app.include_router(agents.router, prefix=PREFIX, tags=["Agents"])
app.include_router(details.router, prefix=PREFIX, tags=["Dispute Details"])
app.include_router(admin.router, prefix=PREFIX, tags=["Admin Configuration"])
app.include_router(platform.router, prefix=PREFIX, tags=["Platform Impact"])


# ── Global error handler ──────────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    import uuid
    correlation_id = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
    logger.error("unhandled_exception", error=str(exc), correlation_id=correlation_id)
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred.",
                "correlation_id": correlation_id,
            }
        },
    )
