import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.persistence.sqlite.database import get_session
from packages.persistence.sqlite.models import ActionModel, ApprovalModel, DisputeModel, AuditEventModel
from packages.security.auth import TokenData, get_current_user
from packages.security.rbac import Permissions, require_permission

router = APIRouter()


class ApproveActionRequest(BaseModel):
    decision: str   # APPROVED, REJECTED, DEFERRED
    reason: str


class ApprovalResponse(BaseModel):
    approval_id: str
    case_id: str
    action_id: Optional[str]
    approver_id: str
    approver_role: str
    decision: str
    reason: str
    timestamp: datetime
    state_version_reviewed: int
    status: str
    stale_reason: Optional[str]


@router.post("/disputes/{dispute_id}/actions/{action_id}/approve", response_model=ApprovalResponse)
async def approve_action(
    dispute_id: str,
    action_id: str,
    body: ApproveActionRequest,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.ACTION_APPROVE)),
):
    dispute_result = await db.execute(
        select(DisputeModel).where(
            DisputeModel.dispute_id == dispute_id,
            DisputeModel.tenant_id == current_user.tenant_id,
        )
    )
    dispute = dispute_result.scalar_one_or_none()
    if not dispute:
        raise HTTPException(status_code=404, detail="Dispute not found")

    action_result = await db.execute(
        select(ActionModel).where(
            ActionModel.action_id == action_id,
            ActionModel.case_id == dispute_id,
        )
    )
    action = action_result.scalar_one_or_none()
    if not action:
        raise HTTPException(status_code=404, detail="Action not found")

    if action.status not in ("PENDING_APPROVAL", "PROPOSED"):
        raise HTTPException(status_code=409, detail=f"Action status is {action.status}, cannot approve")

    # Maker-checker: a CLASS_C action cannot be approved by the same user who
    # requested it. Segregation of duties is not optional for consequential
    # actions (chargeback submission, credit issuance).
    if action.action_class == "CLASS_C" and action.requested_by == current_user.user_id:
        raise HTTPException(
            status_code=409,
            detail="Maker-checker violation: the requesting user cannot approve their own CLASS_C action.",
        )

    now = datetime.utcnow()
    approval = ApprovalModel(
        approval_id=str(uuid.uuid4()),
        case_id=dispute_id,
        action_id=action_id,
        approver_id=current_user.user_id,
        approver_role=current_user.roles[0] if current_user.roles else "unknown",
        decision=body.decision,
        reason=body.reason,
        timestamp=now,
        state_version_reviewed=dispute.current_state_version,
        evidence_version_reviewed={},
        status="ACTIVE",
    )
    db.add(approval)

    if body.decision == "APPROVED":
        action.status = "APPROVED"
        action.approved_at = now
    elif body.decision == "REJECTED":
        action.status = "CANCELLED"

    audit = AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=now,
        actor_id=current_user.user_id,
        actor_type="USER",
        tenant_id=current_user.tenant_id,
        case_id=dispute_id,
        event_type="ACTION_APPROVED" if body.decision == "APPROVED" else "ACTION_REJECTED",
        approval_id=approval.approval_id,
        metadata_={"decision": body.decision, "reason": body.reason},
    )
    db.add(audit)

    return ApprovalResponse(
        approval_id=approval.approval_id,
        case_id=approval.case_id,
        action_id=approval.action_id,
        approver_id=approval.approver_id,
        approver_role=approval.approver_role,
        decision=approval.decision,
        reason=approval.reason,
        timestamp=approval.timestamp,
        state_version_reviewed=approval.state_version_reviewed,
        status=approval.status,
        stale_reason=approval.stale_reason,
    )
