import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.persistence.sqlite.database import get_session
from packages.persistence.sqlite.models import ActionModel, DisputeModel, AuditEventModel
from packages.security.auth import TokenData, get_current_user
from packages.security.rbac import Permissions, require_permission

router = APIRouter()


class ProposeActionRequest(BaseModel):
    action_type: str
    action_class: str   # CLASS_A, CLASS_B, CLASS_C
    connector: Optional[str] = None
    input: dict = {}
    proposed_by: Optional[str] = None
    approval_requirement: Optional[str] = None


class ActionResponse(BaseModel):
    action_id: str
    case_id: str
    action_type: str
    action_class: str
    status: str
    requested_by: str
    proposed_by: Optional[str]
    approval_requirement: Optional[str]
    idempotency_key: str
    input: dict
    result: Optional[dict]
    error: Optional[str]
    retry_count: int
    created_at: datetime
    approved_at: Optional[datetime]
    completed_at: Optional[datetime]


@router.post("/disputes/{dispute_id}/actions", response_model=ActionResponse, status_code=201)
async def propose_action(
    dispute_id: str,
    body: ProposeActionRequest,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.ACTION_PROPOSE)),
):
    result = await db.execute(
        select(DisputeModel).where(
            DisputeModel.dispute_id == dispute_id,
            DisputeModel.tenant_id == current_user.tenant_id,
        )
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Dispute not found")

    idempotency_key = f"{current_user.tenant_id}:{dispute_id}:{body.action_type}:{uuid.uuid4().hex[:8]}"
    now = datetime.utcnow()
    action = ActionModel(
        action_id=str(uuid.uuid4()),
        case_id=dispute_id,
        tenant_id=current_user.tenant_id,
        action_type=body.action_type,
        action_class=body.action_class,
        requested_by=current_user.user_id,
        proposed_by=body.proposed_by or current_user.user_id,
        approval_requirement=body.approval_requirement,
        status="PROPOSED" if body.action_class == "CLASS_C" else "PENDING_APPROVAL",
        idempotency_key=idempotency_key,
        connector=body.connector,
        input=body.input,
        retry_count=0,
        created_at=now,
    )

    # CLASS_C requires approval
    if body.action_class == "CLASS_C":
        action.status = "PENDING_APPROVAL"

    db.add(action)

    audit = AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=now,
        actor_id=current_user.user_id,
        actor_type="USER",
        tenant_id=current_user.tenant_id,
        case_id=dispute_id,
        event_type="ACTION_PROPOSED",
        metadata_={"action_type": body.action_type, "action_class": body.action_class},
    )
    db.add(audit)

    return _to_response(action)


@router.get("/disputes/{dispute_id}/actions", response_model=List[ActionResponse])
async def list_actions(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.ACTION_READ)),
):
    result = await db.execute(
        select(ActionModel).where(
            ActionModel.case_id == dispute_id,
            ActionModel.tenant_id == current_user.tenant_id,
        ).order_by(ActionModel.created_at.desc())
    )
    return [_to_response(a) for a in result.scalars().all()]


def _to_response(a: ActionModel) -> ActionResponse:
    return ActionResponse(
        action_id=a.action_id,
        case_id=a.case_id,
        action_type=a.action_type,
        action_class=a.action_class,
        status=a.status,
        requested_by=a.requested_by,
        proposed_by=a.proposed_by,
        approval_requirement=a.approval_requirement,
        idempotency_key=a.idempotency_key,
        input=a.input or {},
        result=a.result,
        error=a.error,
        retry_count=a.retry_count,
        created_at=a.created_at,
        approved_at=a.approved_at,
        completed_at=a.completed_at,
    )
