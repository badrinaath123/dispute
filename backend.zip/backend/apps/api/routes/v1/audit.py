from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.persistence.sqlite.database import get_session
from packages.persistence.sqlite.models import AuditEventModel
from packages.security.auth import TokenData, get_current_user
from packages.security.rbac import Permissions, require_permission

router = APIRouter()


class AuditEventResponse(BaseModel):
    model_config = {"protected_namespaces": ()}  # model_version is a domain field, not pydantic internals

    audit_id: str
    timestamp: datetime
    actor_id: str
    actor_type: str
    event_type: str
    case_id: Optional[str]
    previous_state_version: Optional[int]
    new_state_version: Optional[int]
    evidence_refs: List[str]
    node_name: Optional[str]
    model_version: Optional[str]
    tool_used: Optional[str]
    decision: Optional[str]
    metadata: dict


@router.get("/disputes/{dispute_id}/audit", response_model=List[AuditEventResponse])
async def get_audit_trail(
    dispute_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.AUDIT_READ)),
):
    q = (
        select(AuditEventModel)
        .where(
            AuditEventModel.case_id == dispute_id,
            AuditEventModel.tenant_id == current_user.tenant_id,
        )
        .order_by(AuditEventModel.timestamp.asc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )
    result = await db.execute(q)
    events = result.scalars().all()
    return [_to_response(e) for e in events]


@router.get("/disputes/{dispute_id}/replay", response_model=List[AuditEventResponse])
async def replay_audit(
    dispute_id: str,
    at: Optional[datetime] = None,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.AUDIT_REPLAY)),
):
    q = select(AuditEventModel).where(
        AuditEventModel.case_id == dispute_id,
        AuditEventModel.tenant_id == current_user.tenant_id,
    )
    if at:
        q = q.where(AuditEventModel.timestamp <= at)
    q = q.order_by(AuditEventModel.timestamp.asc())
    result = await db.execute(q)
    return [_to_response(e) for e in result.scalars().all()]


def _to_response(e: AuditEventModel) -> AuditEventResponse:
    return AuditEventResponse(
        audit_id=e.audit_id,
        timestamp=e.timestamp,
        actor_id=e.actor_id,
        actor_type=e.actor_type,
        event_type=e.event_type,
        case_id=e.case_id,
        previous_state_version=e.previous_state_version,
        new_state_version=e.new_state_version,
        evidence_refs=e.evidence_refs or [],
        node_name=e.node_name,
        model_version=e.model_version,
        tool_used=e.tool_used,
        decision=e.decision,
        metadata=e.metadata_ or {},
    )
