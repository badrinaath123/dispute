"""
Platform-wide impact metrics — every number here is a live query against this
tenant's real data (audit_events, approvals, recommendations, evidence_gaps,
claims). Nothing is hardcoded or precomputed; nothing is fabricated for
demo purposes. Section 19 of README.md documents exactly what each field
measures and how — this endpoint is the verification surface for that
section, not the other way around.
"""
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from packages.intelligence import eval_service
from packages.persistence.sqlite.database import get_session
from packages.persistence.sqlite.models import (
    DisputeModel, ApprovalModel, RecommendationModel, EvidenceGapModel,
    EvidenceModel, ClaimModel, AIEvalScoreModel, AICostLogModel,
)
from packages.security.auth import TokenData
from packages.security.rbac import Permissions, require_permission

router = APIRouter()

_RESOLVED_STATUSES = {"APPROVED", "REJECTED", "CLOSED"}


# ── DTOs ──────────────────────────────────────────────────────────────────────

class StaleApprovalEntry(BaseModel):
    dispute_id: str
    action_id: Optional[str]
    approval_id: str
    state_version_reviewed: int
    stale_reason: Optional[str]


class StaleApprovalsMetric(BaseModel):
    count: int
    entries: List[StaleApprovalEntry]
    note: Optional[str] = None


class RecommendationFlipEntry(BaseModel):
    dispute_id: str
    recommendation_id: str
    version: int
    recommendation_type: str
    previous_recommendation_id: Optional[str]
    change_reason: Optional[str]


class RecommendationFlipsMetric(BaseModel):
    count: int
    entries: List[RecommendationFlipEntry]
    note: Optional[str] = None


class MeanTimeToRecommendationMetric(BaseModel):
    sample_size: int
    mean_seconds: Optional[float]
    mean_human: Optional[str]
    note: str


class EvidenceGapsMetric(BaseModel):
    gaps_identified_total: int
    gaps_open: int
    evidence_items_total: int
    note: str


class ClaimEntry(BaseModel):
    claim_id: str
    sub_case_count: int
    dispute_ids: List[str]


class MultiTransactionClaimsMetric(BaseModel):
    claims_with_multiple_sub_cases: int
    total_sub_cases_across_them: int
    entries: List[ClaimEntry]
    note: Optional[str] = None


class IntakeTimeBucket(BaseModel):
    sample_size: int
    mean_seconds: Optional[float]
    mean_human: Optional[str]


class IntakeTimeComparisonMetric(BaseModel):
    ai_assisted: IntakeTimeBucket
    manual: IntakeTimeBucket
    sample_data_excluded_count: int
    note: str


class AIEvalMetricBucket(BaseModel):
    sample_size: int
    mean_score: Optional[float]
    pass_rate: Optional[float]


class AIQualityMetric(BaseModel):
    enabled: bool
    by_metric: dict[str, AIEvalMetricBucket]
    note: str


class AISpendByModel(BaseModel):
    model: str
    call_count: int
    input_tokens: int
    output_tokens: int
    cost_usd: float
    priced: bool


class AISpendMetric(BaseModel):
    total_cost_usd: float
    total_calls: int
    total_input_tokens: int
    total_output_tokens: int
    by_model: List[AISpendByModel]
    note: str


class PlatformImpactResponse(BaseModel):
    generated_at: datetime
    tenant_id: str
    stale_approvals_prevented: StaleApprovalsMetric
    recommendations_that_flipped: RecommendationFlipsMetric
    mean_time_to_recommendation: MeanTimeToRecommendationMetric
    evidence_gaps_auto_identified: EvidenceGapsMetric
    multi_transaction_claims_processed: MultiTransactionClaimsMetric
    case_intake_time: IntakeTimeComparisonMetric
    ai_quality: AIQualityMetric
    ai_spend: AISpendMetric


# ── Route ──────────────────────────────────────────────────────────────────────

@router.get("/platform/impact", response_model=PlatformImpactResponse)
async def get_platform_impact(
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    tenant_id = current_user.tenant_id

    # ── 1. Stale approvals prevented (Z2) ──────────────────────────────────
    # Every query below excludes archived cases (README §31) — a case an
    # analyst deleted from their queue shouldn't keep inflating platform-wide
    # metrics with data that's no longer part of anyone's active work.
    stale_result = await db.execute(
        select(ApprovalModel)
        .join(DisputeModel, ApprovalModel.case_id == DisputeModel.dispute_id)
        .where(DisputeModel.tenant_id == tenant_id, DisputeModel.is_archived.is_(False), ApprovalModel.status == "STALE")
        .order_by(ApprovalModel.timestamp.desc())
    )
    stale_approvals = stale_result.scalars().all()
    stale_metric = StaleApprovalsMetric(
        count=len(stale_approvals),
        entries=[
            StaleApprovalEntry(
                dispute_id=a.case_id,
                action_id=a.action_id,
                approval_id=a.approval_id,
                state_version_reviewed=a.state_version_reviewed,
                stale_reason=a.stale_reason,
            )
            for a in stale_approvals
        ],
        note=None if stale_approvals else (
            "No approval in this dataset has been invalidated yet. This happens when a "
            "CLASS_C action is approved and material (HIGH-materiality) evidence then "
            "arrives before execution — Z2 (dispute_state_service.apply_material_evidence_change) "
            "flips the approval and any already-approved CLASS_C action to STALE. "
            "Reproduce: approve a CLASS_C action, then POST HIGH-materiality evidence "
            "for the same dispute."
        ),
    )

    # ── 2. Recommendations that flipped ────────────────────────────────────
    flip_result = await db.execute(
        select(RecommendationModel)
        .join(DisputeModel, RecommendationModel.case_id == DisputeModel.dispute_id)
        .where(
            DisputeModel.tenant_id == tenant_id,
            DisputeModel.is_archived.is_(False),
            RecommendationModel.previous_recommendation_id.isnot(None),
        )
        .order_by(RecommendationModel.created_at.desc())
    )
    flips = flip_result.scalars().all()
    flips_metric = RecommendationFlipsMetric(
        count=len(flips),
        entries=[
            RecommendationFlipEntry(
                dispute_id=r.case_id,
                recommendation_id=r.recommendation_id,
                version=r.version,
                recommendation_type=r.recommendation_type,
                previous_recommendation_id=r.previous_recommendation_id,
                change_reason=r.change_reason,
            )
            for r in flips
        ],
        note=None if flips else (
            "No recommendation in this dataset has a previous_recommendation_id set yet — "
            "that field is only populated when late evidence supersedes an earlier "
            "recommendation (README §9 'Late Evidence Re-evaluation'). Reproduce: run the "
            "agent once, ingest HIGH-materiality evidence, run it again."
        ),
    )

    # ── 3. Mean time to first recommendation ───────────────────────────────
    first_rec_result = await db.execute(
        select(
            RecommendationModel.case_id,
            func.min(RecommendationModel.created_at).label("first_rec_at"),
        )
        .join(DisputeModel, RecommendationModel.case_id == DisputeModel.dispute_id)
        .where(DisputeModel.tenant_id == tenant_id, DisputeModel.is_archived.is_(False))
        .group_by(RecommendationModel.case_id)
    )
    first_rec_rows = first_rec_result.all()

    disputes_result = await db.execute(
        select(DisputeModel.dispute_id, DisputeModel.created_at)
        .where(DisputeModel.tenant_id == tenant_id, DisputeModel.is_archived.is_(False))
    )
    dispute_created_at = {d.dispute_id: d.created_at for d in disputes_result.all()}

    deltas = []
    for case_id, first_rec_at in first_rec_rows:
        created_at = dispute_created_at.get(case_id)
        if created_at and first_rec_at:
            deltas.append((first_rec_at - created_at).total_seconds())

    mean_seconds = sum(deltas) / len(deltas) if deltas else None
    mttr_metric = MeanTimeToRecommendationMetric(
        sample_size=len(deltas),
        mean_seconds=mean_seconds,
        mean_human=_human_duration(mean_seconds) if mean_seconds is not None else None,
        note=(
            f"Computed over every dispute in this tenant that has at least one "
            f"recommendation (n={len(deltas)}): mean(first RecommendationModel.created_at "
            f"- DisputeModel.created_at). For seeded demo scenarios this reflects "
            f"seed-time timestamps, not live agent latency; for disputes investigated via "
            f"a live agent run in this session, it reflects real elapsed wall-clock time."
        ),
    )

    # ── 4. Evidence gaps auto-identified ───────────────────────────────────
    gaps_result = await db.execute(
        select(EvidenceGapModel)
        .join(DisputeModel, EvidenceGapModel.case_id == DisputeModel.dispute_id)
        .where(DisputeModel.tenant_id == tenant_id, DisputeModel.is_archived.is_(False))
    )
    gaps = gaps_result.scalars().all()
    open_gaps = [g for g in gaps if g.status == "OPEN"]

    evidence_count_result = await db.execute(
        select(func.count(EvidenceModel.evidence_id))
        .join(DisputeModel, EvidenceModel.case_id == DisputeModel.dispute_id)
        .where(DisputeModel.tenant_id == tenant_id, DisputeModel.is_archived.is_(False))
    )
    evidence_total = evidence_count_result.scalar_one()

    gaps_metric = EvidenceGapsMetric(
        gaps_identified_total=len(gaps),
        gaps_open=len(open_gaps),
        evidence_items_total=evidence_total,
        note=(
            "Every EvidenceGapModel row in this architecture is created by the agent's "
            "identify_gaps node (packages/agent/nodes.py) or its scheme-rules safety net "
            "(packages/intelligence/scheme_rules.py) — there is no human-created-gap path "
            "in the current schema, so gaps_identified_total is, by construction, entirely "
            "system-identified. gaps_open is how many are still unresolved; "
            "evidence_items_total is shown for scale, not as a ratio claim."
        ),
    )

    # ── 5. Multi-transaction claims processed ──────────────────────────────
    claims_result = await db.execute(
        select(ClaimModel).where(ClaimModel.tenant_id == tenant_id)
    )
    claims = claims_result.scalars().all()

    claim_entries: List[ClaimEntry] = []
    for claim in claims:
        sub_result = await db.execute(
            select(DisputeModel.dispute_id)
            .where(DisputeModel.claim_id == claim.claim_id, DisputeModel.is_archived.is_(False))
            .order_by(DisputeModel.claim_sequence.asc())
        )
        dispute_ids = [row[0] for row in sub_result.all()]
        if len(dispute_ids) > 1:
            claim_entries.append(ClaimEntry(
                claim_id=claim.claim_id,
                sub_case_count=len(dispute_ids),
                dispute_ids=dispute_ids,
            ))

    claims_metric = MultiTransactionClaimsMetric(
        claims_with_multiple_sub_cases=len(claim_entries),
        total_sub_cases_across_them=sum(c.sub_case_count for c in claim_entries),
        entries=claim_entries,
        note=None if claim_entries else (
            "No claim in this dataset currently has more than one transaction sub-case. "
            "Reproduce: POST /claims with 2+ entries in `transactions` (README §8.11)."
        ),
    )

    # ── 6. Case intake time — AI-assisted vs. manual (§29) ─────────────────
    # creation_seconds/intake_method are written by NewDisputeModal.tsx itself
    # (a live stopwatch running from when the modal opens to submit) into the
    # new case's metadata at creation time — nothing here is derived or
    # estimated. Cases created before this feature existed, or via a seed
    # script, simply have no creation_seconds and are excluded from both
    # buckets — this metric only ever reflects cases actually measured live.
    all_meta_result = await db.execute(
        select(DisputeModel.metadata_).where(DisputeModel.tenant_id == tenant_id, DisputeModel.is_archived.is_(False))
    )
    ai_seconds: List[float] = []
    manual_seconds: List[float] = []
    sample_count = 0
    for (metadata,) in all_meta_result.all():
        m = metadata or {}
        seconds = m.get("creation_seconds")
        method = m.get("intake_method")
        if seconds is None or method is None:
            continue
        if method == "ai_assisted":
            ai_seconds.append(float(seconds))
        elif method == "manual":
            manual_seconds.append(float(seconds))
        elif method == "sample":
            sample_count += 1

    def _bucket(values: List[float]) -> IntakeTimeBucket:
        mean = sum(values) / len(values) if values else None
        return IntakeTimeBucket(
            sample_size=len(values),
            mean_seconds=mean,
            mean_human=_human_duration(mean) if mean is not None else None,
        )

    intake_metric = IntakeTimeComparisonMetric(
        ai_assisted=_bucket(ai_seconds),
        manual=_bucket(manual_seconds),
        sample_data_excluded_count=sample_count,
        note=(
            "Each value is a real elapsed-time measurement from a live stopwatch in New "
            "Case (modal open -> submit), not an estimate. ai_assisted = the analyst used "
            "document upload and/or the Analyze predictor for this case; manual = neither "
            "was used, every field was typed by hand. Cases created via \"Use Sample "
            "Data\" (no real extraction happened) are counted separately "
            "(sample_data_excluded_count) and never included in either bucket, since they "
            "represent neither condition honestly. Buckets with sample_size=0 haven't been "
            "demonstrated yet in this session."
        ),
    )

    # ── 7. AI quality — live DeepEval scores (§30) ─────────────────────────
    # Every row here was judged right after a real AI answer was returned to
    # an analyst (packages/intelligence/eval_service.py), not a synthetic
    # benchmark run. Empty when ENABLE_DEEPEVAL is off — no scores exist to
    # aggregate — or before any AI feature has actually been used yet.
    eval_rows_result = await db.execute(
        select(AIEvalScoreModel).where(AIEvalScoreModel.tenant_id == tenant_id)
    )
    eval_rows = eval_rows_result.scalars().all()
    by_metric: dict[str, list] = {}
    for row in eval_rows:
        by_metric.setdefault(row.metric, []).append(row)

    ai_quality_metric = AIQualityMetric(
        enabled=eval_service.ENABLED,
        by_metric={
            metric: AIEvalMetricBucket(
                sample_size=len(rows),
                mean_score=(
                    round(sum(r.score for r in rows if r.score is not None) / len([r for r in rows if r.score is not None]), 3)
                    if any(r.score is not None for r in rows) else None
                ),
                pass_rate=(
                    round(sum(1 for r in rows if r.passed) / len([r for r in rows if r.passed is not None]), 3)
                    if any(r.passed is not None for r in rows) else None
                ),
            )
            for metric, rows in by_metric.items()
        },
        note=(
            "Judged live by an LLM (through the same LiteLLM proxy every other AI feature here "
            "uses) immediately after each real answer, from a background task — never blocking "
            "the analyst waiting on the answer itself. Currently wired into \"Ask the Case\" "
            "only (Faithfulness, Answer Relevancy); other AI features are candidates for the "
            "same treatment (README §30)."
            if eval_service.ENABLED else
            "ENABLE_DEEPEVAL is off — no live scores are being collected. Set it to true in "
            ".env and restart to start scoring real AI answers."
        ),
    )

    # ── 8. AI spend — real token usage from every LLM/embedding call (§37) ──
    # No tenant_id on ai_cost_log (packages/intelligence/llm_client.py's functions
    # don't carry tenant context) — this is a platform-wide running total, not
    # scoped per-tenant like the other metrics above.
    cost_rows_result = await db.execute(select(AICostLogModel))
    cost_rows = cost_rows_result.scalars().all()
    by_model_rows: dict[str, list] = {}
    for row in cost_rows:
        by_model_rows.setdefault(row.model, []).append(row)

    ai_spend_metric = AISpendMetric(
        total_cost_usd=round(sum(r.cost_usd for r in cost_rows), 4),
        total_calls=len(cost_rows),
        total_input_tokens=sum(r.input_tokens for r in cost_rows),
        total_output_tokens=sum(r.output_tokens for r in cost_rows),
        by_model=[
            AISpendByModel(
                model=model,
                call_count=len(rows),
                input_tokens=sum(r.input_tokens for r in rows),
                output_tokens=sum(r.output_tokens for r in rows),
                cost_usd=round(sum(r.cost_usd for r in rows), 4),
                priced=rows[0].priced,
            )
            for model, rows in by_model_rows.items()
        ],
        note=(
            "Every call through this app's own LLM/embedding client is metered here from "
            "the provider's own reported token usage — not a fabricated estimate of a call "
            "count. Cost is computed against public list pricing (OpenAI/Google's own "
            "published per-token rates, checked live August 2026, README §37), since this "
            "app calls an internal LiteLLM gateway whose actual contracted rate isn't public "
            "— treat this as a good-faith estimate against list price, not the exact bill. "
            "Embedding token counts are approximated (~4 chars/token) since the embeddings "
            "client doesn't return exact usage the way chat completions do."
        ),
    )

    return PlatformImpactResponse(
        generated_at=datetime.utcnow(),
        tenant_id=tenant_id,
        stale_approvals_prevented=stale_metric,
        recommendations_that_flipped=flips_metric,
        mean_time_to_recommendation=mttr_metric,
        evidence_gaps_auto_identified=gaps_metric,
        multi_transaction_claims_processed=claims_metric,
        case_intake_time=intake_metric,
        ai_quality=ai_quality_metric,
        ai_spend=ai_spend_metric,
    )


class EvalScoreEntry(BaseModel):
    eval_id: str
    case_id: Optional[str]
    feature: str
    metric: str
    score: Optional[float]
    passed: Optional[bool]
    reason: Optional[str]
    input_text: Optional[str]
    created_at: datetime


@router.get("/platform/eval-scores", response_model=List[EvalScoreEntry])
async def list_eval_scores(
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    """
    Every individual live DeepEval score (README §30) — the ai_quality block
    on GET /platform/impact is the aggregate of exactly these rows, newest
    first, capped at 200 so this stays a live view, not an unbounded export.
    """
    result = await db.execute(
        select(AIEvalScoreModel)
        .where(AIEvalScoreModel.tenant_id == current_user.tenant_id)
        .order_by(AIEvalScoreModel.created_at.desc())
        .limit(200)
    )
    return result.scalars().all()


def _human_duration(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    minutes = seconds / 60
    if minutes < 60:
        return f"{minutes:.1f} min"
    hours = minutes / 60
    if hours < 48:
        return f"{hours:.1f} hr"
    return f"{hours / 24:.1f} days"
