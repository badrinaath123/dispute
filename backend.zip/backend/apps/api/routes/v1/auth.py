import asyncio
from datetime import timedelta
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.persistence.sqlite.database import get_session
from packages.persistence.sqlite.models import UserModel
from packages.security.auth import (
    JWT_EXPIRY_HOURS, Token, TokenData, create_access_token,
    get_current_user, verify_password,
)
from packages.security.rbac import ROLE_SCREENS, get_user_permissions

router = APIRouter()


class MeResponse(BaseModel):
    user_id: str
    username: str
    email: str
    tenant_id: str
    roles: List[str]
    permissions: List[str]
    screens: List[str]


@router.post("/auth/token", response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_session),
):
    result = await db.execute(
        select(UserModel).where(UserModel.username == form_data.username)
    )
    user = result.scalar_one_or_none()
    # bcrypt is CPU-bound — run in thread pool to avoid blocking the event loop
    password_ok = user is not None and await asyncio.to_thread(
        verify_password, form_data.password, user.password_hash
    )
    if not user or not password_ok:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is disabled")

    token_data = {
        "user_id": user.user_id,
        "tenant_id": user.tenant_id,
        "username": user.username,
        "email": user.email,
        "roles": user.roles,
    }
    access_token = create_access_token(token_data, timedelta(hours=JWT_EXPIRY_HOURS))
    return Token(
        access_token=access_token,
        expires_in=JWT_EXPIRY_HOURS * 3600,
        user=TokenData(**token_data),
    )


@router.get("/auth/me", response_model=MeResponse)
async def get_me(current_user: TokenData = Depends(get_current_user)):
    screens: List[str] = []
    for role in current_user.roles:
        screens.extend(ROLE_SCREENS.get(role, []))
    return MeResponse(
        user_id=current_user.user_id,
        username=current_user.username,
        email=current_user.email,
        tenant_id=current_user.tenant_id,
        roles=current_user.roles,
        permissions=get_user_permissions(current_user.roles),
        screens=list(set(screens)),
    )
