"""Admin configuration — statuses, outcomes, roles.
Reads are open to any authenticated user; writes require config:manage (admin role).
"""
import asyncio
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, HTTPException, UploadFile, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.persistence.sqlite.database import get_session
import os
from packages.intelligence import faiss_index, evidence_requirement_extraction
from packages.persistence.sqlite.models import (
    EvidenceRequirementModel, OutcomeConfigModel, RegulatoryDocumentModel,
    RoleConfigModel, StatusConfigModel, UserModel,
)
from packages.security.auth import TokenData, get_current_user
from packages.security.rbac import Permissions, require_permission, ROLE_SCREENS

router = APIRouter()

_REGULATORY_DOCS_DIR = Path("./data/regulatory_docs")
_VALID_NETWORKS = ("VISA", "MASTERCARD", "OTHER")
# INTERNAL_POLICY / REGULATORY cover documents that aren't a card-scheme rulebook at
# all — the internal SOP/policy handbook and the Reg Z reference guide (README §21.9).
_VALID_DOC_TYPES = ("RULES", "DISPUTE_GUIDE", "INTERNAL_POLICY", "REGULATORY", "OTHER")
_ALLOWED_EXTRACTION_MIME_TYPES = {"application/pdf", "image/png", "image/jpeg", "image/webp"}

# ── Pydantic schemas ──────────────────────────────────────────────────────────

class StatusConfigIn(BaseModel):
    code: str
    display_name: str
    description: str = ""
    category: str = "WORKFLOW"
    sort_order: int = 0
    is_active: bool = True
    color: str = "neutral"
    is_initial: bool = False
    is_terminal: bool = False


class StatusConfigOut(BaseModel):
    status_id: str
    code: str
    display_name: str
    description: str
    category: str
    sort_order: int
    is_active: bool
    color: str
    is_initial: bool
    is_terminal: bool
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str]

    class Config:
        from_attributes = True


class OutcomeConfigIn(BaseModel):
    code: str
    display_name: str
    description: str = ""
    sort_order: int = 0
    is_active: bool = True
    color: str = "neutral"


class OutcomeConfigOut(BaseModel):
    outcome_id: str
    code: str
    display_name: str
    description: str
    sort_order: int
    is_active: bool
    color: str
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str]

    class Config:
        from_attributes = True


class RoleConfigIn(BaseModel):
    code: str
    display_name: str
    description: str = ""
    is_active: bool = True
    permissions: List[str] = []
    allowed_screens: List[str] = []


class RoleConfigOut(BaseModel):
    role_id: str
    code: str
    display_name: str
    description: str
    is_active: bool
    permissions: List[str]
    allowed_screens: List[str]
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str]

    class Config:
        from_attributes = True


class EvidenceRequirementIn(BaseModel):
    dispute_type: str
    evidence_type: str
    description: str = ""
    is_required: bool = True
    sort_order: int = 0
    is_active: bool = True


class EvidenceRequirementOut(BaseModel):
    requirement_id: str
    dispute_type: str
    evidence_type: str
    description: str
    is_required: bool
    sort_order: int
    is_active: bool
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str]

    class Config:
        from_attributes = True


class ExtractedRequirement(BaseModel):
    evidence_type: str
    description: str
    is_required: bool


class EvidenceRequirementExtractionResponse(BaseModel):
    requirements: List[ExtractedRequirement]
    confidence: float
    notes: str


class RegulatoryDocumentOut(BaseModel):
    document_id: str
    filename: str
    uploaded_by: str
    uploaded_at: datetime
    status: str
    page_count: Optional[int]
    chunks_indexed: int
    error: Optional[str]
    network: str
    doc_type: str

    class Config:
        from_attributes = True


class RegulatoryDocumentTagsIn(BaseModel):
    network: str
    doc_type: str


class RegulatorySearchRequest(BaseModel):
    query: str
    top_k: int = 5
    network: Optional[str] = None


class RegulatorySearchHit(BaseModel):
    title: str
    text: str
    source: str
    page: Optional[int]
    similarity: float
    network: Optional[str] = None
    doc_type: Optional[str] = None


# ── STATUS CONFIG ─────────────────────────────────────────────────────────────

@router.get("/admin/statuses", response_model=List[StatusConfigOut])
async def list_statuses(
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    result = await db.execute(
        select(StatusConfigModel).order_by(StatusConfigModel.sort_order)
    )
    return result.scalars().all()


@router.get("/admin/statuses/{status_id}", response_model=StatusConfigOut)
async def get_status(
    status_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    row = await _get_status_or_404(db, status_id)
    return row


@router.post("/admin/statuses", response_model=StatusConfigOut, status_code=201)
async def create_status(
    body: StatusConfigIn,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    raise HTTPException(
        status.HTTP_400_BAD_REQUEST,
        "This list is fixed to the status codes the application's own logic actually "
        "recognizes (dispute creation, chargeback, merchant accept/challenge, SLA and "
        "priority scoring all key off these exact codes). A new code here would have no "
        "real behavior behind it, so adding one is disabled — display name, description, "
        "and color are still fully editable.",
    )


@router.put("/admin/statuses/{status_id}", response_model=StatusConfigOut)
async def update_status(
    status_id: str,
    body: StatusConfigIn,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    row = await _get_status_or_404(db, status_id)
    if body.code.upper() != row.code:
        await _assert_code_unique(db, StatusConfigModel, "code", body.code)
    row.code = body.code.upper()
    row.display_name = body.display_name
    row.description = body.description
    row.category = body.category
    row.sort_order = body.sort_order
    row.is_active = body.is_active
    row.color = body.color
    row.is_initial = body.is_initial
    row.is_terminal = body.is_terminal
    row.updated_at = datetime.utcnow()
    row.created_by = current_user.username
    await db.flush()
    return row


@router.delete("/admin/statuses/{status_id}", status_code=204)
async def deactivate_status(
    status_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    raise HTTPException(
        status.HTTP_400_BAD_REQUEST,
        "This status code is recognized by the application's own logic — deactivating it "
        "would leave real cases in a status the platform no longer displays correctly. "
        "Removal is disabled; edit its display name, description, or color instead.",
    )


# ── OUTCOME CONFIG ────────────────────────────────────────────────────────────

@router.get("/admin/outcomes", response_model=List[OutcomeConfigOut])
async def list_outcomes(
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    result = await db.execute(
        select(OutcomeConfigModel).order_by(OutcomeConfigModel.sort_order)
    )
    return result.scalars().all()


@router.get("/admin/outcomes/{outcome_id}", response_model=OutcomeConfigOut)
async def get_outcome(
    outcome_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    row = await _get_outcome_or_404(db, outcome_id)
    return row


@router.post("/admin/outcomes", response_model=OutcomeConfigOut, status_code=201)
async def create_outcome(
    body: OutcomeConfigIn,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    raise HTTPException(
        status.HTTP_400_BAD_REQUEST,
        "Outcomes aren't read by any code in this platform yet — DisputeModel has no "
        "outcome field, so this list is a reserved concept for a future case-resolution "
        "flow, not something a new code here could actually attach to. Adding one is "
        "disabled; display name, description, and color are still editable.",
    )


@router.put("/admin/outcomes/{outcome_id}", response_model=OutcomeConfigOut)
async def update_outcome(
    outcome_id: str,
    body: OutcomeConfigIn,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    row = await _get_outcome_or_404(db, outcome_id)
    if body.code.upper() != row.code:
        await _assert_code_unique(db, OutcomeConfigModel, "code", body.code)
    row.code = body.code.upper()
    row.display_name = body.display_name
    row.description = body.description
    row.sort_order = body.sort_order
    row.is_active = body.is_active
    row.color = body.color
    row.updated_at = datetime.utcnow()
    row.created_by = current_user.username
    await db.flush()
    return row


@router.delete("/admin/outcomes/{outcome_id}", status_code=204)
async def deactivate_outcome(
    outcome_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    raise HTTPException(
        status.HTTP_400_BAD_REQUEST,
        "Removal is disabled for this reserved list — edit its display name, "
        "description, or color instead.",
    )


# ── ROLE CONFIG ───────────────────────────────────────────────────────────────

@router.get("/admin/roles", response_model=List[RoleConfigOut])
async def list_roles(
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    result = await db.execute(
        select(RoleConfigModel).order_by(RoleConfigModel.display_name)
    )
    return result.scalars().all()


@router.get("/admin/roles/{role_id}", response_model=RoleConfigOut)
async def get_role(
    role_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    row = await _get_role_or_404(db, role_id)
    return row


@router.post("/admin/roles", response_model=RoleConfigOut, status_code=201)
async def create_role(
    body: RoleConfigIn,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    await _assert_code_unique(db, RoleConfigModel, "code", body.code)
    row = RoleConfigModel(
        role_id=str(uuid.uuid4()),
        code=body.code.upper(),
        display_name=body.display_name,
        description=body.description,
        is_active=body.is_active,
        permissions=body.permissions,
        allowed_screens=body.allowed_screens,
        created_by=current_user.username,
    )
    db.add(row)
    await db.flush()
    return row


@router.put("/admin/roles/{role_id}", response_model=RoleConfigOut)
async def update_role(
    role_id: str,
    body: RoleConfigIn,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    row = await _get_role_or_404(db, role_id)
    if body.code.upper() != row.code:
        await _assert_code_unique(db, RoleConfigModel, "code", body.code)
    row.code = body.code.upper()
    row.display_name = body.display_name
    row.description = body.description
    row.is_active = body.is_active
    row.permissions = body.permissions
    row.allowed_screens = body.allowed_screens
    row.updated_at = datetime.utcnow()
    row.created_by = current_user.username
    await db.flush()
    return row


@router.delete("/admin/roles/{role_id}", status_code=204)
async def deactivate_role(
    role_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    row = await _get_role_or_404(db, role_id)
    row.is_active = False
    row.updated_at = datetime.utcnow()
    await db.flush()


# ── EVIDENCE REQUIREMENTS ────────────────────────────────────────────────────
# Admin-editable replacement for what used to be a hardcoded checklist in
# packages/intelligence/scheme_rules.py — read by the agent's identify_gaps
# node and GET /disputes/:id/evidence-completeness (packages/intelligence/
# evidence_requirements.py) as a fallback safety net when a case has no
# network/reason_code set. See README §26.

@router.get("/admin/evidence-requirements", response_model=List[EvidenceRequirementOut])
async def list_evidence_requirements(
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    result = await db.execute(
        select(EvidenceRequirementModel)
        .order_by(EvidenceRequirementModel.dispute_type, EvidenceRequirementModel.sort_order)
    )
    return result.scalars().all()


@router.get("/admin/evidence-requirements/{requirement_id}", response_model=EvidenceRequirementOut)
async def get_evidence_requirement(
    requirement_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    return await _get_evidence_requirement_or_404(db, requirement_id)


@router.post("/admin/evidence-requirements", response_model=EvidenceRequirementOut, status_code=201)
async def create_evidence_requirement(
    body: EvidenceRequirementIn,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    await _assert_requirement_unique(db, body.dispute_type, body.evidence_type)
    row = EvidenceRequirementModel(
        requirement_id=str(uuid.uuid4()),
        dispute_type=body.dispute_type.upper(),
        evidence_type=body.evidence_type.upper(),
        description=body.description,
        is_required=body.is_required,
        sort_order=body.sort_order,
        is_active=body.is_active,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
        created_by=current_user.username,
    )
    db.add(row)
    await db.flush()
    return row


@router.put("/admin/evidence-requirements/{requirement_id}", response_model=EvidenceRequirementOut)
async def update_evidence_requirement(
    requirement_id: str,
    body: EvidenceRequirementIn,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    row = await _get_evidence_requirement_or_404(db, requirement_id)
    if body.dispute_type.upper() != row.dispute_type or body.evidence_type.upper() != row.evidence_type:
        await _assert_requirement_unique(db, body.dispute_type, body.evidence_type)
    row.dispute_type = body.dispute_type.upper()
    row.evidence_type = body.evidence_type.upper()
    row.description = body.description
    row.is_required = body.is_required
    row.sort_order = body.sort_order
    row.is_active = body.is_active
    row.updated_at = datetime.utcnow()
    row.created_by = current_user.username
    await db.flush()
    return row


@router.delete("/admin/evidence-requirements/{requirement_id}", status_code=204)
async def delete_evidence_requirement(
    requirement_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    # Real delete, not the soft-deactivate pattern statuses/outcomes/roles use —
    # nothing else references a requirement_id by foreign key, so there's
    # nothing left dangling by removing the row outright.
    row = await _get_evidence_requirement_or_404(db, requirement_id)
    await db.delete(row)
    await db.flush()


@router.post("/admin/evidence-requirements/extract", response_model=EvidenceRequirementExtractionResponse)
async def extract_evidence_requirements(
    file: UploadFile = File(...),
    dispute_type: str = Form(...),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    """
    Reads an uploaded reference document (rulebook excerpt, SOP page,
    checklist, etc.) and extracts candidate evidence-requirement rows for the
    given dispute_type — lets an admin bulk-seed the checklist from a
    document instead of typing every row by hand. Nothing is saved here; the
    admin reviews the extracted list and picks which rows to actually create
    via the existing POST /admin/evidence-requirements.
    """
    if not file.content_type or file.content_type not in _ALLOWED_EXTRACTION_MIME_TYPES:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Unsupported file type '{file.content_type}' — upload a PDF, PNG, JPEG, or WebP.",
        )
    if not dispute_type.strip():
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "dispute_type is required.")

    contents = await file.read()
    if not contents:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Uploaded file is empty.")

    try:
        result = evidence_requirement_extraction.extract_requirements(
            contents, file.content_type, dispute_type.strip().upper(),
        )
    except Exception as exc:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            f"Could not process this document: {exc}",
        )

    return EvidenceRequirementExtractionResponse(
        requirements=[ExtractedRequirement(**r) for r in result["requirements"]],
        confidence=result["confidence"],
        notes=result["notes"],
    )


# ── PERMISSIONS REFERENCE ─────────────────────────────────────────────────────

@router.get("/admin/permissions")
async def available_permissions(
    current_user: TokenData = Depends(get_current_user),
):
    """Canonical permission catalog grouped by domain."""
    return {
        "categories": [
            {
                "category": "Disputes",
                "permissions": ["dispute:read", "dispute:create", "dispute:update"],
            },
            {
                "category": "Evidence",
                "permissions": ["evidence:read", "evidence:ingest"],
            },
            {
                "category": "Hypotheses",
                "permissions": ["hypothesis:read", "contradiction:read"],
            },
            {
                "category": "Recommendations",
                "permissions": ["recommendation:read", "recommendation:override"],
            },
            {
                "category": "Actions",
                "permissions": ["action:propose", "action:read", "action:approve"],
            },
            {
                "category": "Approvals",
                "permissions": ["approval:read", "approval:create"],
            },
            {
                "category": "Audit",
                "permissions": ["audit:read", "audit:replay"],
            },
            {
                "category": "Agents",
                "permissions": ["agent:trigger", "agent:trace:read"],
            },
            {
                "category": "Administration",
                "permissions": ["tenant:manage", "user:manage", "config:manage"],
            },
        ],
    }


# ── USER MANAGEMENT ──────────────────────────────────────────────────────────

class UserOut(BaseModel):
    user_id: str
    username: str
    email: str
    tenant_id: str
    roles: List[str]
    is_active: bool
    created_at: datetime
    screens: List[str]

    class Config:
        from_attributes = True


@router.get("/admin/users", response_model=List[UserOut])
async def list_users(
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    result = await db.execute(select(UserModel).order_by(UserModel.username))
    users = result.scalars().all()
    out = []
    for u in users:
        screens: list = []
        for role in (u.roles or []):
            screens.extend(ROLE_SCREENS.get(role, []))
        out.append(UserOut(
            user_id=u.user_id,
            username=u.username,
            email=u.email,
            tenant_id=u.tenant_id,
            roles=u.roles or [],
            is_active=u.is_active,
            created_at=u.created_at,
            screens=list(set(screens)),
        ))
    return out


@router.patch("/admin/users/{user_id}/toggle", response_model=UserOut)
async def toggle_user(
    user_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    result = await db.execute(select(UserModel).where(UserModel.user_id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "User not found")
    if user.user_id == current_user.user_id:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Cannot deactivate your own account")
    user.is_active = not user.is_active
    await db.flush()
    screens: list = []
    for role in (user.roles or []):
        screens.extend(ROLE_SCREENS.get(role, []))
    return UserOut(
        user_id=user.user_id, username=user.username, email=user.email,
        tenant_id=user.tenant_id, roles=user.roles or [], is_active=user.is_active,
        created_at=user.created_at, screens=list(set(screens)),
    )


# ── SYSTEM INFO ───────────────────────────────────────────────────────────────

@router.get("/admin/system")
async def system_info(
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    """Non-sensitive system configuration and feature flags."""
    return {
        "ai": {
            "model": os.getenv("LLM_MODEL", "not configured"),
            "base_url": os.getenv("LITELLM_BASE_URL", "not configured"),
            "max_steps": int(os.getenv("AGENT_MAX_STEPS", "20")),
            "max_runtime_seconds": int(os.getenv("AGENT_MAX_RUNTIME_SECONDS", "120")),
        },
        "features": {
            "demo_mode": os.getenv("DEMO_MODE", "false").lower() == "true",
            "vector_store": faiss_index.collection_stats(),
            "sms_notifications": {
                "enabled": os.getenv("ENABLE_SMS_NOTIFICATIONS", "false").lower() == "true",
                "configured": bool(
                    os.getenv("TWILIO_ACCOUNT_SID") and os.getenv("TWILIO_AUTH_TOKEN")
                    and os.getenv("TWILIO_FROM_NUMBER")
                ),
            },
        },
        "auth": {
            "algorithm": os.getenv("JWT_ALGORITHM", "HS256"),
            "expiry_hours": int(os.getenv("JWT_EXPIRY_HOURS", "8")),
        },
        "database": {
            "url": os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./data/dispute_system.db").split("///")[1],
        },
    }


# ── REGULATORY DOCUMENTS (Knowledge Base — admin PDF upload -> RAG) ────────────

async def _ingest_regulatory_document(
    document_id: str, file_path: str, filename: str, network: str, doc_type: str,
) -> None:
    """
    Background task: extract + chunk + embed a just-uploaded PDF. Runs after the
    upload response has already been sent (status starts PENDING/PROCESSING).
    PDF extraction and embedding are both CPU-bound sync work — run via
    asyncio.to_thread so a 1,000+ page document doesn't block the event loop for
    everyone else (same rule as bcrypt verification in packages/security/auth.py).
    """
    from packages.persistence.sqlite.database import AsyncSessionLocal
    from packages.intelligence import pdf_ingest

    async def _set(**fields):
        async with AsyncSessionLocal() as db:
            doc = await db.get(RegulatoryDocumentModel, document_id)
            if not doc:
                return
            for k, v in fields.items():
                setattr(doc, k, v)
            await db.commit()

    await _set(status="PROCESSING")
    try:
        page_total = await asyncio.to_thread(pdf_ingest.page_count, file_path)
        chunks = await asyncio.to_thread(pdf_ingest.extract_chunks, file_path)

        if not chunks:
            await _set(
                status="FAILED", page_count=page_total,
                error="No extractable text found in this PDF — it may be scanned/image-only.",
            )
            return

        indexed = await asyncio.to_thread(
            faiss_index.add_regulatory_chunks, document_id, filename, chunks, network, doc_type,
        )
        await _set(status="READY", page_count=page_total, chunks_indexed=indexed)
    except Exception as exc:
        await _set(status="FAILED", error=str(exc)[:500])


@router.get("/admin/regulatory-documents", response_model=List[RegulatoryDocumentOut])
async def list_regulatory_documents(
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    result = await db.execute(
        select(RegulatoryDocumentModel).order_by(RegulatoryDocumentModel.uploaded_at.desc())
    )
    return result.scalars().all()


@router.post("/admin/regulatory-documents", response_model=RegulatoryDocumentOut, status_code=201)
async def upload_regulatory_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    network: str = Form("OTHER"),
    doc_type: str = Form("OTHER"),
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    if not file.filename or not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Only PDF files are supported")
    if network not in _VALID_NETWORKS:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"network must be one of {_VALID_NETWORKS}")
    if doc_type not in _VALID_DOC_TYPES:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"doc_type must be one of {_VALID_DOC_TYPES}")

    document_id = str(uuid.uuid4())
    _REGULATORY_DOCS_DIR.mkdir(parents=True, exist_ok=True)
    dest_path = _REGULATORY_DOCS_DIR / f"{document_id}.pdf"
    contents = await file.read()
    dest_path.write_bytes(contents)

    doc = RegulatoryDocumentModel(
        document_id=document_id,
        filename=file.filename,
        file_path=str(dest_path),
        uploaded_by=current_user.user_id,
        uploaded_at=datetime.utcnow(),
        status="PENDING",
        chunks_indexed=0,
        network=network,
        doc_type=doc_type,
    )
    db.add(doc)
    await db.commit()

    background_tasks.add_task(
        _ingest_regulatory_document, document_id, str(dest_path), file.filename, network, doc_type,
    )

    return doc


@router.patch("/admin/regulatory-documents/{document_id}/tags", response_model=RegulatoryDocumentOut)
async def retag_regulatory_document(
    document_id: str,
    body: RegulatoryDocumentTagsIn,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    """Correct a document's network/doc_type after upload — patches its already-indexed
    chunks' metadata in place (no re-embedding needed, faiss_index.update_regulatory_document_tags)."""
    doc = await db.get(RegulatoryDocumentModel, document_id)
    if not doc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")
    if body.network not in _VALID_NETWORKS:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"network must be one of {_VALID_NETWORKS}")
    if body.doc_type not in _VALID_DOC_TYPES:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"doc_type must be one of {_VALID_DOC_TYPES}")

    doc.network = body.network
    doc.doc_type = body.doc_type
    faiss_index.update_regulatory_document_tags(document_id, body.network, body.doc_type)
    await db.commit()
    return doc


@router.delete("/admin/regulatory-documents/{document_id}", status_code=204)
async def delete_regulatory_document(
    document_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    doc = await db.get(RegulatoryDocumentModel, document_id)
    if not doc:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")

    faiss_index.remove_regulatory_document(document_id)
    try:
        Path(doc.file_path).unlink(missing_ok=True)
    except Exception:
        pass
    await db.delete(doc)
    await db.commit()


@router.post("/admin/regulatory-documents/search", response_model=List[RegulatorySearchHit])
async def search_regulatory_documents(
    body: RegulatorySearchRequest,
    current_user: TokenData = Depends(require_permission(Permissions.CONFIG_MANAGE)),
):
    """Admin-only: verify retrieval quality directly against whatever is indexed right
    now — the same faiss_index.find_regulatory_context the agent itself uses."""
    hits = faiss_index.find_regulatory_context(body.query, top_k=body.top_k, network=body.network)
    return [RegulatorySearchHit(**h) for h in hits]


# ── ADMIN SUMMARY ─────────────────────────────────────────────────────────────

@router.get("/admin/summary")
async def admin_summary(
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(get_current_user),
):
    """Quick counts for admin dashboard."""
    statuses = (await db.execute(select(StatusConfigModel))).scalars().all()
    outcomes = (await db.execute(select(OutcomeConfigModel))).scalars().all()
    roles    = (await db.execute(select(RoleConfigModel))).scalars().all()
    users    = (await db.execute(select(UserModel))).scalars().all()
    return {
        "statuses": {"total": len(statuses), "active": sum(1 for s in statuses if s.is_active)},
        "outcomes": {"total": len(outcomes), "active": sum(1 for o in outcomes if o.is_active)},
        "roles":    {"total": len(roles),    "active": sum(1 for r in roles    if r.is_active)},
        "users":    {"total": len(users),    "active": sum(1 for u in users    if u.is_active)},
    }


# ── Private helpers ───────────────────────────────────────────────────────────

async def _get_status_or_404(db: AsyncSession, status_id: str) -> StatusConfigModel:
    result = await db.execute(
        select(StatusConfigModel).where(StatusConfigModel.status_id == status_id)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Status not found")
    return row


async def _get_outcome_or_404(db: AsyncSession, outcome_id: str) -> OutcomeConfigModel:
    result = await db.execute(
        select(OutcomeConfigModel).where(OutcomeConfigModel.outcome_id == outcome_id)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Outcome not found")
    return row


async def _get_role_or_404(db: AsyncSession, role_id: str) -> RoleConfigModel:
    result = await db.execute(
        select(RoleConfigModel).where(RoleConfigModel.role_id == role_id)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Role not found")
    return row


async def _get_evidence_requirement_or_404(db: AsyncSession, requirement_id: str) -> EvidenceRequirementModel:
    result = await db.execute(
        select(EvidenceRequirementModel).where(EvidenceRequirementModel.requirement_id == requirement_id)
    )
    row = result.scalar_one_or_none()
    if not row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Evidence requirement not found")
    return row


async def _assert_requirement_unique(db: AsyncSession, dispute_type: str, evidence_type: str):
    result = await db.execute(
        select(EvidenceRequirementModel).where(
            EvidenceRequirementModel.dispute_type == dispute_type.upper(),
            EvidenceRequirementModel.evidence_type == evidence_type.upper(),
        )
    )
    if result.scalar_one_or_none():
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"A requirement for {dispute_type.upper()} / {evidence_type.upper()} already exists",
        )


async def _assert_code_unique(db: AsyncSession, model, field: str, value: str):
    result = await db.execute(
        select(model).where(getattr(model, field) == value.upper())
    )
    if result.scalar_one_or_none():
        raise HTTPException(
            status.HTTP_409_CONFLICT, f"Code '{value.upper()}' already exists"
        )
