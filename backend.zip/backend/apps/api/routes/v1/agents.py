import asyncio
import json
import uuid
from datetime import datetime
from typing import AsyncGenerator, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.persistence.sqlite.database import get_session
from packages.persistence.sqlite.models import AgentRunModel, DisputeModel
from packages.security.auth import TokenData, get_current_user
from packages.security.rbac import Permissions, require_permission

router = APIRouter()

# In-memory SSE event queues per dispute (demo-grade; production: Redis pub/sub)
_sse_queues: dict[str, asyncio.Queue] = {}


class AgentRunRequest(BaseModel):
    trigger: str = "USER_REQUEST"


class AgentRunResponse(BaseModel):
    run_id: str
    case_id: str
    status: str
    trigger: str
    start_time: datetime


@router.post("/disputes/{dispute_id}/agent/run", response_model=AgentRunResponse, status_code=202)
async def trigger_agent(
    dispute_id: str,
    body: AgentRunRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.AGENT_TRIGGER)),
):
    result = await db.execute(
        select(DisputeModel).where(
            DisputeModel.dispute_id == dispute_id,
            DisputeModel.tenant_id == current_user.tenant_id,
        )
    )
    if not result.scalar_one_or_none():
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Dispute not found")

    run_id = str(uuid.uuid4())
    now = datetime.utcnow()
    run = AgentRunModel(
        run_id=run_id,
        case_id=dispute_id,
        trigger=body.trigger,
        status="RUNNING",
        graph_version="1.0.0",
        model_version="claude-sonnet-5",
        steps_used=0,
        start_time=now,
    )
    db.add(run)
    await db.commit()

    # Kick off real LangGraph agent in background
    from packages.agent.runner import run_agent
    from packages.persistence.sqlite.database import AsyncSessionLocal
    background_tasks.add_task(
        run_agent,
        dispute_id=dispute_id,
        tenant_id=current_user.tenant_id,
        user_id=current_user.user_id,
        session_factory=AsyncSessionLocal,
        sse_queues=_sse_queues,
        run_id=run_id,
    )

    return AgentRunResponse(
        run_id=run_id,
        case_id=dispute_id,
        status="RUNNING",
        trigger=body.trigger,
        start_time=now,
    )


@router.get("/disputes/{dispute_id}/agent/stream")
async def stream_agent_events(
    dispute_id: str,
    request: Request,
    current_user: TokenData = Depends(require_permission(Permissions.AGENT_TRACE_READ)),
):
    queue: asyncio.Queue = _sse_queues.setdefault(dispute_id, asyncio.Queue(maxsize=100))

    async def event_generator() -> AsyncGenerator[str, None]:
        yield _sse_event("connected", {"dispute_id": dispute_id})
        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30.0)
                    yield event
                    # Real bug, found live: json.dumps's default separators put a
                    # space after the colon ({"type": "COMPLETE", ...}), so a naive
                    # no-space substring check here never matched — the terminal
                    # event was still delivered to the client (yield already ran
                    # above), but this generator never broke out of its own loop,
                    # leaking one open stream per dispute indefinitely. Parse the
                    # actual JSON instead of guessing at its serialized form.
                    try:
                        event_type = json.loads(event[len("data: "):].strip()).get("type")
                    except Exception:
                        event_type = None
                    if event_type in ("COMPLETE", "FAILED"):
                        break
                except asyncio.TimeoutError:
                    yield _sse_event("heartbeat", {})
        except asyncio.CancelledError:
            pass

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@router.get("/disputes/{dispute_id}/agent/status")
async def get_agent_status(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.AGENT_TRACE_READ)),
):
    result = await db.execute(
        select(AgentRunModel)
        .where(AgentRunModel.case_id == dispute_id)
        .order_by(AgentRunModel.start_time.desc())
        .limit(1)
    )
    run = result.scalar_one_or_none()
    if not run:
        return {"status": "NO_RUN", "case_id": dispute_id}
    return {
        "run_id": run.run_id,
        "status": run.status,
        "steps_used": run.steps_used,
        "tokens_used": run.tokens_used,
        "termination_reason": run.termination_reason,
        "start_time": run.start_time,
        "end_time": run.end_time,
    }


def _sse_event(event_type: str, data: dict) -> str:
    payload = json.dumps({"type": event_type, **data})
    return f"data: {payload}\n\n"
