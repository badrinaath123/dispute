import hashlib
import json
import uuid
from datetime import datetime
from typing import List, Optional

from packages.intelligence import materiality as mat_engine
from packages.intelligence import faiss_index
from packages.application.services import evidence_reassessment_service

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.persistence.sqlite.database import get_session
from packages.persistence.sqlite.models import (
    DisputeModel, EvidenceModel, ProvenanceModel, AuditEventModel
)
from packages.security.auth import TokenData, get_current_user
from packages.security.rbac import Permissions, require_permission

router = APIRouter()


# ── DTOs ──────────────────────────────────────────────────────────────────────

class IngestEvidenceRequest(BaseModel):
    source_type: str
    source_system: str
    source_record_id: str
    evidence_type: str
    normalized_content: dict
    event_time: datetime
    materiality: str = "UNKNOWN"
    retrieval_method: str = "API_PULL"


class DuplicateMatch(BaseModel):
    evidence_id: str
    case_id: str
    similarity: float


class EvidenceResponse(BaseModel):
    evidence_id: str
    case_id: str
    source_type: str
    source_system: str
    source_record_id: str
    evidence_type: str
    version: int
    normalized_content: dict
    event_time: datetime
    received_time: datetime
    materiality: str
    quality: str
    is_current: bool
    previous_version_id: Optional[str]
    superseded_by: Optional[str]
    content_hash: str
    created_at: datetime
    possible_duplicates: List[DuplicateMatch] = []


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/disputes/{dispute_id}/evidence", response_model=EvidenceResponse, status_code=201)
async def ingest_evidence(
    dispute_id: str,
    body: IngestEvidenceRequest,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.EVIDENCE_INGEST)),
):
    # Tenant-scoped dispute check
    result = await db.execute(
        select(DisputeModel).where(
            DisputeModel.dispute_id == dispute_id,
            DisputeModel.tenant_id == current_user.tenant_id,
        )
    )
    dispute = result.scalar_one_or_none()
    if not dispute:
        raise HTTPException(status_code=404, detail="Dispute not found")

    content_hash = hashlib.sha256(
        json.dumps(body.normalized_content, sort_keys=True).encode()
    ).hexdigest()

    # ── Deduplication: check exact match ──────────────────────────────────────
    dup_result = await db.execute(
        select(EvidenceModel).where(
            EvidenceModel.case_id == dispute_id,
            EvidenceModel.source_type == body.source_type,
            EvidenceModel.source_record_id == body.source_record_id,
            EvidenceModel.content_hash == content_hash,
        )
    )
    existing = dup_result.scalar_one_or_none()
    if existing:
        return _to_evidence_response(existing)

    # ── Version detection: is this a new version of existing evidence? ─────────
    prev_result = await db.execute(
        select(EvidenceModel).where(
            EvidenceModel.case_id == dispute_id,
            EvidenceModel.source_type == body.source_type,
            EvidenceModel.source_record_id == body.source_record_id,
            EvidenceModel.is_current == True,
        )
    )
    previous = prev_result.scalar_one_or_none()

    new_version = 1
    previous_version_id = None
    if previous:
        new_version = previous.version + 1
        previous_version_id = previous.evidence_id

    # Auto-assess materiality when caller passes UNKNOWN
    resolved_materiality = body.materiality
    if resolved_materiality == "UNKNOWN":
        resolved_materiality = mat_engine.assess(
            body.evidence_type, body.normalized_content, body.source_type
        )

    now = datetime.utcnow()
    new_evidence_id = str(uuid.uuid4())

    evidence = EvidenceModel(
        evidence_id=new_evidence_id,
        case_id=dispute_id,
        tenant_id=current_user.tenant_id,
        source_type=body.source_type,
        source_system=body.source_system,
        source_record_id=body.source_record_id,
        evidence_type=body.evidence_type,
        version=new_version,
        previous_version_id=previous_version_id,
        normalized_content=body.normalized_content,
        event_time=body.event_time,
        received_time=now,
        effective_time=now,
        content_hash=content_hash,
        materiality=resolved_materiality,
        quality="UNVERIFIED",
        is_current=True,
        created_at=now,
    )

    # Supersede previous version
    if previous:
        previous.is_current = False
        previous.superseded_by = new_evidence_id

    db.add(evidence)

    # Provenance
    prov = ProvenanceModel(
        provenance_id=str(uuid.uuid4()),
        evidence_id=new_evidence_id,
        source_type=body.source_type,
        source_system=body.source_system,
        source_record_id=body.source_record_id,
        retrieval_method=body.retrieval_method,
        retrieved_by=current_user.user_id,
        retrieved_at=now,
        verified=False,
        chain_of_custody=[{
            "actor": current_user.user_id,
            "action": "INGESTED",
            "at": now.isoformat(),
        }],
    )
    db.add(prov)

    # Audit
    audit = AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=now,
        actor_id=current_user.user_id,
        actor_type="USER",
        tenant_id=current_user.tenant_id,
        case_id=dispute_id,
        event_type="EVIDENCE_RECEIVED" if new_version == 1 else "EVIDENCE_CHANGED",
        evidence_refs=[new_evidence_id],
        metadata_={
            "source_type": body.source_type,
            "evidence_type": body.evidence_type,
            "version": new_version,
            "materiality": resolved_materiality,
        },
    )
    db.add(audit)

    # Incorporate it, reassess dependent conclusions, make the change visible
    # (README §43) — contradiction detection, Z2 stale-invalidation on HIGH
    # materiality, and the live SSE banner, all in one place shared with the
    # document-upload path (disputes.py's _attach_document). No longer gated
    # behind "this must be a version update of existing evidence" — a merchant's
    # first-ever submission that contradicts the cardholder's original claim
    # needs exactly the same handling as a superseding version does.
    await evidence_reassessment_service.process_new_evidence(dispute, evidence, db)

    # Semantic duplicate check — tenant-wide, against everything already indexed
    # (cross-case matches are the point: catches the same real-world transaction
    # disputed/evidenced twice under different cases). Non-blocking; failures are
    # non-fatal — never blocks ingestion, only flags for human review.
    possible_duplicates: list[dict] = []
    try:
        possible_duplicates = faiss_index.find_similar_evidence(
            current_user.tenant_id, body.evidence_type, body.normalized_content
        )
    except Exception:
        pass

    if possible_duplicates:
        db.add(AuditEventModel(
            audit_id=str(uuid.uuid4()),
            timestamp=now,
            actor_id=current_user.user_id,
            actor_type="USER",
            tenant_id=current_user.tenant_id,
            case_id=dispute_id,
            event_type="POSSIBLE_DUPLICATE_DETECTED",
            evidence_refs=[new_evidence_id] + [d["evidence_id"] for d in possible_duplicates],
            metadata_={"matches": possible_duplicates},
        ))

    await db.flush()

    # Update semantic index (non-blocking; failures are non-fatal)
    try:
        faiss_index.add_evidence(
            new_evidence_id, current_user.tenant_id, dispute_id, body.evidence_type, body.normalized_content
        )
    except Exception:
        pass

    return _to_evidence_response(evidence, possible_duplicates)


@router.get("/disputes/{dispute_id}/evidence", response_model=List[EvidenceResponse])
async def list_evidence(
    dispute_id: str,
    current_only: bool = Query(True),
    evidence_type: Optional[str] = None,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.EVIDENCE_READ)),
):
    q = select(EvidenceModel).where(
        EvidenceModel.case_id == dispute_id,
        EvidenceModel.tenant_id == current_user.tenant_id,
    )
    if current_only:
        q = q.where(EvidenceModel.is_current == True)
    if evidence_type:
        q = q.where(EvidenceModel.evidence_type == evidence_type)
    q = q.order_by(EvidenceModel.event_time.asc())
    result = await db.execute(q)
    items = result.scalars().all()
    return [_to_evidence_response(e) for e in items]


@router.get("/disputes/{dispute_id}/evidence/{evidence_id}", response_model=EvidenceResponse)
async def get_evidence(
    dispute_id: str,
    evidence_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.EVIDENCE_READ)),
):
    result = await db.execute(
        select(EvidenceModel).where(
            EvidenceModel.evidence_id == evidence_id,
            EvidenceModel.case_id == dispute_id,
            EvidenceModel.tenant_id == current_user.tenant_id,
        )
    )
    ev = result.scalar_one_or_none()
    if not ev:
        raise HTTPException(status_code=404, detail="Evidence not found")
    return _to_evidence_response(ev)


# ── Private helpers ────────────────────────────────────────────────────────────

def _to_evidence_response(e: EvidenceModel, possible_duplicates: Optional[list[dict]] = None) -> EvidenceResponse:
    return EvidenceResponse(
        evidence_id=e.evidence_id,
        case_id=e.case_id,
        source_type=e.source_type,
        source_system=e.source_system,
        source_record_id=e.source_record_id,
        evidence_type=e.evidence_type,
        version=e.version,
        normalized_content=e.normalized_content,
        event_time=e.event_time,
        received_time=e.received_time,
        materiality=e.materiality,
        quality=e.quality,
        is_current=e.is_current,
        previous_version_id=e.previous_version_id,
        superseded_by=e.superseded_by,
        content_hash=e.content_hash,
        created_at=e.created_at,
        possible_duplicates=[DuplicateMatch(**d) for d in (possible_duplicates or [])],
    )


