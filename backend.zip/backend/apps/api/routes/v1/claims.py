"""
Claims — one cardholder intake that may cover multiple transactions.

Each transaction in a claim becomes its own DisputeModel sub-case (own
merchant, own evidence, own agent investigation, own recommendation, own
approval) linked back to the claim via DisputeModel.claim_id. Everything
downstream of dispute creation (agent pipeline, evidence, hypotheses,
actions, approvals, audit) is untouched — it already operates per dispute_id,
which is exactly the per-transaction granularity this needs.
"""
import uuid
from datetime import datetime, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.intelligence import priority_scoring
from packages.persistence.sqlite.database import get_session
from packages.persistence.sqlite.models import ClaimModel, DisputeModel, AuditEventModel
from packages.security.auth import TokenData
from packages.security.rbac import Permissions, require_permission

router = APIRouter()

_RESOLVED_STATUSES = {"APPROVED", "REJECTED", "CLOSED"}


# ── DTOs ──────────────────────────────────────────────────────────────────────

class TransactionSubCase(BaseModel):
    dispute_type: str
    transaction_reference: Optional[str] = None
    metadata: dict = {}


class CreateClaimRequest(BaseModel):
    cardholder_claim: str
    priority: str = "MEDIUM"
    deadline: Optional[datetime] = None
    transactions: List[TransactionSubCase]


class ClaimSubCaseResponse(BaseModel):
    dispute_id: str
    claim_sequence: Optional[int]
    dispute_type: str
    transaction_reference: Optional[str]
    status: str
    metadata: dict


class ClaimResponse(BaseModel):
    claim_id: str
    tenant_id: str
    cardholder_claim: str
    status: str
    created_at: datetime
    sub_cases: List[ClaimSubCaseResponse]


class CreateClaimResponse(BaseModel):
    claim_id: str
    dispute_ids: List[str]


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/claims", response_model=CreateClaimResponse, status_code=201)
async def create_claim(
    body: CreateClaimRequest,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_CREATE)),
):
    if not body.transactions:
        raise HTTPException(status_code=422, detail="A claim must include at least one transaction")

    now = datetime.utcnow()
    claim_id = str(uuid.uuid4())
    claim = ClaimModel(
        claim_id=claim_id,
        tenant_id=current_user.tenant_id,
        cardholder_claim=body.cardholder_claim,
        created_by=current_user.user_id,
        created_at=now,
    )
    db.add(claim)

    dispute_ids: List[str] = []
    for i, txn in enumerate(body.transactions, start=1):
        dispute_id = str(uuid.uuid4())
        dispute_ids.append(dispute_id)
        # README §49: same per-dispute_type SLA tiering as the single-case path
        # (disputes.py) — each transaction in a multi-transaction claim can be a
        # different type, so this is computed per-transaction, not once for the claim.
        deadline = body.deadline or (now + timedelta(days=priority_scoring.sla_days_for(txn.dispute_type)))
        db.add(DisputeModel(
            dispute_id=dispute_id,
            tenant_id=current_user.tenant_id,
            status="OPEN",
            dispute_type=txn.dispute_type,
            lifecycle_stage="INTAKE",
            priority=body.priority,
            current_state_version=1,
            deadline=deadline,
            transaction_reference=txn.transaction_reference,
            cardholder_claim=body.cardholder_claim,
            metadata_=txn.metadata,
            claim_id=claim_id,
            claim_sequence=i,
            created_at=now,
            updated_at=now,
        ))
        db.add(AuditEventModel(
            audit_id=str(uuid.uuid4()),
            timestamp=now,
            actor_id=current_user.user_id,
            actor_type="USER",
            tenant_id=current_user.tenant_id,
            case_id=dispute_id,
            event_type="DISPUTE_CREATED",
            new_state_version=1,
            metadata_={"dispute_type": txn.dispute_type, "claim_id": claim_id, "claim_sequence": i},
        ))

    db.add(AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=now,
        actor_id=current_user.user_id,
        actor_type="USER",
        tenant_id=current_user.tenant_id,
        case_id=None,
        event_type="CLAIM_CREATED",
        metadata_={"claim_id": claim_id, "sub_case_count": len(dispute_ids)},
    ))

    return CreateClaimResponse(claim_id=claim_id, dispute_ids=dispute_ids)


@router.get("/claims/{claim_id}", response_model=ClaimResponse)
async def get_claim(
    claim_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    result = await db.execute(
        select(ClaimModel).where(
            ClaimModel.claim_id == claim_id,
            ClaimModel.tenant_id == current_user.tenant_id,
        )
    )
    claim = result.scalar_one_or_none()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")

    sub_result = await db.execute(
        select(DisputeModel)
        .where(DisputeModel.claim_id == claim_id)
        .order_by(DisputeModel.claim_sequence.asc())
    )
    sub_cases = sub_result.scalars().all()

    statuses = {d.status for d in sub_cases}
    claim_status = "RESOLVED" if statuses and statuses <= _RESOLVED_STATUSES else "IN_PROGRESS"

    return ClaimResponse(
        claim_id=claim.claim_id,
        tenant_id=claim.tenant_id,
        cardholder_claim=claim.cardholder_claim,
        status=claim_status,
        created_at=claim.created_at,
        sub_cases=[
            ClaimSubCaseResponse(
                dispute_id=d.dispute_id,
                claim_sequence=d.claim_sequence,
                dispute_type=d.dispute_type,
                transaction_reference=d.transaction_reference,
                status=d.status,
                metadata=d.metadata_ or {},
            )
            for d in sub_cases
        ],
    )
