import hashlib
import mimetypes
import os
import re
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.intelligence import document_understanding, sample_letter, priority_scoring, claim_classifier, pii_guard, vision_utils, materiality, evidence_request_draft
from packages.application.services import evidence_reassessment_service
from packages.persistence.sqlite.database import get_session
from packages.persistence.sqlite.models import DisputeModel, EvidenceModel, ProvenanceModel, StatusConfigModel, EvidenceGapModel, AuditEventModel
from packages.security.auth import TokenData, get_current_user
from packages.security.rbac import Permissions, require_permission

router = APIRouter()
_ALLOWED_DOCUMENT_MIME_TYPES = {"application/pdf", "image/png", "image/jpeg", "image/webp"}

# Cyera Validation (README §38, §46) — off by default. It was blocking/erroring on
# ordinary evidence uploads (only CARDHOLDER_LETTER reliably worked) and the
# extract-from-document call site (_check_cyera_flags below) had gone stale — the
# function it called was never actually defined, so every extraction request threw
# a 500. Rather than keep chasing false positives this close to the demo, the check
# is now flag-gated the same way ENABLE_SMS_NOTIFICATIONS/ENABLE_DEEPEVAL are: the
# code stays in place for later, but real uploads are never blocked while this is off.
_ENABLE_CYERA_VALIDATION = os.getenv("ENABLE_CYERA_VALIDATION", "false").lower() == "true"

# Local document storage root (repo_root/storage/disputes/<dispute_id>/<file>).
# Evidence rows with source_type="DOCUMENT" store the file's path relative to
# this root in `content_reference` — the JSON API only ever exposes
# documentId/documentType/fileName, never file bytes or an absolute path.
_STORAGE_ROOT = Path(__file__).resolve().parents[4] / "storage" / "disputes"


# ── DTOs ──────────────────────────────────────────────────────────────────────

class CreateDisputeRequest(BaseModel):
    dispute_type: str
    cardholder_claim: str
    transaction_reference: Optional[str] = None
    priority: str = "MEDIUM"
    deadline: Optional[datetime] = None
    metadata: dict = {}


class DisputeResponse(BaseModel):
    dispute_id: str
    tenant_id: str
    status: str
    dispute_type: str
    lifecycle_stage: str
    priority: str
    current_state_version: int
    cardholder_claim: str
    transaction_reference: Optional[str]
    deadline: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    metadata: dict
    claim_id: Optional[str] = None
    # Additive — deterministic 0-100 triage score (packages/intelligence/
    # priority_scoring.py), computed fresh on every read so it's always
    # current with the deadline's remaining time. Not stored.
    priority_score: int = 0
    days_remaining: Optional[float] = None
    is_archived: bool = False


class DisputeListResponse(BaseModel):
    items: List[DisputeResponse]
    total: int
    page: int
    page_size: int


# ── Case detail contract (GET /disputes/{id}) ──────────────────────────────────
# Nested cardholder/transaction/dispute/evidence shape. Fields beyond that
# contract (status, priority, lifecycle_stage, deadline, metadata, claim_id) are
# additive — kept so the rest of the case screen (SLA, chargeback gating, agent,
# recommendations, hypotheses) keeps working unchanged off the same endpoint.

class CardholderInfo(BaseModel):
    customerId: Optional[str]
    name: Optional[str]
    maskedCardNumber: Optional[str]
    authenticationStatus: Optional[str]
    # Additive — drives the priority score's card-tier weighting
    # (packages/intelligence/priority_scoring.py), not part of the original
    # cardholder contract.
    cardTier: Optional[str] = None
    # Additive — SMS notification destination (packages/connectors/sms.py, README §45).
    phone: Optional[str] = None


class TransactionInfo(BaseModel):
    transactionId: Optional[str]
    merchantName: Optional[str]
    amount: Optional[float]
    currency: Optional[str]
    transactionDate: Optional[str]
    postingDate: Optional[str]
    merchantId: Optional[str]
    merchantCategoryCode: Optional[str]
    transactionChannel: Optional[str]


class DisputeDetail(BaseModel):
    disputeType: str
    disputeAmount: Optional[float]
    description: str
    returnDate: Optional[str]
    expectedRefundAmount: Optional[float]
    expectedRefundDate: Optional[str]
    merchantContacted: Optional[bool]
    merchantContactDate: Optional[str]
    merchantResponse: Optional[str]
    refundReferenceNumber: Optional[str]


class EvidenceDocumentInfo(BaseModel):
    evidenceId: str
    documentId: str
    documentType: str
    fileName: str
    # Additive, not part of the original documentId/documentType/fileName-only
    # contract (README §24) — a short human-readable summary of what the
    # document actually says, derived from its content, never raw file bytes.
    textSummary: Optional[str] = None


class CaseDetailResponse(BaseModel):
    caseId: str
    cardholder: CardholderInfo
    transaction: TransactionInfo
    dispute: DisputeDetail
    evidence: List[EvidenceDocumentInfo]

    # Additive — not part of the requested contract, but required by the rest
    # of the existing case screen (SLA, chargeback action, agent panels, etc.),
    # which all key off dispute_id (== caseId) rather than the new field name.
    dispute_id: str
    tenant_id: str
    status: str
    dispute_type: str
    lifecycle_stage: str
    priority: str
    current_state_version: int
    transaction_reference: Optional[str]
    cardholder_claim: str
    deadline: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    metadata: dict
    claim_id: Optional[str] = None
    priority_score: int = 0
    days_remaining: Optional[float] = None
    is_archived: bool = False


class UpdateDisputeRequest(BaseModel):
    status: Optional[str] = None
    lifecycle_stage: Optional[str] = None
    priority: Optional[str] = None
    metadata: Optional[dict] = None


class ExtractedTransaction(BaseModel):
    dispute_type: Optional[str]
    transaction_reference: Optional[str]
    merchant_name: Optional[str]
    amount_disputed: Optional[str]
    transaction_date: Optional[str]
    posting_date: Optional[str]


class DocumentExtractionResponse(BaseModel):
    document_type: str
    text_summary: str
    customer_name: Optional[str]
    masked_card_number: Optional[str]
    card_tier: Optional[str]
    authentication_status: Optional[str]
    document_date: Optional[str]
    narrative: str
    return_date: Optional[str]
    expected_refund_amount: Optional[str]
    expected_refund_date: Optional[str]
    refund_reference_number: Optional[str]
    merchant_response: Optional[str]
    merchant_contact_date: Optional[str]
    transactions: List[ExtractedTransaction]
    confidence: float
    notes: str


class ClassifyClaimRequest(BaseModel):
    cardholder_claim: str


class ClassifyClaimResponse(BaseModel):
    dispute_type: Optional[str]
    priority: str
    confidence: float
    reasoning: str


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.post("/disputes/classify-claim", response_model=ClassifyClaimResponse)
async def classify_claim(
    body: ClassifyClaimRequest,
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_CREATE)),
):
    """
    Predicts dispute_type + priority from the cardholder's claim narrative
    alone, before any document exists — New Case's "Analyze" step. Text-only
    (packages/intelligence/claim_classifier.py), same permission as creating
    a case; the analyst reviews/can override both fields before submitting.
    """
    if not body.cardholder_claim.strip():
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "cardholder_claim is required.")

    result = claim_classifier.classify_claim(body.cardholder_claim.strip())
    return ClassifyClaimResponse(**result)

@router.post("/disputes/extract-from-document", response_model=DocumentExtractionResponse)
async def extract_from_document(
    file: UploadFile = File(...),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_CREATE)),
):
    """
    Document Understanding — the first box of the AI intake layer (Email/Letter ->
    Document Understanding -> Case Creation Assistant). Extracts structured fields from
    an uploaded letter/scan to pre-fill NewDisputeModal; never creates anything itself.
    Synchronous (a single page through gemini-2.5-flash is fast — no background-task/
    polling needed here, unlike the multi-hundred-page Knowledge Base ingestion).
    Same DISPUTE_CREATE permission already required to actually create a case.
    """
    if not file.content_type or file.content_type not in _ALLOWED_DOCUMENT_MIME_TYPES:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Unsupported file type '{file.content_type}' — upload a PDF, PNG, JPEG, or WebP.",
        )

    contents = await file.read()
    if not contents:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Uploaded file is empty.")

    try:
        result = document_understanding.extract_claim_from_document(contents, file.content_type)
    except Exception as exc:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            f"Could not process this document: {exc}",
        )

    # Cyera Validation (README §38, §46) — folded into the extraction call above (one
    # vision round-trip instead of two) rather than a separate pre-flight request.
    # Flag-gated off by default; see _ENABLE_CYERA_VALIDATION above.
    if _ENABLE_CYERA_VALIDATION:
        _check_cyera_flags(result)

    return DocumentExtractionResponse(
        document_type=result["document_type"],
        text_summary=result["text_summary"],
        customer_name=result["customer_name"],
        masked_card_number=result["masked_card_number"],
        card_tier=result["card_tier"],
        authentication_status=result["authentication_status"],
        document_date=result["document_date"],
        narrative=result["narrative"],
        return_date=result["return_date"],
        expected_refund_amount=result["expected_refund_amount"],
        expected_refund_date=result["expected_refund_date"],
        refund_reference_number=result["refund_reference_number"],
        merchant_response=result["merchant_response"],
        merchant_contact_date=result["merchant_contact_date"],
        transactions=[ExtractedTransaction(**t) for t in result["transactions"]],
        confidence=result["confidence"],
        notes=result["notes"],
    )


@router.post("/disputes", response_model=DisputeResponse, status_code=201)
async def create_dispute(
    body: CreateDisputeRequest,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_CREATE)),
):
    now = datetime.utcnow()
    dispute_id = str(uuid.uuid4())
    # SLA deadline is never analyst-picked — auto-assigned so it's consistent
    # and so the priority score (packages/intelligence/priority_scoring.py)
    # always has a real time-remaining to weigh, not an arbitrary human guess.
    # README §49: tiered per dispute_type (Reg Z's 90-day cap, tuned by how
    # evidence-heavy each category realistically is), not one flat number.
    deadline = body.deadline or (now + timedelta(days=priority_scoring.sla_days_for(body.dispute_type)))
    dispute = DisputeModel(
        dispute_id=dispute_id,
        tenant_id=current_user.tenant_id,
        status="OPEN",
        dispute_type=body.dispute_type,
        lifecycle_stage="INTAKE",
        priority=body.priority,
        current_state_version=1,
        deadline=deadline,
        transaction_reference=body.transaction_reference,
        cardholder_claim=body.cardholder_claim,
        metadata_=body.metadata,
        created_at=now,
        updated_at=now,
    )
    db.add(dispute)
    await db.flush()

    # Emit audit event
    from packages.persistence.sqlite.models import AuditEventModel
    audit = AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=now,
        actor_id=current_user.user_id,
        actor_type="USER",
        tenant_id=current_user.tenant_id,
        case_id=dispute_id,
        event_type="DISPUTE_CREATED",
        new_state_version=1,
        metadata_={"dispute_type": body.dispute_type},
    )
    db.add(audit)

    return _to_response(dispute)


@router.get("/disputes", response_model=DisputeListResponse)
async def list_disputes(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    q = select(DisputeModel).where(
        DisputeModel.tenant_id == current_user.tenant_id,
        DisputeModel.is_archived.is_(False),
    )
    if status:
        q = q.where(DisputeModel.status == status)
    q = q.order_by(DisputeModel.created_at.desc())

    count_result = await db.execute(q)
    total = len(count_result.scalars().all())

    q = q.offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(q)
    disputes = result.scalars().all()

    return DisputeListResponse(
        items=[_to_response(d) for d in disputes],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.patch("/disputes/{dispute_id}", response_model=DisputeResponse)
async def update_dispute(
    dispute_id: str,
    body: UpdateDisputeRequest,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_UPDATE)),
):
    dispute = await _get_or_404(dispute_id, current_user.tenant_id, db)
    old_status = dispute.status
    now = datetime.utcnow()
    if body.status:
        await _assert_valid_status(db, body.status)
        if body.status.upper() == "REJECTED":
            _assert_issuer_only(current_user, "Rejecting a customer's claim")
        dispute.status = body.status.upper()
    if body.lifecycle_stage:
        dispute.lifecycle_stage = body.lifecycle_stage
    if body.priority:
        dispute.priority = body.priority
    if body.metadata:
        dispute.metadata_ = {**(dispute.metadata_ or {}), **body.metadata}
    dispute.updated_at = now
    dispute.current_state_version = dispute.current_state_version + 1

    from packages.persistence.sqlite.models import AuditEventModel
    audit = AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=now,
        actor_id=current_user.user_id,
        actor_type="USER",
        tenant_id=current_user.tenant_id,
        case_id=dispute_id,
        event_type="DISPUTE_UPDATED",
        previous_state_version=dispute.current_state_version - 1,
        new_state_version=dispute.current_state_version,
        metadata_={"changes": body.model_dump(exclude_none=True), "previous_status": old_status},
    )
    db.add(audit)

    if dispute.status == "APPROVED" and old_status != "APPROVED":
        await _notify_customer_sms(
            dispute, current_user, db,
            "Good news — your dispute has been resolved in your favor. The merchant "
            "has accepted the chargeback and no further action is needed from you.",
        )
    elif dispute.status == "REJECTED" and old_status != "REJECTED":
        # Mirrors the APPROVED branch above — the issuer's "Reject Customer Claim"
        # action (DisputeCommandCenter.tsx's NBA button) reaches this same generic
        # update path, so it needed the same customer-facing notification the accept
        # path already gets, not silence.
        await _notify_customer_sms(
            dispute, current_user, db,
            "We've completed our review of your dispute. Based on the evidence "
            "available, we were unable to support your claim. If you have additional "
            "information, please contact us.",
        )
    return _to_response(dispute)


@router.post("/disputes/{dispute_id}/archive", response_model=DisputeResponse)
async def archive_dispute(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_UPDATE)),
):
    """
    Soft delete — the "delete a case" option on the issuer/merchant queue.
    Nothing is actually removed (evidence, hypotheses, actions, audit trail all
    stay exactly as they are); this only flips is_archived so the case drops out
    of GET /disputes, which both personas' queues read from. Reversible in the
    database even though there's no "restore" UI yet — matches the platform's
    own "audit events are forever" rule instead of contradicting it.
    """
    dispute = await _get_or_404(dispute_id, current_user.tenant_id, db)
    if dispute.is_archived:
        raise HTTPException(status.HTTP_409_CONFLICT, "This case is already archived.")

    now = datetime.utcnow()
    dispute.is_archived = True
    dispute.updated_at = now
    dispute.current_state_version = dispute.current_state_version + 1

    from packages.persistence.sqlite.models import AuditEventModel
    audit = AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=now,
        actor_id=current_user.user_id,
        actor_type="USER",
        tenant_id=current_user.tenant_id,
        case_id=dispute_id,
        event_type="DISPUTE_ARCHIVED",
        previous_state_version=dispute.current_state_version - 1,
        new_state_version=dispute.current_state_version,
        metadata_={},
    )
    db.add(audit)
    return _to_response(dispute)


@router.post("/disputes/{dispute_id}/chargeback", response_model=DisputeResponse)
async def chargeback_dispute(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_UPDATE)),
):
    """
    Issuer-side action: formally charges the dispute back to the merchant.
    Transitions status to CHARGEBACK and flags the case as action-required in
    the merchant's queue (GET /disputes, filtered by tenant, is shared by both
    personas — this is what actually makes the case appear there for the
    merchant analyst to respond to).
    """
    _assert_issuer_only(current_user, "Issuing a chargeback")
    dispute = await _get_or_404(dispute_id, current_user.tenant_id, db)
    if dispute.status == "CHARGEBACK":
        raise HTTPException(status.HTTP_409_CONFLICT, "This dispute has already been charged back.")

    now = datetime.utcnow()
    dispute.status = "CHARGEBACK"
    dispute.lifecycle_stage = "CHARGEBACK"
    dispute.metadata_ = {
        **(dispute.metadata_ or {}),
        "work_status": "ACTION_REQUIRED",
        "chargeback_issued_at": now.isoformat(),
        "chargeback_issued_by": current_user.user_id,
    }
    dispute.updated_at = now
    dispute.current_state_version = dispute.current_state_version + 1

    from packages.persistence.sqlite.models import AuditEventModel
    audit = AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=now,
        actor_id=current_user.user_id,
        actor_type="USER",
        tenant_id=current_user.tenant_id,
        case_id=dispute_id,
        event_type="DISPUTE_CHARGEBACK_ISSUED",
        new_state_version=dispute.current_state_version,
        metadata_={},
    )
    db.add(audit)

    await _notify_customer_sms(
        dispute, current_user, db,
        "Your dispute has been escalated — we've issued a formal chargeback to the "
        "merchant on your behalf. We'll text you again once it's resolved.",
    )
    return _to_response(dispute)


class EvidenceRequestDraftResponse(BaseModel):
    draft_text: str


class DraftMissingDocumentRequestBody(BaseModel):
    cardholder_claim: str
    missing_items: List[str]


@router.post("/disputes/draft-missing-document-request", response_model=EvidenceRequestDraftResponse)
async def draft_missing_document_request_route(
    body: DraftMissingDocumentRequestBody,
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_CREATE)),
):
    """
    README §55: New Case's own version of §52's evidence-request draft — used before a
    case exists at all, while the analyst is still filling in New Case and a mandatory
    document is missing. No dispute_id yet, so nothing is logged/sent here (there's
    nothing real to send to); the analyst copies the draft themselves. Once the case
    exists, §52's dispute_id-scoped draft/send endpoints take over.
    """
    draft = evidence_request_draft.draft_evidence_request(body.cardholder_claim, body.missing_items)
    return EvidenceRequestDraftResponse(draft_text=draft)


@router.post("/disputes/{dispute_id}/evidence-request/draft", response_model=EvidenceRequestDraftResponse)
async def draft_evidence_request_route(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_UPDATE)),
):
    """
    README §52: after a merchant challenges (status REPRESENTMENT), the issuer analyst
    can ask the cardholder for more evidence. Drafts a plain-English request from the
    case's own real open evidence gaps — never a generic template.
    """
    dispute = await _get_or_404(dispute_id, current_user.tenant_id, db)
    gaps_result = await db.execute(
        select(EvidenceGapModel).where(
            EvidenceGapModel.case_id == dispute_id, EvidenceGapModel.status == "OPEN",
        )
    )
    missing_items = [
        (g.expected_evidence_type or g.gap_type or "supporting document").replace("_", " ").title()
        for g in gaps_result.scalars().all()
    ]
    draft = evidence_request_draft.draft_evidence_request(dispute.cardholder_claim, missing_items)
    return EvidenceRequestDraftResponse(draft_text=draft)


class SendEvidenceRequestBody(BaseModel):
    message: str


@router.post("/disputes/{dispute_id}/evidence-request/send", response_model=DisputeResponse)
async def send_evidence_request_route(
    dispute_id: str,
    body: SendEvidenceRequestBody,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_UPDATE)),
):
    """
    Marks the analyst-approved evidence-request draft as sent. No real SMTP is wired
    up (README §45's SMS feature made the same call for the same reason) — this is
    honestly logged as an audit event and a case metadata flag the UI can key off of,
    not a claim of real delivery to the cardholder's inbox.
    """
    dispute = await _get_or_404(dispute_id, current_user.tenant_id, db)
    now = datetime.utcnow()
    dispute.metadata_ = {
        **(dispute.metadata_ or {}),
        "evidence_requested_at": now.isoformat(),
        "evidence_requested_by": current_user.user_id,
    }
    dispute.updated_at = now

    db.add(AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=now,
        actor_id=current_user.user_id,
        actor_type="USER",
        tenant_id=current_user.tenant_id,
        case_id=dispute_id,
        event_type="EVIDENCE_REQUEST_SENT",
        new_state_version=dispute.current_state_version,
        metadata_={"message_preview": body.message[:200]},
    ))
    return _to_response(dispute)


@router.get("/disputes/{dispute_id}", response_model=CaseDetailResponse)
async def get_dispute(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    dispute = await _get_or_404(dispute_id, current_user.tenant_id, db)

    doc_result = await db.execute(
        select(EvidenceModel).where(
            EvidenceModel.case_id == dispute_id,
            EvidenceModel.tenant_id == current_user.tenant_id,
            # Real rows use source_type CARDHOLDER/MERCHANT (README §43), never the
            # literal "DOCUMENT" — source_system is the reliable document-upload
            # marker (README §46.1). See _attach_document below for the same fix.
            EvidenceModel.source_system == "DOCUMENT_STORAGE",
            EvidenceModel.is_current == True,
        )
    )
    documents = doc_result.scalars().all()
    return _to_case_detail(dispute, documents)


@router.get("/disputes/{dispute_id}/documents/{document_id}")
async def get_document_file(
    dispute_id: str,
    document_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.EVIDENCE_READ)),
):
    """
    Serves the actual evidence file for a documentId referenced in the case
    detail's `evidence` array. The JSON never carries file content — this is
    the only place bytes are returned, and only for a documentId that resolves
    to a stored path on this tenant's own case (never a client-supplied path).
    """
    await _get_or_404(dispute_id, current_user.tenant_id, db)

    doc_result = await db.execute(
        select(EvidenceModel).where(
            EvidenceModel.case_id == dispute_id,
            EvidenceModel.tenant_id == current_user.tenant_id,
            EvidenceModel.source_system == "DOCUMENT_STORAGE",
            EvidenceModel.source_record_id == document_id,
        )
    )
    doc = doc_result.scalar_one_or_none()
    if not doc or not doc.content_reference:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")

    file_path = (_STORAGE_ROOT / doc.content_reference).resolve()
    if _STORAGE_ROOT.resolve() not in file_path.parents or not file_path.is_file():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Document not found")

    file_name = (doc.normalized_content or {}).get("fileName", file_path.name)
    media_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
    return FileResponse(file_path, media_type=media_type, filename=file_name)


@router.post("/disputes/{dispute_id}/documents", response_model=EvidenceDocumentInfo, status_code=201)
async def upload_document(
    dispute_id: str,
    file: UploadFile = File(...),
    document_type: Optional[str] = Form(None),
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.EVIDENCE_INGEST)),
):
    """
    Attaches an uploaded file as a real, storage-backed evidence document on
    the case — the file the analyst uploaded in New Case (or afterward) shows
    up in the case's Evidence section immediately, same documentId/storage
    mapping as the seeded demo documents (README §24).

    The document is always summarized from its actual content at attach time
    (never trusting the analyst's original upload filename, e.g. "scan001.pdf")
    — the storage filename and normalized_content.textSummary always come from
    that analysis. The stored evidence_type is auto-classified from content
    UNLESS the caller explicitly provides `document_type` (e.g. New Case's
    per-requirement upload slots — the analyst put this file in the
    "ORDER_INVOICE" slot, so it's stored as ORDER_INVOICE regardless of what
    content classification alone would guess), in which case that's trusted
    as the analyst's actual intent (README §27) and only used as a last-resort
    fallback if extraction fails outright.
    """
    if not file.content_type or file.content_type not in _ALLOWED_DOCUMENT_MIME_TYPES:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Unsupported file type '{file.content_type}' — upload a PDF, PNG, JPEG, or WebP.",
        )
    dispute = await _get_or_404(dispute_id, current_user.tenant_id, db)
    contents = await file.read()
    if not contents:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Uploaded file is empty.")

    # Cyera Validation (README §38, §46) — runs BEFORE anything below: before storage
    # write, before evidence extraction proceeds, before this could ever be
    # vectorized. A flagged document is rejected outright, not saved-with-a-warning.
    # Flag-gated off by default; see _ENABLE_CYERA_VALIDATION above.
    if _ENABLE_CYERA_VALIDATION:
        _run_cyera_validation(contents, file.content_type)

    explicit_type = document_type.strip().upper() if document_type and document_type.strip() else None
    try:
        result = document_understanding.extract_claim_from_document(contents, file.content_type)
        doc_type = explicit_type or result["document_type"]
        document_title = result.get("document_title")
        text_summary = result["text_summary"]
        business_event_date = document_understanding.best_business_event_date(result)
    except Exception:
        doc_type = explicit_type or "OTHER"
        document_title = None
        text_summary = ""
        business_event_date = None

    # Safety net: even if the document itself isn't an ID card, a raw Aadhar/PAN-shaped
    # number could have leaked into the extracted free text (e.g. a letter that quotes
    # one). Redact it before it's ever stored/vectorized, and still flag the upload.
    # Flag-gated off by default; see _ENABLE_CYERA_VALIDATION above.
    if _ENABLE_CYERA_VALIDATION:
        _, touched_fields = pii_guard.scan_and_redact_text_fields({"text_summary": text_summary})
        if touched_fields:
            raise HTTPException(
                status.HTTP_422_UNPROCESSABLE_ENTITY,
                "Cyera Validation: this document appears to contain an unmasked personal ID number "
                "(Aadhar/PAN format). The file was not saved.",
            )

    stored_name = document_understanding.suggested_file_name(doc_type, file.content_type)
    return await _attach_document(
        db, dispute, current_user,
        document_type=doc_type, file_name=stored_name, text_summary=text_summary,
        content=contents, business_event_date=business_event_date, document_title=document_title,
    )


@router.post("/disputes/{dispute_id}/documents/sample", response_model=EvidenceDocumentInfo, status_code=201)
async def attach_sample_document(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.EVIDENCE_INGEST)),
):
    """
    Generates and attaches one realistic (clearly-labeled synthetic) cardholder
    letter PDF built from this case's own data — lets a newly created case have
    a real, viewable evidence document without the analyst needing to source a
    file of their own (e.g. after using "Use Sample Data" in New Case).
    """
    dispute = await _get_or_404(dispute_id, current_user.tenant_id, db)
    m = dispute.metadata_ or {}
    pdf_bytes = sample_letter.generate_cardholder_letter_pdf(
        customer_name=m.get("customer_name", ""),
        merchant_name=m.get("merchant_name", ""),
        amount=m.get("amount_disputed", ""),
        currency=m.get("currency", ""),
        cardholder_claim=dispute.cardholder_claim,
    )
    return await _attach_document(
        db, dispute, current_user,
        document_type="CARDHOLDER_LETTER",
        file_name=document_understanding.suggested_file_name("CARDHOLDER_LETTER", "application/pdf"),
        text_summary=dispute.cardholder_claim,
        content=pdf_bytes,
    )


# ── Private helpers ────────────────────────────────────────────────────────────

def _check_cyera_flags(result: dict) -> None:
    """
    Cyera Validation (README §38, §46) for the merged single-call path — checks the
    is_id_document/id_types fields document_understanding.extract_claim_from_document
    already classified in the same vision call, instead of a second round-trip through
    pii_guard. Only reachable when _ENABLE_CYERA_VALIDATION is true.
    """
    if result.get("is_id_document"):
        id_types = result.get("id_types") or []
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            "Cyera Validation: this document appears to be a "
            f"{'/'.join(t.replace('_', ' ').title() for t in id_types) or 'government identity document'} — a "
            "government identity document. This dispute doesn't call for personal ID documents, and this "
            "platform doesn't accept them as evidence. The file was not saved.",
        )


def _run_cyera_validation(contents: bytes, mime_type: str) -> None:
    """
    Cyera Validation (README §38) — a PII/sensitive-document screen shared by both
    upload endpoints. Renders a PDF's first page to an image the same way document
    understanding does, asks packages/intelligence/pii_guard whether the document
    itself is a government ID document, and raises 422 (never saving/proceeding) if so.
    A screening failure is treated as "not flagged" — never blocks a legitimate upload
    because of a transient error, and pii_guard.check_image_for_pii already never raises.
    """
    try:
        image_bytes = (
            vision_utils.render_pdf_first_page_to_png(contents)
            if mime_type == "application/pdf" else contents
        )
        image_mime = "image/png" if mime_type == "application/pdf" else mime_type
        pii_check = pii_guard.check_image_for_pii(vision_utils.b64_of(image_bytes), image_mime)
    except Exception:
        pii_check = {"is_id_document": False, "id_types": [], "reasoning": ""}

    if pii_check["is_id_document"]:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            "Cyera Validation: this document appears to be a "
            f"{'/'.join(t.replace('_', ' ').title() for t in pii_check['id_types'])} — a government identity "
            "document. This dispute doesn't call for personal ID documents, and this platform doesn't accept "
            "them as evidence. The file was not saved.",
        )


async def _get_or_404(dispute_id: str, tenant_id: str, db: AsyncSession) -> DisputeModel:
    result = await db.execute(
        select(DisputeModel).where(
            DisputeModel.dispute_id == dispute_id,
            DisputeModel.tenant_id == tenant_id,
        )
    )
    dispute = result.scalar_one_or_none()
    if not dispute:
        raise HTTPException(status_code=404, detail="Dispute not found")
    return dispute


async def _assert_valid_status(db: AsyncSession, status_code: str) -> None:
    """
    Enforces PATCH /disputes/:id's status against the real, live set of active codes in
    admin_status_config (README §42) — the same table Admin -> Statuses edits, not a
    second hardcoded list that could quietly drift from it. Before this, status was a
    completely unvalidated free string; any value at all was silently accepted.
    """
    result = await db.execute(
        select(StatusConfigModel.code).where(StatusConfigModel.is_active.is_(True))
    )
    valid_codes = {row[0] for row in result.all()}
    if status_code.upper() not in valid_codes:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"'{status_code}' is not a recognized status. Valid codes: {', '.join(sorted(valid_codes))} "
            "(managed under Admin → Statuses).",
        )


def _assert_issuer_only(current_user: TokenData, action: str) -> None:
    """
    Some actions only ever make sense from the issuer side — issuing a chargeback,
    rejecting the cardholder's claim. Both used to be gated only by the generic
    DISPUTE_UPDATE permission, which merchant_analyst also holds (it needs it for
    its own legitimate updates — accepting/challenging a case), so nothing actually
    stopped a merchant-side token from calling chargeback_dispute directly, or
    PATCHing a case straight to REJECTED, even though neither is ever exposed on
    the merchant UI. Confirmed live during a full end-to-end test (README §80)
    before fixing.

    Checked directly against the JWT's roles claim rather than a new permission —
    matches the same pattern _attach_document already uses to tell CARDHOLDER
    evidence from MERCHANT evidence by role, and needs no admin-config changes.
    Explicitly not applied to the reverse case (an issuer setting APPROVED/
    REPRESENTMENT) — that wasn't part of what was reported, and blocking it without
    being asked risks breaking a real flow that hasn't been checked for one.
    """
    if "merchant_analyst" in current_user.roles:
        raise HTTPException(
            status.HTTP_403_FORBIDDEN,
            f"{action} is an issuer-side action and isn't available to a merchant account.",
        )


async def _notify_customer_sms(
    dispute: DisputeModel, current_user: TokenData, db: AsyncSession, body: str,
) -> None:
    """
    Best-effort SMS to the cardholder (README §45, packages/connectors/sms.py) — never
    raises, never blocks or rolls back the real state change it's announcing. Writes an
    audit event either way (SMS_SENT / SMS_NOT_SENT with the reason) so a skipped or
    failed send is visible in the case's own audit trail, not a silent no-op — matches
    this platform's "make the change visible" rule (README §36/§43) applied to a
    notification going to someone outside the app entirely.
    """
    from packages.connectors import sms
    from packages.persistence.sqlite.models import AuditEventModel

    phone = (dispute.metadata_ or {}).get("customer_phone")
    result = await sms.send_sms(phone, body)
    db.add(AuditEventModel(
        audit_id=str(uuid.uuid4()),
        timestamp=datetime.utcnow(),
        actor_id="system",
        actor_type="SYSTEM",
        tenant_id=current_user.tenant_id,
        case_id=dispute.dispute_id,
        event_type="SMS_SENT" if result.success else "SMS_NOT_SENT",
        metadata_={} if result.success else {"reason": result.error},
    ))


async def _attach_document(
    db: AsyncSession, dispute: DisputeModel, current_user: TokenData,
    document_type: str, file_name: str, content: bytes, text_summary: str = "",
    business_event_date: Optional[str] = None, document_title: Optional[str] = None,
) -> "EvidenceDocumentInfo":
    """Shared by upload_document and attach_sample_document: writes the file
    to storage/disputes/<dispute_id>/, then records it as a DOCUMENT evidence
    row (README §24's documentId -> storage-file mapping).

    `business_event_date` (from document_understanding.best_business_event_date)
    is the actual real-world date the document is about (e.g. the transaction
    date on a receipt), not when it was uploaded — this is what the Event
    Timeline's `event_time` should reflect, kept distinct from `received_time`
    (the actual upload moment), matching the page's own "business event time —
    not ingestion time" claim. Falls back to upload time honestly when no date
    could be extracted, rather than fabricating one.
    """
    # README §46.1: this used to filter on source_type == "DOCUMENT", a value no
    # evidence row has ever actually been stored with (real rows use CARDHOLDER/
    # MERCHANT, README §43) — so this always counted 0 existing documents, every
    # upload got document_id "DOC-001", and the second document on any case hit a
    # real UNIQUE(case_id, source_type, source_record_id, version) violation and
    # 500'd. source_system is the reliable document-upload marker instead.
    existing_result = await db.execute(
        select(EvidenceModel).where(
            EvidenceModel.case_id == dispute.dispute_id,
            EvidenceModel.source_system == "DOCUMENT_STORAGE",
        )
    )
    next_idx = len(existing_result.scalars().all()) + 1
    document_id = f"DOC-{next_idx:03d}"

    safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", file_name) or "document"
    stored_name = f"{document_id}_{safe_name}"
    dispute_dir = _STORAGE_ROOT / dispute.dispute_id
    dispute_dir.mkdir(parents=True, exist_ok=True)
    (dispute_dir / stored_name).write_bytes(content)

    now = datetime.utcnow()
    event_time = now
    if business_event_date:
        try:
            event_time = datetime.strptime(business_event_date, "%Y-%m-%d")
        except ValueError:
            pass
    evidence_id = str(uuid.uuid4())
    # Who this evidence represents matters, not just that a file was uploaded — the
    # hackathon scenario ("merchant provides material evidence late, contradicting the
    # customer's original description") only means anything if a merchant's document
    # is distinguishable from the cardholder/issuer's own, so contradiction detection
    # (evidence_reassessment_service, README §43) has two actual sides to compare.
    source_type = "MERCHANT" if "merchant_analyst" in current_user.roles else "CARDHOLDER"
    normalized_content = {
        "documentId": document_id, "documentType": document_type,
        "fileName": safe_name, "textSummary": text_summary,
        # A short (2-4 word) real display name for this specific document — "Cancellation
        # Policy", not a truncated sentence from text_summary — see document_understanding
        # .py's document_title field. Null for documents attached before this existed
        # (attach_sample_document, older uploads); the frontend falls back to the type's
        # generic label rather than a chopped-summary heuristic (README §72).
        "documentTitle": document_title,
    }
    evidence = EvidenceModel(
        evidence_id=evidence_id,
        case_id=dispute.dispute_id,
        tenant_id=current_user.tenant_id,
        source_type=source_type,
        source_system="DOCUMENT_STORAGE",
        source_record_id=document_id,
        evidence_type=document_type,
        version=1,
        normalized_content=normalized_content,
        content_reference=f"{dispute.dispute_id}/{stored_name}",
        event_time=event_time,
        received_time=now,
        effective_time=now,
        content_hash=hashlib.sha256(content).hexdigest(),
        materiality=materiality.assess(document_type, normalized_content, source_type),
        quality="UNVERIFIED",
        is_current=True,
        created_at=now,
    )
    db.add(evidence)
    await evidence_reassessment_service.process_new_evidence(dispute, evidence, db)
    db.add(ProvenanceModel(
        provenance_id=str(uuid.uuid4()),
        evidence_id=evidence_id,
        source_type="DOCUMENT",
        source_system="DOCUMENT_STORAGE",
        source_record_id=document_id,
        retrieval_method="ANALYST_UPLOAD",
        retrieved_by=current_user.user_id,
        retrieved_at=now,
        verified=False,
        chain_of_custody=[{"actor": current_user.user_id, "action": "UPLOADED", "at": now.isoformat()}],
    ))
    await db.flush()

    return EvidenceDocumentInfo(
        evidenceId=evidence_id, documentId=document_id,
        documentType=document_type, fileName=safe_name, textSummary=text_summary,
    )


def _to_response(d: DisputeModel) -> DisputeResponse:
    m = d.metadata_ or {}
    score = priority_scoring.compute_priority_score(
        _as_float(m.get("amount_disputed")), m.get("card_tier"), d.deadline, datetime.utcnow(),
    )
    return DisputeResponse(
        dispute_id=d.dispute_id,
        tenant_id=d.tenant_id,
        status=d.status,
        dispute_type=d.dispute_type,
        lifecycle_stage=d.lifecycle_stage,
        priority=d.priority,
        current_state_version=d.current_state_version,
        cardholder_claim=d.cardholder_claim,
        transaction_reference=d.transaction_reference,
        deadline=d.deadline,
        created_at=d.created_at,
        updated_at=d.updated_at,
        metadata=m,
        claim_id=d.claim_id,
        priority_score=score["score"],
        days_remaining=score["days_remaining"],
        is_archived=bool(d.is_archived),
    )


def _as_float(v) -> Optional[float]:
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _to_case_detail(d: DisputeModel, documents: List[EvidenceModel]) -> CaseDetailResponse:
    m = d.metadata_ or {}
    score = priority_scoring.compute_priority_score(
        _as_float(m.get("amount_disputed")), m.get("card_tier"), d.deadline, datetime.utcnow(),
    )
    return CaseDetailResponse(
        caseId=d.dispute_id,
        cardholder=CardholderInfo(
            customerId=m.get("customer_id"),
            name=m.get("customer_name"),
            maskedCardNumber=m.get("masked_card_number"),
            authenticationStatus=m.get("authentication_status"),
            cardTier=m.get("card_tier"),
            phone=m.get("customer_phone"),
        ),
        transaction=TransactionInfo(
            transactionId=m.get("transaction_id") or d.transaction_reference,
            merchantName=m.get("merchant_name"),
            amount=_as_float(m.get("amount_disputed")),
            currency=m.get("currency"),
            transactionDate=m.get("transaction_date"),
            postingDate=m.get("posting_date"),
            merchantId=m.get("merchant_id"),
            merchantCategoryCode=m.get("merchant_category_code"),
            transactionChannel=m.get("transaction_channel"),
        ),
        dispute=DisputeDetail(
            disputeType=d.dispute_type,
            disputeAmount=_as_float(m.get("amount_disputed")),
            description=d.cardholder_claim,
            returnDate=m.get("return_date"),
            expectedRefundAmount=_as_float(m.get("expected_refund_amount")),
            expectedRefundDate=m.get("expected_refund_date"),
            merchantContacted=m.get("merchant_contacted"),
            merchantContactDate=m.get("merchant_contact_date"),
            merchantResponse=m.get("merchant_response"),
            refundReferenceNumber=m.get("refund_reference_number"),
        ),
        evidence=[
            EvidenceDocumentInfo(
                evidenceId=doc.evidence_id,
                documentId=doc.source_record_id,
                documentType=doc.evidence_type,
                fileName=(doc.normalized_content or {}).get("fileName", ""),
                textSummary=(doc.normalized_content or {}).get("textSummary") or None,
            )
            for doc in documents
        ],
        dispute_id=d.dispute_id,
        tenant_id=d.tenant_id,
        status=d.status,
        dispute_type=d.dispute_type,
        lifecycle_stage=d.lifecycle_stage,
        priority=d.priority,
        current_state_version=d.current_state_version,
        transaction_reference=d.transaction_reference,
        cardholder_claim=d.cardholder_claim,
        deadline=d.deadline,
        created_at=d.created_at,
        updated_at=d.updated_at,
        metadata=m,
        claim_id=d.claim_id,
        priority_score=score["score"],
        days_remaining=score["days_remaining"],
        is_archived=bool(d.is_archived),
    )
