"""
Sub-resource routes for a dispute:
  GET /disputes/{id}/hypotheses
  GET /disputes/{id}/contradictions
  GET /disputes/{id}/recommendation
  GET /disputes/{id}/timeline
  GET /disputes/{id}/changes
  GET /disputes/{id}/evidence-completeness
  GET /disputes/{id}/precedents
  POST /disputes/{id}/classify-reason-code
  POST /disputes/{id}/representment-draft
  POST /disputes/{id}/ask
"""
from datetime import datetime
from typing import List, Optional

import uuid

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.intelligence import scheme_rules, faiss_index, reason_code_classifier, representment, case_qa
from packages.intelligence import evidence_requirements, eval_service
from packages.persistence.sqlite.database import get_session, AsyncSessionLocal
from packages.persistence.sqlite.models import (
    DisputeModel, HypothesisModel, ContradictionModel,
    RecommendationModel, TimelineEventModel, AuditEventModel, EvidenceGapModel,
    EvidenceModel, AIEvalScoreModel,
)
from packages.security.auth import TokenData
from packages.security.rbac import Permissions, require_permission

router = APIRouter()


# ── Response schemas ───────────────────────────────────────────────────────────

class HypothesisResponse(BaseModel):
    hypothesis_id: str
    case_id: str
    description: str
    status: str
    confidence_score: Optional[float]
    confidence_descriptor: Optional[str]
    supporting_evidence_ids: List[str]
    weakening_evidence_ids: List[str]
    unresolved_questions: List[str]
    reasoning: Optional[str]
    created_at: datetime


class ContradictionResponse(BaseModel):
    contradiction_id: str
    case_id: str
    description: str
    evidence_a_id: str
    evidence_b_id: str
    conflict_type: str
    materiality: str
    status: str
    created_at: datetime


class RecommendationResponse(BaseModel):
    model_config = {"protected_namespaces": ()}  # model_version is a domain field, not pydantic internals

    recommendation_id: str
    case_id: str
    version: int
    content: str
    recommendation_type: str
    confidence_score: Optional[float]
    confidence_descriptor: Optional[str]
    uncertainty_statement: Optional[str]
    is_current: bool
    is_stale: bool
    stale_reason: Optional[str]
    change_reason: Optional[str]
    previous_recommendation_id: Optional[str]
    supporting_evidence_ids: List[str]
    model_version: Optional[str]
    prompt_version: Optional[str]
    graph_version: Optional[str]
    evidence_state_version: Optional[int]
    created_at: datetime


class TimelineEventResponse(BaseModel):
    event_id: str
    case_id: str
    event_type: str
    event_time: datetime
    recorded_time: datetime
    actor: Optional[str]
    description: Optional[str]
    is_disputed: bool
    confidence: float


class EvidenceGapResponse(BaseModel):
    gap_id: str
    case_id: str
    gap_type: str
    description: Optional[str]
    materiality: Optional[str]
    expected_source: Optional[str]
    expected_evidence_type: Optional[str]
    status: str
    created_at: datetime


class RegulatoryPassageResponse(BaseModel):
    title: str
    text: str
    similarity: float
    source: str = "platform_policy"
    page: Optional[int] = None
    network: Optional[str] = None
    doc_type: Optional[str] = None


class EligibilityResponse(BaseModel):
    within_deadline: Optional[bool]
    days_elapsed: Optional[int]
    deadline_days: Optional[int]
    note: str


class EvidenceCompletenessResponse(BaseModel):
    rule_found: bool
    network: Optional[str]
    reason_code: Optional[str]
    completeness_pct: Optional[int]
    satisfied: List[str]
    missing_required: List[str]
    checklist: List[str]
    regulatory_passages: List[RegulatoryPassageResponse] = []
    eligibility: EligibilityResponse


class PrecedentEntry(BaseModel):
    dispute_id: str
    dispute_type: str
    recommendation_type: str
    confidence_score: Optional[float]
    outcome: Optional[str]
    similarity: float


class PrecedentsResponse(BaseModel):
    dispute_id: str
    entries: List[PrecedentEntry]
    note: Optional[str] = None


class CitationResponse(BaseModel):
    source: str
    page: Optional[int]
    title: str


class StandardReferenceResponse(BaseModel):
    network: str
    code: str
    label: str


class ClassifyReasonCodeResponse(BaseModel):
    suggested_code: str
    confidence: float
    rationale: str
    citation: Optional[CitationResponse]
    disclaimer: str
    # Deterministic Visa/Mastercard reference table fallback (README §76) — not RAG-
    # grounded, not an LLM output. None when the table has no confident entry for
    # this dispute_type (never guessed rather than leaving this out silently wrong).
    standard_reference: Optional[StandardReferenceResponse] = None


class RepresentmentDraftResponse(BaseModel):
    draft_text: str
    citations: List[CitationResponse]


class AskCaseRequest(BaseModel):
    question: str


class AskCaseResponse(BaseModel):
    answer: str
    can_answer: bool
    citations: List[CitationResponse]


class ChangeResponse(BaseModel):
    audit_id: str
    timestamp: datetime
    event_type: str
    actor_id: str
    actor_type: str
    new_state_version: Optional[int]
    evidence_refs: List[str]


# ── Helpers ────────────────────────────────────────────────────────────────────

async def _check_dispute(dispute_id: str, tenant_id: str, db: AsyncSession) -> None:
    result = await db.execute(
        select(DisputeModel).where(
            DisputeModel.dispute_id == dispute_id,
            DisputeModel.tenant_id == tenant_id,
        )
    )
    if not result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Dispute not found")


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.get("/disputes/{dispute_id}/hypotheses", response_model=List[HypothesisResponse])
async def get_hypotheses(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    await _check_dispute(dispute_id, current_user.tenant_id, db)
    result = await db.execute(
        select(HypothesisModel)
        .where(HypothesisModel.case_id == dispute_id)
        .order_by(HypothesisModel.confidence_score.desc())
    )
    return [
        HypothesisResponse(
            hypothesis_id=h.hypothesis_id,
            case_id=h.case_id,
            description=h.description,
            status=h.status,
            confidence_score=h.confidence_score,
            confidence_descriptor=h.confidence_descriptor,
            supporting_evidence_ids=h.supporting_evidence_ids or [],
            weakening_evidence_ids=h.weakening_evidence_ids or [],
            unresolved_questions=h.unresolved_questions or [],
            reasoning=h.reasoning,
            created_at=h.created_at,
        )
        for h in result.scalars().all()
    ]


@router.get("/disputes/{dispute_id}/contradictions", response_model=List[ContradictionResponse])
async def get_contradictions(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    await _check_dispute(dispute_id, current_user.tenant_id, db)
    result = await db.execute(
        select(ContradictionModel)
        .where(ContradictionModel.case_id == dispute_id)
        .order_by(ContradictionModel.created_at.desc())
    )
    return [
        ContradictionResponse(
            contradiction_id=c.contradiction_id,
            case_id=c.case_id,
            description=c.description,
            evidence_a_id=c.evidence_a_id,
            evidence_b_id=c.evidence_b_id,
            conflict_type=c.conflict_type,
            materiality=c.materiality,
            status=c.status,
            created_at=c.created_at,
        )
        for c in result.scalars().all()
    ]


@router.get("/disputes/{dispute_id}/recommendation", response_model=RecommendationResponse)
async def get_recommendation(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    await _check_dispute(dispute_id, current_user.tenant_id, db)
    result = await db.execute(
        select(RecommendationModel).where(
            RecommendationModel.case_id == dispute_id,
            RecommendationModel.is_current == True,
        )
    )
    rec = result.scalar_one_or_none()
    if not rec:
        raise HTTPException(status_code=404, detail="No current recommendation")
    return RecommendationResponse(
        recommendation_id=rec.recommendation_id,
        case_id=rec.case_id,
        version=rec.version,
        content=rec.content,
        recommendation_type=rec.recommendation_type,
        confidence_score=rec.confidence_score,
        confidence_descriptor=rec.confidence_descriptor,
        uncertainty_statement=rec.uncertainty_statement,
        is_current=rec.is_current,
        is_stale=rec.is_stale,
        stale_reason=rec.stale_reason,
        change_reason=rec.change_reason,
        previous_recommendation_id=rec.previous_recommendation_id,
        supporting_evidence_ids=rec.supporting_evidence_ids or [],
        model_version=rec.model_version,
        prompt_version=rec.prompt_version,
        graph_version=rec.graph_version,
        evidence_state_version=rec.evidence_state_version,
        created_at=rec.created_at,
    )


@router.get("/disputes/{dispute_id}/timeline", response_model=List[TimelineEventResponse])
async def get_timeline(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    await _check_dispute(dispute_id, current_user.tenant_id, db)
    result = await db.execute(
        select(TimelineEventModel)
        .where(TimelineEventModel.case_id == dispute_id)
        .order_by(TimelineEventModel.event_time.asc())
    )
    return [
        TimelineEventResponse(
            event_id=t.event_id,
            case_id=t.case_id,
            event_type=t.event_type,
            event_time=t.event_time,
            recorded_time=t.recorded_time,
            actor=t.actor,
            description=t.description,
            is_disputed=t.is_disputed,
            confidence=t.confidence,
        )
        for t in result.scalars().all()
    ]


@router.get("/disputes/{dispute_id}/gaps", response_model=List[EvidenceGapResponse])
async def get_evidence_gaps(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    await _check_dispute(dispute_id, current_user.tenant_id, db)
    result = await db.execute(
        select(EvidenceGapModel)
        .where(EvidenceGapModel.case_id == dispute_id, EvidenceGapModel.status == "OPEN")
        .order_by(EvidenceGapModel.created_at.asc())
    )
    return [
        EvidenceGapResponse(
            gap_id=g.gap_id, case_id=g.case_id, gap_type=g.gap_type,
            description=g.description, materiality=g.materiality,
            expected_source=g.expected_source, expected_evidence_type=g.expected_evidence_type,
            status=g.status, created_at=g.created_at,
        )
        for g in result.scalars().all()
    ]


@router.get("/disputes/{dispute_id}/evidence-completeness", response_model=EvidenceCompletenessResponse)
async def get_evidence_completeness(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    """
    Deterministic, scheme-aware evidence-completeness check — computed live
    against current evidence, not cached from the last agent run.
    """
    result = await db.execute(
        select(DisputeModel).where(
            DisputeModel.dispute_id == dispute_id,
            DisputeModel.tenant_id == current_user.tenant_id,
        )
    )
    dispute = result.scalar_one_or_none()
    if not dispute:
        raise HTTPException(status_code=404, detail="Dispute not found")

    metadata = dispute.metadata_ or {}
    network = metadata.get("network")
    reason_code = metadata.get("reason_code")

    ev_result = await db.execute(
        select(EvidenceModel).where(
            EvidenceModel.case_id == dispute_id,
            EvidenceModel.is_current == True,
        )
    )
    evidence_list = [{"evidence_type": e.evidence_type} for e in ev_result.scalars().all()]

    dispute_type_rules = await evidence_requirements.load_active(db)
    assessment = scheme_rules.assess_completeness(
        network, reason_code, evidence_list, dispute.dispute_type, dispute_type_rules,
    )
    eligibility = scheme_rules.assess_eligibility(network, reason_code, dispute.created_at, datetime.utcnow())

    # Retrieval-grounded passages — additive to the deterministic checklist above,
    # not a replacement. Best-effort; an empty list here just means no passage cleared
    # the retrieval threshold, not that the deterministic check above is wrong.
    regulatory_passages: list[dict] = []
    try:
        query = f"{dispute.dispute_type} {network or ''} {reason_code or ''} evidence requirements"
        regulatory_passages = faiss_index.find_regulatory_context(
            query, top_k=2, network=(network or "").upper() or None
        )
    except Exception:
        pass

    return EvidenceCompletenessResponse(
        network=network,
        reason_code=reason_code,
        regulatory_passages=[RegulatoryPassageResponse(**p) for p in regulatory_passages],
        eligibility=EligibilityResponse(**eligibility),
        **assessment,
    )


@router.get("/disputes/{dispute_id}/precedents", response_model=PrecedentsResponse)
async def get_precedents(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    """
    Similar past cases and how they resolved — computed live from the precedent vector
    collection (packages/intelligence/faiss_index), written whenever the agent produces
    a recommendation for any case. Tenant-scoped, excludes the current dispute itself.
    """
    result = await db.execute(
        select(DisputeModel).where(
            DisputeModel.dispute_id == dispute_id,
            DisputeModel.tenant_id == current_user.tenant_id,
        )
    )
    dispute = result.scalar_one_or_none()
    if not dispute:
        raise HTTPException(status_code=404, detail="Dispute not found")

    metadata = dispute.metadata_ or {}
    entries: list[dict] = []
    try:
        entries = faiss_index.find_precedents(
            current_user.tenant_id, dispute.dispute_type,
            metadata.get("network"), metadata.get("reason_code"),
            exclude_dispute_id=dispute_id, top_k=3,
        )
    except Exception:
        pass

    return PrecedentsResponse(
        dispute_id=dispute_id,
        entries=[PrecedentEntry(**e) for e in entries],
        note=None if entries else (
            "No similar past case has a recommendation in this tenant yet. Precedents are "
            "written automatically whenever the agent produces a recommendation for any "
            "dispute (packages/agent/runner.py) — run the agent on a second, similarly "
            "typed case to populate this."
        ),
    )


@router.get("/disputes/{dispute_id}/changes", response_model=List[ChangeResponse])
async def get_changes(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    """Material state changes — audit events that represent evidence or recommendation changes."""
    await _check_dispute(dispute_id, current_user.tenant_id, db)
    CHANGE_EVENTS = {
        "EVIDENCE_RECEIVED", "EVIDENCE_CHANGED", "EVIDENCE_SUPERSEDED",
        "RECOMMENDATION_CREATED", "RECOMMENDATION_STALE", "POSSIBLE_DUPLICATE_DETECTED",
    }
    result = await db.execute(
        select(AuditEventModel)
        .where(
            AuditEventModel.case_id == dispute_id,
            AuditEventModel.tenant_id == current_user.tenant_id,
            AuditEventModel.event_type.in_(CHANGE_EVENTS),
        )
        .order_by(AuditEventModel.timestamp.desc())
    )
    return [
        ChangeResponse(
            audit_id=e.audit_id,
            timestamp=e.timestamp,
            event_type=e.event_type,
            actor_id=e.actor_id,
            actor_type=e.actor_type,
            new_state_version=e.new_state_version,
            evidence_refs=e.evidence_refs or [],
        )
        for e in result.scalars().all()
    ]


async def _load_dispute_context(dispute_id: str, tenant_id: str, db: AsyncSession) -> DisputeModel:
    result = await db.execute(
        select(DisputeModel).where(
            DisputeModel.dispute_id == dispute_id, DisputeModel.tenant_id == tenant_id,
        )
    )
    dispute = result.scalar_one_or_none()
    if not dispute:
        raise HTTPException(status_code=404, detail="Dispute not found")
    return dispute


@router.post("/disputes/{dispute_id}/classify-reason-code", response_model=ClassifyReasonCodeResponse)
async def classify_reason_code(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    """
    On-demand (not automatic): retrieval-grounded reason-code suggestion, not a
    certified classification — see packages/intelligence/reason_code_classifier.py.
    """
    dispute = await _load_dispute_context(dispute_id, current_user.tenant_id, db)
    metadata = dispute.metadata_ or {}
    result = reason_code_classifier.suggest_reason_code(
        dispute.dispute_type, dispute.cardholder_claim, metadata.get("network"),
    )
    return ClassifyReasonCodeResponse(**result)


@router.post("/disputes/{dispute_id}/representment-draft", response_model=RepresentmentDraftResponse)
async def representment_draft(
    dispute_id: str,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    """On-demand: LLM representment draft grounded in the case's recommendation, open
    evidence gaps, and network-scoped regulatory passages — see
    packages/intelligence/representment.py. Does not persist anything; the caller
    (ResponseBuilder in the frontend) is responsible for the actual submission."""
    dispute = await _load_dispute_context(dispute_id, current_user.tenant_id, db)
    metadata = dispute.metadata_ or {}

    rec_result = await db.execute(
        select(RecommendationModel).where(
            RecommendationModel.case_id == dispute_id, RecommendationModel.is_current == True,
        )
    )
    rec = rec_result.scalar_one_or_none()

    ev_result = await db.execute(
        select(EvidenceModel).where(EvidenceModel.case_id == dispute_id, EvidenceModel.is_current == True)
    )
    evidence_types = [e.evidence_type for e in ev_result.scalars().all()]

    gaps_result = await db.execute(
        select(EvidenceGapModel).where(EvidenceGapModel.case_id == dispute_id, EvidenceGapModel.status == "OPEN")
    )
    gap_descriptions = [g.description for g in gaps_result.scalars().all() if g.description]

    result = representment.generate_representment_draft(
        dispute.dispute_type, dispute.cardholder_claim, metadata.get("network"),
        rec.content if rec else "No recommendation generated yet.",
        evidence_types, gap_descriptions,
    )
    return RepresentmentDraftResponse(**result)


async def _score_case_qa_in_background(
    tenant_id: str, dispute_id: str, question: str, answer: str, retrieval_context: list[str],
) -> None:
    """
    Runs after the real answer is already back with the analyst — a judging
    failure or slow judge call must never affect the Q&A feature itself.
    Opens its own DB session since the request's session is long closed by
    the time a FastAPI BackgroundTask actually runs (README §30).
    """
    scores = eval_service.evaluate_case_qa(question, answer, retrieval_context)
    if not scores:
        return
    async with AsyncSessionLocal() as db:
        now = datetime.utcnow()
        for s in scores:
            db.add(AIEvalScoreModel(
                eval_id=str(uuid.uuid4()),
                tenant_id=tenant_id,
                case_id=dispute_id,
                feature="case_qa",
                metric=s["metric"],
                score=s["score"],
                passed=s["passed"],
                reason=s["reason"],
                input_text=question[:500],
                created_at=now,
            ))
        await db.commit()


@router.post("/disputes/{dispute_id}/ask", response_model=AskCaseResponse)
async def ask_case_question(
    dispute_id: str,
    body: AskCaseRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_session),
    current_user: TokenData = Depends(require_permission(Permissions.DISPUTE_READ)),
):
    """Stateless, source-grounded Q&A about this specific case — see
    packages/intelligence/case_qa.py. One question at a time, no persisted history."""
    dispute = await _load_dispute_context(dispute_id, current_user.tenant_id, db)
    metadata = dispute.metadata_ or {}

    rec_result = await db.execute(
        select(RecommendationModel).where(
            RecommendationModel.case_id == dispute_id, RecommendationModel.is_current == True,
        )
    )
    rec = rec_result.scalar_one_or_none()

    gaps_result = await db.execute(
        select(EvidenceGapModel).where(EvidenceGapModel.case_id == dispute_id, EvidenceGapModel.status == "OPEN")
    )
    gap_descriptions = [g.description for g in gaps_result.scalars().all() if g.description]

    result = case_qa.ask_case(
        body.question, dispute.dispute_type, metadata.get("network"), dispute.cardholder_claim,
        rec.content if rec else "", gap_descriptions,
    )
    retrieval_context = result.pop("_retrieval_context", [])

    if eval_service.ENABLED:
        background_tasks.add_task(
            _score_case_qa_in_background,
            current_user.tenant_id, dispute_id, body.question, result["answer"], retrieval_context,
        )

    return AskCaseResponse(**result)
