"""
Dispute state-invalidation service.

Business logic for what happens when material evidence changes a case's
state: the current recommendation is marked stale, and any approval (or
already-approved CLASS_C action) reviewed against a now-superseded state
version is invalidated. Extracted out of the evidence route so it's callable
and testable independently of the HTTP layer (Z2: never authorize action
against a stale approval).
"""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.persistence.sqlite.models import ApprovalModel, ActionModel, RecommendationModel


async def mark_recommendation_stale(dispute_id: str, reason: str, db: AsyncSession) -> None:
    result = await db.execute(
        select(RecommendationModel).where(
            RecommendationModel.case_id == dispute_id,
            RecommendationModel.is_current == True,
            RecommendationModel.is_stale == False,
        )
    )
    rec = result.scalar_one_or_none()
    if rec:
        rec.is_stale = True
        rec.stale_reason = reason


async def mark_approvals_stale(dispute_id: str, new_state_version: int, reason: str, db: AsyncSession) -> None:
    """Z2: an ACTIVE approval reviewed against a prior state_version must not
    authorize execution once material evidence has advanced the case state."""
    result = await db.execute(
        select(ApprovalModel).where(
            ApprovalModel.case_id == dispute_id,
            ApprovalModel.status == "ACTIVE",
            ApprovalModel.state_version_reviewed < new_state_version,
        )
    )
    for approval in result.scalars().all():
        approval.status = "STALE"
        approval.stale_reason = reason

    # Already-approved CLASS_C actions relying on those approvals must be
    # re-reviewed before they can execute.
    action_result = await db.execute(
        select(ActionModel).where(
            ActionModel.case_id == dispute_id,
            ActionModel.action_class == "CLASS_C",
            ActionModel.status == "APPROVED",
        )
    )
    for action in action_result.scalars().all():
        action.status = "STALE"


async def apply_material_evidence_change(dispute, new_state_version: int, reason: str, db: AsyncSession) -> None:
    """Single entry point a route calls when HIGH-materiality evidence lands:
    advances the case's state version and cascades staleness to the
    recommendation and any approvals/actions reviewed against the old state."""
    dispute.current_state_version = new_state_version
    await mark_recommendation_stale(dispute.dispute_id, reason, db)
    await mark_approvals_stale(dispute.dispute_id, new_state_version, reason, db)
