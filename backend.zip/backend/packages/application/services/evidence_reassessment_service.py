"""
Late-material-evidence handling — the hackathon problem statement's core scenario:
"A merchant provides material evidence late, contradicting the customer's original
description. The solution must incorporate it, reassess dependent conclusions and make
the change visible."

This was previously only implemented inside `POST /disputes/:id/evidence`
(apps/api/routes/v1/evidence.py) — a route no frontend anywhere actually calls. The real,
reachable evidence-submission path (a merchant/analyst uploading a document —
apps/api/routes/v1/disputes.py's _attach_document, used by both New Case and
MerchantWorkspace) never ran contradiction detection, never assessed materiality beyond a
hardcoded MEDIUM, never invalidated a stale approval (Z2), and never told a connected
analyst anything had changed. Extracted here so both the document-upload path and the
structured evidence-ingest route call the exact same logic instead of drifting apart the
way this session's earlier bugs kept happening.

Also broadened from the original: contradiction detection used to only run when new
evidence superseded a PRIOR VERSION of the exact same (source_type, source_record_id) —
which never fires for a merchant's first-ever submission contradicting the cardholder's
original claim, the actual scenario asked for. Now checks every new evidence item against
everything currently on the case, regardless of whether it's superseding anything.
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.application.services import dispute_state_service
from packages.intelligence import materiality as mat_engine
from packages.persistence.sqlite.models import (
    ContradictionModel, DisputeModel, EvidenceModel,
)


async def _detect_contradictions(dispute_id: str, new_ev: EvidenceModel, db: AsyncSession) -> list[ContradictionModel]:
    """Same evidence type from a different source is a potential factual conflict —
    e.g. the cardholder's CARDHOLDER_LETTER narrative vs. the merchant's
    MERCHANT_COMMUNICATION response. Deliberately simple/deterministic (a real
    disagreement-detector would need the agent's own LLM reasoning, which already runs
    separately in assess_evidence) — this is the fast, structured signal the UI's
    Contradictions panel and the Digital Twin timeline (README §36) render directly,
    without waiting for the analyst to manually re-run the agent."""
    existing_result = await db.execute(
        select(EvidenceModel).where(
            EvidenceModel.case_id == dispute_id,
            EvidenceModel.is_current == True,
            EvidenceModel.evidence_id != new_ev.evidence_id,
        )
    )
    existing = existing_result.scalars().all()

    created: list[ContradictionModel] = []
    for ev in existing:
        if ev.evidence_type == new_ev.evidence_type and ev.source_type != new_ev.source_type:
            dup_check = await db.execute(
                select(ContradictionModel).where(
                    ContradictionModel.case_id == dispute_id,
                    ContradictionModel.evidence_a_id == ev.evidence_id,
                    ContradictionModel.evidence_b_id == new_ev.evidence_id,
                )
            )
            if dup_check.scalar_one_or_none():
                continue
            contradiction = ContradictionModel(
                contradiction_id=str(uuid.uuid4()),
                case_id=dispute_id,
                description=f"Conflicting {new_ev.evidence_type} from {ev.source_type} vs {new_ev.source_type}",
                evidence_a_id=ev.evidence_id,
                evidence_b_id=new_ev.evidence_id,
                conflict_type="SOURCE_DISAGREEMENT",
                materiality=new_ev.materiality,
                status="OPEN",
                created_at=datetime.utcnow(),
            )
            db.add(contradiction)
            created.append(contradiction)
    return created


def _broadcast_evidence_changed(dispute_id: str, evidence_id: str, version: int, materiality: str) -> None:
    """Best-effort SSE push to DisputeCommandCenter.tsx's live connection (the
    "New evidence received" banner) — never blocks or fails the actual evidence
    write if no one is currently connected or the broadcast fails for any reason."""
    try:
        from apps.api.routes.v1.agents import _sse_queues
        q = _sse_queues.get(dispute_id)
        if q:
            event = f"data: {json.dumps({'type': 'EVIDENCE_CHANGED', 'evidence_id': evidence_id, 'version': version, 'materiality': materiality})}\n\n"
            q.put_nowait(event)
    except Exception:
        pass


async def process_new_evidence(
    dispute: DisputeModel, evidence: EvidenceModel, db: AsyncSession,
    reassess_materiality: bool = False,
) -> dict[str, Any]:
    """
    Call once per new EvidenceModel row, after it's been added to the session but
    before commit. Runs the full "incorporate it, reassess dependent conclusions, make
    the change visible" pipeline:
      1. (optional) re-assess materiality with the rule-based engine, if the caller
         passed a placeholder value rather than a real assessment
      2. detect contradictions against every other current evidence item on the case
      3. if HIGH materiality: invalidate the current recommendation and any approval
         reviewed against the now-stale state (Z2)
      4. broadcast EVIDENCE_CHANGED over SSE so a connected analyst sees it live

    Returns {"materiality": str, "contradictions_found": int, "stale_triggered": bool}
    for the caller to include in its own response/audit event if useful.
    """
    if reassess_materiality:
        evidence.materiality = mat_engine.assess(
            evidence.evidence_type, evidence.normalized_content or {}, evidence.source_type
        )

    contradictions = await _detect_contradictions(dispute.dispute_id, evidence, db)

    stale_triggered = False
    if evidence.materiality == "HIGH":
        stale_triggered = True
        await dispute_state_service.apply_material_evidence_change(
            dispute,
            dispute.current_state_version + 1,
            f"New {evidence.evidence_type} evidence received ({evidence.source_type})",
            db,
        )

    _broadcast_evidence_changed(dispute.dispute_id, evidence.evidence_id, evidence.version, evidence.materiality)

    return {
        "materiality": evidence.materiality,
        "contradictions_found": len(contradictions),
        "stale_triggered": stale_triggered,
    }
