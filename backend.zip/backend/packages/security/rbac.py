"""
RBAC — Role-Based Access Control

Three personas, deliberately kept to three:
  issuer_analyst  — Issuer-side investigation: view cases, ingest evidence, view
                     recommendations, propose actions. Screens: My Work / My Cases /
                     Search + per-dispute case context.
  merchant_analyst — Merchant-side investigation and response, same shape as the
                     issuer analyst, scoped to the merchant portal.
  admin           — Back-office configuration only: statuses, outcomes, roles &
                     permissions, users, integrations. Not an operational persona —
                     admin does not see the dispute queues or case screens; it also
                     carries every permission (including action:approve), so it is the
                     approver of record for CLASS_C actions on both sides, even though
                     the current sidebar doesn't surface an approval screen for it.
"""
from functools import wraps
from typing import Callable, List, Optional

from fastapi import Depends, HTTPException, status

from packages.security.auth import get_current_user, TokenData


# ── Permission catalog ─────────────────────────────────────────────────────────

class Permissions:
    # Disputes
    DISPUTE_READ = "dispute:read"
    DISPUTE_CREATE = "dispute:create"
    DISPUTE_UPDATE = "dispute:update"

    # Evidence
    EVIDENCE_READ = "evidence:read"
    EVIDENCE_INGEST = "evidence:ingest"

    # Hypotheses / contradictions
    HYPOTHESIS_READ = "hypothesis:read"
    CONTRADICTION_READ = "contradiction:read"

    # Recommendations
    RECOMMENDATION_READ = "recommendation:read"
    RECOMMENDATION_OVERRIDE = "recommendation:override"

    # Actions
    ACTION_PROPOSE = "action:propose"
    ACTION_READ = "action:read"
    ACTION_APPROVE = "action:approve"     # CLASS_C actions

    # Approvals
    APPROVAL_READ = "approval:read"
    APPROVAL_CREATE = "approval:create"

    # Audit
    AUDIT_READ = "audit:read"
    AUDIT_REPLAY = "audit:replay"

    # Agent
    AGENT_TRIGGER = "agent:trigger"
    AGENT_TRACE_READ = "agent:trace:read"

    # Admin
    TENANT_MANAGE = "tenant:manage"
    USER_MANAGE = "user:manage"
    CONFIG_MANAGE = "config:manage"


ROLE_PERMISSIONS: dict[str, List[str]] = {
    "issuer_analyst": [
        Permissions.DISPUTE_READ,
        Permissions.DISPUTE_CREATE,
        Permissions.DISPUTE_UPDATE,
        Permissions.EVIDENCE_READ,
        Permissions.EVIDENCE_INGEST,
        Permissions.HYPOTHESIS_READ,
        Permissions.CONTRADICTION_READ,
        Permissions.RECOMMENDATION_READ,
        Permissions.ACTION_PROPOSE,
        Permissions.ACTION_READ,
        Permissions.APPROVAL_READ,
        Permissions.AUDIT_READ,
        Permissions.AGENT_TRIGGER,
        Permissions.AGENT_TRACE_READ,
    ],
    "merchant_analyst": [
        Permissions.DISPUTE_READ,
        Permissions.DISPUTE_UPDATE,
        Permissions.EVIDENCE_READ,
        Permissions.EVIDENCE_INGEST,
        Permissions.HYPOTHESIS_READ,
        Permissions.CONTRADICTION_READ,
        Permissions.RECOMMENDATION_READ,
        Permissions.ACTION_PROPOSE,
        Permissions.ACTION_READ,
        Permissions.APPROVAL_READ,
        Permissions.AUDIT_READ,
        Permissions.AGENT_TRIGGER,
        Permissions.AGENT_TRACE_READ,
    ],
    "admin": sorted({p for p in vars(Permissions).values() if isinstance(p, str) and ":" in p}),
}


# ── Screen visibility per role ─────────────────────────────────────────────────
# Used by frontend to conditionally render navigation items

ROLE_SCREENS: dict[str, List[str]] = {
    "issuer_analyst": [
        "dispute-command-center",
        "evidence-explorer",
        "timeline",
        "hypotheses",
        "next-best-action",
        "approval-workspace",
        "audit",
    ],
    "merchant_analyst": [
        "merchant-home",
        "merchant-disputes",
        "merchant-workspace",
        "merchant-alerts",
        "merchant-insights",
    ],
    # Admin is a back-office persona only — statuses/outcomes/roles/users/integrations.
    # Deliberately does NOT include the operational dispute/case screens above.
    "admin": [
        "admin-statuses",
        "admin-outcomes",
        "admin-roles",
        "admin-evidence-requirements",
        "admin-users",
        "admin-integrations",
        "admin-impact",
        "admin-eval-scores",
        "admin-knowledge",
    ],
}


# ── Helpers ────────────────────────────────────────────────────────────────────

def get_user_permissions(roles: List[str]) -> List[str]:
    perms: set[str] = set()
    for role in roles:
        perms.update(ROLE_PERMISSIONS.get(role, []))
    return list(perms)


def has_permission(user: TokenData, permission: str) -> bool:
    user_perms = get_user_permissions(user.roles)
    return permission in user_perms


def require_permission(permission: str) -> Callable:
    def dependency(current_user: TokenData = Depends(get_current_user)) -> TokenData:
        if not has_permission(current_user, permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission denied: {permission} required",
            )
        return current_user
    return dependency
