"""
Vector store — three named FAISS collections, one shared remote embedding model
(text-embedding-3-large, via the same LiteLLM proxy the chat LLM uses — no local
embedding model; see packages/intelligence/llm_client.py and
ref/rag-testing/rag.py for the reference implementation this mirrors).
Retrieval aid only, never the source of truth; every collection is rebuildable
from the SQL tables it's derived from.

Collections:
  evidence    — one vector per evidence record, for semantic duplicate detection
                (README's Deduplication section: cosine similarity > 0.98 -> possible
                duplicate, flagged for review, never silently discarded).
  regulatory  — this platform's own evidence-requirement policy passages
                (`regulatory_corpus.py`), retrievable so `identify_gaps` can ground its
                reasoning in policy text instead of only an exact-match dict lookup.
  precedent   — one vector per dispute's fact pattern, written whenever the agent
                produces a recommendation, so a new case can retrieve similar past cases
                and how they resolved (the platform's own "Learning" loop stage, README §1).

`evidence` and `precedent` are tenant-scoped (every entry carries tenant_id, every search
filters by it — required so duplicate/precedent detection never leaks across tenants,
per Z1). `regulatory` is platform-wide policy, not tenant data, so it carries no tenant
filter.
"""
import json
import os
import threading
from pathlib import Path
from typing import Any, Callable, Optional

import numpy as np

try:
    import faiss
    _DEPS_OK = True
except ImportError:
    _DEPS_OK = False

from packages.intelligence.llm_client import embed_texts, embed_query, EMBED_MODEL, EMBED_DIM
from packages.observability.logging import get_logger

logger = get_logger("intelligence.vector_store")

_BASE_DIR = Path(os.getenv("FAISS_INDEX_PATH", "./data/faiss"))
_MODEL_NAME = EMBED_MODEL
_DIM = EMBED_DIM  # text-embedding-3-large output dimension (3072)
_FAISS_ENABLED = os.getenv("FAISS_ENABLED", "true").lower() == "true"

_embed_lock = threading.Lock()


def _embed(text: str) -> np.ndarray:
    """Single-text embed — remote call to text-embedding-3-large via the LiteLLM proxy."""
    with _embed_lock:
        vec = embed_query(text)
    return np.array([vec], dtype="float32")


def _embed_batch(texts: list[str]) -> np.ndarray:
    """Batch embed — one (LangChain-internally-paginated) call, not one request per text."""
    with _embed_lock:
        vecs = embed_texts(texts)
    return np.array(vecs, dtype="float32")


def deps_available() -> bool:
    return _DEPS_OK and _FAISS_ENABLED


class VectorCollection:
    """One named FAISS index + a parallel metadata list, persisted to disk."""

    def __init__(self, name: str, dim: int = _DIM):
        self.name = name
        self.dim = dim
        self._lock = threading.Lock()
        self._index = None
        self._meta: list[dict[str, Any]] = []

    @property
    def index_path(self) -> Path:
        return _BASE_DIR / f"{self.name}.index"

    @property
    def meta_path(self) -> Path:
        return _BASE_DIR / f"{self.name}.meta.json"

    def initialize(self) -> None:
        if not deps_available():
            logger.warning("vector_collection_disabled", collection=self.name,
                            deps_ok=_DEPS_OK, faiss_enabled=_FAISS_ENABLED)
            return
        with self._lock:
            if self.index_path.exists() and self.meta_path.exists():
                self._index = faiss.read_index(str(self.index_path))
                with open(self.meta_path) as f:
                    self._meta = json.load(f)
                logger.info("vector_collection_loaded", collection=self.name, vectors=len(self._meta))
            else:
                self._index = faiss.IndexFlatL2(self.dim)
                self._meta = []
                logger.info("vector_collection_created", collection=self.name)

    def _save(self) -> None:
        _BASE_DIR.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._index, str(self.index_path))
        with open(self.meta_path, "w") as f:
            json.dump(self._meta, f)

    def count(self) -> int:
        return len(self._meta)

    def add(self, vector_id: str, text: str, metadata: dict[str, Any]) -> None:
        if not deps_available() or self._index is None:
            return
        vec = _embed(text[:2048])
        with self._lock:
            self._index.add(vec)
            self._meta.append({"vector_id": vector_id, **metadata})
            self._save()
        logger.debug("vector_added", collection=self.name, vector_id=vector_id)

    def add_batch(
        self, items: list[tuple[str, str, dict[str, Any]]], batch_size: int = 200,
        on_progress: Optional[Callable[[int], None]] = None,
    ) -> int:
        """
        Bulk add — one remote embedding call per batch instead of one per item, index
        saved to disk once at the end instead of once per item. Needed for anything
        beyond a handful of vectors (e.g. a multi-hundred-page PDF); `add()` alone would
        rewrite the whole index+meta.json file on every single call, and embedding one
        text at a time would mean one HTTP round-trip per chunk. `on_progress(n)`, if
        given, is called with the running total of items added after each batch — used
        to update a document's chunks_indexed for a progress-visible upload.
        Returns the number of items actually added (0 if deps unavailable).
        """
        if not deps_available() or self._index is None or not items:
            return 0
        added = 0
        with self._lock:
            for start in range(0, len(items), batch_size):
                batch = items[start:start + batch_size]
                texts = [text[:2048] for _, text, _ in batch]
                vecs = _embed_batch(texts)
                self._index.add(vecs)
                for vector_id, _, metadata in batch:
                    self._meta.append({"vector_id": vector_id, **metadata})
                added += len(batch)
                if on_progress:
                    on_progress(added)
            self._save()
        logger.info("vector_batch_added", collection=self.name, count=added)
        return added

    def remove_by(self, where: dict[str, Any]) -> int:
        """Rebuild the collection excluding entries matching `where` (exact equality on
        every key). IndexFlatL2 stores raw vectors, so a matching entry's embedding can
        be reconstructed directly (`reconstruct`) instead of re-embedding its source
        text — cheap even for a few thousand vectors."""
        if not deps_available() or self._index is None or self._index.ntotal == 0:
            return 0
        with self._lock:
            keep_positions = [i for i, m in enumerate(self._meta) if any(m.get(k) != v for k, v in where.items())]
            removed = len(self._meta) - len(keep_positions)
            if removed == 0:
                return 0
            new_index = faiss.IndexFlatL2(self.dim)
            if keep_positions:
                vecs = np.vstack([self._index.reconstruct(i) for i in keep_positions]).astype("float32")
                new_index.add(vecs)
            self._index = new_index
            self._meta = [self._meta[i] for i in keep_positions]
            self._save()
        logger.info("vector_collection_pruned", collection=self.name, removed=removed)
        return removed

    def search(
        self,
        query: str,
        top_k: int = 5,
        where: Optional[dict[str, Any]] = None,
        exclude_vector_id: Optional[str] = None,
    ) -> list[tuple[dict[str, Any], float]]:
        """
        Return [(metadata, similarity), ...] most similar to `query`, filtered by exact
        equality on `where` (e.g. {"tenant_id": "..."}). similarity is cosine similarity
        in [-1, 1], derived from FAISS's squared-L2 distance on normalized vectors
        (||a-b||^2 = 2 - 2*cos(a,b) for unit vectors).

        When `where`/`exclude_vector_id` is given, the raw FAISS fetch covers the WHOLE
        collection (not just top_k*5) before filtering. IndexFlatL2 computes exact
        distances to every vector regardless of k — it's a brute-force index, so this
        costs nothing extra in accuracy or real compute, only in how many sorted results
        get materialized. Without it, a large single document's raw similarity dominance
        for a query can push every filter-matching candidate outside a small top-k*5
        window, making a legitimately-matching filtered search return empty.
        """
        if not deps_available() or self._index is None or self._index.ntotal == 0:
            return []
        vec = _embed(query)
        with self._lock:
            if where or exclude_vector_id:
                k = self._index.ntotal
            else:
                k = min(max(top_k * 5, top_k), self._index.ntotal)
            distances, indices = self._index.search(vec, k)
        results: list[tuple[dict[str, Any], float]] = []
        for dist, idx in zip(distances[0], indices[0]):
            if idx < 0 or idx >= len(self._meta):
                continue
            entry = self._meta[idx]
            if exclude_vector_id and entry.get("vector_id") == exclude_vector_id:
                continue
            if where and any(entry.get(k2) != v for k2, v in where.items()):
                continue
            similarity = 1.0 - (float(dist) / 2.0)
            results.append((entry, similarity))
            if len(results) >= top_k:
                break
        return results

    def rebuild(self, rows: list[tuple[str, str, dict[str, Any]]]) -> None:
        """Full rebuild from (vector_id, text, metadata) tuples."""
        if not deps_available():
            return
        with self._lock:
            self._index = faiss.IndexFlatL2(self.dim)
            self._meta = []
            for vector_id, text, metadata in rows:
                vec = _embed(text[:2048])
                self._index.add(vec)
                self._meta.append({"vector_id": vector_id, **metadata})
            self._save()
        logger.info("vector_collection_rebuilt", collection=self.name, count=len(self._meta))


evidence_collection = VectorCollection("evidence")
regulatory_collection = VectorCollection("regulatory")
precedent_collection = VectorCollection("precedent")


def initialize_all() -> None:
    """Call once at app startup. Seeds the regulatory collection if empty."""
    evidence_collection.initialize()
    regulatory_collection.initialize()
    precedent_collection.initialize()

    if deps_available() and regulatory_collection.count() == 0:
        from packages.intelligence.regulatory_corpus import REGULATORY_PASSAGES
        for passage in REGULATORY_PASSAGES:
            regulatory_collection.add(
                passage["id"],
                f"{passage['title']} {passage['text']}",
                {
                    "title": passage["title"],
                    "text": passage["text"],
                    "network": passage["network"],
                    "reason_code": passage["reason_code"],
                    "source": "platform_policy",
                    "page": None,
                    "document_id": None,
                },
            )
        logger.info("regulatory_corpus_seeded", count=len(REGULATORY_PASSAGES))


def collection_stats() -> dict[str, Any]:
    return {
        "deps_available": deps_available(),
        "faiss_installed": _DEPS_OK,
        "faiss_enabled_flag": _FAISS_ENABLED,
        "embed_model": _MODEL_NAME,
        "collections": {
            "evidence": {"vectors": evidence_collection.count()},
            "regulatory": {"vectors": regulatory_collection.count()},
            "precedent": {"vectors": precedent_collection.count()},
        },
    }


# ── Evidence duplicate detection ────────────────────────────────────────────────

def _evidence_text(evidence_type: str, content: dict) -> str:
    return f"{evidence_type} {json.dumps(content)}"


def add_evidence(evidence_id: str, tenant_id: str, case_id: str, evidence_type: str, content: dict) -> None:
    evidence_collection.add(
        evidence_id,
        _evidence_text(evidence_type, content),
        {"evidence_id": evidence_id, "tenant_id": tenant_id, "case_id": case_id, "evidence_type": evidence_type},
    )


def find_similar_evidence(
    tenant_id: str, evidence_type: str, content: dict, top_k: int = 3, min_similarity: float = 0.98,
) -> list[dict[str, Any]]:
    """Possible near-duplicate evidence, tenant-wide (cross-case matches are the point —
    catches the same real-world transaction disputed/evidenced twice under different cases)."""
    hits = evidence_collection.search(
        _evidence_text(evidence_type, content), top_k=top_k, where={"tenant_id": tenant_id},
    )
    return [
        {"evidence_id": meta["evidence_id"], "case_id": meta["case_id"], "similarity": round(sim, 4)}
        for meta, sim in hits
        if sim >= min_similarity
    ]


def rebuild_evidence_from_rows(evidence_rows: list) -> None:
    """Full rebuild from DB rows. Call on startup if the index is missing/corrupt."""
    rows = [
        (e.evidence_id, _evidence_text(e.evidence_type, e.normalized_content),
         {"evidence_id": e.evidence_id, "tenant_id": e.tenant_id, "case_id": e.case_id, "evidence_type": e.evidence_type})
        for e in evidence_rows
    ]
    evidence_collection.rebuild(rows)


# ── Regulatory grounding ─────────────────────────────────────────────────────────

def find_regulatory_context(
    query_text: str, top_k: int = 2, network: Optional[str] = None,
) -> list[dict[str, Any]]:
    """
    `network`, when given, restricts retrieval to chunks tagged with that network plus
    anything not tied to a specific card scheme — general-principle platform_policy
    passages (network="") and documents explicitly tagged network="OTHER" (internal
    SOPs/policies, the Reg Z reference guide — none of these are Visa- or
    Mastercard-specific, so they should stay eligible no matter which network a search
    is scoped to). Separate `where`-filtered searches (not one over-fetch-then-filter)
    so a large single document's raw similarity dominance can't starve another
    network's candidates out of the window before filtering ever runs. Omit `network`
    to search everything, e.g. for the cross-network "Ask the Case" copilot.
    """
    if network:
        network_hits = regulatory_collection.search(query_text, top_k=top_k, where={"network": network})
        general_hits = regulatory_collection.search(query_text, top_k=top_k, where={"network": ""})
        other_hits = regulatory_collection.search(query_text, top_k=top_k, where={"network": "OTHER"})
        hits = sorted(network_hits + general_hits + other_hits, key=lambda h: h[1], reverse=True)[:top_k]
    else:
        hits = regulatory_collection.search(query_text, top_k=top_k)
    return [
        {
            "title": meta["title"], "text": meta["text"], "similarity": round(sim, 4),
            "source": meta.get("source", "platform_policy"), "page": meta.get("page"),
            "network": meta.get("network"), "doc_type": meta.get("doc_type"),
        }
        for meta, sim in hits
    ]


def add_regulatory_chunks(
    document_id: str, source: str, chunks: list[dict[str, Any]],
    network: str = "OTHER", doc_type: str = "OTHER",
    on_progress: Optional[Callable[[int], None]] = None,
) -> int:
    """Bulk-index a document's page chunks ({"page": int, "text": str}, ...). Each
    chunk's `title` is derived from its source filename + page for display; the full
    text is what gets embedded and returned on retrieval. `on_progress(n)`, if given,
    is called with the running count of chunks indexed so far — the caller (the admin
    upload background task) uses it to update the document row's chunks_indexed."""
    items = [
        (
            f"{document_id}:{i}",
            f"{source} p.{c['page']} {c['text']}",
            {
                "title": f"{source}, p. {c['page']}",
                "text": c["text"],
                "network": network, "doc_type": doc_type, "reason_code": "",
                "source": source, "page": c["page"], "document_id": document_id,
            },
        )
        for i, c in enumerate(chunks)
    ]
    return regulatory_collection.add_batch(items, on_progress=on_progress)


def remove_regulatory_document(document_id: str) -> int:
    return regulatory_collection.remove_by({"document_id": document_id})


def update_regulatory_document_tags(document_id: str, network: str, doc_type: str) -> int:
    """Patch network/doc_type on an already-indexed document's chunks in place — no
    re-embedding, since only metadata changes. Returns the number of chunks updated."""
    updated = 0
    with regulatory_collection._lock:
        for entry in regulatory_collection._meta:
            if entry.get("document_id") == document_id:
                entry["network"] = network
                entry["doc_type"] = doc_type
                updated += 1
        if updated:
            regulatory_collection._save()
    logger.info("regulatory_document_retagged", document_id=document_id, network=network,
                doc_type=doc_type, chunks_updated=updated)
    return updated


# ── Precedent retrieval ──────────────────────────────────────────────────────────

def _precedent_text(dispute_type: str, network: Optional[str], reason_code: Optional[str], evidence_types: list[str]) -> str:
    return f"{dispute_type} {network or ''} {reason_code or ''} evidence: {', '.join(sorted(set(evidence_types)))}"


def add_precedent(
    tenant_id: str, dispute_id: str, dispute_type: str, network: Optional[str], reason_code: Optional[str],
    evidence_types: list[str], recommendation_type: str, confidence_score: Optional[float], outcome: Optional[str],
) -> None:
    # Upsert, not append — the agent re-runs on the same case (new evidence, a
    # manual re-trigger), and `.add()` alone would leave one stale vector per past
    # run, so `find_precedents` could return the same dispute_id twice (duplicate
    # React keys in "Similar Past Cases"). Each case should have at most one
    # precedent entry, reflecting its latest recommendation.
    precedent_collection.remove_by({"dispute_id": dispute_id, "tenant_id": tenant_id})
    precedent_collection.add(
        dispute_id,
        _precedent_text(dispute_type, network, reason_code, evidence_types),
        {
            "dispute_id": dispute_id, "tenant_id": tenant_id, "dispute_type": dispute_type,
            "network": network, "reason_code": reason_code,
            "recommendation_type": recommendation_type, "confidence_score": confidence_score,
            "outcome": outcome,
        },
    )


def find_precedents(
    tenant_id: str, dispute_type: str, network: Optional[str], reason_code: Optional[str],
    exclude_dispute_id: str, top_k: int = 3,
) -> list[dict[str, Any]]:
    # top_k * 2: a stale duplicate from before add_precedent upserted (or any other
    # index inconsistency) can otherwise crowd out a genuinely distinct case once
    # de-duped below.
    hits = precedent_collection.search(
        _precedent_text(dispute_type, network, reason_code, []),
        top_k=top_k * 2, where={"tenant_id": tenant_id}, exclude_vector_id=exclude_dispute_id,
    )
    results: list[dict[str, Any]] = []
    seen_dispute_ids: set[str] = set()
    for meta, sim in hits:
        did = meta["dispute_id"]
        if did in seen_dispute_ids:
            continue
        seen_dispute_ids.add(did)
        results.append({
            "dispute_id": did, "dispute_type": meta["dispute_type"],
            "recommendation_type": meta["recommendation_type"], "confidence_score": meta.get("confidence_score"),
            "outcome": meta.get("outcome"), "similarity": round(sim, 4),
        })
        if len(results) >= top_k:
            break
    return results
