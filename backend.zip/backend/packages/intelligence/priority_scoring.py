"""
Deterministic case-priority score — 0-100, higher = handle sooner. No LLM,
same "deterministic, explainable, no I/O" convention as scheme_rules.py.

Combines three weighted factors, each independently capped so no single one
can dominate the others:
  - Urgency  (0-50): how little time is left before the case's deadline
  - Amount   (0-30): how much money is actually in dispute
  - Card tier(0-20): the cardholder's card product tier

This is this platform's own synthesized weighting, not a claim of a bank's
real triage model — same honesty convention as every other scoring/checklist
table in this codebase. Tune the constants below if the weighting should
differ; there's no admin UI for this one (unlike scheme_rules' evidence
checklist) since it's a formula, not a lookup table.
"""
from __future__ import annotations
from datetime import datetime
from typing import Any, Optional

DEFAULT_SLA_DAYS = 14  # fallback for a dispute_type not in SLA_DAYS_BY_TYPE below

# Regulation Z (Fair Credit Billing Act) sets the legal ceiling for a US credit-card
# billing-error dispute: acknowledge within 30 days, resolve within 2 complete billing
# cycles and never more than 90 days. Every value below is well inside that 90-day cap;
# the platform's own internal target, tiered by how evidence-heavy each dispute type
# realistically is to investigate — not a claim that Reg Z itself mandates these exact
# day counts per category. Mirrors DISPUTE_TYPES in
# packages/intelligence/document_understanding.py; the 3 ranked by the platform's own
# CFPB-category analysis (README §49) get the most deliberate values:
#   #1 SUBSCRIPTION_CANCELLATION  (Visa 13.2, 40% of volume) — cancellation proof is
#      often merchant-side and slow to surface, so this gets the most runway.
#   #2 MERCHANDISE_NOT_RECEIVED  (Visa 13.1, 21%) — resolves quickly once shipping/
#      delivery status is confirmed.
#   #3 REFUND_NOT_PROCESSED  (Visa 13.6/13.7, 18%) — usually a fast yes/no once the
#      merchant confirms or denies the credit.
# Fraud-adjacent types (unauthorized charges, cash withdrawals) get the shortest SLA —
# real money-movement risk, same urgency logic every issuer applies in practice.
SLA_DAYS_BY_TYPE: dict[str, int] = {
    "SUBSCRIPTION_CANCELLATION":     45,
    "MERCHANDISE_NOT_RECEIVED":      30,
    "REFUND_NOT_PROCESSED":          21,
    "MERCHANDISE_NOT_AS_DESCRIBED":  30,
    "PROCESSING_ERROR":              15,
    "DUPLICATE_TRANSACTION":         15,
    "UNAUTHORIZED_TRANSACTION":      10,
    "CASH_WITHDRAWAL_DISPUTE":       10,
}


def sla_days_for(dispute_type: Optional[str]) -> int:
    """The deterministic, per-dispute-type SLA day count — same lookup used at case
    creation (disputes.py, claims.py) and available here for anywhere else that needs
    to explain "why this deadline" without re-deriving the mapping."""
    return SLA_DAYS_BY_TYPE.get((dispute_type or "").upper(), DEFAULT_SLA_DAYS)

# Days-remaining-to-deadline -> urgency decays linearly from 50 (due now or
# overdue) to 0 (a full window away). This was a flat 30 days — after §49 gave
# SLA_DAYS_BY_TYPE real per-type values up to 45 days, a fresh SUBSCRIPTION_CANCELLATION
# case (45 days remaining) sat *beyond* that 30-day window from the moment it was
# created, clamping urgency to 0 and leaving the priority score as whatever
# amount/card-tier alone added up to — often single digits (README §63).
#
# The fix is NOT to make the window each case's own SLA length — that was tried and
# reverted: days_remaining always equals a case's own SLA right at creation by
# definition, so a self-referential window makes urgency 0 for literally every case
# type the moment it's created (including ones like REFUND_NOT_PROCESSED's 21-day SLA
# that were never broken). The fix is simply widening the one shared window to
# comfortably cover the longest real SLA (45 days) — every shorter-SLA case type still
# gets a meaningful non-zero urgency head start proportional to how much less runway
# it has, and only the longest-SLA type legitimately starts at 0 (consistent with its
# own "most runway, least initial pressure" design intent, README §49).
_URGENCY_MAX_POINTS = 50
_URGENCY_WINDOW_DAYS = 45.0

_AMOUNT_TIERS = [  # (minimum amount, points) — highest matching tier wins
    (50_000, 30),
    (20_000, 22),
    (5_000, 14),
    (1_000, 7),
    (0.01, 3),
]

_CARD_TIER_POINTS = {"PLATINUM": 20, "GOLD": 12, "CLASSIC": 5, "STANDARD": 5}


def _urgency_points(deadline: Optional[datetime], now: datetime) -> tuple[int, Optional[float]]:
    if deadline is None:
        return 0, None
    days_remaining = (deadline - now).total_seconds() / 86400
    raw = _URGENCY_MAX_POINTS - (days_remaining * _URGENCY_MAX_POINTS / _URGENCY_WINDOW_DAYS)
    return max(0, min(_URGENCY_MAX_POINTS, round(raw))), round(days_remaining, 1)


def _amount_points(amount: Optional[float]) -> int:
    if not amount or amount <= 0:
        return 0
    for threshold, points in _AMOUNT_TIERS:
        if amount >= threshold:
            return points
    return 0


def _card_tier_points(card_tier: Optional[str]) -> int:
    return _CARD_TIER_POINTS.get((card_tier or "").upper(), 0)


def compute_priority_score(
    amount: Optional[float], card_tier: Optional[str],
    deadline: Optional[datetime], now: datetime,
) -> dict[str, Any]:
    urgency, days_remaining = _urgency_points(deadline, now)
    amount_pts = _amount_points(amount)
    tier_pts = _card_tier_points(card_tier)
    return {
        "score": urgency + amount_pts + tier_pts,
        "days_remaining": days_remaining,
        "breakdown": {"urgency": urgency, "amount": amount_pts, "card_tier": tier_pts},
    }
