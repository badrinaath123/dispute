"""
Live DeepEval scoring for real AI outputs (README §30) — not an offline/CI
suite, an evaluator wired directly into the running application. Judges
through the same LiteLLM proxy every other AI feature in this codebase
already uses (no separate Anthropic/OpenAI key needed) via a small
DeepEvalBaseLLM wrapper around packages/intelligence/llm_client.call_llm.

Opt-in via ENABLE_DEEPEVAL (.env) — off by default, so it never adds cost or
latency unless explicitly turned on. Even when on, callers run this from a
FastAPI BackgroundTask *after* the real response has already gone back to the
analyst — judging a real answer costs 1-2 extra LLM calls, which must never
be on the critical path of a feature the analyst is waiting on.

Started with "Ask the Case" (case_qa.py) — the cleanest true-RAG shape in
this codebase (retrieved passages -> grounded answer -> citations), the best
fit for Faithfulness/AnswerRelevancy. Other features listed in README §30 as
candidates for the same treatment.
"""
from __future__ import annotations

import os
from typing import Any, Optional

ENABLED = os.getenv("ENABLE_DEEPEVAL", "false").lower() == "true"

_judge = None


def _get_judge():
    """Lazily built, reused across calls — constructing it touches deepeval's
    import machinery, not worth paying that cost when ENABLED is False."""
    global _judge
    if _judge is None:
        from deepeval.models.base_model import DeepEvalBaseLLM
        from packages.intelligence.llm_client import call_llm, LLM_MODEL

        class _LiteLLMJudge(DeepEvalBaseLLM):
            def load_model(self):
                return None

            def generate(self, prompt: str) -> str:
                return call_llm("You are an impartial evaluator scoring AI output quality.", prompt)

            async def a_generate(self, prompt: str) -> str:
                return self.generate(prompt)

            def get_model_name(self) -> str:
                return f"litellm-proxy:{LLM_MODEL}"

        _judge = _LiteLLMJudge()
    return _judge


def evaluate_case_qa(question: str, answer: str, retrieval_context: list[str]) -> list[dict[str, Any]]:
    """
    Faithfulness + Answer Relevancy for one real "Ask the Case" answer.
    Returns [] with zero LLM calls when ENABLE_DEEPEVAL is off. Never raises —
    a judging failure must never surface as a failure of the real feature
    being scored; caught and reported as a single "error" entry instead.
    """
    if not ENABLED:
        return []
    try:
        from deepeval.metrics import FaithfulnessMetric, AnswerRelevancyMetric
        from deepeval.test_case import LLMTestCase

        judge = _get_judge()
        test_case = LLMTestCase(
            input=question,
            actual_output=answer,
            retrieval_context=retrieval_context or ["(no passages retrieved)"],
        )
        metrics = [
            FaithfulnessMetric(threshold=0.7, model=judge, include_reason=True),
            AnswerRelevancyMetric(threshold=0.7, model=judge, include_reason=True),
        ]
        results = []
        for m in metrics:
            m.measure(test_case)
            results.append({
                "metric": m.__class__.__name__.replace("Metric", ""),
                "score": round(m.score, 3) if m.score is not None else None,
                "passed": bool(m.success) if m.success is not None else None,
                "reason": m.reason,
            })
        return results
    except Exception as exc:
        return [{"metric": "error", "score": None, "passed": None, "reason": str(exc)[:300]}]
