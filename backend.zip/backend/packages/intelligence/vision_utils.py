"""
Shared image/PDF-to-base64 helpers for gemini-2.5-flash vision calls — used
by both document_understanding.py (case document upload) and
evidence_requirement_extraction.py (admin evidence-checklist upload) so the
PDF-rendering logic exists in exactly one place.
"""
from __future__ import annotations
import base64


def b64_of(image_bytes: bytes) -> str:
    return base64.b64encode(image_bytes).decode()


def render_pdf_first_page_to_png(pdf_bytes: bytes) -> bytes:
    import pymupdf

    doc = pymupdf.open(stream=pdf_bytes, filetype="pdf")
    try:
        if doc.page_count == 0:
            raise ValueError("PDF has no pages")
        page = doc.load_page(0)
        # 2x zoom for a sharper image than the PDF's default render resolution —
        # helps OCR accuracy on small print.
        pix = page.get_pixmap(matrix=pymupdf.Matrix(2, 2))
        return pix.tobytes("png")
    finally:
        doc.close()


def render_pdf_pages_to_png(pdf_bytes: bytes, max_pages: int = 5) -> list[bytes]:
    """
    A real support-ticket log or email thread routinely spans more than one page —
    e.g. the cardholder's opening message on page 1, the merchant's actual reply on
    page 2 — and only ever rendering page 1 (the original single-page assumption)
    silently hid every later page from the vision model, causing real
    misclassifications (a document classified as CANCELLATION_CONFIRMATION or
    CARDHOLDER_LETTER when its merchant reply, invisible past page 1, would have made
    MERCHANT_COMMUNICATION the correct answer). Capped at max_pages to bound image
    payload size/cost — plenty for this platform's realistic document lengths.
    """
    import pymupdf

    doc = pymupdf.open(stream=pdf_bytes, filetype="pdf")
    try:
        if doc.page_count == 0:
            raise ValueError("PDF has no pages")
        pages_to_render = min(doc.page_count, max_pages)
        images = []
        for i in range(pages_to_render):
            page = doc.load_page(i)
            pix = page.get_pixmap(matrix=pymupdf.Matrix(2, 2))
            images.append(pix.tobytes("png"))
        return images
    finally:
        doc.close()
