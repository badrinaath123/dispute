"""
Reason-code suggestion — RAG-grounded, explicitly not authoritative.

This is NOT a certified/deterministic classifier. It retrieves the most relevant
network-scoped regulatory passages (packages/intelligence/faiss_index.find_regulatory_context)
for a claim, then asks the LLM to suggest a reason code ONLY if those retrieved passages
actually support one — the same epistemic status as the agent's own hypotheses (AI
Integrity Rule, README §1: never present an inference as a fact). A human should verify
before relying on this operationally; the response always carries a disclaimer field.
"""
from __future__ import annotations

import json
from typing import Any, Optional

from packages.intelligence import faiss_index, reason_code_reference
from packages.intelligence.llm_client import call_llm, extract_json_str

_SYSTEM = """\
You are a card-dispute reason-code assistant. You suggest a reason/chargeback code only
when the retrieved policy passages below clearly support it. Never invent a code that
isn't grounded in the passages. If the passages don't clearly support a specific code,
return "NONE_CONFIDENT" rather than guess.
"""

_PROMPT = """\
Dispute type: {dispute_type}
Network: {network}
Cardholder claim: {cardholder_claim}

Retrieved policy passages:
{passages}

Based ONLY on the passages above, suggest the most likely reason/chargeback code for
this claim. Respond as JSON with fields: suggested_code (string, or "NONE_CONFIDENT"),
confidence (0.0-1.0), rationale (1-2 sentences), citation_index (integer index, 1-based,
of the passage above that most supports this — or null if NONE_CONFIDENT).
""".strip()


def suggest_reason_code(
    dispute_type: str, cardholder_claim: str, network: Optional[str],
) -> dict[str, Any]:
    passages = faiss_index.find_regulatory_context(
        f"{dispute_type} {cardholder_claim}", top_k=4, network=(network or "").upper() or None,
    )

    disclaimer = (
        "LLM-suggested from retrieved policy text — verify before relying on it "
        "operationally. This is not a certified classification."
    )

    if not passages:
        return {
            "suggested_code": "NONE_CONFIDENT",
            "confidence": 0.0,
            "rationale": "No relevant regulatory passages were retrieved for this claim.",
            "citation": None,
            "disclaimer": disclaimer,
            "standard_reference": reason_code_reference.standard_reference(dispute_type),
        }

    def _fmt_passage(i: int, p: dict) -> str:
        page_suffix = f", p. {p['page']}" if p.get("page") else ""
        return f"[{i + 1}] ({p['source']}{page_suffix}): {p['text'][:600]}"

    passages_text = "\n\n".join(_fmt_passage(i, p) for i, p in enumerate(passages))
    prompt = _PROMPT.format(
        dispute_type=dispute_type, network=network or "UNKNOWN",
        cardholder_claim=cardholder_claim, passages=passages_text,
    )

    try:
        raw = call_llm(_SYSTEM, prompt)
        parsed = json.loads(extract_json_str(raw))
        if not isinstance(parsed, dict):
            parsed = {}
    except Exception:
        parsed = {}

    citation_index = parsed.get("citation_index")
    citation = None
    if isinstance(citation_index, int) and 1 <= citation_index <= len(passages):
        p = passages[citation_index - 1]
        citation = {"source": p["source"], "page": p.get("page"), "title": p["title"]}

    return {
        "suggested_code": parsed.get("suggested_code", "NONE_CONFIDENT"),
        "confidence": float(parsed.get("confidence", 0.0) or 0.0),
        "rationale": parsed.get("rationale", "Could not parse a rationale from the model output."),
        "citation": citation,
        "disclaimer": disclaimer,
        # A deterministic fallback (README §76), not an LLM/RAG output — only meant
        # to be shown when the RAG suggestion above is NONE_CONFIDENT (or None, for
        # a dispute_type the reference table has no confident entry for either).
        "standard_reference": reason_code_reference.standard_reference(dispute_type),
    }
