"""
Regulatory / evidence-requirement policy corpus — retrievable via embeddings.

Honesty note: these passages are this platform's OWN synthesized evidence-requirement
policy, expanded from the same (network, reason_code) -> required evidence table already
in `scheme_rules.py` (which has never claimed to be a licensed Visa/Mastercard rulebook
excerpt — it's the platform's own documented rule for this demo's seed data). Turning
that table into fuller prose and indexing it lets `identify_gaps` retrieve a grounding
passage even for reason codes with no exact dict match, instead of falling straight to
"no scheme-specific rule on file." It must never be presented to a user as literal,
licensed scheme-rulebook text — it isn't, and nothing in this codebase has that text.
"""
from __future__ import annotations

REGULATORY_PASSAGES: list[dict[str, str]] = [
    {
        "id": "policy-visa-10.4",
        "title": "Visa 10.4 — Fraud: Card-Absent / Unauthorized Transaction",
        "network": "VISA",
        "reason_code": "10.4",
        "text": (
            "For a card-absent unauthorized-transaction dispute, this platform's policy "
            "requires proof of cardholder authentication at the time of the transaction "
            "(3DS result or chip & PIN verification, including any liability-shift "
            "indicator) and a transaction receipt showing AVS/CVV match and the channel "
            "(card-present vs. card-not-present). Without an authentication record, the "
            "platform treats the merchant's position as materially weaker, since there is "
            "no evidence the cardholder authorized the charge."
        ),
    },
    {
        "id": "policy-visa-13.1",
        "title": "Visa 13.1 — Consumer Dispute: Merchandise/Services Not Received",
        "network": "VISA",
        "reason_code": "13.1",
        "text": (
            "For a merchandise-not-received dispute, this platform's policy requires proof "
            "of shipment with a carrier tracking number and proof of delivery to the "
            "order's actual shipping address — a signature, photo, or GPS delivery scan. "
            "A tracking number alone, without confirmation the package reached the correct "
            "address, does not fully satisfy this requirement."
        ),
    },
    {
        "id": "policy-mastercard-4853",
        "title": "Mastercard 4853 — Cardholder Dispute: Not as Described or Defective",
        "network": "MASTERCARD",
        "reason_code": "4853",
        "text": (
            "For a not-as-described-or-defective dispute, this platform's policy requires "
            "the original order record showing exactly what was ordered or described to "
            "the cardholder, plus the merchant's response (if any) to the cardholder's "
            "complaint. Absent the merchant's response, the platform cannot establish "
            "whether the merchant was given a chance to remedy the issue before the "
            "dispute was filed."
        ),
    },
    {
        "id": "policy-predispute",
        "title": "Pre-Dispute Alert — Platform-Specific Prevention Concept",
        "network": "RUPAY",
        "reason_code": "PRE-DISPUTE",
        "text": (
            "A pre-dispute alert is this platform's own mechanism for resolving a "
            "cardholder complaint before it becomes a formal chargeback. Policy requires "
            "the order record and a communication log documenting the complaint and any "
            "resolution the merchant offered. Resolving at this stage avoids the scheme "
            "fee that a formal chargeback would trigger."
        ),
    },
    {
        "id": "policy-materiality-general",
        "title": "General Principle — Evidence Materiality",
        "network": "",
        "reason_code": "",
        "text": (
            "Across all dispute types, this platform treats transaction receipts, "
            "authentication logs, delivery confirmations, chargeback rebuttals, and "
            "merchant shipping evidence as HIGH materiality by default. Evidence "
            "containing a signature, a verified PIN, a matched CVV, a tracking number, or "
            "a recorded delivery timestamp is elevated to HIGH regardless of its type. "
            "Cardholder statements and communication logs, on their own and unsupported by "
            "harder evidence, are treated as LOW materiality — persuasive context, not "
            "proof."
        ),
    },
    {
        "id": "policy-provenance-general",
        "title": "General Principle — Evidence Provenance and Versioning",
        "network": "",
        "reason_code": "",
        "text": (
            "This platform never overwrites evidence. A correction to a previously "
            "submitted record creates a new version, and the prior version is marked "
            "superseded rather than deleted. Every evidence record must carry its source "
            "system, retrieval method, and the identity of who retrieved it. A gap "
            "identified against evidence that later turns out to be a stale version should "
            "be re-checked against the current version before being treated as resolved."
        ),
    },
]
