"""
"Cyera Validation" (README §38) — a PII/sensitive-document guardrail on document upload.
Named after the request that asked for it; not an integration with the actual Cyera
product (no credentials or API for that exist in this codebase) — this is this
platform's own PII check, built the same way every other AI feature here is: through
the shared LiteLLM-proxied vision client, honestly, with nothing fabricated.

Runs BEFORE a document is written to storage or attached as evidence (disputes.py's
_attach_document) — a flagged document is never saved, never vectorized. Two layers:

1. Vision classification: asks the model whether the document itself IS (or prominently
   displays) a government identity document — an Aadhar card, PAN card, passport, voter
   ID, or driving licence — the case this was built for. Deliberately instructs the model
   NEVER to transcribe the actual ID number back to us; we want to know THAT a document
   is sensitive, not to have it echo the sensitive value into our own systems (which
   would be its own PII leak into normalized_content / the vector store).
2. Regex safety net over whatever free-text the main extraction already returned
   (text_summary, narrative, customer_name) — catches an Aadhar-shaped or PAN-shaped
   number that leaked into a field despite the instruction above, and redacts it before
   that text is ever stored.
"""
from __future__ import annotations

import json
import re
from typing import Any

from packages.intelligence.llm_client import call_vision_llm, extract_json_str

_AADHAR_RE = re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b")
_PAN_RE = re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b")

_SYSTEM = """\
You are a data-protection screening step. Your only job is to say whether an uploaded
document is, or prominently displays, a sensitive government identity document — never
to extract or repeat the actual ID number.
"""

_PROMPT = """\
Look at this document and answer honestly:

- is_id_document: true if this document IS a government-issued identity document (an
  Aadhar card, PAN card, passport, voter ID card, or driving licence) or prominently
  displays one (e.g. a photo/scan of one attached alongside other content) — false for
  an ordinary business document (receipt, invoice, letter, shipping label, agreement)
  even if it happens to mention a masked card number
- id_types: array of the specific type(s) detected, using ONLY these labels —
  "AADHAR_CARD", "PAN_CARD", "PASSPORT", "VOTER_ID", "DRIVING_LICENCE" — empty array if
  is_id_document is false
- reasoning: one short sentence on what you saw that led to this conclusion

CRITICAL: Do NOT transcribe, repeat, or include the actual ID number, even partially, in
your reasoning or anywhere in your response — describe what kind of document it is, not
its contents.

Respond as a single JSON object with exactly these fields.
""".strip()


def _redact(text: str | None) -> tuple[str | None, bool]:
    if not text:
        return text, False
    redacted = _AADHAR_RE.sub("[REDACTED-AADHAR]", text)
    redacted = _PAN_RE.sub("[REDACTED-PAN]", redacted)
    return redacted, redacted != text


def check_image_for_pii(image_b64: str, mime_type: str) -> dict[str, Any]:
    """
    Returns {is_id_document, id_types, reasoning}. Never raises — a failure here must
    never block a legitimate upload; honestly reports is_id_document=False with a note
    on failure rather than guessing.
    """
    try:
        raw = call_vision_llm(_SYSTEM, _PROMPT, image_b64, mime_type)
        parsed = json.loads(extract_json_str(raw))
        if not isinstance(parsed, dict):
            parsed = {}
    except Exception as exc:
        return {"is_id_document": False, "id_types": [], "reasoning": f"Screening failed: {exc}"[:200]}

    valid_types = {"AADHAR_CARD", "PAN_CARD", "PASSPORT", "VOTER_ID", "DRIVING_LICENCE"}
    id_types = [t for t in (parsed.get("id_types") or []) if t in valid_types]
    return {
        "is_id_document": bool(parsed.get("is_id_document")) and len(id_types) > 0,
        "id_types": id_types,
        "reasoning": str(parsed.get("reasoning") or "")[:300],
    }


def scan_and_redact_text_fields(fields: dict[str, str | None]) -> tuple[dict[str, str | None], list[str]]:
    """Safety-net regex pass over already-extracted free text (text_summary, narrative,
    etc.) — redacts any Aadhar/PAN-shaped number found and returns which field names
    were touched, so the caller can still flag the upload even if the vision
    classification above missed it."""
    redacted_fields: dict[str, str | None] = {}
    touched: list[str] = []
    for key, value in fields.items():
        new_value, changed = _redact(value)
        redacted_fields[key] = new_value
        if changed:
            touched.append(key)
    return redacted_fields, touched
