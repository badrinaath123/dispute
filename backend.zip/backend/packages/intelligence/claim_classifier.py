"""
Predicts a dispute_type and priority from the cardholder's own claim
narrative alone — before any evidence document exists. Powers New Case's
"Analyze" step: the analyst types (or dictates) what happened, and the system
tells them the likely dispute type and urgency instead of asking them to pick
a dispute type manually before it can even suggest which documents to
collect (packages/intelligence/evidence_requirements.py).

Text-only LLM call (packages/intelligence/llm_client.call_llm) — no vision
needed, there's no document at this point in the flow. Same honesty rule as
every other AI feature here: if the narrative doesn't clearly indicate a
dispute type, dispute_type comes back null and confidence reflects the
uncertainty, rather than the model forcing a confident-sounding guess.
"""
from __future__ import annotations

import json
from typing import Any, Optional

from packages.intelligence.document_understanding import DISPUTE_TYPES
from packages.intelligence.llm_client import call_llm, extract_json_str

_SYSTEM = """\
You are triaging a cardholder's dispute claim for a bank analyst, before any
supporting evidence has been collected. Classify only what the claim text
itself supports — if it's genuinely ambiguous which dispute type applies,
say so honestly (null, low confidence) rather than forcing a confident-
sounding guess. A human analyst reviews and can override every field before
anything is submitted.
"""

_PROMPT = """\
Cardholder's claim: "{narrative}"

Classify this claim:
- dispute_type: one of {dispute_types}, your best classification, or null if
  the claim doesn't clearly indicate one
- priority: one of CRITICAL, HIGH, MEDIUM, LOW — based on apparent urgency in
  the claim itself (e.g. a large amount mentioned, suspected fraud, or a
  cardholder describing repeated failed resolution attempts suggests higher
  priority). Default to MEDIUM if nothing in the text indicates otherwise —
  never invent urgency that isn't there.
- confidence: your confidence (0.0-1.0) in the dispute_type classification
- reasoning: one sentence explaining the classification, in plain language
  suitable to show the analyst

Respond as a single JSON object with exactly these fields.
""".strip()


def classify_claim(narrative: str) -> dict[str, Any]:
    prompt = _PROMPT.format(narrative=narrative, dispute_types=DISPUTE_TYPES)
    raw = call_llm(_SYSTEM, prompt)

    try:
        parsed = json.loads(extract_json_str(raw))
        if not isinstance(parsed, dict):
            parsed = {}
    except Exception:
        parsed = {}

    dispute_type: Optional[str] = parsed.get("dispute_type")
    if dispute_type not in DISPUTE_TYPES:
        dispute_type = None

    priority = str(parsed.get("priority") or "MEDIUM").upper()
    if priority not in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
        priority = "MEDIUM"

    return {
        "dispute_type": dispute_type,
        "priority": priority,
        "confidence": float(parsed.get("confidence", 0.0) or 0.0),
        "reasoning": parsed.get("reasoning") or "",
    }
