"""
Scheme-aware evidence rules — deterministic, no LLM.

Maps (network, reason_code) to the evidence types a card network actually
requires to support a representment, so gap-finding isn't purely LLM freeform.
Scoped to the reason codes present in this platform's seed data:
  Visa 10.4    — Fraud: Card-Absent / Unauthorized Transaction
  Visa 13.1    — Consumer Dispute: Merchandise/Services Not Received
  Mastercard 4853 — Cardholder Dispute: Not as Described or Defective
  PRE-DISPUTE  — platform-specific pre-chargeback alert (not a scheme code)

Also hosts the evidence-citation validator used to keep LLM output honest:
any evidence ID an LLM claims support from must actually belong to the case.
"""
from __future__ import annotations
from datetime import datetime
from typing import Any

# (network, reason_code) -> required evidence_type set + human-readable checklist.
# "network" is matched case-insensitively; reason codes match the exact scheme code.
_REQUIRED_EVIDENCE: dict[tuple[str, str], list[str]] = {
    ("VISA", "10.4"): ["AUTHENTICATION_LOG", "TRANSACTION_RECEIPT"],
    ("VISA", "13.1"): ["DELIVERY_CONFIRMATION", "ORDER_RECORD"],
    ("MASTERCARD", "4853"): ["ORDER_RECORD", "COMMUNICATION_LOG"],
    ("RUPAY", "PRE-DISPUTE"): ["ORDER_RECORD", "COMMUNICATION_LOG"],
}

_CHECKLIST: dict[tuple[str, str], list[str]] = {
    ("VISA", "10.4"): [
        "Cardholder authentication result (3DS/chip & PIN) with liability-shift indicator",
        "Transaction receipt showing AVS/CVV match and channel (card-present vs CNP)",
    ],
    ("VISA", "13.1"): [
        "Proof of shipment with carrier tracking number",
        "Proof of delivery to the order's shipping address (signature, photo, or GPS scan)",
    ],
    ("MASTERCARD", "4853"): [
        "Order record showing what was actually ordered/described",
        "Merchant's response to the cardholder's complaint, if any",
    ],
    ("RUPAY", "PRE-DISPUTE"): [
        "Order record",
        "Communication log documenting the complaint and any resolution offered",
    ],
}

# dispute_type -> required evidence used to live here as a hardcoded dict.
# It's now admin-editable data (EvidenceRequirementModel, "Evidence
# Requirements" in Admin) — see README §26. Callers load the active rows and
# pass them in as `dispute_type_rules`: {dispute_type: [{"evidence_type",
# "description", "is_required"}, ...]}. Keeps this module DB-free and pure —
# it's a fallback used when the scheme-specific (network, reason_code) table
# above has no rule for this case, so the deterministic safety net isn't
# fully dormant on the network/reason_code-less data most cases have today.

_DEFAULT_CHECKLIST = ["No scheme-specific rule on file for this network/reason code — falling back to general materiality."]

# Explicitly approximate — a small seed table, not a claim of extracted regulatory
# accuracy. Real per-reason-code deadlines vary by region/scenario and aren't
# systematically extractable from free text at this corpus's scale (see README §21.3).
_DEFAULT_DEADLINE_DAYS: dict[tuple[str, str], int] = {
    ("VISA", "10.4"): 120,
    ("VISA", "13.1"): 120,
    ("MASTERCARD", "4853"): 120,
    ("RUPAY", "PRE-DISPUTE"): 15,
}
_FALLBACK_DEADLINE_DAYS = 120  # generic card-network chargeback window when no specific rule is on file


def assess_completeness(
    network: str | None,
    reason_code: str | None,
    evidence_list: list[dict[str, Any]],
    dispute_type: str | None = None,
    dispute_type_rules: dict[str, list[dict[str, Any]]] | None = None,
) -> dict[str, Any]:
    """
    Deterministic evidence-completeness check — not a substitute for the LLM's
    gap analysis, a safety net under it. Tries the scheme-specific
    (network, reason_code) table first (the more precise rule when both are
    known); most disputes in this platform don't have network/reason_code set,
    so this falls back to `dispute_type_rules` — the admin-editable
    EvidenceRequirementModel rows for this dispute_type, loaded and passed in
    by the caller (this module stays DB-free) — so the safety net isn't
    dormant for those cases. `rule_source` tells the caller which one matched.
    """
    key = ((network or "").upper(), (reason_code or "").upper())
    required = _REQUIRED_EVIDENCE.get(key)
    checklist = _CHECKLIST.get(key)
    rule_source = "SCHEME" if required else None

    if not required and dispute_type and dispute_type_rules:
        rows = dispute_type_rules.get(dispute_type.upper())
        if rows:
            required = [r["evidence_type"] for r in rows if r.get("is_required")]
            checklist = [r["description"] for r in rows if r.get("description")]
            rule_source = "DISPUTE_TYPE" if required else None

    if not required:
        return {
            "rule_found": False,
            "rule_source": None,
            "completeness_pct": None,
            "satisfied": [],
            "missing_required": [],
            "checklist": checklist or _DEFAULT_CHECKLIST,
        }

    present_types = {e.get("evidence_type", "").upper() for e in evidence_list}
    satisfied = [t for t in required if t in present_types]
    missing = [t for t in required if t not in present_types]
    pct = round(100 * len(satisfied) / len(required)) if required else 100

    return {
        "rule_found": True,
        "rule_source": rule_source,
        "completeness_pct": pct,
        "satisfied": satisfied,
        "missing_required": missing,
        "checklist": checklist or _DEFAULT_CHECKLIST,
    }


def assess_eligibility(
    network: str | None, reason_code: str | None,
    dispute_created_at: datetime | None, now: datetime,
) -> dict[str, Any]:
    """
    Deterministic time-based eligibility heuristic — separate from and additive to
    assess_completeness's exact-match evidence check, which stays untouched. Returns
    None fields with an explanatory note when there isn't enough information, rather
    than guessing an answer.

    Deliberately narrow: this checks days-elapsed against a small, explicitly-
    approximate deadline table (_DEFAULT_DEADLINE_DAYS above), not MCC, region, or
    scenario-specific rules extracted from the uploaded corpus — see README §21.3 for
    what that would take and why it isn't done here.
    """
    if dispute_created_at is None:
        return {
            "within_deadline": None, "days_elapsed": None, "deadline_days": None,
            "note": "No dispute creation timestamp available to compute elapsed time.",
        }

    key = ((network or "").upper(), (reason_code or "").upper())
    deadline_days = _DEFAULT_DEADLINE_DAYS.get(key, _FALLBACK_DEADLINE_DAYS)
    days_elapsed = (now - dispute_created_at).days
    within = days_elapsed <= deadline_days

    note = (
        f"Heuristic check: {days_elapsed} day(s) since dispute creation against a "
        f"{deadline_days}-day approximate window"
        + ("" if key in _DEFAULT_DEADLINE_DAYS else
           f" (no specific rule on file for {key[0] or 'this network'}/{key[1] or 'this reason code'} — used the generic fallback)")
        + ". This is a seed heuristic, not a verified regulatory deadline."
    )
    return {
        "within_deadline": within, "days_elapsed": days_elapsed,
        "deadline_days": deadline_days, "note": note,
    }


def missing_evidence_gaps(
    network: str | None, reason_code: str | None, evidence_list: list[dict[str, Any]],
    dispute_type: str | None = None,
    dispute_type_rules: dict[str, list[dict[str, Any]]] | None = None,
) -> list[str]:
    """Gap descriptions for required evidence types absent from the case."""
    result = assess_completeness(network, reason_code, evidence_list, dispute_type, dispute_type_rules)
    if result["rule_source"] == "SCHEME":
        reason = f"required by {(network or '').upper()} for reason code {reason_code} representment"
    else:
        reason = f"commonly required to investigate a {(dispute_type or '').replace('_', ' ').lower()} dispute"
    return [
        f"Missing {evidence_type.replace('_', ' ').title()} — {reason}"
        for evidence_type in result["missing_required"]
    ]


def validate_citations(evidence_refs: list[str], known_evidence_ids: set[str]) -> tuple[list[str], list[str]]:
    """
    Enforce the platform's own "AI must never fabricate evidence" rule (E3) in
    code, not just in the prompt. Any cited evidence ID that doesn't belong to
    the case is dropped rather than silently persisted as if verified.

    The LLM's context only ever shows evidence as an 8-char ID prefix (see
    nodes.assess_evidence's evidence_summary) — it cannot produce the full
    UUID even when asked to. A ref matching exactly one known ID by prefix is
    resolved to that full ID rather than dropped; an ambiguous or unknown
    prefix is dropped, never guessed.

    Returns (valid_refs, dropped_refs).
    """
    valid, dropped = [], []
    for ref in evidence_refs or []:
        if ref in known_evidence_ids:
            valid.append(ref)
            continue
        matches = [eid for eid in known_evidence_ids if eid.startswith(ref)]
        if len(matches) == 1:
            valid.append(matches[0])
        else:
            dropped.append(ref)
    return valid, dropped
