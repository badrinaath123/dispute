"""
Document Understanding — first box of the "AI Intake & Classification Layer" the user
designed (Email/Letter -> Document Understanding -> Case Creation Assistant). Takes an
uploaded letter/scan (image or PDF) and extracts structured fields to pre-fill the
existing case-creation form — it never creates a case itself. Uses gemini-2.5-flash
(packages/intelligence/llm_client.call_vision_llm) for the vision/OCR step, per the
user's explicit instruction.

Honesty rule, same as every other AI feature in this codebase: a field that can't
actually be read from the document comes back null, never a guessed plausible value.
"""
from __future__ import annotations

import json
from typing import Any, Optional

from packages.intelligence import vision_utils
from packages.intelligence.llm_client import call_vision_llm_multi, extract_json_str
from packages.observability.logging import get_logger

logger = get_logger("intelligence.document_understanding")

# Mirrors NewCasePage.tsx's DISPUTE_TYPES exactly — Gemini classifies against the
# platform's real categories, not invented ones. README §49/§56: narrowed to the 3
# CFPB-ranked categories the demo actually shows (Cancelled Recurring Transaction 40%,
# Service Not Received 21%, Credit Not Processed 18%) after live classification kept
# mis-firing UNAUTHORIZED_TRANSACTION on documents that were actually one of these
# three — a smaller, correct enum beats a larger one the model occasionally guesses
# wrong on. The removed types (UNAUTHORIZED_TRANSACTION, DUPLICATE_TRANSACTION,
# MERCHANDISE_NOT_AS_DESCRIBED, CASH_WITHDRAWAL_DISPUTE, PROCESSING_ERROR) aren't
# blocked anywhere else in the backend — only the classifier's vocabulary shrank, not
# the domain model, so nothing breaks if a case with one of those types already exists.
DISPUTE_TYPES = [
    "SUBSCRIPTION_CANCELLATION",
    "MERCHANDISE_NOT_RECEIVED",
    "REFUND_NOT_PROCESSED",
]

# Mirrors the evidence documentType vocabulary already used across the platform
# (seeded demo evidence, sample-letter generation — README §24). Lets each
# uploaded document be classified and attached as evidence under its actual
# type instead of a generic catch-all when multiple documents are uploaded.
#
# CHARGEBACK_REBUTTAL and MERCHANT_SHIPPING_EVIDENCE (README §71) were added after
# real merchant-side uploads (a chargeback rebuttal letter, delivery/shipping proof
# filed specifically to contest a chargeback) kept falling into OTHER — they're
# real HIGH-materiality evidence types (packages/intelligence/materiality.py's
# _HIGH_TYPES) that this classifier's vocabulary simply didn't have words for yet.
DOCUMENT_TYPES = [
    "CARDHOLDER_LETTER",
    "ORDER_INVOICE",
    "RETURN_CONFIRMATION",
    "REFUND_CONFIRMATION",
    "MERCHANT_COMMUNICATION",
    "TRANSACTION_RECEIPT",
    "AUTHENTICATION_LOG",
    "SHIPPING_TRACKING",
    "CANCELLATION_CONFIRMATION",
    "SUBSCRIPTION_AGREEMENT",
    "CHARGEBACK_REBUTTAL",
    "MERCHANT_SHIPPING_EVIDENCE",
    "OTHER",
]

_SYSTEM = """\
You are extracting structured information from a cardholder's dispute letter or claim
document for a bank analyst to review before creating a case. Extract ONLY what the
document actually states. If a field cannot be determined from the document, return
null for it — never invent or guess a plausible-looking value. A case creation form
will be pre-filled from your output and a human will review every field before
anything is submitted, so accuracy and honesty about uncertainty matter more than
completeness.
"""

_PROMPT = """\
This is ONE document among possibly several the analyst is uploading for the same case.
First classify what kind of document this actually is, then extract whatever it states.

- document_type: your best classification of this specific document, one of
  {document_types}. Use OTHER if none clearly fits — never force a guess. Classify by
  what the document itself functionally IS, never by which keywords it happens to
  contain — a document that merely mentions or quotes a cancellation somewhere in its
  text is NOT automatically a CANCELLATION_CONFIRMATION:
  - CANCELLATION_CONFIRMATION is ONLY the actual formal cancellation notice itself —
    its own primary content IS the confirmation (e.g. "Your subscription has been
    cancelled, confirmation #X"). A support ticket, email thread, or dispute narrative
    that merely quotes or references a cancellation confirmation number issued
    elsewhere is NOT this type.
  - MERCHANT_COMMUNICATION is any email, support-ticket log, or letter that contains
    the merchant's own reply/response addressing the complaint (their position, an
    offer, a policy explanation) — this applies even if the same document also
    contains the cardholder's original message, and even if the thread's subject or
    narrative is about a cancellation. A merchant's actual reply is always the more
    specific, correct classification over a topic the thread happens to discuss.
  - CHARGEBACK_REBUTTAL is a document a merchant is submitting specifically to
    contest/rebut a chargeback — a formal representment letter, a "response to
    dispute" cover document, or a structured rebuttal that argues against the
    cardholder's claim point by point. This is more specific than MERCHANT_COMMUNICATION
    when the document's actual purpose is contesting the chargeback itself, not just
    replying to a support inquiry.
  - MERCHANT_SHIPPING_EVIDENCE is delivery/shipping proof the merchant is submitting as
    evidence (a courier tracking record, proof-of-delivery scan, signed delivery
    confirmation) — more specific than the generic SHIPPING_TRACKING when it's framed
    as evidence being filed for a dispute rather than a routine tracking page.
  - Use OTHER only when the document genuinely doesn't fit any listed type — never as a
    default for "looks like a business document but I'm not sure which kind." If it's
    clearly a letter, receipt, log, or confirmation of some kind, pick the closest real
    category above rather than reaching for OTHER.
- is_id_document: true if this document IS a government-issued identity document (an
  Aadhar card, PAN card, passport, voter ID card, or driving licence) or prominently
  displays one — false for an ordinary business document even if it mentions a masked
  card number. Cyera Validation (README §38) blocks the upload entirely when true, so
  get this right rather than guessing toward false.
- id_types: array of the specific type(s) detected — ONLY "AADHAR_CARD", "PAN_CARD",
  "PASSPORT", "VOTER_ID", "DRIVING_LICENCE" — empty array if is_id_document is false.
  CRITICAL: never transcribe the actual ID number anywhere in your response, including
  here or in text_summary — describe what kind of document it is, not its contents.
- document_title: a short display name for THIS document, 2-4 words, Title Case — the
  kind of label you'd see on a file tab or folder, not a sentence (e.g. "Cancellation
  Policy", "Order Invoice", "Chargeback Rebuttal Letter", "Delivery Confirmation").
  Base it on what the document itself actually is (its own heading/subject/nature),
  not a restatement of document_type and never a summary of its contents — this is a
  name, not a description. Still required even when document_type is OTHER; a short
  real name is possible even for a document that doesn't fit the fixed type list.
- text_summary: a factual 1-2 sentence summary of what THIS document actually shows or
  states (e.g. "Order invoice for a laptop bag, Rs 2,999, dated 10 Mar 2026" or "Email
  from merchant support confirming the refund was processed on 29 Mar"). This is what an
  analyst will see later instead of re-opening the file, so make it substantive, not a
  restatement of the document_type. For a policy, terms, or agreement document
  specifically: ALWAYS include the exact governing numbers stated — a notice period in
  days, a deadline, a fee amount, a percentage — verbatim, never paraphrased into a vague
  phrase like "cancellation terms apply" or "a notice period is required". The case
  recommendation is reasoned from this summary text alone, not the original file — a rule
  mentioned without its actual number is functionally useless to it (e.g. "requires 7
  days' written notice before the billing date", not "has a cancellation notice period").
- customer_name: the cardholder's name, or null
- masked_card_number: a masked/partial card number if shown (e.g. "****1234"), or null
- card_tier: the card's tier/product name, ONE OF "PLATINUM", "GOLD", "CLASSIC" — only if
  the document actually states or shows a card tier (e.g. "Platinum Card", a product name
  containing one of these words); null if not stated, never guessed from the card number
  or anything else
- authentication_status: ONE OF "AUTHENTICATED", "NOT_AUTHENTICATED" — only if a document
  like an authentication/3DS/chip-and-PIN log actually states the result; null otherwise,
  never inferred from context
- document_date: the single date this document is fundamentally ABOUT — the date of the
  real-world event/action it records (e.g. the cancellation date on a cancellation
  confirmation, the transaction date on a receipt, the date a refund was actually
  processed on a refund confirmation, the date stated on a merchant's response letter).
  This is the platform's own "business event time," distinct from and never the same as
  when the analyst happens to be uploading this file — never today's date, never a
  guess. Null if the document genuinely doesn't state any date tied to what it records.
- narrative: a 1-3 sentence summary of the cardholder's claim in their own words/intent,
  or null if this document is not the cardholder's own letter/statement (e.g. it's an
  invoice or shipping record with no narrative of its own)
- return_date: date merchandise was returned, if stated, or null
- expected_refund_amount: numeric amount, if a refund amount is stated, or null
- expected_refund_date: date a refund was expected/promised, if stated, or null
- refund_reference_number: refund/reference number, if stated, or null
- merchant_response: the merchant's stated position specifically replying to the
  cardholder's complaint (e.g. from a support email or complaint-response letter) — null
  for a generic invoice/receipt line, even if the document contains other text
- merchant_contact_date: date the merchant was contacted, if stated, or null
- transactions: an array of ONE ENTRY PER DISTINCT DISPUTED TRANSACTION mentioned (a
  letter disputing several separate charges should produce several entries, not one).
  Each entry: {{
    "dispute_type": one of {dispute_types}, or null if the type isn't clear,
    "transaction_reference": order/transaction reference number if stated, or null,
    "merchant_name": merchant name if stated, or null,
    "amount_disputed": numeric amount if stated, or null,
    "transaction_date": date the transaction/purchase occurred, if stated, or null,
    "posting_date": date the transaction posted/settled on the statement, if stated
      and different from transaction_date, or null
  }}
- confidence: your overall confidence (0.0-1.0) that this extraction is accurate and complete
- notes: a short honest note on anything illegible, ambiguous, or missing — empty string if none

Every date field above (document_date, return_date, expected_refund_date,
merchant_contact_date, transaction_date, posting_date) MUST be normalized to ISO 8601 "YYYY-MM-DD" format
regardless of how it's written on the document (e.g. "July 15, 2025" or "15/07/2025"
both become "2025-07-15") — a form field downstream requires this exact format and will
silently reject anything else. Still null if no date is stated; never guess a date.

Extract ONLY fields this specific document actually states — leave everything else null
rather than inferring it from context you don't have. Respond as a single JSON object
with exactly these fields.
""".strip()


_b64_of = vision_utils.b64_of


def extract_claim_from_document(file_bytes: bytes, mime_type: str) -> dict[str, Any]:
    """
    Returns a dict: customer_name, narrative, transactions (list of dicts), confidence,
    notes. Raises on a genuinely unreadable file (corrupt PDF, empty image); the caller
    is responsible for turning that into a 4xx response, not silently returning empty.
    """
    if mime_type == "application/pdf":
        # Every page, not just the first — a real support-ticket log/email thread
        # commonly puts the merchant's actual reply on page 2+; only ever seeing page 1
        # caused real misclassifications (e.g. a document with a merchant reply on
        # page 2 coming back CANCELLATION_CONFIRMATION or CARDHOLDER_LETTER because the
        # model never saw the reply at all).
        pages = vision_utils.render_pdf_pages_to_png(file_bytes)
        images = [(_b64_of(p), "image/png") for p in pages]
    else:
        images = [(_b64_of(file_bytes), mime_type)]

    prompt = _PROMPT.format(dispute_types=DISPUTE_TYPES, document_types=DOCUMENT_TYPES)
    raw = call_vision_llm_multi(_SYSTEM, prompt, images)

    try:
        parsed = json.loads(extract_json_str(raw))
        if not isinstance(parsed, dict):
            parsed = {}
    except Exception:
        # Silently returning {} here used to be indistinguishable from a genuinely
        # blank/unreadable document — logging the raw response is what actually
        # surfaced the real cause of a "why did this come back empty?" report
        # (a truncated max_tokens cutting the JSON off mid-object).
        logger.warning("vision_extraction_json_parse_failed", raw_response=raw[:2000])
        parsed = {}

    def _as_str(v: Any) -> Optional[str]:
        # The model doesn't reliably return every field as a string (amount_disputed in
        # particular tends to come back as a JSON number) — normalize defensively rather
        # than trust the model's output typing.
        if v is None:
            return None
        return str(v)

    transactions_raw = parsed.get("transactions")
    transactions: list[dict[str, Optional[str]]] = []
    if isinstance(transactions_raw, list):
        for t in transactions_raw:
            if not isinstance(t, dict):
                continue
            dispute_type = t.get("dispute_type")
            if dispute_type not in DISPUTE_TYPES:
                dispute_type = None
            transactions.append({
                "dispute_type": dispute_type,
                "transaction_reference": _as_str(t.get("transaction_reference")),
                "merchant_name": _as_str(t.get("merchant_name")),
                "amount_disputed": _as_str(t.get("amount_disputed")),
                "transaction_date": _as_str(t.get("transaction_date")),
                "posting_date": _as_str(t.get("posting_date")),
            })

    document_type = parsed.get("document_type")
    if document_type not in DOCUMENT_TYPES:
        document_type = "OTHER"

    card_tier = parsed.get("card_tier")
    if card_tier not in ("PLATINUM", "GOLD", "CLASSIC"):
        card_tier = None
    authentication_status = parsed.get("authentication_status")
    if authentication_status not in ("AUTHENTICATED", "NOT_AUTHENTICATED"):
        authentication_status = None

    valid_id_types = {"AADHAR_CARD", "PAN_CARD", "PASSPORT", "VOTER_ID", "DRIVING_LICENCE"}
    id_types = [t for t in (parsed.get("id_types") or []) if t in valid_id_types]
    is_id_document = bool(parsed.get("is_id_document")) and len(id_types) > 0

    return {
        "document_type": document_type,
        "document_title": _as_str(parsed.get("document_title")),
        "is_id_document": is_id_document,
        "id_types": id_types,
        "text_summary": parsed.get("text_summary") or "",
        "customer_name": _as_str(parsed.get("customer_name")),
        "masked_card_number": _as_str(parsed.get("masked_card_number")),
        "card_tier": card_tier,
        "authentication_status": authentication_status,
        "document_date": _as_str(parsed.get("document_date")),
        "narrative": parsed.get("narrative") or "",
        "return_date": _as_str(parsed.get("return_date")),
        "expected_refund_amount": _as_str(parsed.get("expected_refund_amount")),
        "expected_refund_date": _as_str(parsed.get("expected_refund_date")),
        "refund_reference_number": _as_str(parsed.get("refund_reference_number")),
        "merchant_response": _as_str(parsed.get("merchant_response")),
        "merchant_contact_date": _as_str(parsed.get("merchant_contact_date")),
        "transactions": transactions,
        "confidence": float(parsed.get("confidence", 0.0) or 0.0),
        "notes": parsed.get("notes") or "",
    }


def best_business_event_date(result: dict[str, Any]) -> Optional[str]:
    """
    The single best "when did this actually happen" date for an uploaded document —
    what the Event Timeline (README's business-event-time-not-ingestion-time promise)
    should show instead of the moment the analyst happened to click upload. Priority:
    document_date (the generic field asked for above) first, then the more narrowly-
    named fields for documents where the model found a date but didn't map it to
    document_date. Returns an ISO "YYYY-MM-DD" string or None — callers fall back to
    upload time honestly rather than fabricate a date nothing in the document states.
    """
    candidates = [
        result.get("document_date"),
        (result.get("transactions") or [{}])[0].get("transaction_date"),
        result.get("merchant_contact_date"),
        (result.get("transactions") or [{}])[0].get("posting_date"),
        result.get("return_date"),
        result.get("expected_refund_date"),
    ]
    for c in candidates:
        if c:
            return c
    return None


_EXTENSION_BY_MIME = {
    "application/pdf": "pdf", "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp",
}


def suggested_file_name(document_type: str, mime_type: str) -> str:
    """
    Deterministically derives a storage filename from what the document was
    classified as — never from the name the analyst happened to upload it
    under (e.g. "scan001.pdf", "IMG_4821.jpg"), so the stored evidence is
    named by what it actually is.
    """
    ext = _EXTENSION_BY_MIME.get(mime_type, "bin")
    return f"{document_type.lower()}.{ext}"
