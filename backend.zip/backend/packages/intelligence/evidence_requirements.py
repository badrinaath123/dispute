"""
Loads the admin-editable evidence-requirement rows (EvidenceRequirementModel,
Admin -> Evidence Requirements) into the shape scheme_rules.assess_completeness
/ missing_evidence_gaps expect: {dispute_type: [{"evidence_type", "description",
"is_required"}, ...]}. Shared by the agent runner and the evidence-completeness
API route so both read the same live admin config, not a hardcoded copy.
"""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.persistence.sqlite.models import EvidenceRequirementModel


async def load_active(db: AsyncSession) -> dict[str, list[dict]]:
    result = await db.execute(
        select(EvidenceRequirementModel)
        .where(EvidenceRequirementModel.is_active == True)
        .order_by(EvidenceRequirementModel.dispute_type, EvidenceRequirementModel.sort_order)
    )
    rules: dict[str, list[dict]] = {}
    for row in result.scalars().all():
        rules.setdefault(row.dispute_type.upper(), []).append({
            "evidence_type": row.evidence_type,
            "description": row.description,
            "is_required": row.is_required,
        })
    return rules
