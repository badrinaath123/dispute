"""
Generates a single realistic (clearly-labeled synthetic) cardholder dispute
letter PDF from a case's own data — used by the "attach a sample document"
action so a newly created case can have a real, viewable evidence document
without the analyst needing to source a file of their own. Not a claim of a
real document — same honesty convention as scripts/generate_dummy_docs.py.
"""
from __future__ import annotations
import io
from datetime import datetime

from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer


def generate_cardholder_letter_pdf(
    customer_name: str, merchant_name: str, amount: str, currency: str, cardholder_claim: str,
) -> bytes:
    styles = getSampleStyleSheet()
    title = ParagraphStyle("Title", parent=styles["Title"], fontSize=14, spaceAfter=4)
    sub = ParagraphStyle("Sub", parent=styles["Normal"], fontSize=9, textColor=colors.grey, spaceAfter=16)
    body = ParagraphStyle("Body", parent=styles["Normal"], fontSize=10.5, leading=16, spaceAfter=10)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=LETTER,
                             topMargin=1 * inch, bottomMargin=1 * inch,
                             leftMargin=1 * inch, rightMargin=1 * inch)

    flow = [
        Paragraph(f"{datetime.utcnow().strftime('%d %B %Y')}", body),
        Spacer(1, 8),
        Paragraph("Dispute Letter", title),
        Paragraph("SAMPLE DOCUMENT — generated for demonstration purposes only", sub),
        Paragraph(f"From: {customer_name or 'Cardholder'}", body),
        Paragraph(f"Re: Transaction with {merchant_name or 'the merchant'}"
                   + (f" for {currency or ''} {amount}" if amount else ""), body),
        Spacer(1, 8),
        Paragraph("To Whom It May Concern,", body),
        Paragraph(cardholder_claim or "I am writing to formally dispute a transaction on my account.", body),
        Paragraph("I would appreciate a prompt investigation into this matter.", body),
        Spacer(1, 20),
        Paragraph(f"Sincerely,<br/>{customer_name or 'Cardholder'}", body),
        Paragraph("Sample document — not a real cardholder letter.",
                   ParagraphStyle("Note", parent=styles["Normal"], fontSize=8, textColor=colors.HexColor("#c50f1f"), spaceBefore=24)),
    ]
    doc.build(flow)
    return buf.getvalue()
