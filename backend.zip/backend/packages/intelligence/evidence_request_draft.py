"""
Evidence-request draft — the issuer's own outbound message to the cardholder asking
for specific missing documents once a merchant has challenged (README §52). AI drafts
it, the analyst reviews/edits, then marks it sent. No real SMTP wired up — mirrors the
Twilio SMS feature's draft/log pattern (README §45): honest that nothing is actually
delivered, rather than pretending to without real credentials.
"""
from __future__ import annotations

from packages.intelligence.llm_client import call_llm

_SYSTEM = """\
You are drafting a short, polite email from a bank to a cardholder, asking them to
send specific documents needed to continue investigating their dispute. Use plain,
simple English — short sentences, everyday words, no legal or banking jargon. This
is for a reader who may not be a native English speaker.
"""

_PROMPT = """\
Cardholder's dispute: {cardholder_claim}
Documents we still need: {missing_items}

Write a short email (under 100 words) asking the cardholder to send these documents.
Be polite and clear about what's needed and why. Sign off as "Dispute Resolution Team".
Return only the email body text, nothing else — no subject line, no JSON.
""".strip()


def draft_evidence_request(cardholder_claim: str, missing_items: list[str]) -> str:
    items = ", ".join(missing_items) or "any documents supporting your claim"
    try:
        prompt = _PROMPT.format(cardholder_claim=cardholder_claim or "your recent dispute", missing_items=items)
        return call_llm(_SYSTEM, prompt).strip()
    except Exception:
        return (
            "Hello,\n\nWe're reviewing your dispute and need a bit more information to "
            f"continue. Could you please send us: {items}?\n\nThank you,\nDispute Resolution Team"
        )
