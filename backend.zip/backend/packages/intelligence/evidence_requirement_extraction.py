"""
Extracts evidence-requirement rows for a given dispute type from an uploaded
reference document (a scheme rulebook excerpt, internal SOP page, checklist,
policy screenshot, etc.) — powers Admin -> Evidence Requirements' "Upload"
action, so an admin can bulk-seed the admin-editable checklist
(packages/intelligence/evidence_requirements.py, README §26) from a document
instead of typing every row by hand.

Same gemini-2.5-flash vision pipeline and honesty rule as
document_understanding.py: extract ONLY what the document actually states —
an empty list if it doesn't describe evidence requirements at all, never a
guessed/invented requirement. Nothing here writes to the database; the admin
reviews every extracted row (Admin UI) before any of it is saved.
"""
from __future__ import annotations

import json
from typing import Any

from packages.intelligence import vision_utils
from packages.intelligence.llm_client import call_vision_llm, extract_json_str

_SYSTEM = """\
You are extracting a list of evidence/documentation requirements for
investigating a specific type of card dispute, from a reference document a
bank administrator has uploaded (e.g. a scheme rulebook excerpt, an internal
SOP page, a policy document, or a checklist). Extract ONLY evidence
requirements the document actually states or clearly lists — never invent a
requirement that isn't there. If the document doesn't describe evidence
requirements at all, or doesn't relate to the given dispute type, say so
honestly and return an empty list rather than guessing.
"""

_PROMPT = """\
The administrator uploaded this document as a reference for what evidence is
needed to investigate a "{dispute_type}" dispute.

Extract a list of evidence/document types this document indicates are
needed or relevant — one entry per distinct evidence type mentioned. Each
entry:
{{
  "evidence_type": a SHORT_UPPERCASE_CODE for this evidence type (e.g.
    ORDER_INVOICE, CANCELLATION_CONFIRMATION, AUTHENTICATION_LOG). Use the
    document's own terminology if it names one explicitly; otherwise derive
    a reasonable code from what the evidence actually is — never a generic
    placeholder,
  "description": a 1-sentence description of what this evidence should show,
    grounded in what the document actually says,
  "is_required": true if the document indicates this is mandatory/required,
    false if it reads as optional/supplementary or this isn't clear
}}

Also return:
- "confidence": your overall confidence (0.0-1.0) that this extraction is accurate
- "notes": a short honest note — e.g. if the document seems unrelated to this
  dispute type, or partially illegible, or you're not confident items are complete

Respond as a single JSON object: {{"requirements": [...], "confidence": ..., "notes": ...}}
""".strip()


def extract_requirements(file_bytes: bytes, mime_type: str, dispute_type: str) -> dict[str, Any]:
    """
    Returns a dict: requirements (list of {evidence_type, description,
    is_required}), confidence, notes. Raises on a genuinely unreadable file;
    the caller turns that into a 4xx, not a silent empty result.
    """
    if mime_type == "application/pdf":
        image_bytes = vision_utils.render_pdf_first_page_to_png(file_bytes)
        image_mime = "image/png"
    else:
        image_bytes = file_bytes
        image_mime = mime_type

    prompt = _PROMPT.format(dispute_type=dispute_type)
    raw = call_vision_llm(_SYSTEM, prompt, vision_utils.b64_of(image_bytes), image_mime)

    try:
        parsed = json.loads(extract_json_str(raw))
        if not isinstance(parsed, dict):
            parsed = {}
    except Exception:
        parsed = {}

    requirements: list[dict[str, Any]] = []
    for r in parsed.get("requirements") or []:
        if not isinstance(r, dict):
            continue
        evidence_type = str(r.get("evidence_type") or "").strip().upper().replace(" ", "_")
        description = str(r.get("description") or "").strip()
        if not evidence_type or not description:
            continue
        requirements.append({
            "evidence_type": evidence_type,
            "description": description,
            "is_required": bool(r.get("is_required", True)),
        })

    return {
        "requirements": requirements,
        "confidence": float(parsed.get("confidence", 0.0) or 0.0),
        "notes": parsed.get("notes") or "",
    }
