"""
Materiality assessment — rule-based heuristics, no LLM.
Returns MaterialityLevel string: HIGH | MEDIUM | LOW | UNKNOWN.
"""
from typing import Any

_HIGH_TYPES = {
    "TRANSACTION_RECEIPT",
    "AUTHENTICATION_LOG",
    "DELIVERY_CONFIRMATION",
    "CHARGEBACK_REBUTTAL",
    "MERCHANT_SHIPPING_EVIDENCE",
    # Real document-upload vocabulary (document_understanding.py's DOCUMENT_TYPES) —
    # these are the types most likely to directly confirm or contradict the
    # cardholder's own claim, so they carry the same weight as the receipt/auth-log
    # types above. Without these, every document a merchant actually uploads through
    # this app fell through to LOW by default and could never trigger Z2's
    # HIGH-materiality stale-approval invalidation.
    "CANCELLATION_CONFIRMATION",
    "MERCHANT_COMMUNICATION",
    "REFUND_CONFIRMATION",
    "RETURN_CONFIRMATION",
}

_MEDIUM_TYPES = {
    "CARDHOLDER_STATEMENT",
    "MERCHANT_POLICY",
    "ACCOUNT_HISTORY",
    "IP_GEOLOCATION",
    "DEVICE_FINGERPRINT",
    "ORDER_INVOICE",
    "SHIPPING_TRACKING",
    "SUBSCRIPTION_AGREEMENT",
    "CARDHOLDER_LETTER",
}


def assess(evidence_type: str, normalized_content: dict[str, Any], source_type: str) -> str:
    """
    Rule-based materiality.

    Upgrade to HIGH if:
    - evidence_type in HIGH set
    - content contains 'signature' or 'pin_verified'
    - delivery confirmed with tracking number and carrier timestamp

    Returns one of HIGH / MEDIUM / LOW / UNKNOWN.
    """
    et = evidence_type.upper()

    if et in _HIGH_TYPES:
        return "HIGH"

    # Content-level signals
    content_str = str(normalized_content).lower()
    high_signals = ["signature", "pin_verified", "cvv_matched", "tracking_number", "delivered_at"]
    if any(sig in content_str for sig in high_signals):
        return "HIGH"

    if et in _MEDIUM_TYPES:
        return "MEDIUM"

    medium_signals = ["timestamp", "ip_address", "device_id", "merchant_id"]
    if any(sig in content_str for sig in medium_signals):
        return "MEDIUM"

    return "LOW"
