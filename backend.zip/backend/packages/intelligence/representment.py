"""
Representment draft generation — upgrades the static template previously hardcoded in
apps/web/src/features/merchant/MerchantWorkspace.tsx's ResponseBuilder
(`We are challenging this chargeback on the following grounds:\\n\\n${recommendation.content}...`)
into an LLM draft grounded in the case's own recommendation, its open evidence gaps, and
network-scoped regulatory passages — explicitly cited, not asserted.
"""
from __future__ import annotations

import json
from typing import Any, Optional

from packages.intelligence import faiss_index
from packages.intelligence.llm_client import call_llm, extract_json_str

_SYSTEM = """\
You are drafting a merchant's chargeback representment response. Ground every claim in
the provided recommendation, evidence, and policy passages. Cite which passage supports
each rule-based claim by its bracketed index, e.g. [2]. Never invent evidence that
isn't listed.

Length is a hard constraint, not a suggestion: this is a real letter a busy reviewer on
the other side has to read, not a case-file essay. The recommendation text you're given
is internal reasoning, written for an analyst — do not copy or paraphrase it at length;
extract only the 2-3 facts that actually carry the argument. Target 100-150 words, a
maximum of 3 short paragraphs, no preamble ("We are writing to..."), no restating the
dispute back to the reader, no closing pleasantries. Plain declarative sentences —
state the grounds, cite the evidence, state the conclusion. If you cannot make the case
in that length, you're including detail that doesn't need to be there, not detail the
letter is missing.
"""

_PROMPT = """\
Dispute type: {dispute_type}
Cardholder claim: {cardholder_claim}
Network: {network}

Recommendation: {recommendation_content}

Evidence available: {evidence_summary}
Open evidence gaps: {gaps_summary}

Retrieved policy passages:
{passages}

Draft a short, professional representment response for the merchant to submit (100-150
words, max 3 short paragraphs — see length constraint above), citing the policy
passages that support the merchant's position by their bracketed index. Respond as
JSON with fields: draft_text (string), citations (array of integer passage indices
actually referenced in draft_text).
""".strip()


def _fmt_passage(i: int, p: dict) -> str:
    page_suffix = f", p. {p['page']}" if p.get("page") else ""
    return f"[{i + 1}] ({p['source']}{page_suffix}): {p['text'][:600]}"


def generate_representment_draft(
    dispute_type: str, cardholder_claim: str, network: Optional[str],
    recommendation_content: str, evidence_types: list[str], gap_descriptions: list[str],
) -> dict[str, Any]:
    passages = faiss_index.find_regulatory_context(
        f"{dispute_type} {cardholder_claim} representment evidence",
        top_k=4, network=(network or "").upper() or None,
    )
    passages_text = "\n\n".join(_fmt_passage(i, p) for i, p in enumerate(passages)) or "(none retrieved)"

    prompt = _PROMPT.format(
        dispute_type=dispute_type, cardholder_claim=cardholder_claim, network=network or "UNKNOWN",
        recommendation_content=recommendation_content[:1000],
        evidence_summary=", ".join(evidence_types) or "(none)",
        gaps_summary="; ".join(gap_descriptions) or "(none)",
        passages=passages_text,
    )

    try:
        raw = call_llm(_SYSTEM, prompt)
        parsed = json.loads(extract_json_str(raw))
        if not isinstance(parsed, dict):
            parsed = {}
    except Exception:
        parsed = {}

    citation_indices = parsed.get("citations", []) if isinstance(parsed.get("citations"), list) else []
    citations = [
        {"source": passages[i - 1]["source"], "page": passages[i - 1].get("page"), "title": passages[i - 1]["title"]}
        for i in citation_indices
        if isinstance(i, int) and 1 <= i <= len(passages)
    ]

    return {
        "draft_text": parsed.get("draft_text") or (
            f"We are challenging this chargeback on the following grounds:\n\n{recommendation_content}"
        ),
        "citations": citations,
    }
