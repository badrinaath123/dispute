"""
Standard Visa reason-code reference — deterministic, no LLM, no RAG.

Fallback for reason_code_classifier.py's RAG-grounded suggestion (README §21):
when the uploaded scheme rulebooks don't contain content specific enough to
ground an LLM suggestion, that's a real, honest outcome (NONE_CONFIDENT), not a
bug — the platform's own indexed corpus is a small seed set, not the full Visa
rulebook (README §17.2). This table is the standard public network
classification for the platform's own dispute_type categories in that case, not
a live regulatory feed and not a claim that any model produced it.

VISA_REASON_CODES (README §77) is the full Visa Claims Resolution code catalog,
supplied directly by the user rather than recalled — the single source of truth
this module's dispute_type mapping is built from, and available on its own for
any future feature that needs the complete list (a glossary, an admin picker)
rather than just the one best-match per dispute_type.
"""
from __future__ import annotations
from typing import Optional

# The full Visa Claims Resolution reason-code catalog (categories 10-13) — kept as
# its own lookup, independent of which subset _REFERENCE below maps a dispute_type
# to, so it's available whole for anything that needs it later.
VISA_REASON_CODES: dict[str, str] = {
    "10.1": "EMV Liability Shift Counterfeit Fraud",
    "10.2": "EMV Liability Shift Non-Counterfeit Fraud",
    "10.3": "Other Fraud: Card-Present Environment",
    "10.4": "Other Fraud: Card-Absent Environment",
    "10.5": "Visa Fraud Monitoring Program",
    "11.1": "Card Recovery Bulletin",
    "11.2": "Declined Authorization",
    "11.3": "No Authorization",
    "12.1": "Late Presentment",
    "12.2": "Incorrect Transaction Code",
    "12.3": "Incorrect Currency",
    "12.4": "Incorrect Account Number",
    "12.5": "Incorrect Amount",
    "12.6": "Duplicate Processing / Paid by Other Means",
    "12.7": "Invalid Data",
    "13.1": "Merchandise / Services Not Received",
    "13.2": "Canceled Recurring Transaction",
    "13.3": "Not as Described or Defective Merchandise / Services",
    "13.4": "Counterfeit Merchandise",
    "13.5": "Misrepresentation",
    "13.6": "Credit Not Processed",
    "13.7": "Canceled Merchandise / Services",
    "13.8": "Original Credit Transaction Not Accepted",
    "13.9": "Non-Receipt of Cash or Recognized Value",
}

# dispute_type -> the single VISA_REASON_CODES entry that most specifically matches
# it. Deliberately not every dispute_type this platform has ever supported:
# PROCESSING_ERROR spans 7 different 12.x subcodes (Late Presentment, Incorrect
# Transaction Code/Currency/Account/Amount, Duplicate Processing, Invalid Data) with
# nothing in this platform's data model to say which one applies to a given case —
# picking one would be a guess dressed up as a lookup, the same "don't guess" rule
# every other AI/deterministic feature in this codebase already follows. Left out
# rather than picked wrong-but-confident.
_DISPUTE_TYPE_TO_CODE: dict[str, str] = {
    "SUBSCRIPTION_CANCELLATION": "13.2",
    "MERCHANDISE_NOT_RECEIVED": "13.1",
    "REFUND_NOT_PROCESSED": "13.6",
    "MERCHANDISE_NOT_AS_DESCRIBED": "13.3",
    "UNAUTHORIZED_TRANSACTION": "10.4",
    "DUPLICATE_TRANSACTION": "12.6",
    "CASH_WITHDRAWAL_DISPUTE": "13.9",
}


def standard_reference(dispute_type: Optional[str]) -> Optional[dict[str, str]]:
    """The standard Visa reason code for this dispute_type, or None if this
    table doesn't have a confident single-code entry for it (never guessed)."""
    code = _DISPUTE_TYPE_TO_CODE.get((dispute_type or "").upper())
    if not code:
        return None
    return {"network": "VISA", "code": code, "label": VISA_REASON_CODES[code]}
