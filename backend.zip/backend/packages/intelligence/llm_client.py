"""
Shared LLM + embedding calls — LiteLLM-proxied, LangChain OpenAI-compatible client.
`call_llm` originally lived only in packages/agent/nodes.py; extracted here so the same
call can be reused outside the agent graph (reason-code suggestion, representment
drafting, case Q&A — packages/intelligence/*) without importing agent internals into API
routes. `embed_texts` is the same proxy's embedding endpoint (text-embedding-3-large) —
see ref/rag-testing/rag.py for the original reference implementation this mirrors.
"""
import os

LLM_MODEL = os.getenv("LLM_MODEL", "azure/genailab-maas-gpt-4.1")
EMBED_MODEL = os.getenv("EMBED_MODEL", "azure/genailab-maas-text-embedding-3-large")
EMBED_DIM = 3072  # text-embedding-3-large
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")  # vision/OCR calls — document understanding
_LLM_BASE_URL = os.getenv("LITELLM_BASE_URL", "https://genailab.tcs.in")
_LLM_API_KEY = os.getenv("LITELLM_API_KEY", "sk-Dummy")

# Every httpx.Client below previously had NO timeout at all — a stalled connection
# to the corporate proxy (genailab.tcs.in) could block the request forever, and
# because FastAPI runs these as plain sync calls on the main event loop, one stuck
# call froze the entire server, not just the request that made it. 60s is well above
# every real call duration observed this session (typically 5-30s).
_HTTP_TIMEOUT = 60.0

_embeddings_client = None


def _get_embeddings_client():
    """Shared OpenAIEmbeddings instance — one HTTP client, not one per call."""
    global _embeddings_client
    if _embeddings_client is None:
        import httpx
        from langchain_openai import OpenAIEmbeddings

        _embeddings_client = OpenAIEmbeddings(
            base_url=_LLM_BASE_URL,
            model=EMBED_MODEL,
            api_key=_LLM_API_KEY,
            http_client=httpx.Client(verify=False),
        )
    return _embeddings_client


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Embed a batch of texts via the LiteLLM-proxied text-embedding-3-large endpoint."""
    from packages.intelligence import cost_tracking

    result = _get_embeddings_client().embed_documents(texts)
    tokens = sum(cost_tracking.estimate_tokens(t) for t in texts)
    cost_tracking.record_usage(EMBED_MODEL, "embed", tokens, 0, estimated_tokens=True)
    return result


def embed_query(text: str) -> list[float]:
    from packages.intelligence import cost_tracking

    result = _get_embeddings_client().embed_query(text)
    cost_tracking.record_usage(EMBED_MODEL, "embed", cost_tracking.estimate_tokens(text), 0, estimated_tokens=True)
    return result


def extract_json_str(text: str) -> str:
    """Extract the first balanced JSON array/object substring from LLM output."""
    start = text.find("[")
    obj_start = text.find("{")
    if start == -1 or (obj_start != -1 and obj_start < start):
        start = obj_start
    if start == -1:
        return "[]"
    depth = 0
    close = "[" if text[start] == "[" else "{"
    end_char = "]" if close == "[" else "}"
    for i, ch in enumerate(text[start:], start):
        if ch == close:
            depth += 1
        elif ch == end_char:
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    return "[]"


def _fix_mojibake(text: str) -> str:
    """Repairs UTF-8 text that the LiteLLM proxy has round-tripped through a
    Latin-1/cp1252 layer somewhere upstream of us — visible live as curly
    quotes/apostrophes in LLM output coming back as "a€™" instead of "'"
    (e.g. recommendation content, hypothesis reasoning). Every real UTF-8
    character above the Latin-1 range (any genuine curly quote, accented
    letter, etc.) cannot be encoded as Latin-1 at all, so this round-trip
    only ever succeeds — and only ever changes anything — on text that was
    already mis-decoded; correctly-decoded text passes through untouched.
    """
    try:
        repaired = text.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return text
    return repaired


def _record_usage(model: str, call_type: str, response) -> None:
    """response.usage_metadata is LangChain's standard shape ({'input_tokens',
    'output_tokens', 'total_tokens', ...}) — verified live against this exact proxy
    for both the chat and vision models before relying on it (README §37)."""
    from packages.intelligence import cost_tracking

    usage = getattr(response, "usage_metadata", None)
    if not usage:
        return
    cost_tracking.record_usage(model, call_type, usage.get("input_tokens", 0), usage.get("output_tokens", 0))


def call_llm(system: str, user: str) -> str:
    """Call LLM via LangChain OpenAI-compatible client (LiteLLM proxy)."""
    import httpx
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import SystemMessage, HumanMessage

    http_client = httpx.Client(verify=False, timeout=_HTTP_TIMEOUT)
    chat = ChatOpenAI(
        base_url=_LLM_BASE_URL,
        model=LLM_MODEL,
        api_key=_LLM_API_KEY,
        http_client=http_client,
        max_tokens=2048,
    )
    messages = [SystemMessage(content=system), HumanMessage(content=user)]
    response = chat.invoke(messages)
    _record_usage(LLM_MODEL, "chat", response)
    return _fix_mojibake(response.content)


def call_vision_llm(system: str, user_text: str, image_b64: str, mime_type: str) -> str:
    """
    Vision/OCR call — gemini-2.5-flash via the same LiteLLM proxy (confirmed available
    through that proxy's own /v1/models listing, no separate Google API key needed).
    Generic (not hardcoded to any one extraction task) so it can be reused beyond
    document understanding; the dispute-letter-specific prompt lives in
    packages/intelligence/document_understanding.py.
    """
    import httpx
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import SystemMessage, HumanMessage

    http_client = httpx.Client(verify=False, timeout=_HTTP_TIMEOUT)
    chat = ChatOpenAI(
        base_url=_LLM_BASE_URL,
        model=GEMINI_MODEL,
        api_key=_LLM_API_KEY,
        http_client=http_client,
        max_tokens=2048,
    )
    messages = [
        SystemMessage(content=system),
        HumanMessage(content=[
            {"type": "text", "text": user_text},
            {"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{image_b64}"}},
        ]),
    ]
    response = chat.invoke(messages)
    _record_usage(GEMINI_MODEL, "vision", response)
    return _fix_mojibake(response.content)


def call_vision_llm_multi(system: str, user_text: str, images: list[tuple[str, str]]) -> str:
    """
    Same as call_vision_llm but for multiple images in one call (e.g. every page of a
    multi-page PDF, vision_utils.render_pdf_pages_to_png) — the model sees the whole
    document, not just page 1. `images` is a list of (image_b64, mime_type) pairs, in
    page order. A separate function rather than changing call_vision_llm's signature —
    pii_guard.py and evidence_requirement_extraction.py's single-image call sites stay
    untouched.
    """
    import httpx
    from langchain_openai import ChatOpenAI
    from langchain_core.messages import SystemMessage, HumanMessage

    http_client = httpx.Client(verify=False, timeout=_HTTP_TIMEOUT)
    chat = ChatOpenAI(
        base_url=_LLM_BASE_URL,
        model=GEMINI_MODEL,
        api_key=_LLM_API_KEY,
        http_client=http_client,
        # Higher than call_vision_llm's 2048 — a multi-page document (a full email
        # thread, several exhibits) gives the model much more to describe across
        # narrative/text_summary/transactions, and a truncated response breaks the
        # caller's json.loads outright (silently falling back to an empty result)
        # rather than degrading gracefully.
        max_tokens=4096,
    )
    content: list[dict] = [{"type": "text", "text": user_text}]
    for image_b64, mime_type in images:
        content.append({"type": "image_url", "image_url": {"url": f"data:{mime_type};base64,{image_b64}"}})
    messages = [SystemMessage(content=system), HumanMessage(content=content)]
    response = chat.invoke(messages)
    _record_usage(GEMINI_MODEL, "vision", response)
    return _fix_mojibake(response.content)
