"""
"Ask the Case" — stateless, source-grounded Q&A over a single dispute. One question at
a time, no persisted conversation history (a real, working feature rather than a
half-built chat system). Retrieves network-scoped regulatory passages relevant to the
question plus the case's own current understanding, and constrains the LLM to answer
only from that context or say it can't — same AI Integrity Rule as every other agent
output in this codebase.
"""
from __future__ import annotations

import json
from typing import Any, Optional

from packages.intelligence import faiss_index
from packages.intelligence.llm_client import call_llm, extract_json_str

_SYSTEM = """\
You answer an analyst's question about a specific dispute case. Answer ONLY from the
case context and retrieved policy passages provided below. If they don't contain enough
information to answer, say so explicitly rather than guessing or using outside
knowledge. Cite which passage supports each claim by its bracketed index, e.g. [1].
"""

_PROMPT = """\
Question: {question}

Case context:
- Dispute type: {dispute_type}
- Network: {network}
- Cardholder claim: {cardholder_claim}
- Current recommendation: {recommendation_summary}
- Open evidence gaps: {gaps_summary}

Retrieved policy passages:
{passages}

Answer the question. Respond as JSON with fields: answer (string), can_answer (boolean —
false if the context above doesn't support a real answer), citations (array of integer
passage indices actually referenced in the answer).
""".strip()


def _fmt_passage(i: int, p: dict) -> str:
    page_suffix = f", p. {p['page']}" if p.get("page") else ""
    return f"[{i + 1}] ({p['source']}{page_suffix}): {p['text'][:600]}"


def ask_case(
    question: str, dispute_type: str, network: Optional[str], cardholder_claim: str,
    recommendation_summary: str, gap_descriptions: list[str],
) -> dict[str, Any]:
    passages = faiss_index.find_regulatory_context(
        f"{question} {dispute_type}", top_k=4, network=(network or "").upper() or None,
    )
    passages_text = "\n\n".join(_fmt_passage(i, p) for i, p in enumerate(passages)) or "(none retrieved)"

    prompt = _PROMPT.format(
        question=question, dispute_type=dispute_type, network=network or "UNKNOWN",
        cardholder_claim=cardholder_claim, recommendation_summary=recommendation_summary[:800] or "(none yet)",
        gaps_summary="; ".join(gap_descriptions) or "(none)",
        passages=passages_text,
    )

    try:
        raw = call_llm(_SYSTEM, prompt)
        parsed = json.loads(extract_json_str(raw))
        if not isinstance(parsed, dict):
            parsed = {}
    except Exception:
        parsed = {}

    citation_indices = parsed.get("citations", []) if isinstance(parsed.get("citations"), list) else []
    citations = [
        {"source": passages[i - 1]["source"], "page": passages[i - 1].get("page"), "title": passages[i - 1]["title"]}
        for i in citation_indices
        if isinstance(i, int) and 1 <= i <= len(passages)
    ]

    return {
        "answer": parsed.get("answer") or "Could not generate an answer from the available context.",
        "can_answer": bool(parsed.get("can_answer", bool(citations))),
        "citations": citations,
        # Not part of AskCaseResponse (API contract unchanged) — used internally
        # to score this answer's faithfulness against what was actually
        # retrieved (packages/intelligence/eval_service.py, README §30).
        "_retrieval_context": [p["text"] for p in passages] or ["(no passages retrieved)"],
    }
