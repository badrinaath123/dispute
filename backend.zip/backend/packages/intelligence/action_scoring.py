"""
Deterministic next-best-action scoring — no LLM.

The agent's LLM proposes *what* actions might help; this module scores *how
valuable* each one is, so the ranking shown to a human is explainable math,
not model vibes. Mirrors the rule-based style of materiality.py.
"""
from __future__ import annotations
from datetime import datetime
from typing import Any

_MATERIALITY_WEIGHT = {"HIGH": 1.0, "MEDIUM": 0.6, "LOW": 0.3, "UNKNOWN": 0.2}

_ACTION_CLASS_COST = {"CLASS_A": 0.1, "CLASS_B": 0.3, "CLASS_C": 0.6}


def _urgency_weight(deadline_iso: str | None, now: datetime) -> float:
    """Closer deadlines score higher urgency, capped at 1.0, floored at 0.2."""
    if not deadline_iso:
        return 0.5
    try:
        deadline = datetime.fromisoformat(deadline_iso.replace("Z", "+00:00"))
        if deadline.tzinfo is not None:
            deadline = deadline.replace(tzinfo=None)
        hours_left = (deadline - now).total_seconds() / 3600
    except (ValueError, TypeError):
        return 0.5
    if hours_left <= 0:
        return 1.0
    if hours_left < 24:
        return 0.9
    if hours_left < 72:
        return 0.6
    return 0.3


def score_action(
    action: dict[str, Any],
    gaps: list[dict[str, Any]],
    deadline_iso: str | None,
    now: datetime,
) -> dict[str, Any]:
    """
    score = materiality_of_targeted_gap * urgency(deadline) * (1 - action_class_cost)

    Returns a dict with the final score plus its components, so the number
    can be shown to a human as "why this action first" rather than asserted.
    """
    description = str(action.get("description", "")).lower()
    targeted_gap = next(
        (g for g in gaps if g.get("description") and g["description"].lower()[:30] in description),
        None,
    )
    materiality = (targeted_gap or {}).get("materiality", "MEDIUM")
    materiality_w = _MATERIALITY_WEIGHT.get(materiality, _MATERIALITY_WEIGHT["MEDIUM"])

    urgency_w = _urgency_weight(deadline_iso, now)

    cost = _ACTION_CLASS_COST.get(action.get("action_class", "CLASS_B"), 0.3)
    cost_w = 1 - cost

    score = round(materiality_w * urgency_w * cost_w, 3)

    return {
        "expected_value_score": score,
        "score_breakdown": {
            "materiality_weight": materiality_w,
            "urgency_weight": urgency_w,
            "cost_weight": cost_w,
            "targeted_gap": (targeted_gap or {}).get("description"),
        },
    }


def rank_actions(
    actions: list[dict[str, Any]],
    gaps: list[dict[str, Any]],
    deadline_iso: str | None,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    """Attach scores to each action and return them sorted highest-value-first."""
    now = now or datetime.utcnow()
    scored = []
    for action in actions:
        scoring = score_action(action, gaps, deadline_iso, now)
        scored.append({**action, **scoring})
    return sorted(scored, key=lambda a: a["expected_value_score"], reverse=True)
