"""
Real LLM/embedding spend tracking (README §37) — every call through llm_client.py's
call_llm/call_vision_llm/embed_texts/embed_query logs its actual token usage and a
computed cost, so Platform Impact can show a genuine running total instead of a
fabricated one.

Pricing table below is PUBLIC LIST pricing (OpenAI/Google's own published per-token
rates, checked live via web search, August 2026) — this platform actually calls an
internal LiteLLM gateway (genailab.tcs.in), whose real contracted/internal rate may
differ from the public list price. This is a stated estimate against public pricing,
never claimed as the platform's actual bill.

Writes go through a small standalone sqlite3 connection rather than the app's async
SQLAlchemy session — call_llm() and friends are plain sync functions called from many
places (API routes, the agent runner, background tasks) that don't carry a DB session,
and making all of them async just to thread one through would be a much bigger, riskier
change than this file needs to be. Never raises — a logging failure must never break the
real LLM call it's tracking.
"""
from __future__ import annotations

import os
import sqlite3
import threading
import uuid
from datetime import datetime

_DB_PATH = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///./data/dispute_system.db").split("///")[-1]
_lock = threading.Lock()

# USD per 1,000,000 tokens. Source: public list pricing (OpenAI, Google), checked live
# via web search, August 2026 — see README §37 for the exact figures and citations.
MODEL_PRICING: dict[str, dict[str, float]] = {
    "azure/genailab-maas-gpt-4.1": {"input": 2.00, "output": 8.00},
    "gpt-4.1": {"input": 2.00, "output": 8.00},
    "gemini-2.5-flash": {"input": 0.30, "output": 2.50},
    "azure/genailab-maas-text-embedding-3-large": {"input": 0.13, "output": 0.0},
    "text-embedding-3-large": {"input": 0.13, "output": 0.0},
}


def compute_cost(model: str, input_tokens: int, output_tokens: int) -> tuple[float, bool]:
    """Returns (cost_usd, priced) — priced=False for an unrecognized model means the
    cost is honestly 0.0 rather than a guessed number; the caller/UI should show
    "unpriced" rather than silently undercounting spend as if it were real."""
    pricing = MODEL_PRICING.get(model)
    if not pricing:
        return 0.0, False
    cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000
    return round(cost, 6), True


def _ensure_table(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS ai_cost_log (
            log_id TEXT PRIMARY KEY,
            model TEXT NOT NULL,
            call_type TEXT NOT NULL,
            estimated_tokens BOOLEAN NOT NULL,
            input_tokens INTEGER NOT NULL,
            output_tokens INTEGER NOT NULL,
            cost_usd REAL NOT NULL,
            priced BOOLEAN NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )


def record_usage(
    model: str, call_type: str, input_tokens: int, output_tokens: int, estimated_tokens: bool = False,
) -> None:
    """
    call_type: a short label for which llm_client.py function this came from
    ("chat", "vision", "embed") — enough to break spend down by kind of call without
    threading case_id/feature context through every one of the ~10 call sites that use
    call_llm/call_vision_llm today.
    """
    cost, priced = compute_cost(model, input_tokens, output_tokens)
    try:
        with _lock:
            conn = sqlite3.connect(_DB_PATH, timeout=5)
            try:
                _ensure_table(conn)
                conn.execute(
                    "INSERT INTO ai_cost_log "
                    "(log_id, model, call_type, estimated_tokens, input_tokens, output_tokens, cost_usd, priced, created_at) "
                    "VALUES (?,?,?,?,?,?,?,?,?)",
                    (
                        str(uuid.uuid4()), model, call_type, estimated_tokens,
                        input_tokens, output_tokens, cost, priced, datetime.utcnow().isoformat(sep=" "),
                    ),
                )
                conn.commit()
            finally:
                conn.close()
    except Exception:
        pass


def estimate_tokens(text: str) -> int:
    """~4 characters per token, the standard rough estimate for English text — used
    only for embeddings, whose LangChain client (OpenAIEmbeddings.embed_documents/
    embed_query) doesn't return usage metadata the way ChatOpenAI does. Always
    recorded with estimated_tokens=True so the UI can show it's an approximation,
    never presented as an exact meter reading."""
    return max(1, len(text) // 4)
