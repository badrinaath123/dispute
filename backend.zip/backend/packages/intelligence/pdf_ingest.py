"""
PDF text extraction and chunking for the regulatory vector collection.
Page-granularity by default: at ~1,000+ page rulebook documents, one chunk per page is
already a large, manageable vector count without over-splitting. A page is only
sub-split if unusually long; pages with effectively no extractable text (blank,
divider, image-only) are skipped rather than indexed as noise.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

_MIN_PAGE_CHARS = 40          # below this (non-whitespace), treat the page as empty
_MAX_CHUNK_CHARS = 1800       # sub-split a page's text beyond this
_SUBSPLIT_TARGET_CHARS = 800  # target size for each sub-split piece


def extract_chunks(pdf_path: str | Path) -> list[dict[str, Any]]:
    """
    Returns [{"page": int, "text": str}, ...], 1-indexed page numbers.
    Raises on a genuinely unreadable/corrupt file; returns an empty list (not an
    exception) for a readable file whose pages just don't have extractable text — the
    caller is responsible for treating an all-empty result as a failure worth surfacing.
    """
    import pypdf

    reader = pypdf.PdfReader(str(pdf_path))
    chunks: list[dict[str, Any]] = []

    for page_index, page in enumerate(reader.pages):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        text = text.strip()
        if len(text.replace(" ", "").replace("\n", "")) < _MIN_PAGE_CHARS:
            continue

        page_number = page_index + 1
        if len(text) <= _MAX_CHUNK_CHARS:
            chunks.append({"page": page_number, "text": text})
        else:
            chunks.extend(
                {"page": page_number, "text": piece}
                for piece in _split_long_page(text)
            )

    return chunks


def _split_long_page(text: str) -> list[str]:
    """Greedily pack paragraphs into ~_SUBSPLIT_TARGET_CHARS pieces."""
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    if not paragraphs:
        paragraphs = [text]

    pieces: list[str] = []
    current = ""
    for para in paragraphs:
        if current and len(current) + len(para) + 2 > _SUBSPLIT_TARGET_CHARS:
            pieces.append(current)
            current = para
        else:
            current = f"{current}\n\n{para}" if current else para
    if current:
        pieces.append(current)
    return pieces


def page_count(pdf_path: str | Path) -> int:
    import pypdf
    return len(pypdf.PdfReader(str(pdf_path)).pages)
