"""Card network connector — fetches chargeback rules and network decisions."""
import os
import httpx
from .base import BaseConnector

NETWORK_API_URL = os.getenv("NETWORK_API_URL", "http://localhost:8100/network")


class NetworkConnector(BaseConnector):
    def __init__(self) -> None:
        super().__init__("network")

    async def _fetch(self, payload: dict) -> dict:
        transaction_id = payload["transaction_id"]
        network = payload.get("network", "VISA")
        async with httpx.AsyncClient(timeout=self.TIMEOUT_SECS) as client:
            r = await client.get(
                f"{NETWORK_API_URL}/chargebacks",
                params={"transaction_id": transaction_id, "network": network},
            )
            r.raise_for_status()
            return r.json()
