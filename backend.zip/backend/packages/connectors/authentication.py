"""Authentication system connector — fetches 3DS / device fingerprint logs."""
import os
import httpx
from .base import BaseConnector

AUTH_API_URL = os.getenv("AUTH_API_URL", "http://localhost:8100/auth-system")


class AuthenticationConnector(BaseConnector):
    def __init__(self) -> None:
        super().__init__("authentication_system")

    async def _fetch(self, payload: dict) -> dict:
        transaction_id = payload["transaction_id"]
        async with httpx.AsyncClient(timeout=self.TIMEOUT_SECS) as client:
            r = await client.get(f"{AUTH_API_URL}/logs/{transaction_id}")
            r.raise_for_status()
            return r.json()
