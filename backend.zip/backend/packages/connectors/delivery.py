"""Delivery carrier connector — fetches shipment tracking records."""
import os
import httpx
from .base import BaseConnector

CARRIER_API_URL = os.getenv("CARRIER_API_URL", "http://localhost:8100/carrier")


class DeliveryConnector(BaseConnector):
    def __init__(self) -> None:
        super().__init__("delivery")

    async def _fetch(self, payload: dict) -> dict:
        tracking_number = payload["tracking_number"]
        carrier = payload.get("carrier", "")
        async with httpx.AsyncClient(timeout=self.TIMEOUT_SECS) as client:
            r = await client.get(
                f"{CARRIER_API_URL}/track/{tracking_number}",
                params={"carrier": carrier},
            )
            r.raise_for_status()
            return r.json()
