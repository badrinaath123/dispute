"""
Base connector interface with retry, circuit breaker, and timeout.
All connectors return a ConnectorResult; never raise to the caller.
"""
import asyncio
import time
from dataclasses import dataclass, field
from typing import Any
from packages.observability.logging import get_logger

logger = get_logger("connectors.base")


@dataclass
class ConnectorResult:
    success: bool
    data: dict = field(default_factory=dict)
    error: str | None = None
    retries_used: int = 0
    latency_ms: float = 0.0


class CircuitBreaker:
    """Simple in-process circuit breaker — not distributed."""

    def __init__(self, name: str, threshold: int = 3, cooldown: float = 60.0) -> None:
        self.name = name
        self.threshold = threshold
        self.cooldown = cooldown
        self._failures = 0
        self._opened_at: float | None = None

    @property
    def is_open(self) -> bool:
        if self._opened_at is None:
            return False
        if time.monotonic() - self._opened_at > self.cooldown:
            self._opened_at = None
            self._failures = 0
            logger.info("circuit_breaker_half_open", name=self.name)
            return False
        return True

    def record_success(self) -> None:
        self._failures = 0
        self._opened_at = None

    def record_failure(self) -> None:
        self._failures += 1
        if self._failures >= self.threshold:
            self._opened_at = time.monotonic()
            logger.warning("circuit_breaker_opened", name=self.name, failures=self._failures)


class BaseConnector:
    """Subclass and implement `_fetch()`."""

    MAX_RETRIES = int(3)
    RETRY_DELAY = 1.0
    TIMEOUT_SECS = 10.0

    def __init__(self, name: str) -> None:
        self.name = name
        self._cb = CircuitBreaker(name)

    async def fetch(self, payload: dict) -> ConnectorResult:
        if self._cb.is_open:
            return ConnectorResult(success=False, error="circuit_open")

        t0 = time.monotonic()
        last_error = ""
        for attempt in range(self.MAX_RETRIES):
            try:
                data = await asyncio.wait_for(self._fetch(payload), timeout=self.TIMEOUT_SECS)
                self._cb.record_success()
                return ConnectorResult(
                    success=True,
                    data=data,
                    retries_used=attempt,
                    latency_ms=(time.monotonic() - t0) * 1000,
                )
            except asyncio.TimeoutError:
                last_error = "timeout"
                self._cb.record_failure()
            except Exception as exc:
                last_error = str(exc)
                self._cb.record_failure()
                logger.warning("connector_retry", name=self.name, attempt=attempt, error=last_error)

            if attempt < self.MAX_RETRIES - 1:
                await asyncio.sleep(self.RETRY_DELAY * (2 ** attempt))

        return ConnectorResult(
            success=False,
            error=last_error,
            retries_used=self.MAX_RETRIES,
            latency_ms=(time.monotonic() - t0) * 1000,
        )

    async def _fetch(self, payload: dict) -> dict:
        raise NotImplementedError
