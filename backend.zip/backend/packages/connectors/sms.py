"""
SMS notifications — Twilio. Sends the cardholder a text at the two issuer-side
lifecycle moments that actually matter to them: a chargeback is issued on their
behalf, and their dispute is resolved in their favor.

Opt-in via ENABLE_SMS_NOTIFICATIONS (.env, off by default — this platform ships with
no real Twilio account, so sending must never be the default until real credentials
are actually in place). Follows this package's own BaseConnector contract (retry,
circuit breaker, never raises to the caller) — an SMS failing must never block or
roll back the real state change (chargeback issued, case resolved) it's just
announcing.
"""
from __future__ import annotations

import os
import httpx

from .base import BaseConnector, ConnectorResult
from packages.observability.logging import get_logger

logger = get_logger("connectors.sms")

TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_FROM_NUMBER = os.getenv("TWILIO_FROM_NUMBER", "")
ENABLE_SMS_NOTIFICATIONS = os.getenv("ENABLE_SMS_NOTIFICATIONS", "false").lower() == "true"


def is_configured() -> bool:
    return bool(TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER)


class TwilioSMSConnector(BaseConnector):
    """Talks to Twilio's REST API directly over httpx (a single authenticated POST)
    rather than pulling in the full twilio SDK for one call — consistent with every
    other external call in this codebase (packages/intelligence/llm_client.py included)
    already being a plain httpx client, no extra SDK dependency for something this
    simple."""

    def __init__(self) -> None:
        super().__init__("twilio_sms")

    async def _fetch(self, payload: dict) -> dict:
        url = f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/Messages.json"
        async with httpx.AsyncClient(timeout=self.TIMEOUT_SECS) as client:
            r = await client.post(
                url,
                auth=(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN),
                data={"To": payload["to"], "From": TWILIO_FROM_NUMBER, "Body": payload["body"]},
            )
            r.raise_for_status()
            return r.json()


_connector: TwilioSMSConnector | None = None


async def send_sms(to: str | None, body: str) -> ConnectorResult:
    """
    Best-effort send — returns a ConnectorResult either way, never raises. Callers
    (disputes.py's chargeback/status-update routes) should log the outcome as an
    audit event but must never let it affect the real state change already committed.
    Honestly no-ops (success=False, error stating why) when notifications are off,
    unconfigured, or no phone number was ever captured for this case — never
    fabricates having sent something it didn't.
    """
    if not ENABLE_SMS_NOTIFICATIONS:
        return ConnectorResult(success=False, error="sms_notifications_disabled")
    if not is_configured():
        return ConnectorResult(success=False, error="twilio_not_configured")
    if not to:
        return ConnectorResult(success=False, error="no_phone_number_on_case")

    global _connector
    if _connector is None:
        _connector = TwilioSMSConnector()

    result = await _connector.fetch({"to": to, "body": body})
    if not result.success:
        logger.warning("sms_send_failed", to_last4=to[-4:] if len(to) >= 4 else to, error=result.error)
    return result
