"""Merchant evidence connector — fetches order/shipping records from merchant API."""
import os
import httpx
from .base import BaseConnector

MERCHANT_API_URL = os.getenv("MERCHANT_API_URL", "http://localhost:8100/merchant")
MERCHANT_API_KEY = os.getenv("MERCHANT_API_KEY", "")


class MerchantConnector(BaseConnector):
    def __init__(self) -> None:
        super().__init__("merchant")

    async def _fetch(self, payload: dict) -> dict:
        transaction_id = payload["transaction_id"]
        async with httpx.AsyncClient(timeout=self.TIMEOUT_SECS) as client:
            r = await client.get(
                f"{MERCHANT_API_URL}/transactions/{transaction_id}",
                headers={"X-Api-Key": MERCHANT_API_KEY},
            )
            r.raise_for_status()
            return r.json()
