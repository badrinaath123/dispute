"""Issuer evidence connector — fetches account/transaction records from issuing bank."""
import os
import httpx
from .base import BaseConnector

ISSUER_API_URL = os.getenv("ISSUER_API_URL", "http://localhost:8100/issuer")
ISSUER_API_KEY = os.getenv("ISSUER_API_KEY", "")


class IssuerConnector(BaseConnector):
    def __init__(self) -> None:
        super().__init__("issuer")

    async def _fetch(self, payload: dict) -> dict:
        account_id = payload["account_id"]
        transaction_ref = payload.get("transaction_reference", "")
        async with httpx.AsyncClient(timeout=self.TIMEOUT_SECS) as client:
            r = await client.get(
                f"{ISSUER_API_URL}/accounts/{account_id}/transactions",
                params={"reference": transaction_ref},
                headers={"X-Api-Key": ISSUER_API_KEY},
            )
            r.raise_for_status()
            return r.json()
