from datetime import datetime
from typing import Optional
from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey, Integer, JSON, String, Text, UniqueConstraint
)
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class TenantModel(Base):
    __tablename__ = "tenants"
    tenant_id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    config = Column(JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)


class UserModel(Base):
    __tablename__ = "users"
    user_id = Column(String, primary_key=True)
    tenant_id = Column(String, ForeignKey("tenants.tenant_id"), nullable=False)
    username = Column(String, unique=True, nullable=False)
    email = Column(String, nullable=False)
    password_hash = Column(String)
    roles = Column(JSON, default=[])
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class ClaimModel(Base):
    """
    A single cardholder intake that may span multiple transactions (e.g. "I
    don't recognize three charges on my statement"). Each transaction becomes
    its own DisputeModel sub-case — its own merchant, evidence, investigation,
    recommendation, approval — linked back here via DisputeModel.claim_id.
    Status is intentionally not stored: it's always computed from the
    sub-cases' current statuses so it can never drift out of sync.
    """
    __tablename__ = "claims"
    claim_id = Column(String, primary_key=True)
    tenant_id = Column(String, ForeignKey("tenants.tenant_id"), nullable=False)
    cardholder_claim = Column(Text, nullable=False)
    created_by = Column(String, nullable=False)
    created_at = Column(DateTime, nullable=False)

    disputes = relationship("DisputeModel", back_populates="claim", lazy="dynamic")


class DisputeModel(Base):
    __tablename__ = "disputes"
    dispute_id = Column(String, primary_key=True)
    tenant_id = Column(String, ForeignKey("tenants.tenant_id"), nullable=False)
    status = Column(String, nullable=False)
    dispute_type = Column(String, nullable=False)
    lifecycle_stage = Column(String, nullable=False)
    priority = Column(String, nullable=False)
    current_state_version = Column(Integer, nullable=False, default=1)
    deadline = Column(DateTime, nullable=True)
    transaction_reference = Column(String, nullable=True)
    cardholder_claim = Column(Text, nullable=False)
    metadata_ = Column("metadata", JSON, default={})
    claim_id = Column(String, ForeignKey("claims.claim_id"), nullable=True)
    claim_sequence = Column(Integer, nullable=True)
    created_at = Column(DateTime, nullable=False)
    updated_at = Column(DateTime, nullable=False)
    # Soft delete — the row, its evidence, and its audit trail are never actually
    # removed (README's "audit events are forever" rule); archiving just hides
    # the case from the default queue view on both the issuer and merchant side
    # (they share GET /disputes).
    is_archived = Column(Boolean, nullable=False, default=False)

    claim = relationship("ClaimModel", back_populates="disputes")

    evidence = relationship("EvidenceModel", back_populates="dispute", lazy="dynamic")
    hypotheses = relationship("HypothesisModel", back_populates="dispute", lazy="dynamic")
    actions = relationship("ActionModel", back_populates="dispute", lazy="dynamic")
    audit_events = relationship("AuditEventModel", back_populates="dispute", lazy="dynamic")


class EvidenceModel(Base):
    __tablename__ = "evidence"
    __table_args__ = (
        UniqueConstraint("case_id", "source_type", "source_record_id", "version", name="uq_evidence_version"),
    )
    evidence_id = Column(String, primary_key=True)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=False)
    tenant_id = Column(String, nullable=False)
    source_type = Column(String, nullable=False)
    source_system = Column(String, nullable=False)
    source_record_id = Column(String, nullable=False)
    evidence_type = Column(String, nullable=False)
    version = Column(Integer, nullable=False, default=1)
    previous_version_id = Column(String, ForeignKey("evidence.evidence_id"), nullable=True)
    content_reference = Column(String, nullable=True)
    normalized_content = Column(JSON, nullable=False)
    event_time = Column(DateTime, nullable=False)
    received_time = Column(DateTime, nullable=False)
    effective_time = Column(DateTime, nullable=False)
    content_hash = Column(String, nullable=False)
    materiality = Column(String, nullable=False, default="UNKNOWN")
    quality = Column(String, nullable=False, default="UNVERIFIED")
    authorization_scope = Column(JSON, default=[])
    is_current = Column(Boolean, nullable=False, default=True)
    superseded_by = Column(String, ForeignKey("evidence.evidence_id"), nullable=True)
    created_at = Column(DateTime, nullable=False)

    dispute = relationship("DisputeModel", back_populates="evidence")

    provenance = relationship(
        "ProvenanceModel", back_populates="evidence", uselist=False, lazy="joined"
    )


class ProvenanceModel(Base):
    __tablename__ = "provenance"
    provenance_id = Column(String, primary_key=True)
    evidence_id = Column(String, ForeignKey("evidence.evidence_id"), nullable=False, unique=True)
    source_type = Column(String)
    source_system = Column(String)
    source_record_id = Column(String)
    retrieval_method = Column(String)
    retrieved_by = Column(String)
    retrieved_at = Column(DateTime)
    verified = Column(Boolean, default=False)
    verification_method = Column(String, nullable=True)
    chain_of_custody = Column(JSON, default=[])

    evidence = relationship("EvidenceModel", back_populates="provenance")


class TimelineEventModel(Base):
    __tablename__ = "timeline_events"
    event_id = Column(String, primary_key=True)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=False)
    event_type = Column(String, nullable=False)
    event_time = Column(DateTime, nullable=False)
    recorded_time = Column(DateTime, nullable=False)
    source_evidence_ids = Column(JSON, default=[])
    actor = Column(String)
    description = Column(Text)
    is_disputed = Column(Boolean, default=False)
    confidence = Column(Float, default=1.0)
    metadata_ = Column("metadata", JSON, default={})
    created_at = Column(DateTime, nullable=False)


class HypothesisModel(Base):
    __tablename__ = "hypotheses"
    hypothesis_id = Column(String, primary_key=True)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=False)
    description = Column(Text, nullable=False)
    status = Column(String, nullable=False)
    supporting_evidence_ids = Column(JSON, default=[])
    weakening_evidence_ids = Column(JSON, default=[])
    neutral_evidence_ids = Column(JSON, default=[])
    unresolved_questions = Column(JSON, default=[])
    confidence_descriptor = Column(String)
    confidence_score = Column(Float)
    created_by = Column(String)
    version = Column(Integer, default=1)
    reasoning = Column(Text)
    last_evaluated_at = Column(DateTime)
    affected_by_evidence_ids = Column(JSON, default=[])
    created_at = Column(DateTime, nullable=False)

    dispute = relationship("DisputeModel", back_populates="hypotheses")


class ContradictionModel(Base):
    __tablename__ = "contradictions"
    contradiction_id = Column(String, primary_key=True)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=False)
    description = Column(Text, nullable=False)
    evidence_a_id = Column(String, ForeignKey("evidence.evidence_id"))
    evidence_b_id = Column(String, ForeignKey("evidence.evidence_id"))
    conflict_type = Column(String)
    materiality = Column(String)
    status = Column(String, nullable=False, default="OPEN")
    resolution = Column(Text, nullable=True)
    resolved_by = Column(String, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False)


class EvidenceGapModel(Base):
    __tablename__ = "evidence_gaps"
    gap_id = Column(String, primary_key=True)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=False)
    gap_type = Column(String, nullable=False)
    description = Column(Text)
    materiality = Column(String)
    affects_hypothesis_ids = Column(JSON, default=[])
    expected_source = Column(String)
    expected_evidence_type = Column(String)
    status = Column(String, nullable=False, default="OPEN")
    requested_at = Column(DateTime, nullable=True)
    received_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, nullable=False)


class RecommendationModel(Base):
    __tablename__ = "recommendations"
    recommendation_id = Column(String, primary_key=True)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=False)
    version = Column(Integer, nullable=False)
    content = Column(Text, nullable=False)
    recommendation_type = Column(String, nullable=False)
    confidence_descriptor = Column(String)
    confidence_score = Column(Float)
    supporting_evidence_ids = Column(JSON, default=[])
    active_hypotheses = Column(JSON, default=[])
    contradictions = Column(JSON, default=[])
    evidence_gaps = Column(JSON, default=[])
    policy_constraints = Column(JSON, default=[])
    uncertainty_statement = Column(Text)
    previous_recommendation_id = Column(String, ForeignKey("recommendations.recommendation_id"), nullable=True)
    change_reason = Column(Text, nullable=True)
    requires_approval = Column(Boolean, default=False)
    model_version = Column(String)
    prompt_version = Column(String)
    graph_version = Column(String)
    evidence_state_version = Column(Integer)
    is_current = Column(Boolean, default=True)
    is_stale = Column(Boolean, default=False)
    stale_reason = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False)


class ActionModel(Base):
    __tablename__ = "actions"
    action_id = Column(String, primary_key=True)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=False)
    tenant_id = Column(String, nullable=False)
    action_type = Column(String, nullable=False)
    action_class = Column(String, nullable=False)
    requested_by = Column(String, nullable=False)
    proposed_by = Column(String, nullable=True)
    authority = Column(String, nullable=True)
    approval_requirement = Column(String, nullable=True)
    status = Column(String, nullable=False)
    idempotency_key = Column(String, unique=True, nullable=False)
    connector = Column(String, nullable=True)
    input = Column(JSON, default={})
    result = Column(JSON, nullable=True)
    error = Column(Text, nullable=True)
    retry_count = Column(Integer, default=0)
    correlation_id = Column(String, nullable=True)
    created_at = Column(DateTime, nullable=False)
    approved_at = Column(DateTime, nullable=True)
    executed_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)

    dispute = relationship("DisputeModel", back_populates="actions")


class ApprovalModel(Base):
    __tablename__ = "approvals"
    approval_id = Column(String, primary_key=True)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=False)
    action_id = Column(String, ForeignKey("actions.action_id"), nullable=True)
    approver_id = Column(String, nullable=False)
    approver_role = Column(String, nullable=False)
    decision = Column(String, nullable=False)
    reason = Column(Text)
    timestamp = Column(DateTime, nullable=False)
    state_version_reviewed = Column(Integer)
    evidence_version_reviewed = Column(JSON, default={})
    status = Column(String, nullable=False, default="ACTIVE")
    stale_reason = Column(Text, nullable=True)


class AuditEventModel(Base):
    __tablename__ = "audit_events"
    audit_id = Column(String, primary_key=True)
    timestamp = Column(DateTime, nullable=False)
    actor_id = Column(String, nullable=False)
    actor_type = Column(String, nullable=False)
    tenant_id = Column(String, nullable=False)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=True)
    event_type = Column(String, nullable=False)
    previous_state_version = Column(Integer, nullable=True)
    new_state_version = Column(Integer, nullable=True)
    evidence_refs = Column(JSON, default=[])
    agent_run_id = Column(String, nullable=True)
    node_name = Column(String, nullable=True)
    model_version = Column(String, nullable=True)
    prompt_version = Column(String, nullable=True)
    graph_version = Column(String, nullable=True)
    tool_used = Column(String, nullable=True)
    input_hash = Column(String, nullable=True)
    output_hash = Column(String, nullable=True)
    decision = Column(String, nullable=True)
    approval_id = Column(String, nullable=True)
    metadata_ = Column("metadata", JSON, default={})

    dispute = relationship("DisputeModel", back_populates="audit_events")


class AgentRunModel(Base):
    __tablename__ = "agent_runs"
    run_id = Column(String, primary_key=True)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=False)
    trigger = Column(String)
    status = Column(String, nullable=False)
    graph_version = Column(String, nullable=True)
    model_version = Column(String, nullable=True)
    steps_used = Column(Integer, nullable=True)
    tokens_used = Column(Integer, nullable=True)
    tool_calls = Column(Integer, nullable=True)
    start_time = Column(DateTime, nullable=True)
    end_time = Column(DateTime, nullable=True)
    termination_reason = Column(String, nullable=True)
    trace = Column(JSON, nullable=True)


class IdempotencyKeyModel(Base):
    __tablename__ = "idempotency_keys"
    key = Column(String, primary_key=True)
    action_id = Column(String, ForeignKey("actions.action_id"), nullable=True)
    status = Column(String, nullable=False)
    result = Column(JSON, nullable=True)
    created_at = Column(DateTime, nullable=False)
    completed_at = Column(DateTime, nullable=True)


# ── Admin configuration tables ────────────────────────────────────────────────

class StatusConfigModel(Base):
    __tablename__ = "admin_status_config"
    status_id = Column(String, primary_key=True)
    code = Column(String, unique=True, nullable=False, index=True)
    display_name = Column(String, nullable=False)
    description = Column(Text, default="")
    category = Column(String, default="WORKFLOW")   # WORKFLOW | TERMINAL
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    color = Column(String, default="neutral")       # neutral|info|warning|success|error|brand
    is_initial = Column(Boolean, default=False)
    is_terminal = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(String, nullable=True)


class OutcomeConfigModel(Base):
    __tablename__ = "admin_outcome_config"
    outcome_id = Column(String, primary_key=True)
    code = Column(String, unique=True, nullable=False, index=True)
    display_name = Column(String, nullable=False)
    description = Column(Text, default="")
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    color = Column(String, default="neutral")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(String, nullable=True)


class RegulatoryDocumentModel(Base):
    """
    A PDF uploaded via Admin -> Knowledge Base, chunked page-by-page and embedded into
    the `regulatory` FAISS collection (packages/intelligence/faiss_index.py) so
    identify_gaps and GET /disputes/:id/evidence-completeness can retrieve real
    scheme-rulebook passages instead of only the platform's synthesized policy text.
    Ingestion runs as a background task (apps/api/routes/v1/admin.py) since a
    1,000+ page document takes real time to extract and embed.
    """
    __tablename__ = "admin_regulatory_documents"
    document_id = Column(String, primary_key=True)
    filename = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    uploaded_by = Column(String, nullable=False)
    uploaded_at = Column(DateTime, nullable=False)
    status = Column(String, nullable=False, default="PENDING")  # PENDING|PROCESSING|READY|FAILED
    page_count = Column(Integer, nullable=True)
    chunks_indexed = Column(Integer, nullable=False, default=0)
    error = Column(Text, nullable=True)
    network = Column(String, nullable=False, default="OTHER")   # VISA|MASTERCARD|OTHER
    doc_type = Column(String, nullable=False, default="OTHER")  # RULES|DISPUTE_GUIDE|OTHER


class RoleConfigModel(Base):
    __tablename__ = "admin_role_config"
    role_id = Column(String, primary_key=True)
    code = Column(String, unique=True, nullable=False, index=True)
    display_name = Column(String, nullable=False)
    description = Column(Text, default="")
    is_active = Column(Boolean, default=True)
    permissions = Column(JSON, default=list)
    allowed_screens = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(String, nullable=True)


class EvidenceRequirementModel(Base):
    """
    Admin-editable replacement for what used to be a hardcoded Python dict in
    packages/intelligence/scheme_rules.py — which dispute types need which
    evidence types, and why. Read by the deterministic gap-detection safety
    net (identify_gaps node + GET /disputes/:id/evidence-completeness) as a
    fallback when the case has no network/reason_code set (README §26).
    Global/platform-wide config, not tenant-scoped, same as Status/Outcome/
    RoleConfig above.
    """
    __tablename__ = "admin_evidence_requirements"
    __table_args__ = (
        UniqueConstraint("dispute_type", "evidence_type", name="uq_evidence_requirement"),
    )
    requirement_id = Column(String, primary_key=True)
    dispute_type = Column(String, nullable=False, index=True)
    evidence_type = Column(String, nullable=False)
    description = Column(Text, default="")
    is_required = Column(Boolean, default=True)
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    created_by = Column(String, nullable=True)


class AIEvalScoreModel(Base):
    """
    Live DeepEval scores for real AI outputs (README §30) — written by
    packages/intelligence/eval_service.py from a FastAPI background task
    *after* the real response has already been sent back to the analyst, so
    judging never adds latency to the feature it's scoring. Opt-in via
    ENABLE_DEEPEVAL; this table stays empty when that flag is off.
    """
    __tablename__ = "ai_eval_scores"
    eval_id = Column(String, primary_key=True)
    tenant_id = Column(String, nullable=False)
    case_id = Column(String, ForeignKey("disputes.dispute_id"), nullable=True)
    feature = Column(String, nullable=False)   # e.g. "case_qa"
    metric = Column(String, nullable=False)    # e.g. "Faithfulness", "AnswerRelevancy"
    score = Column(Float, nullable=True)
    passed = Column(Boolean, nullable=True)
    reason = Column(Text, nullable=True)
    input_text = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=False)


class AICostLogModel(Base):
    """
    Real LLM/embedding spend (README §37) — one row per call through
    packages/intelligence/llm_client.py, written by packages/intelligence/
    cost_tracking.py via its own lightweight sqlite3 connection (not this ORM —
    call_llm() and friends are plain sync functions with no request-scoped async
    session available). Defined here anyway so the API can read the same table
    back through the normal async session for GET /platform/impact's ai_spend
    block. No tenant_id/case_id — llm_client.py's functions don't carry that
    context; this is a platform-wide spend counter, not a per-case one.
    """
    __tablename__ = "ai_cost_log"
    log_id = Column(String, primary_key=True)
    model = Column(String, nullable=False)
    call_type = Column(String, nullable=False)   # "chat" | "vision" | "embed"
    estimated_tokens = Column(Boolean, nullable=False)
    input_tokens = Column(Integer, nullable=False)
    output_tokens = Column(Integer, nullable=False)
    cost_usd = Column(Float, nullable=False)
    priced = Column(Boolean, nullable=False)      # False = unrecognized model, cost is honestly 0
    created_at = Column(DateTime, nullable=False)
