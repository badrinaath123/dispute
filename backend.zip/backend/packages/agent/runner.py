"""
Agent runner — bridges the FastAPI background task and the LangGraph graph.
Publishes progress events to the in-memory SSE queue.
Persists hypotheses, actions, and recommendation to DB on completion.
"""
from __future__ import annotations
import asyncio
import json
import os
import uuid
from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from packages.agent.graph import compiled_graph, GRAPH_VERSION, NODE_PIPELINE
from packages.agent.state import DisputeGraphState
from packages.agent import nodes, prompts
from packages.intelligence import scheme_rules, action_scoring, faiss_index
from packages.intelligence import evidence_requirements as evidence_requirements_loader
from packages.observability.logging import get_logger
from packages.persistence.sqlite.models import (
    DisputeModel, EvidenceModel, HypothesisModel,
    ActionModel, RecommendationModel, AuditEventModel, EvidenceGapModel,
    AgentRunModel,
)

logger = get_logger("agent.runner")

MAX_RUNTIME_SECONDS = int(os.getenv("AGENT_MAX_RUNTIME_SECONDS", "120"))


async def _finish_run(session_factory, run_id: str, **fields: Any) -> None:
    """Persist terminal status/metadata onto the AgentRunModel row."""
    async with session_factory() as db:
        run = await db.get(AgentRunModel, run_id)
        if run:
            for k, v in fields.items():
                setattr(run, k, v)
            await db.commit()


async def run_agent(
    dispute_id: str,
    tenant_id: str,
    user_id: str,
    session_factory,
    sse_queues: dict,  # {dispute_id: asyncio.Queue}
    run_id: str | None = None,
) -> None:
    run_id = run_id or str(uuid.uuid4())
    logger.info("agent_run_start", dispute_id=dispute_id, run_id=run_id)

    async with session_factory() as db:
        # ── Load state from DB ─────────────────────────────────────────────────
        dispute_row = await db.get(DisputeModel, dispute_id)
        if not dispute_row:
            logger.error("agent_dispute_not_found", dispute_id=dispute_id)
            return

        ev_result = await db.execute(
            select(EvidenceModel).where(
                EvidenceModel.case_id == dispute_id,
                EvidenceModel.is_current == True,
            )
        )
        evidence_rows = ev_result.scalars().all()

        dispute_metadata = dispute_row.metadata_ or {}
        dispute_dict = {
            "dispute_id": dispute_row.dispute_id,
            "dispute_type": dispute_row.dispute_type,
            "cardholder_claim": dispute_row.cardholder_claim,
            "transaction_reference": dispute_row.transaction_reference,
            "priority": dispute_row.priority,
            "lifecycle_stage": dispute_row.lifecycle_stage,
            "network": dispute_metadata.get("network"),
            "reason_code": dispute_metadata.get("reason_code"),
            "outcome": dispute_metadata.get("outcome"),
            "deadline": dispute_row.deadline.isoformat() if dispute_row.deadline else None,
        }
        evidence_state_version = dispute_row.current_state_version

        evidence_list = [
            {
                "evidence_id": e.evidence_id,
                "evidence_type": e.evidence_type,
                "source_type": e.source_type,
                "source_system": e.source_system,
                "version": e.version,
                "materiality": e.materiality,
                "normalized_content": e.normalized_content,
                "event_time": e.event_time.isoformat(),
            }
            for e in evidence_rows
        ]

        evidence_requirements = await evidence_requirements_loader.load_active(db)

        initial_state: DisputeGraphState = {
            "dispute_id": dispute_id,
            "tenant_id": tenant_id,
            "run_id": run_id,
            "dispute": dispute_dict,
            "evidence": evidence_list,
            "hypotheses": [],
            "contradictions": [],
            "evidence_gaps": [],
            "timeline_events": [],
            "existing_recommendation": None,
            "understanding": None,
            "evidence_assessment": None,
            "regulatory_context": [],
            "precedent_cases": [],
            "identified_gaps": [],
            "proposed_hypotheses": [],
            "proposed_actions": [],
            "recommendation_draft": None,
            "evidence_requirements": evidence_requirements,
            "steps_used": 0,
            "errors": [],
            "node_trace": [],
            "recommendation": None,
            "terminated": False,
            "termination_reason": None,
        }

    # ── Run graph (may call LLM, outside DB session) ───────────────────────────
    queue = sse_queues.get(dispute_id)

    def _sse(payload: dict) -> str:
        return f"data: {json.dumps(payload)}\n\n"

    # Accumulate full state across all node outputs
    final_state: dict = dict(initial_state)

    async def _stream() -> None:
        # LangGraph's astream() only yields an event once a node has finished —
        # there's no native "about to run" signal. Since this graph is strictly
        # linear (NODE_PIPELINE), the next node to run is always known in
        # advance, so node_start is emitted for it right after the previous
        # node's node_complete (and for the first node before the loop starts).
        if queue and NODE_PIPELINE:
            await queue.put(_sse({"type": "node_start", "node": NODE_PIPELINE[0], "run_id": run_id}))

        async for event in compiled_graph.astream(initial_state):
            for node_name, node_state in event.items():
                if queue:
                    await queue.put(_sse({"type": "node_complete", "node": node_name, "run_id": run_id}))
                    if node_name in NODE_PIPELINE:
                        next_idx = NODE_PIPELINE.index(node_name) + 1
                        if next_idx < len(NODE_PIPELINE):
                            await queue.put(_sse({
                                "type": "node_start", "node": NODE_PIPELINE[next_idx], "run_id": run_id,
                            }))
                if isinstance(node_state, dict):
                    for k, v in node_state.items():
                        # Annotated list fields accumulate; everything else overwrites
                        if isinstance(v, list) and isinstance(final_state.get(k), list) and k in ("errors", "node_trace"):
                            final_state[k] = final_state[k] + v
                        else:
                            final_state[k] = v

    try:
        await asyncio.wait_for(_stream(), timeout=MAX_RUNTIME_SECONDS)
    except asyncio.TimeoutError:
        logger.error("agent_run_timeout", dispute_id=dispute_id, run_id=run_id)
        if queue:
            await queue.put(_sse({"type": "FAILED", "error": "MAX_RUNTIME_EXCEEDED"}))
        await _finish_run(
            session_factory, run_id,
            status="FAILED", termination_reason="MAX_RUNTIME_EXCEEDED",
            steps_used=final_state.get("steps_used", 0), end_time=datetime.utcnow(),
        )
        return
    except Exception as exc:
        logger.error("agent_run_error", dispute_id=dispute_id, error=str(exc))
        if queue:
            await queue.put(_sse({"type": "FAILED", "error": str(exc)}))
        await _finish_run(
            session_factory, run_id,
            status="FAILED", termination_reason=str(exc)[:500],
            steps_used=final_state.get("steps_used", 0), end_time=datetime.utcnow(),
        )
        return

    if not final_state.get("recommendation") and not final_state.get("proposed_hypotheses"):
        if queue:
            await queue.put(_sse({"type": "FAILED", "error": "no_state"}))
        await _finish_run(
            session_factory, run_id,
            status="FAILED", termination_reason="NO_STATE_PRODUCED",
            steps_used=final_state.get("steps_used", 0), end_time=datetime.utcnow(),
        )
        return

    # ── Persist results ────────────────────────────────────────────────────────
    now = datetime.utcnow()
    try:
        await _persist_results(session_factory, dispute_id, tenant_id, user_id, run_id, final_state, now, evidence_state_version)
    except Exception as exc:
        logger.error("agent_persist_error", dispute_id=dispute_id, run_id=run_id, error=str(exc))
        if queue:
            await queue.put(_sse({"type": "FAILED", "error": str(exc)}))
        await _finish_run(
            session_factory, run_id,
            status="FAILED", termination_reason=f"PERSIST_ERROR: {exc}"[:500],
            steps_used=final_state.get("steps_used", 0), end_time=datetime.utcnow(),
        )
        return

    if queue:
        await queue.put(f"data: {json.dumps({'type': 'COMPLETE', 'run_id': run_id})}\n\n")
    logger.info("agent_run_complete", dispute_id=dispute_id, run_id=run_id,
                steps=final_state.get("steps_used", 0),
                hypotheses=len(final_state.get("proposed_hypotheses", [])),
                actions=len(final_state.get("proposed_actions", [])))


async def _persist_results(
    session_factory, dispute_id: str, tenant_id: str, user_id: str, run_id: str,
    final_state: dict, now: datetime, evidence_state_version: int,
) -> None:
    known_evidence_ids = {e["evidence_id"] for e in final_state.get("evidence", [])}
    citation_errors: list[str] = []

    def _validated(refs: list[str]) -> list[str]:
        valid, dropped = scheme_rules.validate_citations(refs, known_evidence_ids)
        if dropped:
            citation_errors.append(f"dropped {len(dropped)} unverified evidence citation(s): {dropped}")
        return valid

    async with session_factory() as db:
        # Hypotheses — every citation is verified against the case's real evidence
        # before being persisted (enforces the "never fabricate evidence" rule in
        # code, not just in the prompt).
        best_hypothesis = None
        for h in final_state.get("proposed_hypotheses", []):
            supporting = _validated(h.get("supporting_evidence_refs", []))
            weakening = _validated(h.get("weakening_evidence_refs", []))
            row = HypothesisModel(
                hypothesis_id=str(uuid.uuid4()),
                case_id=dispute_id,
                description=h.get("description", ""),
                status=h.get("status", "PROPOSED"),
                confidence_score=float(h.get("confidence_score", 0.5)),
                confidence_descriptor=_score_to_descriptor(h.get("confidence_score", 0.5)),
                supporting_evidence_ids=supporting,
                weakening_evidence_ids=weakening,
                unresolved_questions=h.get("unresolved_questions", []),
                created_by="agent",
                reasoning=final_state.get("evidence_assessment", "")[:2000],
                created_at=now,
            )
            db.add(row)
            if best_hypothesis is None or row.confidence_score > best_hypothesis.confidence_score:
                best_hypothesis = row

        # Recommendation
        rec_data = final_state.get("recommendation")
        if rec_data:
            # Mark previous current as not current
            prev_result = await db.execute(
                select(RecommendationModel).where(
                    RecommendationModel.case_id == dispute_id,
                    RecommendationModel.is_current == True,
                )
            )
            prev_rec = prev_result.scalar_one_or_none()
            if prev_rec:
                prev_rec.is_current = False

            new_rec = RecommendationModel(
                recommendation_id=str(uuid.uuid4()),
                case_id=dispute_id,
                version=(prev_rec.version + 1 if prev_rec else 1),
                content=rec_data.get("content", ""),
                recommendation_type=rec_data.get("recommendation_type", "ESCALATE"),
                confidence_score=float(rec_data.get("confidence_score", 0.5)),
                confidence_descriptor=rec_data.get("confidence_descriptor", "MODERATE"),
                uncertainty_statement=rec_data.get("uncertainty_statement", ""),
                change_reason=rec_data.get("change_reason"),
                previous_recommendation_id=prev_rec.recommendation_id if prev_rec else None,
                # Provenance — who/what produced this, so it's replayable and auditable.
                supporting_evidence_ids=list(best_hypothesis.supporting_evidence_ids) if best_hypothesis else [],
                model_version=nodes._LLM_MODEL,
                prompt_version=prompts.VERSION,
                graph_version=GRAPH_VERSION,
                evidence_state_version=evidence_state_version,
                is_current=True,
                is_stale=False,
                created_at=now,
            )
            db.add(new_rec)

            # Precedent write — this case becomes a future precedent the moment it has
            # a recommendation (not gated on a "mark resolved" flow, which doesn't exist
            # in this schema yet). Best-effort; never fails the run.
            try:
                dispute_info = final_state.get("dispute", {})
                faiss_index.add_precedent(
                    tenant_id=tenant_id,
                    dispute_id=dispute_id,
                    dispute_type=dispute_info.get("dispute_type", ""),
                    network=dispute_info.get("network"),
                    reason_code=dispute_info.get("reason_code"),
                    evidence_types=[e.get("evidence_type", "") for e in final_state.get("evidence", [])],
                    recommendation_type=new_rec.recommendation_type,
                    confidence_score=new_rec.confidence_score,
                    outcome=dispute_info.get("outcome"),
                )
            except Exception:
                pass

        # Evidence gaps — reconcile against this run's fresh assessment instead
        # of only ever appending. A gap that was real on an earlier, less-
        # evidenced run must not stay OPEN forever once new evidence resolves
        # it — otherwise "What's missing?" keeps showing stale gaps no matter
        # how much evidence gets uploaded (the exact complaint this fixed).
        current_gaps = final_state.get("identified_gaps", [])
        current_descs = {g["description"] for g in current_gaps if g.get("description")}

        existing_open = (await db.execute(
            select(EvidenceGapModel).where(
                EvidenceGapModel.case_id == dispute_id, EvidenceGapModel.status == "OPEN",
            )
        )).scalars().all()
        for g in existing_open:
            if g.description not in current_descs:
                g.status = "CLOSED"
                g.received_at = now

        existing_open_descs = {g.description for g in existing_open}
        for g in current_gaps:
            desc = g.get("description")
            if desc and desc not in existing_open_descs:
                gap_row = EvidenceGapModel(
                    gap_id=str(uuid.uuid4()),
                    case_id=dispute_id,
                    gap_type=g.get("gap_type", "MISSING_EVIDENCE"),
                    description=desc,
                    materiality=g.get("materiality", "MEDIUM"),
                    expected_source=g.get("expected_source"),
                    expected_evidence_type=g.get("expected_evidence_type"),
                    status="OPEN",
                    created_at=now,
                )
                db.add(gap_row)
                existing_open_descs.add(desc)

        # Actions — ranked by a deterministic, explainable expected-value score
        # (materiality of the gap addressed x urgency x action-class cost) rather
        # than trusting the LLM's proposal order.
        gaps_for_scoring = [
            {"description": g.get("description", ""), "materiality": g.get("materiality", "MEDIUM")}
            for g in current_gaps
        ]
        ranked_actions = action_scoring.rank_actions(
            final_state.get("proposed_actions", []),
            gaps_for_scoring,
            final_state["dispute"].get("deadline"),
            now,
        )
        for a in ranked_actions:
            action_row = ActionModel(
                action_id=str(uuid.uuid4()),
                case_id=dispute_id,
                tenant_id=tenant_id,
                action_type=a.get("action_type", "REQUEST_EVIDENCE"),
                action_class=a.get("action_class", "CLASS_A"),
                requested_by=user_id,
                proposed_by="agent",
                status="PENDING_APPROVAL" if a.get("action_class") == "CLASS_C" else "PROPOSED",
                idempotency_key=f"{run_id}:{a.get('action_type', '')}:{uuid.uuid4().hex[:6]}",
                input=a,
                retry_count=0,
                created_at=now,
            )
            db.add(action_row)

        # Audit — one event per graph node (granular, replayable trace), plus a
        # summary rollup. node_trace is already built by nodes._trace(); this is
        # the first place it's actually persisted instead of being discarded.
        for entry in final_state.get("node_trace", []):
            try:
                node_ts = datetime.fromisoformat(entry["at"])
            except (KeyError, ValueError):
                node_ts = now
            db.add(AuditEventModel(
                audit_id=str(uuid.uuid4()),
                timestamp=node_ts,
                actor_id="agent",
                actor_type="AGENT",
                tenant_id=tenant_id,
                case_id=dispute_id,
                event_type="AGENT_NODE_COMPLETE",
                agent_run_id=run_id,
                node_name=entry.get("node"),
                model_version=nodes._LLM_MODEL,
                metadata_={"result": entry.get("result")},
            ))

        audit = AuditEventModel(
            audit_id=str(uuid.uuid4()),
            timestamp=now,
            actor_id="agent",
            actor_type="AGENT",
            tenant_id=tenant_id,
            case_id=dispute_id,
            event_type="AGENT_RUN_COMPLETE",
            agent_run_id=run_id,
            model_version=nodes._LLM_MODEL,
            metadata_={
                "steps_used": final_state.get("steps_used", 0),
                "hypotheses_count": len(final_state.get("proposed_hypotheses", [])),
                "actions_count": len(final_state.get("proposed_actions", [])),
                "termination_reason": final_state.get("termination_reason"),
                "citation_warnings": citation_errors,
            },
        )
        db.add(audit)

        run_row = await db.get(AgentRunModel, run_id)
        if run_row:
            run_row.status = "COMPLETED"
            run_row.steps_used = final_state.get("steps_used", 0)
            run_row.termination_reason = final_state.get("termination_reason", "COMPLETE")
            run_row.end_time = now

        await db.commit()


def _score_to_descriptor(score: float) -> str:
    if score >= 0.85:
        return "VERY_HIGH"
    elif score >= 0.70:
        return "HIGH"
    elif score >= 0.50:
        return "MODERATE"
    elif score >= 0.30:
        return "LOW"
    return "VERY_LOW"
