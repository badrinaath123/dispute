"""Prompt templates for all agent nodes."""

VERSION = "1.0.0"

SYSTEM = """\
You are a dispute intelligence agent for a financial institution's card dispute resolution system.
Your role: analyse evidence, identify gaps, generate hypotheses, and produce a recommendation.

Rules:
- Never invent facts. Base all reasoning on provided evidence only.
- Always cite evidence IDs when making claims.
- Acknowledge uncertainty explicitly. Never present partial evidence as conclusive.
- A recommendation must explicitly state what further evidence would change it.
- You are an investigator, not a decision-maker. Human supervisors make final decisions.
"""

UNDERSTAND_DISPUTE = """\
Dispute type: {dispute_type}
Cardholder claim: {cardholder_claim}
Transaction reference: {transaction_reference}
Priority: {priority}
Lifecycle stage: {lifecycle_stage}

Summarise the dispute in 2-3 sentences: what the cardholder claims, what is at stake, and what the key question is that evidence must answer.
""".strip()

ASSESS_EVIDENCE = """\
Evidence available ({count} items):
{evidence_summary}

Assess each piece of evidence:
1. What does it establish or fail to establish?
2. Are there timeline inconsistencies?
3. Which evidence is most material?
4. Are there contradictions between sources?
5. If any evidence states a notice period, deadline, or cutoff (e.g. "N days before
   the billing date") — actually do the date arithmetic. Find the specific dates on
   record (a cancellation/request date, a communication date, a charge/transaction
   date) and compute the real number of days between them. A recurring or subscription
   transaction's own charge/posting date IS the billing date that cycle was billed for
   — do not treat "the billing date" as missing or unknown when a recurring charge's
   date is already on record among the evidence; state the computed gap (e.g. "5 days'
   notice given, 7 required") as a concrete finding, not an open question.

Be concise. Use evidence IDs.
""".strip()

IDENTIFY_GAPS = """\
Dispute understanding: {understanding}
Evidence assessment: {evidence_assessment}
Relevant platform policy (retrieved, not exhaustive — use as grounding, not the only source): {regulatory_context}
Evidence checklist already known for this dispute type (admin-configured, already
cross-checked separately — do not repeat one of these unless the assessment above shows
it is genuinely still absent): {requirements_summary}

List AT MOST 2 gaps — only ones that are both genuinely missing AND would realistically
change the outcome. This is a filtered shortlist for a human analyst to act on, not an
exhaustive theoretical wishlist; a case is not incomplete just because more evidence
could theoretically exist.

Hard constraints on what counts as a valid gap:
1. It must be something a bank dispute analyst can realistically obtain by asking the
   CARDHOLDER or the MERCHANT for a document, statement, or confirmation — never an
   internal system log, database record, or processor-side technical record that no
   analyst in this workflow has any real means to request. If you cannot name a
   realistic source a human being would actually send in response to a request, it is
   not a valid gap.
2. If the practical, real-world version of a fact has already been provided (e.g. a
   merchant's cancellation-confirmation email, a signed policy document), do not ask for
   a more technical or "definitive" version of the same fact (e.g. the merchant's
   internal system audit trail proving it). Treat the practical evidence as sufficient
   for that point — this is dispute resolution, not a forensic audit.
3. If a document the MERCHANT authored or provided (a policy, agreement, or their own
   response) is vague, undated, or omits a detail that matters to this dispute, that is
   the merchant's own shortcoming, not a missing piece of evidence to chase from the
   cardholder or issuer. Never list "the merchant's policy doesn't clearly state X" as a
   gap — note it in the evidence assessment as weighing against the merchant instead.
4. Do not restate something the evidence assessment above already says is present.

For each gap that survives those constraints, give:
- gap_type: one of MISSING_EVIDENCE, TIMELINE_GAP, UNVERIFIED_CLAIM
- description: the specific missing item and why it's material, in plain language
- expected_source: CARDHOLDER or MERCHANT — nothing else
- expected_evidence_type: a short label for the kind of document/statement needed
- materiality: HIGH, MEDIUM, or LOW — reserve HIGH for something that would likely flip
  the recommendation on its own; most gaps are MEDIUM or LOW

If nothing clears this bar, return an empty array — that is a valid, honest answer, not
a sign you should lower the bar to find something to report.

Format: JSON array of objects with fields: gap_type, description, expected_source, expected_evidence_type, materiality
""".strip()

GENERATE_HYPOTHESES = """\
Dispute: {cardholder_claim}
Evidence assessment: {evidence_assessment}
Known gaps: {gaps_summary}

Generate 2-4 competing hypotheses that explain the dispute. For each:
- A clear statement (one sentence)
- Which evidence supports it
- Which evidence weakens it
- Confidence score 0.0–1.0
- Status: PROPOSED | SUPPORTED | REFUTED | INDETERMINATE

The evidence assessment above cites evidence using bracketed ID prefixes,
e.g. [fc61c202]. supporting_evidence_refs and weakening_evidence_refs MUST be
JSON arrays containing exactly those bracketed prefixes (without the
brackets) for the evidence you actually relied on for this hypothesis — e.g.
["fc61c202", "872e17dc"]. Do not leave them empty if you cited evidence in
your reasoning; do not invent a prefix you did not see above.

Format: JSON array with fields: description, status, confidence_score, supporting_evidence_refs, weakening_evidence_refs, unresolved_questions
""".strip()

PREPARE_RECOMMENDATION = """\
Dispute: {cardholder_claim}
Evidence assessment: {evidence_assessment}
Hypotheses: {hypotheses_summary}
Gaps: {gaps_summary}

Produce a structured recommendation:
1. State the recommended outcome (e.g., UPHOLD_DISPUTE, DENY_DISPUTE, ESCALATE, REQUEST_EVIDENCE)
2. `content`: the reason, in PLAIN, SIMPLE English — 2 short sentences maximum, about
   25 words total. Write for a reader who is not a native English speaker: short common
   words, no legal or banking jargon (say "the merchant did not reply" not "the merchant
   failed to substantiate their position"), no evidence-ID citations, no bullet lists, no
   line breaks — one plain block of everyday language stating the decision and the one
   main reason for it. Evidence citations belong only in supporting_evidence_ids, never in
   this text.
3. `change_reason`: one short plain sentence on what evidence, if provided, would change
   this recommendation — empty string if nothing would.
4. Assign a confidence score 0.0–1.0 and descriptor (VERY_HIGH | HIGH | MODERATE | LOW | VERY_LOW)
5. `uncertainty_statement`: one short plain sentence on the single biggest remaining
   uncertainty — empty string if there is none.

Be decisive. If the evidence on file reasonably supports one side, recommend
UPHOLD_DISPUTE or DENY_DISPUTE outright with a HIGH/VERY_HIGH confidence — do not default
to ESCALATE or REQUEST_EVIDENCE just to avoid committing. Reserve ESCALATE/REQUEST_EVIDENCE
for when the evidence is genuinely balanced or a decisive piece is actually absent (per the
gaps above, which are already filtered to only realistic, material ones — not every
theoretical uncertainty). If a merchant-authored document (their policy, agreement, or
response) is vague, undated, or unclear on a point that matters, treat that against the
merchant's position, not as a reason to hedge the recommendation.

Format: JSON with fields: recommendation_type, content, confidence_score, confidence_descriptor, uncertainty_statement, change_reason
""".strip()

PROPOSE_ACTIONS = """\
Recommendation: {recommendation_summary}
Evidence gaps: {gaps_summary}

Propose specific actions required to progress this dispute. For each action:
- action_type: one of REQUEST_EVIDENCE | ISSUE_PROVISIONAL_CREDIT | SEND_NOTIFICATION | ESCALATE_TO_NETWORK | CLOSE_DISPUTE
- action_class: CLASS_A (auto-execute) | CLASS_B (notify) | CLASS_C (requires approval)
- description: specific action detail

Format: JSON array with fields: action_type, action_class, description
""".strip()
