"""
LangGraph dispute resolution graph.
Nodes: load_case_state → understand_dispute → assess_evidence →
       identify_gaps → generate_hypotheses → prepare_recommendation →
       propose_actions → finalize
"""
from __future__ import annotations

from langgraph.graph import StateGraph, END

from packages.agent.state import DisputeGraphState
from packages.agent import nodes

GRAPH_VERSION = "1.1.0"  # retrieve_context node added (regulatory + precedent retrieval)

# Single source of truth for node order — the graph is strictly linear (no
# branching besides the termination guard), so this doubles as the sequence
# runner.py uses to emit node_start events ahead of each node's execution.
NODE_PIPELINE = [
    "load_case_state",
    "retrieve_context",
    "understand_dispute",
    "assess_evidence",
    "identify_gaps",
    "generate_hypotheses",
    "prepare_recommendation",
    "propose_actions",
    "finalize",
]


def _should_terminate(state: DisputeGraphState) -> str:
    return "end" if state.get("terminated") else "continue"


def build_graph() -> StateGraph:
    g = StateGraph(DisputeGraphState)

    # Register nodes
    for node_fn in [
        nodes.load_case_state,
        nodes.retrieve_context,
        nodes.understand_dispute,
        nodes.assess_evidence,
        nodes.identify_gaps,
        nodes.generate_hypotheses,
        nodes.prepare_recommendation,
        nodes.propose_actions,
        nodes.finalize,
    ]:
        g.add_node(node_fn.__name__, node_fn)

    g.set_entry_point(NODE_PIPELINE[0])

    for i, name in enumerate(NODE_PIPELINE[:-1]):
        next_name = NODE_PIPELINE[i + 1]
        g.add_conditional_edges(
            name,
            _should_terminate,
            {"end": END, "continue": next_name},
        )

    g.add_edge("finalize", END)

    return g.compile()


# Compiled graph singleton
compiled_graph = build_graph()
