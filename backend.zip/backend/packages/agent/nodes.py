"""
All LangGraph node functions.
Each function receives DisputeGraphState and returns a dict of updates.
"""
from __future__ import annotations
import json
import os
import time
import uuid
from datetime import datetime
from typing import Any

from packages.agent.state import DisputeGraphState
from packages.agent import prompts
from packages.intelligence import scheme_rules, faiss_index
from packages.intelligence.llm_client import (
    LLM_MODEL as _LLM_MODEL, call_llm as _llm, extract_json_str as _extract_json,
)
from packages.observability.logging import get_logger

logger = get_logger("agent.nodes")

MAX_STEPS = int(os.getenv("AGENT_MAX_STEPS", "20"))


def _trace(state: DisputeGraphState, node: str, result: str = "OK") -> list[dict]:
    return [{"node": node, "at": datetime.utcnow().isoformat(), "result": result}]


def _guard(state: DisputeGraphState) -> dict | None:
    """Return termination update if budget exceeded."""
    if state["steps_used"] >= MAX_STEPS:
        return {
            "terminated": True,
            "termination_reason": "MAX_STEPS_EXCEEDED",
            "node_trace": _trace(state, "GUARD"),
        }
    return None


# ── Node implementations ───────────────────────────────────────────────────────

def load_case_state(state: DisputeGraphState) -> dict:
    """DB data already injected before graph start. Just validate."""
    guard = _guard(state)
    if guard:
        return guard
    evidence_count = len(state.get("evidence", []))
    logger.info("agent_load_case", dispute_id=state["dispute_id"], evidence_count=evidence_count)
    return {
        "steps_used": state["steps_used"] + 1,
        "node_trace": _trace(state, "load_case_state"),
    }


def retrieve_context(state: DisputeGraphState) -> dict:
    """
    Retrieval step: pulls relevant platform policy passages and similar past cases
    from the vector store (packages/intelligence/faiss_index). Best-effort — a vector
    store miss or disabled deps must never fail the run, so failures are swallowed and
    downstream nodes see empty lists rather than an error.
    """
    guard = _guard(state)
    if guard:
        return guard
    d = state.get("dispute", {})
    dispute_type = d.get("dispute_type", "")
    network = d.get("network")
    reason_code = d.get("reason_code")

    regulatory_context: list[dict] = []
    precedent_cases: list[dict] = []
    try:
        query = f"{dispute_type} {network or ''} {reason_code or ''} evidence requirements"
        regulatory_context = faiss_index.find_regulatory_context(
            query, top_k=2, network=(network or "").upper() or None
        )
    except Exception:
        pass
    try:
        precedent_cases = faiss_index.find_precedents(
            state["tenant_id"], dispute_type, network, reason_code,
            exclude_dispute_id=state["dispute_id"], top_k=3,
        )
    except Exception:
        pass

    logger.info("agent_retrieve_context", dispute_id=state["dispute_id"],
                regulatory_hits=len(regulatory_context), precedent_hits=len(precedent_cases))
    return {
        "regulatory_context": regulatory_context,
        "precedent_cases": precedent_cases,
        "steps_used": state["steps_used"] + 1,
        "node_trace": _trace(state, "retrieve_context"),
    }


def understand_dispute(state: DisputeGraphState) -> dict:
    guard = _guard(state)
    if guard:
        return guard
    d = state["dispute"]
    prompt = prompts.UNDERSTAND_DISPUTE.format(
        dispute_type=d.get("dispute_type", ""),
        cardholder_claim=d.get("cardholder_claim", ""),
        transaction_reference=d.get("transaction_reference", "N/A"),
        priority=d.get("priority", ""),
        lifecycle_stage=d.get("lifecycle_stage", ""),
    )
    understanding = _llm(prompts.SYSTEM, prompt)
    logger.info("agent_understand_dispute", dispute_id=state["dispute_id"])
    return {
        "understanding": understanding,
        "steps_used": state["steps_used"] + 1,
        "node_trace": _trace(state, "understand_dispute"),
    }


def _evidence_content_line(e: dict) -> str:
    content = e.get("normalized_content", {}) or {}
    # Document-sourced evidence (uploaded/sample files) carries its actual
    # substance in textSummary, not in the structured fields the branch below
    # dumps — surface that text explicitly so the LLM can reason about what a
    # document actually says, not just that a file of some type exists.
    #
    # Was checking source_type == "DOCUMENT" — a value evidence rows never
    # actually have (source_type is always "CARDHOLDER" or "MERCHANT",
    # apps/api/routes/v1/disputes.py's _attach_document; "DOCUMENT_STORAGE" is
    # source_system, a different field entirely). This condition was false for
    # every real document-uploaded evidence item that has ever existed in this
    # app, so assess_evidence always saw a raw, truncated JSON dump of
    # normalized_content instead of the clean summary line the code was
    # written to produce — found live when a merchant-uploaded cancellation
    # policy stating a real 7-day notice period never made it into a
    # recommendation's reasoning (README §81).
    if e.get("source_system") == "DOCUMENT_STORAGE":
        summary = content.get("textSummary") or "(no extracted summary available)"
        return f"{content.get('documentType', e['evidence_type'])} \"{content.get('fileName', '')}\": {summary}"
    return json.dumps(content)[:300]


def assess_evidence(state: DisputeGraphState) -> dict:
    guard = _guard(state)
    if guard:
        return guard
    ev_list = state.get("evidence", [])
    evidence_summary = "\n".join(
        f"- [{e['evidence_id'][:8]}] {e['evidence_type']} (v{e['version']}) "
        f"from {e['source_type']}: {_evidence_content_line(e)}"
        for e in ev_list
    )
    prompt = prompts.ASSESS_EVIDENCE.format(
        count=len(ev_list), evidence_summary=evidence_summary or "(none)"
    )
    assessment = _llm(prompts.SYSTEM, prompt)
    return {
        "evidence_assessment": assessment,
        "steps_used": state["steps_used"] + 1,
        "node_trace": _trace(state, "assess_evidence"),
    }


_VALID_MATERIALITY = {"HIGH", "MEDIUM", "LOW"}
_VALID_GAP_TYPE = {"MISSING_EVIDENCE", "TIMELINE_GAP", "UNVERIFIED_CLAIM"}
_VALID_SOURCE = {"CARDHOLDER", "MERCHANT"}


def _gaps_summary(gaps: list[dict]) -> str:
    return "\n".join(f"- {g.get('description', '')} [{g.get('materiality', 'MEDIUM')}]" for g in gaps)


def identify_gaps(state: DisputeGraphState) -> dict:
    guard = _guard(state)
    if guard:
        return guard
    regulatory_context = state.get("regulatory_context", [])
    regulatory_summary = "\n".join(
        f"- {p['title']}: {p['text']}" for p in regulatory_context
    ) or "(none retrieved)"

    dispute = state.get("dispute", {})
    dispute_type = (dispute.get("dispute_type") or "").upper()
    requirement_rows = (state.get("evidence_requirements") or {}).get(dispute_type, [])
    requirements_summary = "\n".join(
        f"- {r['evidence_type']} ({'required' if r.get('is_required') else 'optional'})"
        for r in requirement_rows
    ) or "(no checklist configured for this dispute type)"

    prompt = prompts.IDENTIFY_GAPS.format(
        understanding=state.get("understanding", ""),
        evidence_assessment=state.get("evidence_assessment", ""),
        regulatory_context=regulatory_summary,
        requirements_summary=requirements_summary,
    )
    raw = _llm(prompts.SYSTEM, prompt)
    try:
        parsed = json.loads(_extract_json(raw))
    except Exception:
        parsed = []

    llm_gaps: list[dict] = []
    for g in parsed if isinstance(parsed, list) else []:
        if not isinstance(g, dict) or not g.get("description"):
            continue
        llm_gaps.append({
            "gap_type": g.get("gap_type") if g.get("gap_type") in _VALID_GAP_TYPE else "MISSING_EVIDENCE",
            "description": g["description"],
            "expected_source": g.get("expected_source") if g.get("expected_source") in _VALID_SOURCE else None,
            "expected_evidence_type": g.get("expected_evidence_type") or None,
            "materiality": g.get("materiality") if g.get("materiality") in _VALID_MATERIALITY else "MEDIUM",
        })
    # The prompt already caps at 2, but never trust the model to honor a limit
    # on its own — enforce it here too.
    llm_gaps = llm_gaps[:2]

    # Deterministic safety net: cross-check against what the card network
    # actually requires for this reason code (falls back to a dispute-type
    # checklist when network/reason_code aren't set — see scheme_rules.py),
    # in case the LLM missed it. These are ground-truth checklist misses, not
    # LLM guesses, so they're always HIGH materiality and carry the real
    # expected_evidence_type — nothing here is invented or downgraded.
    completeness = scheme_rules.assess_completeness(
        dispute.get("network"), dispute.get("reason_code"), state.get("evidence", []),
        dispute.get("dispute_type"), state.get("evidence_requirements"),
    )
    reason = (
        f"required by {(dispute.get('network') or '').upper()} for reason code {dispute.get('reason_code')} representment"
        if completeness["rule_source"] == "SCHEME"
        else f"required to investigate a {dispute_type.replace('_', ' ').lower()} dispute"
    )
    rule_gaps = [
        {
            "gap_type": "MISSING_EVIDENCE",
            "description": f"Missing {evidence_type.replace('_', ' ').title()} — {reason}",
            "expected_source": "MERCHANT" if "MERCHANT" in evidence_type else "CARDHOLDER",
            "expected_evidence_type": evidence_type,
            "materiality": "HIGH",
        }
        for evidence_type in completeness["missing_required"]
    ]

    rule_descs = {r["description"] for r in rule_gaps}
    all_gaps = rule_gaps + [g for g in llm_gaps if g["description"] not in rule_descs]

    return {
        "identified_gaps": all_gaps,
        "steps_used": state["steps_used"] + 1,
        "node_trace": _trace(state, "identify_gaps"),
    }


def generate_hypotheses(state: DisputeGraphState) -> dict:
    guard = _guard(state)
    if guard:
        return guard
    gaps_summary = _gaps_summary(state.get("identified_gaps", []))
    prompt = prompts.GENERATE_HYPOTHESES.format(
        cardholder_claim=state["dispute"].get("cardholder_claim", ""),
        evidence_assessment=state.get("evidence_assessment", ""),
        gaps_summary=gaps_summary or "None identified",
    )
    raw = _llm(prompts.SYSTEM, prompt)
    try:
        hypotheses = json.loads(_extract_json(raw))
    except Exception:
        hypotheses = []
    return {
        "proposed_hypotheses": hypotheses,
        "steps_used": state["steps_used"] + 1,
        "node_trace": _trace(state, "generate_hypotheses"),
    }


def prepare_recommendation(state: DisputeGraphState) -> dict:
    guard = _guard(state)
    if guard:
        return guard
    hyps = state.get("proposed_hypotheses", [])
    hypotheses_summary = "\n".join(
        f"- {h.get('description', '')} [confidence={h.get('confidence_score', 0):.2f}]"
        for h in hyps
    )
    gaps_summary = _gaps_summary(state.get("identified_gaps", []))
    prompt = prompts.PREPARE_RECOMMENDATION.format(
        cardholder_claim=state["dispute"].get("cardholder_claim", ""),
        evidence_assessment=state.get("evidence_assessment", ""),
        hypotheses_summary=hypotheses_summary or "None",
        gaps_summary=gaps_summary or "None",
    )
    raw = _llm(prompts.SYSTEM, prompt)
    try:
        rec = json.loads(_extract_json(raw))
    except Exception:
        rec = {
            "recommendation_type": "ESCALATE",
            "content": raw,
            "confidence_score": 0.5,
            "confidence_descriptor": "MODERATE",
            "uncertainty_statement": "LLM output could not be parsed as JSON",
            "change_reason": None,
        }
    return {
        "recommendation_draft": raw,
        "recommendation": rec,
        "steps_used": state["steps_used"] + 1,
        "node_trace": _trace(state, "prepare_recommendation"),
    }


def propose_actions(state: DisputeGraphState) -> dict:
    guard = _guard(state)
    if guard:
        return guard
    rec = state.get("recommendation") or {}
    gaps_summary = _gaps_summary(state.get("identified_gaps", []))
    prompt = prompts.PROPOSE_ACTIONS.format(
        recommendation_summary=rec.get("content", "")[:500],
        gaps_summary=gaps_summary or "None",
    )
    raw = _llm(prompts.SYSTEM, prompt)
    try:
        actions = json.loads(_extract_json(raw))
    except Exception:
        actions = []
    return {
        "proposed_actions": actions,
        "steps_used": state["steps_used"] + 1,
        "node_trace": _trace(state, "propose_actions"),
    }


def finalize(state: DisputeGraphState) -> dict:
    logger.info(
        "agent_finalize",
        dispute_id=state["dispute_id"],
        steps=state["steps_used"],
        hypotheses=len(state.get("proposed_hypotheses", [])),
        actions=len(state.get("proposed_actions", [])),
    )
    return {
        "terminated": True,
        "termination_reason": "COMPLETE",
        "steps_used": state["steps_used"] + 1,
        "node_trace": _trace(state, "finalize", "COMPLETE"),
    }


