"""
LangGraph state — DisputeGraphState TypedDict.
All agent nodes read from and write to this dict.
"""
from __future__ import annotations
from typing import TypedDict, Annotated, Optional
import operator


class DisputeGraphState(TypedDict):
    # Inputs
    dispute_id: str
    tenant_id: str
    run_id: str

    # Case data loaded from DB
    dispute: dict
    evidence: list[dict]
    hypotheses: list[dict]
    contradictions: list[dict]
    evidence_gaps: list[dict]
    timeline_events: list[dict]
    existing_recommendation: Optional[dict]

    # Working state
    understanding: Optional[str]       # Natural language dispute understanding
    evidence_assessment: Optional[str]
    regulatory_context: list[dict]     # Retrieved policy passages (packages/intelligence/faiss_index.find_regulatory_context)
    precedent_cases: list[dict]        # Similar past cases (packages/intelligence/faiss_index.find_precedents)
    evidence_requirements: dict        # Admin-editable per-dispute-type checklist (packages/intelligence/evidence_requirements.load_active)
    identified_gaps: list[dict]        # {gap_type, description, expected_source, expected_evidence_type, materiality}
    proposed_hypotheses: list[dict]
    proposed_actions: list[dict]
    recommendation_draft: Optional[str]

    # Agent metadata
    steps_used: int
    errors: Annotated[list[str], operator.add]
    node_trace: Annotated[list[dict], operator.add]

    # Output
    recommendation: Optional[dict]
    terminated: bool
    termination_reason: Optional[str]
