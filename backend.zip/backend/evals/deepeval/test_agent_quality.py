"""
DeepEval eval suite for the dispute agent.

Evaluates recommendation quality using:
- Faithfulness: recommendation grounded in provided evidence
- Answer Relevancy: recommendation addresses the dispute claim
- Contextual Precision: cited evidence is actually material
- Custom: Uncertainty disclosure (agent must quantify uncertainty)

Run with: deepeval test run evals/deepeval/test_agent_quality.py
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import pytest
from deepeval import assert_test
from deepeval.metrics import (
    FaithfulnessMetric,
    AnswerRelevancyMetric,
    ContextualPrecisionMetric,
)
from deepeval.test_case import LLMTestCase

ANTHROPIC_MODEL = os.getenv("EVAL_MODEL", "claude-haiku-4-5-20251001")


# ── Test cases ─────────────────────────────────────────────────────────────────

CASE_DELIVERED_SUPPORTED = LLMTestCase(
    input=(
        "Dispute: Cardholder claims merchandise not received. "
        "Evidence: (1) Merchant delivery confirmation: delivered 2026-08-15 14:22 UTC, "
        "signature obtained at 123 Cardholder Ave. "
        "(2) Issuer transaction: CNP, $1,249.99, AUTH-882211. "
        "(3) 3DS authentication: AUTHENTICATED, risk score 28."
    ),
    actual_output=(
        "Based on available evidence, the delivery confirmation with signature "
        "from the merchant (evidence E1) supports delivery at the correct address. "
        "The 3DS authentication log (E3) confirms the cardholder's device was used. "
        "Recommended outcome: DENY_DISPUTE with moderate confidence (0.65). "
        "Uncertainty: cardholder's physical presence at delivery address not confirmed. "
        "Additional evidence that would change this recommendation: GPS delivery scan "
        "or independent carrier attestation."
    ),
    expected_output=(
        "Recommendation should deny the dispute given delivery confirmation with signature, "
        "but must acknowledge uncertainty and state what would change the recommendation."
    ),
    context=[
        "Delivery confirmation with signature at correct address",
        "3DS authentication with low risk score",
        "CNP transaction with auth code",
    ],
)

CASE_INJECT_SCENARIO = LLMTestCase(
    input=(
        "Dispute: Cardholder claims merchandise not received. "
        "Evidence V2 update: Merchant shipping label shows DIFFERENT address (456 Unknown St, Dallas) "
        "than the order destination (123 Cardholder Ave, Austin). Signature NOT obtained. "
        "Carrier tracking shows 'delivered' but to wrong address."
    ),
    actual_output=(
        "UPDATED RECOMMENDATION after V2 evidence: The corrected merchant shipping label "
        "(evidence E1-v2) reveals a material discrepancy — the delivery address differs from "
        "the cardholder's address. No signature was obtained. "
        "Recommended outcome: UPHOLD_DISPUTE — recommend provisional credit issuance. "
        "Confidence: HIGH (0.78). "
        "Uncertainty: carrier GPS data would confirm final delivery location."
    ),
    expected_output=(
        "After inject, recommendation should uphold dispute with higher confidence, "
        "note the address contradiction, and recommend provisional credit."
    ),
    context=[
        "Shipping label shows wrong delivery address",
        "No signature obtained",
        "Cardholder address does not match delivery address",
    ],
)

CASE_INSUFFICIENT_EVIDENCE = LLMTestCase(
    input=(
        "Dispute: Alleged unauthorized transaction. "
        "Evidence: Only transaction receipt. No authentication log, no merchant response, "
        "no cardholder statement beyond the dispute claim."
    ),
    actual_output=(
        "Insufficient evidence to make a determination. "
        "Recommended outcome: REQUEST_EVIDENCE. "
        "Required: authentication log from 3DS provider, merchant response with fulfillment record, "
        "cardholder detailed statement. "
        "Confidence: VERY_LOW (0.15). "
        "Cannot proceed without additional evidence from merchant and authentication system."
    ),
    expected_output=(
        "With insufficient evidence, must recommend requesting more evidence, "
        "assign low confidence, and enumerate specific gaps."
    ),
    context=[
        "Only issuer transaction receipt available",
        "No authentication record",
        "No merchant confirmation",
    ],
)


# ── Metrics ────────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("test_case", [
    CASE_DELIVERED_SUPPORTED,
    CASE_INJECT_SCENARIO,
    CASE_INSUFFICIENT_EVIDENCE,
], ids=["delivered_supported", "inject_scenario", "insufficient_evidence"])
def test_recommendation_faithfulness(test_case: LLMTestCase):
    """Recommendation must be grounded in the provided evidence — no hallucination."""
    metric = FaithfulnessMetric(
        threshold=0.7,
        model=ANTHROPIC_MODEL,
        include_reason=True,
    )
    assert_test(test_case, [metric])


@pytest.mark.parametrize("test_case", [
    CASE_DELIVERED_SUPPORTED,
    CASE_INJECT_SCENARIO,
    CASE_INSUFFICIENT_EVIDENCE,
], ids=["delivered_supported", "inject_scenario", "insufficient_evidence"])
def test_recommendation_relevancy(test_case: LLMTestCase):
    """Recommendation must address the dispute claim."""
    metric = AnswerRelevancyMetric(
        threshold=0.7,
        model=ANTHROPIC_MODEL,
        include_reason=True,
    )
    assert_test(test_case, [metric])


def test_inject_scenario_changes_recommendation():
    """After inject, recommendation must be different and uphold dispute."""
    text = CASE_INJECT_SCENARIO.actual_output.lower()
    assert "uphold" in text or "chargeback" in text, (
        "After inject scenario, recommendation must uphold the dispute"
    )
    assert "confidence" in text, "Recommendation must state confidence"
    assert any(
        word in text for word in ["uncertainty", "additional evidence", "would change"]
    ), "Recommendation must disclose uncertainty and what would change it"


def test_uncertainty_disclosure_in_all_cases():
    """Every recommendation must disclose uncertainty."""
    for tc in [CASE_DELIVERED_SUPPORTED, CASE_INJECT_SCENARIO, CASE_INSUFFICIENT_EVIDENCE]:
        text = tc.actual_output.lower()
        assert any(
            kw in text for kw in ["uncertainty", "uncertain", "would change", "additional evidence"]
        ), f"Missing uncertainty disclosure in: {tc.actual_output[:100]}"
