"""
Mock external API server — simulates merchant, issuer, carrier, auth, network.
Serves the National Finals demo inject scenario:
  - V1: merchant claims delivery confirmed
  - V2 (inject): merchant provides shipping label showing wrong address — triggers re-evaluation
"""
import asyncio
import json
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse

app = FastAPI(title="Mock External APIs", version="1.0.0")

DATA_DIR = Path(__file__).parent / "data"


def _load(name: str) -> dict:
    path = DATA_DIR / name
    if path.exists():
        return json.loads(path.read_text())
    return {}


# ── Merchant ──────────────────────────────────────────────────────────────────

_MERCHANT_V1 = {
    "transaction_id": "TXN-DEMO-001",
    "order_id": "ORD-9988",
    "merchant_name": "ElectroShop Direct",
    "amount": 1249.99,
    "currency": "USD",
    "status": "DELIVERED",
    "shipping": {
        "tracking_number": "1Z999AA10123456784",
        "carrier": "UPS",
        "delivered_at": "2026-08-15T14:22:00Z",
        "delivery_address": "123 Cardholder Ave, Austin TX 78701",
        "signature_obtained": True,
    },
    "evidence_version": 1,
}

_MERCHANT_V2 = {
    **_MERCHANT_V1,
    "evidence_version": 2,
    "shipping": {
        **_MERCHANT_V1["shipping"],
        "delivery_address": "456 Unknown St, Dallas TX 75201",  # WRONG ADDRESS — the inject
        "shipping_label_url": "/mock/shipping_label_v2.pdf",
        "signature_obtained": False,
        "injected_at": "2026-08-30T10:00:00Z",
        "note": "Corrected record — label shows different address than originally reported",
    },
}

# Simulate inject state
_inject_active = {"merchant": False}


@app.get("/merchant/transactions/{transaction_id}")
async def merchant_transaction(transaction_id: str):
    if transaction_id != "TXN-DEMO-001":
        raise HTTPException(404, detail="Transaction not found")
    return JSONResponse(_MERCHANT_V2 if _inject_active["merchant"] else _MERCHANT_V1)


@app.post("/inject/merchant")
async def activate_merchant_inject():
    """Activate the National Finals inject — merchant late evidence."""
    _inject_active["merchant"] = True
    return {"status": "injected", "version": 2}


@app.post("/inject/reset")
async def reset_inject():
    _inject_active["merchant"] = False
    return {"status": "reset"}


# ── Issuer ────────────────────────────────────────────────────────────────────

@app.get("/issuer/accounts/{account_id}/transactions")
async def issuer_transactions(account_id: str, reference: str = ""):
    return JSONResponse({
        "account_id": account_id,
        "transaction_reference": reference,
        "transactions": [
            {
                "reference": "TXN-DEMO-001",
                "amount": 1249.99,
                "currency": "USD",
                "posted_at": "2026-08-14T19:45:00Z",
                "merchant_category": "5732",
                "auth_code": "AUTH-882211",
                "cardholder_present": False,
                "channel": "CNP",
            }
        ],
    })


# ── Carrier ───────────────────────────────────────────────────────────────────

@app.get("/carrier/track/{tracking_number}")
async def carrier_track(tracking_number: str, carrier: str = ""):
    return JSONResponse({
        "tracking_number": tracking_number,
        "carrier": carrier or "UPS",
        "events": [
            {
                "timestamp": "2026-08-15T14:22:00Z",
                "location": "Austin, TX 78701",
                "status": "DELIVERED",
                "description": "Package delivered to front door",
            },
            {
                "timestamp": "2026-08-15T09:11:00Z",
                "location": "Austin, TX Hub",
                "status": "OUT_FOR_DELIVERY",
            },
        ],
        "destination": "456 Unknown St, Dallas TX 75201" if _inject_active["merchant"] else "123 Cardholder Ave, Austin TX 78701",
        "signature": None if _inject_active["merchant"] else "J. SMITH",
    })


# ── Authentication system ─────────────────────────────────────────────────────

@app.get("/auth-system/logs/{transaction_id}")
async def auth_logs(transaction_id: str):
    return JSONResponse({
        "transaction_id": transaction_id,
        "authentication_result": "AUTHENTICATED",
        "method": "3DS2",
        "eci": "05",
        "device_id": "DEV-9f3a21b",
        "ip_address": "203.0.113.45",
        "ip_country": "US",
        "risk_score": 28,
        "timestamp": "2026-08-14T19:44:55Z",
    })


# ── Network ───────────────────────────────────────────────────────────────────

@app.get("/network/chargebacks")
async def network_chargebacks(transaction_id: str = "", network: str = "VISA"):
    return JSONResponse({
        "transaction_id": transaction_id,
        "network": network,
        "chargeback_reason_code": "13.1",
        "reason_description": "Merchandise / Services Not Received",
        "time_limit_days": 30,
        "days_remaining": 12,
        "representment_eligible": True,
    })


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8100, log_level="info")
