"""
E2E test: National Finals inject journey.

Tests the full critical path:
1. Create dispute
2. Ingest V1 evidence
3. Run agent → recommendation created
4. Inject V2 evidence (wrong address)
5. Recommendation marked STALE
6. Re-run agent → new recommendation with different confidence
7. Approve CLASS_C action
8. Audit trail complete

Run with: pytest tests/e2e/test_full_journey.py -v
Requires live API at http://localhost:8000
"""
import asyncio
import hashlib
import json
import time

import pytest
import httpx

BASE = "http://localhost:8000/api/v1"
ANALYST_CREDS = {"username": "analyst", "password": "Analyst@123!"}
SUPERVISOR_CREDS = {"username": "supervisor", "password": "Supervisor@123!"}


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def analyst_token():
    r = httpx.post(f"{BASE}/auth/token", data=ANALYST_CREDS)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def supervisor_token():
    r = httpx.post(f"{BASE}/auth/token", data=SUPERVISOR_CREDS)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]


def _headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


# ── Tests ──────────────────────────────────────────────────────────────────────

def test_health():
    r = httpx.get(f"{BASE}/health")
    assert r.status_code == 200


def test_full_journey(analyst_token: str, supervisor_token: str):
    ah = _headers(analyst_token)
    sh = _headers(supervisor_token)

    # ── Step 1: Create dispute ────────────────────────────────────────────────
    r = httpx.post(f"{BASE}/disputes", json={
        "dispute_type": "MERCHANDISE_NOT_RECEIVED",
        "cardholder_claim": "E2E test: item not received despite merchant claim of delivery",
        "transaction_reference": "TXN-E2E-001",
        "priority": "HIGH",
    }, headers=ah)
    assert r.status_code == 201, r.text
    dispute_id = r.json()["dispute_id"]

    # ── Step 2: Ingest V1 delivery evidence ────────────────────────────────
    v1_content = {
        "tracking_number": "E2E-TRACK-001",
        "carrier": "UPS",
        "delivered_at": "2026-08-15T14:00:00Z",
        "delivery_address": "123 Main St, Austin TX",
        "signature_obtained": True,
        "evidence_version": 1,
    }
    r = httpx.post(f"{BASE}/disputes/{dispute_id}/evidence", json={
        "source_type": "MERCHANT",
        "source_system": "E2E-OMS",
        "source_record_id": "E2E-DELIVERY-001",
        "evidence_type": "DELIVERY_CONFIRMATION",
        "normalized_content": v1_content,
        "event_time": "2026-08-15T14:00:00Z",
        "materiality": "HIGH",
    }, headers=ah)
    assert r.status_code == 201, r.text
    ev1 = r.json()
    assert ev1["version"] == 1
    assert ev1["is_current"] is True

    # Also ingest transaction receipt
    r = httpx.post(f"{BASE}/disputes/{dispute_id}/evidence", json={
        "source_type": "ISSUER",
        "source_system": "CoreBanking",
        "source_record_id": "TXN-E2E-001-ISSUER",
        "evidence_type": "TRANSACTION_RECEIPT",
        "normalized_content": {"amount": 499.99, "currency": "USD", "auth_code": "AUTH-E2E"},
        "event_time": "2026-08-14T10:00:00Z",
        "materiality": "HIGH",
    }, headers=ah)
    assert r.status_code == 201, r.text

    # ── Step 3: Run agent → recommendation ────────────────────────────────
    # (Skip actual LLM in E2E; just verify endpoint responds and creates run)
    r = httpx.post(f"{BASE}/disputes/{dispute_id}/agent/run",
                   json={"trigger": "E2E_TEST"}, headers=ah)
    assert r.status_code == 202, r.text
    run_id = r.json()["run_id"]

    # Poll status — allow up to 60s for agent
    for _ in range(30):
        time.sleep(2)
        r = httpx.get(f"{BASE}/disputes/{dispute_id}/agent/status", headers=ah)
        status = r.json().get("status", "")
        if status in ("COMPLETED", "COMPLETE", "FAILED", "NO_RUN"):
            break

    # ── Step 4: Inject V2 evidence (wrong address) ────────────────────────
    v2_content = {
        **v1_content,
        "delivery_address": "456 Wrong St, Dallas TX",  # INJECT
        "signature_obtained": False,
        "evidence_version": 2,
    }
    r = httpx.post(f"{BASE}/disputes/{dispute_id}/evidence", json={
        "source_type": "MERCHANT",
        "source_system": "E2E-OMS",
        "source_record_id": "E2E-DELIVERY-001",  # same record_id → triggers version
        "evidence_type": "DELIVERY_CONFIRMATION",
        "normalized_content": v2_content,
        "event_time": "2026-08-15T14:00:00Z",
        "materiality": "HIGH",
    }, headers=ah)
    assert r.status_code == 201, r.text
    ev2 = r.json()
    assert ev2["version"] == 2, f"Expected v2, got v{ev2['version']}"
    assert ev2["is_current"] is True

    # ── Step 5: V1 should now be superseded ───────────────────────────────
    r = httpx.get(f"{BASE}/disputes/{dispute_id}/evidence?current_only=false", headers=ah)
    assert r.status_code == 200
    all_ev = r.json()
    v1_row = next((e for e in all_ev if e["evidence_id"] == ev1["evidence_id"]), None)
    assert v1_row is not None
    assert v1_row["is_current"] is False, "V1 must be superseded"
    assert v1_row["superseded_by"] == ev2["evidence_id"]

    # ── Step 6: Recommendation should be STALE ───────────────────────────
    r = httpx.get(f"{BASE}/disputes/{dispute_id}/recommendation", headers=ah)
    if r.status_code == 200:
        rec = r.json()
        assert rec["is_stale"] is True, "Recommendation must be stale after HIGH evidence inject"

    # ── Step 7: Propose a CLASS_C action ─────────────────────────────────
    r = httpx.post(f"{BASE}/disputes/{dispute_id}/actions", json={
        "action_type": "ISSUE_PROVISIONAL_CREDIT",
        "action_class": "CLASS_C",
    }, headers=ah)
    assert r.status_code == 201, r.text
    action = r.json()
    assert action["status"] == "PENDING_APPROVAL"
    action_id = action["action_id"]

    # ── Step 8: Supervisor approves ───────────────────────────────────────
    r = httpx.post(
        f"{BASE}/disputes/{dispute_id}/actions/{action_id}/approve",
        json={"decision": "APPROVED", "reason": "E2E: evidence confirms fraud"},
        headers=sh,
    )
    assert r.status_code == 200, r.text
    approval = r.json()
    assert approval["decision"] == "APPROVED"

    # ── Step 9: Audit trail ───────────────────────────────────────────────
    r = httpx.get(f"{BASE}/disputes/{dispute_id}/audit", headers=ah)
    assert r.status_code == 200
    events = r.json()
    event_types = {e["event_type"] for e in events}

    assert "DISPUTE_CREATED" in event_types
    # Evidence events
    evidence_events = {"EVIDENCE_RECEIVED", "EVIDENCE_CHANGED"}
    assert event_types & evidence_events, f"Expected evidence audit events, got {event_types}"
    assert "ACTION_APPROVED" in event_types

    print(f"\n✓ E2E journey passed. Dispute: {dispute_id}")
    print(f"  Events recorded: {sorted(event_types)}")


def test_rbac_read_only_cannot_ingest(analyst_token: str):
    """read_only role cannot ingest evidence."""
    r = httpx.post(f"{BASE}/auth/token", data={"username": "readonly", "password": "Readonly@123!"})
    if r.status_code != 200:
        pytest.skip("read_only user not seeded")
    ro_token = r.json()["access_token"]

    # Need a dispute to test against
    r = httpx.post(f"{BASE}/disputes", json={
        "dispute_type": "MERCHANDISE_NOT_RECEIVED",
        "cardholder_claim": "RBAC test",
    }, headers=_headers(analyst_token))
    assert r.status_code == 201
    dispute_id = r.json()["dispute_id"]

    r = httpx.post(f"{BASE}/disputes/{dispute_id}/evidence", json={
        "source_type": "MERCHANT",
        "source_system": "X",
        "source_record_id": "X-001",
        "evidence_type": "DELIVERY_CONFIRMATION",
        "normalized_content": {},
        "event_time": "2026-08-01T00:00:00Z",
    }, headers=_headers(ro_token))
    assert r.status_code == 403, f"read_only must not ingest evidence, got {r.status_code}"


def test_duplicate_evidence_deduplication(analyst_token: str):
    """Identical content hash → return existing, no duplicate."""
    ah = _headers(analyst_token)
    r = httpx.post(f"{BASE}/disputes", json={
        "dispute_type": "MERCHANDISE_NOT_RECEIVED",
        "cardholder_claim": "Dedup test",
    }, headers=ah)
    dispute_id = r.json()["dispute_id"]

    payload = {
        "source_type": "ISSUER",
        "source_system": "CoreBanking",
        "source_record_id": "DEDUP-001",
        "evidence_type": "TRANSACTION_RECEIPT",
        "normalized_content": {"amount": 100.00},
        "event_time": "2026-08-01T00:00:00Z",
    }
    r1 = httpx.post(f"{BASE}/disputes/{dispute_id}/evidence", json=payload, headers=ah)
    r2 = httpx.post(f"{BASE}/disputes/{dispute_id}/evidence", json=payload, headers=ah)
    assert r1.status_code == r2.status_code == 201
    assert r1.json()["evidence_id"] == r2.json()["evidence_id"], "Duplicate must return same ID"
