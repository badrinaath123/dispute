# Frontend Deployment Guide

## Overview

- **Framework:** React 18, TypeScript, Vite
- **Served by:** nginx (inside the container)
- **Port:** 80 (mapped to a host port of your choice)
- **API calls:** All `/api/*` requests are proxied by nginx to the backend container — the frontend itself makes no direct LLM or database calls.

---

## How the Frontend Talks to the Backend

```
Browser → http://YOUR-SERVER-IP → nginx (port 80)
                                      │
                    /api/* requests   │ proxy_pass
                                      ▼
                              http://api:8000  (backend container on dispute-net)
```

- The React app uses relative URLs (`/api/v1/...`).
- nginx handles the proxy. See `nginx.conf` for the routing rules.
- The backend container **must be named `api`** and on the same network (`dispute-net`).
  If you rename it, update `proxy_pass` in `nginx.conf` and rebuild this image.

---

## Prerequisites

- Backend container is running and named `api` on `dispute-net`.
- `dispute-net` network exists.

If not, set up the backend first — see `backend/DEPLOY.md`.

---

## Build the Image

Run from the **project root** (`dispute_system/`):

```bash
podman build -t dispute-frontend:latest ./frontend
```

### Optional build argument — VITE_API_URL

By default `VITE_API_URL` is empty, meaning the React app uses relative paths
(`/api/v1/...`) and nginx handles routing. This is the correct setting for
the containerised deployment — **do not set this unless you know you need it**.

```bash
# Only if you need the frontend to call an external API URL directly:
podman build \
  --build-arg VITE_API_URL=https://api.your-domain.com \
  -t dispute-frontend:latest ./frontend
```

---

## Run the Container

```bash
podman run -d \
  --name web \
  --network dispute-net \
  -p 80:80 \
  dispute-frontend:latest
```

The app is now accessible at `http://YOUR-SERVER-IP`.

### Using a different host port (e.g. 3000)

```bash
podman run -d \
  --name web \
  --network dispute-net \
  -p 3000:80 \
  dispute-frontend:latest
```

Access at `http://YOUR-SERVER-IP:3000`.

> If you change the host port, also update `CORS_ORIGINS` in `backend/server.env`
> to match (e.g. `http://YOUR-SERVER-IP:3000`) and restart the backend container.

---

## Logs

```bash
podman logs web          # print all logs
podman logs -f web       # follow live logs
```

nginx logs (access + error) are inside the container at:
- `/var/log/nginx/access.log`
- `/var/log/nginx/error.log`

```bash
podman exec web cat /var/log/nginx/error.log
```

---

## Stop / Remove

```bash
podman stop web
podman rm web
```

---

## Rebuild and Redeploy (after code changes)

```bash
podman stop web && podman rm web
podman build -t dispute-frontend:latest ./frontend
podman run -d \
  --name web \
  --network dispute-net \
  -p 80:80 \
  dispute-frontend:latest
```

The backend does not need to be touched for a frontend-only change.

---

## Auto-Start on Reboot (systemd)

```bash
mkdir -p ~/.config/systemd/user
podman generate systemd --name web --files --new
mv container-web.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now container-web.service
loginctl enable-linger $USER
```

---

## Default Login Credentials

| Role              | Username            | Password              |
|-------------------|---------------------|-----------------------|
| Issuer analyst    | `analyst`           | `Analyst@123!`        |
| Merchant analyst  | `merchant_analyst`  | `MerchantAnalyst@123!`|
| Admin             | `admin`             | `Admin@12345!`        |

> Change these after first login, especially on a production server.

---

## Troubleshooting

| Symptom                          | Likely cause                                      | Fix                                          |
|----------------------------------|---------------------------------------------------|----------------------------------------------|
| Blank page on load               | JS/CSS not built correctly                        | Check `podman logs web` for nginx errors     |
| `502 Bad Gateway` on API calls   | Backend container not running or wrong name       | Run `podman ps` — ensure container is `api` on `dispute-net` |
| Login fails / JWT error          | `JWT_SECRET_KEY` mismatch                         | Ensure `server.env` has consistent secrets   |
| CORS error in browser console    | `CORS_ORIGINS` in `server.env` does not match host port | Update `CORS_ORIGINS` and restart backend |
