import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { useAuthStore } from './store'
import { LoginPage } from '@/features/auth/LoginPage'
import { AppShell } from '@/components/layouts/AppShell'
import { ErrorBoundary } from '@/components/ErrorBoundary'

// Analyst views
import { MyWork } from '@/features/work/MyWork'
import { DisputeListPage } from '@/features/disputes/DisputeListPage'
import { NewCasePage } from '@/features/disputes/NewCasePage'
import { DisputeCommandCenter } from '@/features/disputes/DisputeCommandCenter'
import { EvidenceExplorer } from '@/features/evidence/EvidenceExplorer'
import { TimelineViewer } from '@/features/timeline/TimelineViewer'
import { HypothesisWorkspace } from '@/features/hypotheses/HypothesisWorkspace'
import { ApprovalWorkspace } from '@/features/approvals/ApprovalWorkspace'
import { AuditReplay } from '@/features/audit/AuditReplay'
import { AdminDashboard } from '@/features/admin/AdminDashboard'
import { StatusConfigPage } from '@/features/admin/StatusConfigPage'
import { OutcomeConfigPage } from '@/features/admin/OutcomeConfigPage'
import { RolesConfigPage } from '@/features/admin/RolesConfigPage'
import { EvidenceRequirementsPage } from '@/features/admin/EvidenceRequirementsPage'
import { EvalScoresPage } from '@/features/admin/EvalScoresPage'
import { UsersConfigPage } from '@/features/admin/UsersConfigPage'
import { IntegrationsPage } from '@/features/admin/IntegrationsPage'
import { PlatformImpactPage } from '@/features/admin/PlatformImpactPage'
import { KnowledgeBasePage } from '@/features/admin/KnowledgeBasePage'

// Merchant views
import { MerchantHome } from '@/features/merchant/MerchantHome'
import { MerchantDisputeQueue } from '@/features/merchant/MerchantDisputeQueue'
import { MerchantWorkspace } from '@/features/merchant/MerchantWorkspace'
import { MerchantAlerts } from '@/features/merchant/MerchantAlerts'
import { MerchantInsights } from '@/features/merchant/MerchantInsights'

// Onboarding tour
import { TourProvider, TourOverlay, TourModal } from '@/features/tour'

function RequireAuth({ children }: { children: React.ReactNode }) {
  const token = useAuthStore(s => s.token)
  return token ? <>{children}</> : <Navigate to="/login" replace />
}

function RootRedirect() {
  const user = useAuthStore(s => s.user)
  const isMerchant = user?.roles?.some(r => r.startsWith('merchant_')) ?? false
  const isAdminOnly = !isMerchant && (user?.roles?.includes('admin') ?? false)
  if (isMerchant) return <Navigate to="/merchant" replace />
  if (isAdminOnly) return <Navigate to="/admin" replace />
  return <MyWork />
}

// Wraps only the routed page content (not the sidebar/nav) in an ErrorBoundary, keyed
// by pathname so a caught error's fallback is discarded and the boundary resets fresh
// on every navigation — staying on the broken page keeps the "Try again" fallback,
// navigating elsewhere always renders the new page rather than the stale error screen.
function AppRoutes() {
  const location = useLocation()
  return (
    <ErrorBoundary key={location.pathname}>
      <Routes>
        {/* Root — redirects to merchant home for merchant roles */}
        <Route index element={<RootRedirect />} />

        {/* ── Analyst routes ── */}
        <Route path="disputes" element={<DisputeListPage />} />
        <Route path="disputes/new" element={<NewCasePage />} />
        <Route path="search" element={<DisputeListPage />} />
        <Route path="disputes/:id" element={<DisputeCommandCenter />} />
        <Route path="disputes/:id/evidence" element={<EvidenceExplorer />} />
        <Route path="disputes/:id/timeline" element={<TimelineViewer />} />
        <Route path="disputes/:id/hypotheses" element={<HypothesisWorkspace />} />
        <Route path="disputes/:id/approvals" element={<ApprovalWorkspace />} />
        <Route path="disputes/:id/audit" element={<AuditReplay />} />
        <Route path="admin" element={<AdminDashboard />} />
        <Route path="admin/statuses" element={<StatusConfigPage />} />
        <Route path="admin/outcomes" element={<OutcomeConfigPage />} />
        <Route path="admin/roles" element={<RolesConfigPage />} />
        <Route path="admin/evidence-requirements" element={<EvidenceRequirementsPage />} />
        <Route path="admin/eval-scores" element={<EvalScoresPage />} />
        <Route path="admin/users" element={<UsersConfigPage />} />
        <Route path="admin/integrations" element={<IntegrationsPage />} />
        <Route path="admin/impact" element={<PlatformImpactPage />} />
        <Route path="admin/knowledge" element={<KnowledgeBasePage />} />

        {/* ── Merchant routes ── */}
        <Route path="merchant" element={<MerchantHome />} />
        <Route path="merchant/disputes" element={<MerchantDisputeQueue />} />
        <Route path="merchant/disputes/:id" element={<MerchantWorkspace />} />
        <Route path="merchant/disputes/:id/story" element={<MerchantWorkspace initialTab="story" />} />
        <Route path="merchant/disputes/:id/evidence" element={<MerchantWorkspace initialTab="evidence" />} />
        <Route path="merchant/disputes/:id/response" element={<MerchantWorkspace initialTab="response" />} />
        <Route path="merchant/disputes/:id/timeline" element={<MerchantWorkspace initialTab="timeline" />} />
        <Route path="merchant/alerts" element={<MerchantAlerts />} />
        <Route path="merchant/insights" element={<MerchantInsights />} />
        <Route path="merchant/search" element={<MerchantDisputeQueue />} />
      </Routes>
    </ErrorBoundary>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route
          path="/*"
          element={
            <RequireAuth>
              <TourProvider>
                <AppShell>
                  <AppRoutes />
                </AppShell>
                <TourOverlay />
                <TourModal />
              </TourProvider>
            </RequireAuth>
          }
        />
      </Routes>
    </BrowserRouter>
  )
}
