import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface User {
  user_id: string
  username: string
  email: string
  tenant_id: string
  roles: string[]
  permissions: string[]
  screens: string[]
}

interface AuthState {
  token: string | null
  user: User | null
  theme: 'light' | 'dark'
  setAuth: (token: string, user: User) => void
  clearAuth: () => void
  toggleTheme: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      token: null,
      user: null,
      theme: 'light',
      setAuth: (token, user) => set({ token, user }),
      clearAuth: () => set({ token: null, user: null }),
      toggleTheme: () => {
        const next = get().theme === 'light' ? 'dark' : 'light'
        document.documentElement.classList.toggle('dark', next === 'dark')
        set({ theme: next })
      },
    }),
    { name: 'dispute-auth' }
  )
)

// Apply persisted theme on page load
const stored = JSON.parse(localStorage.getItem('dispute-auth') || '{}')
if (stored?.state?.theme === 'dark') {
  document.documentElement.classList.add('dark')
}
