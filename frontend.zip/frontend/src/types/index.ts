// Nested shape returned only by GET /disputes/{id} (case detail) — the list
// endpoint (GET /disputes) does not include these, so they're optional here.
export interface CardholderInfo {
  customerId: string | null
  name: string | null
  maskedCardNumber: string | null
  authenticationStatus: string | null
  cardTier?: string | null
  phone?: string | null
}

export interface TransactionInfo {
  transactionId: string | null
  merchantName: string | null
  amount: number | null
  currency: string | null
  transactionDate: string | null
  postingDate: string | null
  merchantId: string | null
  merchantCategoryCode: string | null
  transactionChannel: string | null
}

export interface DisputeDetailInfo {
  disputeType: string
  disputeAmount: number | null
  description: string
  returnDate: string | null
  expectedRefundAmount: number | null
  expectedRefundDate: string | null
  merchantContacted: boolean | null
  merchantContactDate: string | null
  merchantResponse: string | null
  refundReferenceNumber: string | null
}

export interface EvidenceDocumentInfo {
  evidenceId: string
  documentId: string
  documentType: string
  fileName: string
}

export interface Dispute {
  dispute_id: string
  tenant_id: string
  status: string
  dispute_type: string
  lifecycle_stage: string
  priority: string
  current_state_version: number
  cardholder_claim: string
  transaction_reference: string | null
  deadline: string | null
  created_at: string
  updated_at: string
  metadata: Record<string, unknown>
  claim_id?: string | null
  // Deterministic 0-100 triage score (packages/intelligence/priority_scoring.py)
  // — computed fresh on every read, present on both list and detail responses.
  priority_score: number
  days_remaining: number | null
  is_archived: boolean
  // Case-detail-only fields (present on GET /disputes/{id}, absent on list items)
  caseId?: string
  cardholder?: CardholderInfo
  transaction?: TransactionInfo
  dispute?: DisputeDetailInfo
  evidence?: EvidenceDocumentInfo[]
}

// A claim is one cardholder intake that may span multiple transactions —
// each transaction is its own Dispute sub-case (own merchant, own
// investigation), linked back here via Dispute.claim_id.
export interface ClaimSubCase {
  dispute_id: string
  claim_sequence: number | null
  dispute_type: string
  transaction_reference: string | null
  status: string
  metadata: Record<string, unknown>
}

export interface Claim {
  claim_id: string
  tenant_id: string
  cardholder_claim: string
  status: 'IN_PROGRESS' | 'RESOLVED'
  created_at: string
  sub_cases: ClaimSubCase[]
}

// Platform impact — every field here is computed live from real data (README §19).
export interface PlatformImpact {
  generated_at: string
  tenant_id: string
  stale_approvals_prevented: {
    count: number
    entries: { dispute_id: string; action_id: string | null; approval_id: string; state_version_reviewed: number; stale_reason: string | null }[]
    note: string | null
  }
  recommendations_that_flipped: {
    count: number
    entries: { dispute_id: string; recommendation_id: string; version: number; recommendation_type: string; previous_recommendation_id: string | null; change_reason: string | null }[]
    note: string | null
  }
  mean_time_to_recommendation: {
    sample_size: number
    mean_seconds: number | null
    mean_human: string | null
    note: string
  }
  evidence_gaps_auto_identified: {
    gaps_identified_total: number
    gaps_open: number
    evidence_items_total: number
    note: string
  }
  multi_transaction_claims_processed: {
    claims_with_multiple_sub_cases: number
    total_sub_cases_across_them: number
    entries: { claim_id: string; sub_case_count: number; dispute_ids: string[] }[]
    note: string | null
  }
  case_intake_time: {
    ai_assisted: { sample_size: number; mean_seconds: number | null; mean_human: string | null }
    manual: { sample_size: number; mean_seconds: number | null; mean_human: string | null }
    sample_data_excluded_count: number
    note: string
  }
  ai_quality: {
    enabled: boolean
    by_metric: Record<string, { sample_size: number; mean_score: number | null; pass_rate: number | null }>
    note: string
  }
  ai_spend: {
    total_cost_usd: number
    total_calls: number
    total_input_tokens: number
    total_output_tokens: number
    by_model: {
      model: string; call_count: number; input_tokens: number; output_tokens: number
      cost_usd: number; priced: boolean
    }[]
    note: string
  }
}

// One live DeepEval judge score (README §30) — GET /platform/eval-scores.
export interface EvalScoreEntry {
  eval_id: string
  case_id: string | null
  feature: string
  metric: string
  score: number | null
  passed: boolean | null
  reason: string | null
  input_text: string | null
  created_at: string
}

// Similar past cases — computed live from the precedent vector collection, written
// whenever the agent produces a recommendation for any case (README §21).
export interface PrecedentEntry {
  dispute_id: string
  dispute_type: string
  recommendation_type: string
  confidence_score: number | null
  outcome: string | null
  similarity: number
}

export interface Precedents {
  dispute_id: string
  entries: PrecedentEntry[]
  note: string | null
}

export interface Evidence {
  evidence_id: string
  case_id: string
  source_type: string
  source_system: string
  source_record_id: string
  evidence_type: string
  version: number
  normalized_content: Record<string, unknown>
  event_time: string
  received_time: string
  materiality: 'HIGH' | 'MEDIUM' | 'LOW' | 'UNKNOWN'
  quality: string
  is_current: boolean
  previous_version_id: string | null
  superseded_by: string | null
  content_hash: string
  created_at: string
}

export interface Hypothesis {
  hypothesis_id: string
  case_id: string
  description: string        // backend field name
  status: string
  confidence_score: number
  confidence_descriptor: string
  supporting_evidence_ids: string[]
  weakening_evidence_ids: string[]   // backend field name
  unresolved_questions: string[]
  created_at: string
}

export interface Contradiction {
  contradiction_id: string
  case_id: string
  description: string
  evidence_a_id: string
  evidence_b_id: string
  conflict_type: string    // backend field name
  materiality: string
  status: string
  created_at: string
}

export interface Recommendation {
  recommendation_id: string
  case_id: string
  version: number
  content: string
  recommendation_type: string
  confidence_score: number
  confidence_descriptor: string
  uncertainty_statement: string
  is_current: boolean
  is_stale: boolean
  stale_reason: string | null
  change_reason: string | null
  previous_recommendation_id: string | null
  created_at: string
}

export interface Action {
  action_id: string
  case_id: string
  action_type: string
  action_class: string
  status: string
  requested_by: string
  proposed_by: string | null
  approval_requirement: string | null
  idempotency_key: string
  input: Record<string, unknown>
  result: Record<string, unknown> | null
  error: string | null
  retry_count: number
  created_at: string
  approved_at: string | null
  completed_at: string | null
}

export interface AuditEvent {
  audit_id: string           // backend field name
  case_id: string | null
  event_type: string
  actor_id: string
  actor_type: string
  previous_state_version: number | null
  new_state_version: number | null
  evidence_refs: string[]
  node_name: string | null
  tool_used: string | null
  decision: string | null
  metadata: Record<string, unknown>
  timestamp: string          // backend field name
}

export interface AgentNode {
  node: string
  step: number
  status: 'pending' | 'running' | 'complete' | 'failed'
  started_at?: number
  ended_at?: number
}

export interface EvidenceGap {
  gap_id: string
  case_id: string
  gap_type: string
  description: string | null
  materiality: string | null
  expected_source: string | null
  expected_evidence_type: string | null
  status: string
  created_at: string
}

export interface TimelineEvent {
  event_id: string
  case_id: string
  event_type: string
  event_time: string
  recorded_time: string
  actor: string | null
  description: string | null
  is_disputed: boolean
  confidence: number
}

// ── Admin config types ────────────────────────────────────────────────────────

export type StatusColor = 'neutral' | 'info' | 'warning' | 'success' | 'error' | 'brand'

export interface StatusConfig {
  status_id: string
  code: string
  display_name: string
  description: string
  category: 'WORKFLOW' | 'TERMINAL'
  sort_order: number
  is_active: boolean
  color: StatusColor
  is_initial: boolean
  is_terminal: boolean
  created_at: string
  updated_at: string
  created_by: string | null
}

export interface OutcomeConfig {
  outcome_id: string
  code: string
  display_name: string
  description: string
  sort_order: number
  is_active: boolean
  color: StatusColor
  created_at: string
  updated_at: string
  created_by: string | null
}

export interface EvidenceRequirement {
  requirement_id: string
  dispute_type: string
  evidence_type: string
  description: string
  is_required: boolean
  sort_order: number
  is_active: boolean
  created_at: string
  updated_at: string
  created_by: string | null
}

export interface RoleConfig {
  role_id: string
  code: string
  display_name: string
  description: string
  is_active: boolean
  permissions: string[]
  allowed_screens: string[]
  created_at: string
  updated_at: string
  created_by: string | null
}

export interface AdminSummary {
  statuses: { total: number; active: number }
  outcomes: { total: number; active: number }
  roles:    { total: number; active: number }
  users:    { total: number; active: number }
}

export interface PermissionCategory {
  category: string
  permissions: string[]
}
