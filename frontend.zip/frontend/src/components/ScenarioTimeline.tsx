import { PlayCircle, CheckCircle2, AlertTriangle, Zap, ThumbsUp, ThumbsDown } from 'lucide-react'
import { format } from 'date-fns'
import type { Dispute, Evidence, Contradiction } from '@/types'
import { evidenceLabel } from '@/lib/evidenceLabel'

// The "Digital Twin" scenario reconstruction — a single narrative timeline of what
// actually happened in a dispute, built entirely from data this platform already has
// (no new data source, no manual seeding): the case's own lifecycle milestones, every
// piece of evidence at its real business-event time (README §36 — event_time now
// reflects what a document actually says, not when it was uploaded), and contradictions
// placed at the moment they became apparent. Shown identically on both the issuer's
// case workspace and the merchant's, built from a shared component so the two personas
// are always looking at the same reconstructed story, not two versions that can drift.

function titleCase(s: string): string {
  return s.replace(/_/g, ' ').replace(/\w\S*/g, (w) => w[0].toUpperCase() + w.slice(1).toLowerCase())
}

const SOURCE_COLOR: Record<string, string> = {
  ISSUER: '#0078d4',
  MERCHANT: '#107c10',
  CARDHOLDER: '#5c2d91',
  DELIVERY_CARRIER: '#ca5010',
  AUTHENTICATION_SYSTEM: '#2b88d8',
  NETWORK: '#767676',
  DOCUMENT: '#767676',
}

// A one-line, human label per evidence type — falls back to a title-cased version of
// the type itself for anything not in this list, so a new evidence type never breaks.
const EVIDENCE_LABEL: Record<string, string> = {
  TRANSACTION_RECEIPT: 'Transaction occurred',
  AUTHENTICATION_LOG: 'Authentication recorded',
  ORDER_INVOICE: 'Order placed',
  SHIPPING_TRACKING: 'Shipment tracked',
  RETURN_CONFIRMATION: 'Return confirmed',
  REFUND_CONFIRMATION: 'Refund confirmed',
  CANCELLATION_CONFIRMATION: 'Cancellation confirmed',
  SUBSCRIPTION_AGREEMENT: 'Subscription agreement on file',
  MERCHANT_COMMUNICATION: 'Merchant responded',
  CARDHOLDER_LETTER: 'Cardholder statement received',
  CHARGEBACK_REBUTTAL: 'Merchant filed a rebuttal',
  MERCHANT_SHIPPING_EVIDENCE: 'Shipping evidence filed',
}

export interface ScenarioEvent {
  id: string
  time: string
  kind: 'milestone' | 'evidence' | 'contradiction'
  title: string
  detail?: string
  badge?: string
  color: string
  icon: typeof CheckCircle2
}

export function buildScenarioEvents(
  dispute: Dispute, evidence: Evidence[], contradictions: Contradiction[]
): ScenarioEvent[] {
  const events: ScenarioEvent[] = []
  const meta = (dispute.metadata ?? {}) as Record<string, unknown>

  events.push({
    id: 'created',
    time: dispute.created_at,
    kind: 'milestone',
    title: 'Case opened',
    detail: `${titleCase(dispute.dispute_type)} reported by the cardholder.`,
    color: '#0078d4',
    icon: PlayCircle,
  })

  for (const ev of evidence) {
    const summary = (ev.normalized_content?.textSummary as string) || undefined
    const docTitle = (ev.normalized_content?.documentTitle as string) || undefined
    events.push({
      id: ev.evidence_id,
      time: ev.event_time,
      kind: 'evidence',
      title: EVIDENCE_LABEL[ev.evidence_type] ?? evidenceLabel(ev.evidence_type, summary, docTitle),
      detail: summary,
      badge: ev.source_type,
      color: SOURCE_COLOR[ev.source_type] ?? '#767676',
      icon: CheckCircle2,
    })
  }

  // A contradiction is placed at the later of its two evidence items' event
  // times — that's the actual moment the conflict became visible, not when
  // the detection algorithm happened to run (created_at).
  const evidenceById = new Map(evidence.map((e) => [e.evidence_id, e]))
  for (const c of contradictions) {
    const times = [c.evidence_a_id, c.evidence_b_id]
      .map((eid) => evidenceById.get(eid)?.event_time)
      .filter((t): t is string => !!t)
    const time = times.length > 0 ? times.sort().slice(-1)[0] : c.created_at
    events.push({
      id: c.contradiction_id,
      time,
      kind: 'contradiction',
      title: 'Contradiction detected',
      detail: c.description,
      color: '#d13438',
      icon: AlertTriangle,
    })
  }

  if (meta.chargeback_issued_at) {
    events.push({
      id: 'chargeback',
      time: meta.chargeback_issued_at as string,
      kind: 'milestone',
      title: 'Chargeback issued to merchant',
      color: '#c50f1f',
      icon: Zap,
    })
  }

  if (dispute.status === 'APPROVED') {
    events.push({
      id: 'resolved',
      time: dispute.updated_at,
      kind: 'milestone',
      title: 'Merchant accepted the chargeback',
      detail: "Case resolved in the cardholder's favor.",
      color: '#107c10',
      icon: ThumbsDown,
    })
  } else if (dispute.status === 'REPRESENTMENT') {
    events.push({
      id: 'representment',
      time: dispute.updated_at,
      kind: 'milestone',
      title: 'Merchant submitted a representment',
      detail: 'The merchant is contesting this chargeback.',
      color: '#5c2d91',
      icon: ThumbsUp,
    })
  }

  return events.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime())
}

export function ScenarioTimeline({ dispute, evidence, contradictions }: {
  dispute: Dispute; evidence: Evidence[]; contradictions: Contradiction[]
}) {
  const events = buildScenarioEvents(dispute, evidence, contradictions)

  if (events.length <= 1) {
    return (
      <p className="text-sm" style={{ color: 'var(--color-text-muted)' }}>
        Only the case-opened event so far — upload evidence to build out the scenario.
      </p>
    )
  }

  return (
    <div className="relative">
      <div className="absolute left-5 top-1 bottom-1 w-px" style={{ background: 'var(--color-border)' }} />
      <div className="space-y-4">
        {events.map((e) => {
          const Icon = e.icon
          return (
            <div key={e.id} className="flex gap-3 items-start relative">
              <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0 z-10"
                style={{ background: `${e.color}18`, border: `2px solid ${e.color}` }}>
                <Icon size={14} style={{ color: e.color }} />
              </div>
              <div className="flex-1 min-w-0 pt-1.5">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>
                    {e.title}
                  </span>
                  {e.badge && (
                    <span className="text-2xs px-1.5 py-0.5 rounded" style={{ background: `${e.color}15`, color: e.color }}>
                      {e.badge}
                    </span>
                  )}
                  <span className="text-2xs ml-auto shrink-0" style={{ color: 'var(--color-text-subtle)' }}>
                    {format(new Date(e.time), 'd MMM yyyy')}
                  </span>
                </div>
                {e.detail && (
                  <p className="text-xs mt-0.5" style={{ color: 'var(--color-text-muted)' }}>{e.detail}</p>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
