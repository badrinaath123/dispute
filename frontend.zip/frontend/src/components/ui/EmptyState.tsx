import type { ReactNode } from 'react'

interface EmptyStateProps {
  icon: ReactNode
  title: string
  description?: string
  action?: ReactNode
}

/** Standard "nothing here" placeholder used across list/detail views. */
export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div
      className="rounded-fluent-lg border p-10 text-center"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
    >
      <div className="mx-auto mb-3 opacity-40" style={{ color: 'var(--color-text-subtle)' }}>
        {icon}
      </div>
      <p className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>{title}</p>
      {description && (
        <p className="text-xs mt-1 max-w-sm mx-auto" style={{ color: 'var(--color-text-muted)' }}>
          {description}
        </p>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}
