import { useState, type ReactNode } from 'react'

interface TooltipProps {
  label: string
  children: ReactNode
  side?: 'right' | 'top'
  disabled?: boolean
}

/** Minimal hover tooltip — no portal, positioned relative to its wrapper. */
export function Tooltip({ label, children, side = 'right', disabled = false }: TooltipProps) {
  const [show, setShow] = useState(false)

  if (disabled) return <>{children}</>

  return (
    <div
      className="relative inline-flex w-full"
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
      onFocus={() => setShow(true)}
      onBlur={() => setShow(false)}
    >
      {children}
      {show && (
        <div
          role="tooltip"
          className={
            side === 'right'
              ? 'absolute left-full top-1/2 -translate-y-1/2 ml-2 z-50 whitespace-nowrap px-2 py-1 rounded-fluent text-2xs font-medium shadow-fluent animate-fade-in'
              : 'absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-50 whitespace-nowrap px-2 py-1 rounded-fluent text-2xs font-medium shadow-fluent animate-fade-in'
          }
          style={{ background: 'var(--color-text)', color: 'var(--color-bg)' }}
        >
          {label}
        </div>
      )}
    </div>
  )
}
