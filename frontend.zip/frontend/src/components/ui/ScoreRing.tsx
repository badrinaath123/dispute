interface ScoreRingProps {
  /** 0-100 — same deterministic priority score shown as a number everywhere else. */
  value: number
  size?: number
  /** Track/arc color — pass the same semantic color already used for the number. */
  color?: string
  trackColor?: string
}

/**
 * Compact circular progress ring around a priority score — table-row-sized (default
 * 28px), same score/color semantics as the plain number badge it replaces, just a
 * more legible-at-a-glance visual than a flat pill.
 */
export function ScoreRing({ value, size = 28, color = 'var(--color-brand)', trackColor }: ScoreRingProps) {
  const stroke = 3
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  const pct = Math.max(0, Math.min(100, value))
  const offset = c - (pct / 100) * c

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0" style={{ transform: 'rotate(-90deg)' }}>
      <circle
        cx={size / 2} cy={size / 2} r={r}
        fill="none" strokeWidth={stroke}
        stroke={trackColor ?? 'var(--color-border)'}
      />
      <circle
        cx={size / 2} cy={size / 2} r={r}
        fill="none" strokeWidth={stroke} strokeLinecap="round"
        stroke={color}
        strokeDasharray={c}
        strokeDashoffset={offset}
        style={{ transition: 'stroke-dashoffset 0.6s cubic-bezier(0.16, 1, 0.3, 1)' }}
      />
    </svg>
  )
}
