import type { HTMLAttributes } from 'react'
import clsx from 'clsx'

export type BadgeVariant = 'success' | 'warning' | 'error' | 'info' | 'neutral' | 'brand'

const VARIANT_STYLE: Record<BadgeVariant, { bg: string; color: string; border: string }> = {
  success: { bg: 'rgba(16,124,16,0.1)', color: 'var(--color-success)', border: 'rgba(16,124,16,0.25)' },
  warning: { bg: 'rgba(202,80,16,0.1)', color: 'var(--color-medium)', border: 'rgba(202,80,16,0.25)' },
  error:   { bg: 'rgba(197,15,31,0.1)', color: 'var(--color-critical)', border: 'rgba(197,15,31,0.25)' },
  info:    { bg: 'rgba(79,70,229,0.1)', color: 'var(--color-info)', border: 'rgba(79,70,229,0.25)' },
  neutral: { bg: 'var(--color-surface-r)', color: 'var(--color-text-muted)', border: 'var(--color-border)' },
  brand:   { bg: 'var(--color-brand-light)', color: 'var(--color-brand)', border: 'transparent' },
}

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant
}

/** Small status pill — consistent size/radius across the app; color follows the semantic token map. */
export function Badge({ variant = 'neutral', className, style, children, ...rest }: BadgeProps) {
  const v = VARIANT_STYLE[variant]
  return (
    <span
      className={clsx('inline-flex items-center gap-1 text-2xs font-medium px-1.5 py-0.5 rounded-fluent border', className)}
      style={{ background: v.bg, color: v.color, borderColor: v.border, ...style }}
      {...rest}
    >
      {children}
    </span>
  )
}
