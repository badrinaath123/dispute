import { forwardRef, type ButtonHTMLAttributes } from 'react'
import { Loader2 } from 'lucide-react'
import clsx from 'clsx'

export type ButtonVariant = 'primary' | 'secondary' | 'destructive' | 'ghost'
export type ButtonSize = 'sm' | 'md'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant
  size?: ButtonSize
  loading?: boolean
}

const VARIANT_CLASS: Record<ButtonVariant, string> = {
  primary: 'text-white bg-grad-brand shadow-glow-brand hover:brightness-110 active:scale-[0.97] border border-transparent disabled:opacity-50 disabled:shadow-none',
  secondary: 'border hover:bg-neutral-50 dark:hover:bg-neutral-800 active:scale-[0.97] active:bg-neutral-100 dark:active:bg-neutral-700',
  destructive: 'text-white bg-[color:var(--color-critical)] hover:opacity-90 active:scale-[0.97] border border-transparent',
  ghost: 'border border-transparent hover:bg-neutral-100 dark:hover:bg-neutral-800 active:scale-[0.97]',
}

const SIZE_CLASS: Record<ButtonSize, string> = {
  sm: 'h-7 px-2.5 text-xs gap-1.5',
  md: 'h-9 px-3.5 text-sm gap-2',
}

/**
 * Standard button primitive — variant/size/loading only. Every native button
 * prop (onClick, type, form, etc.) passes straight through unchanged.
 */
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'secondary', size = 'md', loading = false, disabled, className, children, style, ...rest },
  ref
) {
  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={clsx(
        'inline-flex items-center justify-center rounded-fluent font-medium whitespace-nowrap transition-colors',
        'disabled:opacity-60 disabled:cursor-not-allowed',
        VARIANT_CLASS[variant],
        SIZE_CLASS[size],
        className
      )}
      style={
        variant === 'secondary'
          ? { background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-text)', ...style }
          : style
      }
      {...rest}
    >
      {loading && <Loader2 size={size === 'sm' ? 12 : 14} className="animate-spin" />}
      {children}
    </button>
  )
})
