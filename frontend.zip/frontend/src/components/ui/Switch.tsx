interface SwitchProps {
  checked: boolean
  onChange: (checked: boolean) => void
  label?: string
  id?: string
}

/** Standard on/off toggle switch — reuses the brand token for the "on" state. */
export function Switch({ checked, onChange, label, id }: SwitchProps) {
  return (
    <label htmlFor={id} className="flex items-center justify-between gap-3 cursor-pointer select-none">
      {label && <span className="text-sm" style={{ color: 'var(--color-text)' }}>{label}</span>}
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className="relative inline-flex h-5 w-9 shrink-0 items-center rounded-full transition-colors"
        style={{ background: checked ? 'var(--color-brand)' : 'var(--color-border-strong)' }}
      >
        <span
          className="inline-block h-3.5 w-3.5 transform rounded-full bg-white transition-transform"
          style={{ transform: checked ? 'translateX(19px)' : 'translateX(3px)' }}
        />
      </button>
    </label>
  )
}
