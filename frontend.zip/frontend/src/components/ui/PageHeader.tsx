import type { ReactNode } from 'react'

interface PageHeaderProps {
  icon?: ReactNode
  title: string
  description?: string
  actions?: ReactNode
}

/** Standard title + description + actions row used at the top of every page. */
export function PageHeader({ icon, title, description, actions }: PageHeaderProps) {
  return (
    <div className="flex items-start justify-between gap-4 mb-6 animate-fade-in-up">
      <div className="flex items-center gap-3 min-w-0">
        {icon && (
          <div
            className="w-9 h-9 rounded-fluent-md flex items-center justify-center shrink-0 bg-grad-brand shadow-glow-brand"
            style={{ color: '#fff' }}
          >
            {icon}
          </div>
        )}
        <div className="min-w-0">
          <h1 className="font-display text-xl font-semibold truncate tracking-tight" style={{ color: 'var(--color-text)' }}>
            {title}
          </h1>
          {description && (
            <p className="text-sm mt-0.5" style={{ color: 'var(--color-text-muted)' }}>
              {description}
            </p>
          )}
        </div>
      </div>
      {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
    </div>
  )
}
