import clsx from 'clsx'

/** Loading placeholder block — pair with Tailwind width/height utility classes. */
export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={clsx('animate-pulse rounded-fluent', className)}
      style={{ background: 'var(--color-surface-r)' }}
    />
  )
}
