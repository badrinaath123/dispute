import { forwardRef, type InputHTMLAttributes, type SelectHTMLAttributes, type TextareaHTMLAttributes, type ReactNode } from 'react'
import clsx from 'clsx'

const FIELD_BASE =
  'w-full text-sm px-3 rounded-fluent border outline-none transition-colors ' +
  'focus:border-[color:var(--color-brand)] disabled:opacity-60 disabled:cursor-not-allowed'

const fieldStyle = (error?: boolean) => ({
  background: 'var(--color-surface-r)',
  borderColor: error ? 'var(--color-critical)' : 'var(--color-border-strong)',
  color: 'var(--color-text)',
})

interface FieldWrapperProps {
  label?: string
  required?: boolean
  error?: string
  helperText?: string
  children: ReactNode
}

/** Shared label / error / helper-text chrome for form fields. */
export function Field({ label, required, error, helperText, children }: FieldWrapperProps) {
  return (
    <div>
      {label && (
        <label className="block text-xs font-medium mb-1.5" style={{ color: 'var(--color-text)' }}>
          {label}
          {required && <span className="ml-0.5" style={{ color: 'var(--color-critical)' }}>*</span>}
        </label>
      )}
      {children}
      {error ? (
        <p className="text-2xs mt-1" style={{ color: 'var(--color-critical)' }}>{error}</p>
      ) : helperText ? (
        <p className="text-2xs mt-1" style={{ color: 'var(--color-text-subtle)' }}>{helperText}</p>
      ) : null}
    </div>
  )
}

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  error?: boolean
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input({ className, error, style, ...rest }, ref) {
  return (
    <input
      ref={ref}
      className={clsx(FIELD_BASE, 'h-9', className)}
      style={{ ...fieldStyle(error), ...style }}
      {...rest}
    />
  )
})

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  error?: boolean
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea({ className, error, style, ...rest }, ref) {
  return (
    <textarea
      ref={ref}
      className={clsx(FIELD_BASE, 'py-2 resize-none', className)}
      style={{ ...fieldStyle(error), ...style }}
      {...rest}
    />
  )
})

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  error?: boolean
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(function Select({ className, error, style, children, ...rest }, ref) {
  return (
    <select
      ref={ref}
      className={clsx(FIELD_BASE, 'h-9 cursor-pointer', className)}
      style={{ ...fieldStyle(error), ...style }}
      {...rest}
    >
      {children}
    </select>
  )
})
