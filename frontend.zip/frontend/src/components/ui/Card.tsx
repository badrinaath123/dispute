import type { HTMLAttributes } from 'react'
import clsx from 'clsx'

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  padding?: 'none' | 'sm' | 'md'
  shadow?: boolean
  /** Hover lift + shadow — for clickable/navigable cards (list rows, stat tiles). */
  interactive?: boolean
  /** Thin brand-gradient top border — for hero/summary cards that should stand out. */
  accent?: boolean
}

/** Standard bordered surface — subtle border, soft shadow, consistent padding. */
export function Card({
  padding = 'md', shadow = true, interactive = false, accent = false,
  className, style, children, ...rest
}: CardProps) {
  const paddingClass = padding === 'none' ? '' : padding === 'sm' ? 'p-3' : 'p-4'
  return (
    <div
      className={clsx(
        'relative rounded-fluent-lg border transition-all duration-200',
        shadow && 'shadow-fluent-sm',
        interactive && 'hover:shadow-fluent hover:-translate-y-0.5 cursor-pointer',
        accent && 'border-t-2 overflow-hidden',
        paddingClass,
        className
      )}
      style={{
        background: 'var(--color-surface)',
        borderColor: 'var(--color-border)',
        ...(accent ? { borderTopColor: 'transparent', backgroundImage: 'linear-gradient(var(--color-surface), var(--color-surface)), var(--gradient-brand)', backgroundOrigin: 'border-box', backgroundClip: 'padding-box, border-box' } : {}),
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  )
}

export function CardHeader({ className, style, children, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={clsx('px-4 py-3 border-b', className)}
      style={{ borderColor: 'var(--color-border)', ...style }}
      {...rest}
    >
      {children}
    </div>
  )
}

export function CardTitle({ className, style, children, ...rest }: HTMLAttributes<HTMLHeadingElement>) {
  return (
    <h3 className={clsx('text-sm font-semibold', className)} style={{ color: 'var(--color-text)', ...style }} {...rest}>
      {children}
    </h3>
  )
}
