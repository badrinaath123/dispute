interface EvidenceBalanceBarProps {
  supporting: number
  contradicting: number
}

/**
 * One-glance "which way does the evidence lean" bar — replaces reading a paragraph to
 * find out. Green segment = supporting evidence, red = contradicting, proportional to
 * count; a neutral gray bar when there's no evidence on either side yet.
 */
export function EvidenceBalanceBar({ supporting, contradicting }: EvidenceBalanceBarProps) {
  const total = supporting + contradicting
  const supportPct = total === 0 ? 50 : (supporting / total) * 100

  return (
    <div>
      <div className="flex items-center justify-between text-2xs mb-1" style={{ color: 'var(--color-text-muted)' }}>
        <span>{supporting} for</span>
        <span>{contradicting} against</span>
      </div>
      <div className="h-2 rounded-full overflow-hidden flex" style={{ background: 'var(--color-border)' }}>
        {total === 0 ? (
          <div className="h-full w-full" style={{ background: 'var(--color-border-strong)' }} />
        ) : (
          <>
            <div className="h-full transition-all duration-500" style={{ width: `${supportPct}%`, background: 'var(--color-success)' }} />
            <div className="h-full transition-all duration-500" style={{ width: `${100 - supportPct}%`, background: 'var(--color-critical)' }} />
          </>
        )}
      </div>
    </div>
  )
}
