import { XCircle, FileSearch } from 'lucide-react'
import type { DocPreview } from '@/hooks/useDocumentPreview'

/** `pendingName` is set the instant a document is requested, before the file itself
 * has arrived — the modal opens right away with a scanning-style loading state
 * instead of staying invisible until the whole blob is in, which read as "nothing is
 * happening" for a larger file. */
export function DocumentPreviewModal({ preview, pendingName, onClose }: {
  preview: DocPreview | null; pendingName?: string | null; onClose: () => void
}) {
  if (!preview && !pendingName) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.5)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="w-full max-w-3xl h-[85vh] rounded-fluent-lg shadow-xl overflow-hidden flex flex-col"
        style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}>
        <div className="flex items-center justify-between px-4 py-3 border-b shrink-0"
          style={{ borderColor: 'var(--color-border)' }}>
          <span className="text-sm font-medium truncate" style={{ color: 'var(--color-text)' }}>
            {preview?.name ?? pendingName}
          </span>
          <button onClick={onClose} className="shrink-0 ml-3">
            <XCircle size={18} style={{ color: 'var(--color-text-muted)' }} />
          </button>
        </div>
        <div className="flex-1 overflow-auto relative" style={{ background: 'var(--color-bg)' }}>
          {!preview ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
              <div className="relative w-14 h-14 rounded-fluent-lg flex items-center justify-center overflow-hidden bg-grad-brand-soft">
                <div className="absolute left-0 right-0 h-0.5 animate-scanline bg-grad-brand shadow-glow-brand" aria-hidden="true" />
                <FileSearch size={22} style={{ color: 'var(--color-brand)' }} />
              </div>
              <span className="text-sm" style={{ color: 'var(--color-text-muted)' }}>Loading document…</span>
            </div>
          ) : preview.mime.startsWith('image/') ? (
            <img src={preview.url} alt={preview.name} className="max-w-full mx-auto" />
          ) : (
            <iframe src={preview.url} title={preview.name} className="w-full h-full border-0" />
          )}
        </div>
      </div>
    </div>
  )
}
