import { Component, type ErrorInfo, type ReactNode } from 'react'
import { AlertTriangle } from 'lucide-react'
import { Button } from '@/components/ui'

interface Props { children: ReactNode }
interface State { error: Error | null }

/**
 * Wraps the routed page content (not the sidebar/nav) so a bug on one screen shows a
 * recoverable fallback instead of an uncaught error unmounting the entire SPA to a
 * blank page — which is exactly what happened before this existed (an unguarded
 * refetchInterval callback threw on every render of one admin page and took down
 * navigation everywhere until a hard refresh).
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null }

  static getDerivedStateFromError(error: Error): State {
    return { error }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('Unhandled error in page content:', error, info.componentStack)
  }

  render() {
    if (this.state.error) {
      return (
        <div className="p-10 max-w-lg mx-auto text-center">
          <div className="w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center"
            style={{ background: 'rgba(197,15,31,0.1)' }}>
            <AlertTriangle size={22} style={{ color: 'var(--color-critical)' }} />
          </div>
          <h2 className="text-base font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
            Something went wrong on this page
          </h2>
          <p className="text-sm mb-4" style={{ color: 'var(--color-text-muted)' }}>
            {this.state.error.message || 'An unexpected error occurred.'}
          </p>
          <Button variant="primary" onClick={() => this.setState({ error: null })}>
            Try again
          </Button>
        </div>
      )
    }
    return this.props.children
  }
}
