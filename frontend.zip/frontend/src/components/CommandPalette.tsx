import { useEffect, useMemo, useRef, useState } from 'react'
import { Search, CornerDownLeft, ArrowUp, ArrowDown } from 'lucide-react'

export interface CommandItem {
  id: string
  label: string
  group: string
  icon: React.ElementType
  action: () => void
  keywords?: string
}

/**
 * Cmd/Ctrl+K quick-navigation overlay — fuzzy-filters every reachable screen and
 * quick action into one searchable list, arrow keys + Enter to jump straight there.
 * The signature "this is a serious product" cue in Linear/Raycast/Notion-class tools;
 * functionally real (actually navigates), not decorative chrome.
 */
export function CommandPalette({ items, open, onClose }: { items: CommandItem[]; open: boolean; onClose: () => void }) {
  const [query, setQuery] = useState('')
  const [activeIndex, setActiveIndex] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return items
    return items.filter((i) =>
      i.label.toLowerCase().includes(q) ||
      i.group.toLowerCase().includes(q) ||
      i.keywords?.toLowerCase().includes(q)
    )
  }, [items, query])

  useEffect(() => {
    if (open) {
      setQuery('')
      setActiveIndex(0)
      setTimeout(() => inputRef.current?.focus(), 10)
    }
  }, [open])

  useEffect(() => { setActiveIndex(0) }, [query])

  useEffect(() => {
    if (!open) return
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') { onClose(); return }
      if (e.key === 'ArrowDown') { e.preventDefault(); setActiveIndex((i) => Math.min(i + 1, filtered.length - 1)) }
      if (e.key === 'ArrowUp') { e.preventDefault(); setActiveIndex((i) => Math.max(i - 1, 0)) }
      if (e.key === 'Enter') {
        e.preventDefault()
        const item = filtered[activeIndex]
        if (item) { item.action(); onClose() }
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [open, filtered, activeIndex, onClose])

  if (!open) return null

  let lastGroup = ''

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-[12vh] px-4"
      style={{ background: 'rgba(0,0,0,0.55)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="w-full max-w-lg rounded-fluent-xl shadow-fluent-xl overflow-hidden glass animate-fade-in-up"
        style={{ borderColor: 'var(--color-border)' }}>
        <div className="flex items-center gap-3 px-4 h-12 border-b" style={{ borderColor: 'var(--color-border)' }}>
          <Search size={16} style={{ color: 'var(--color-text-muted)' }} />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Jump to a screen or action…"
            className="flex-1 bg-transparent outline-none text-sm"
            style={{ color: 'var(--color-text)' }}
          />
          <kbd className="text-2xs px-1.5 py-0.5 rounded font-mono" style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-subtle)' }}>
            esc
          </kbd>
        </div>

        <div className="max-h-[50vh] overflow-y-auto py-2">
          {filtered.length === 0 && (
            <p className="text-xs text-center py-6" style={{ color: 'var(--color-text-subtle)' }}>No matches</p>
          )}
          {filtered.map((item, i) => {
            const showGroup = item.group !== lastGroup
            lastGroup = item.group
            const Icon = item.icon
            return (
              <div key={item.id}>
                {showGroup && (
                  <div className="px-4 pt-2 pb-1 text-2xs font-semibold uppercase tracking-wider"
                    style={{ color: 'var(--color-text-subtle)' }}>
                    {item.group}
                  </div>
                )}
                <button
                  onClick={() => { item.action(); onClose() }}
                  onMouseEnter={() => setActiveIndex(i)}
                  className="w-full flex items-center gap-3 px-4 py-2 text-left transition-colors"
                  style={{ background: i === activeIndex ? 'var(--color-brand-light)' : 'transparent' }}
                >
                  <Icon size={14} style={{ color: i === activeIndex ? 'var(--color-brand)' : 'var(--color-text-muted)' }} />
                  <span className="text-sm flex-1" style={{ color: i === activeIndex ? 'var(--color-brand)' : 'var(--color-text)' }}>
                    {item.label}
                  </span>
                  {i === activeIndex && <CornerDownLeft size={12} style={{ color: 'var(--color-brand)' }} />}
                </button>
              </div>
            )
          })}
        </div>

        <div className="flex items-center gap-3 px-4 h-9 border-t text-2xs"
          style={{ borderColor: 'var(--color-border)', color: 'var(--color-text-subtle)' }}>
          <span className="flex items-center gap-1"><ArrowUp size={10} /><ArrowDown size={10} /> navigate</span>
          <span className="flex items-center gap-1"><CornerDownLeft size={10} /> select</span>
        </div>
      </div>
    </div>
  )
}
