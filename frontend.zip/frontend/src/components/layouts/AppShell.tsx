import { useEffect, useState, type ReactNode } from 'react'
import { NavLink, useNavigate, useLocation } from 'react-router-dom'
import {
  LayoutDashboard, FileSearch, Clock, GitBranch, CheckSquare,
  FileText, LogOut, Sun, Moon, ChevronLeft, ChevronRight,
  Shield, Tag, Target, Settings, Home, Search, Users, Cpu,
  Bell, BarChart2, Building2, Send, Map, TrendingUp, HelpCircle, BookOpen, Command
} from 'lucide-react'
import { useAuthStore } from '@/app/store'
import { Tooltip } from '@/components/ui'
import { useTour } from '@/features/tour'
import { CommandPalette, type CommandItem } from '@/components/CommandPalette'
import clsx from 'clsx'

// ── Analyst (issuer) nav ──────────────────────────────────────────────────────

const DISPUTE_NAV = [
  { id: 'dispute-command-center', label: 'Command Center', icon: LayoutDashboard, path: '' },
  { id: 'evidence-explorer',      label: 'Evidence',       icon: FileSearch,       path: '/evidence' },
  { id: 'timeline',               label: 'Timeline',       icon: Clock,            path: '/timeline' },
  { id: 'hypotheses',             label: 'Hypotheses',     icon: GitBranch,        path: '/hypotheses' },
  { id: 'approval-workspace',     label: 'Approvals',      icon: CheckSquare,      path: '/approvals' },
  { id: 'audit',                  label: 'Audit Trail',    icon: FileText,         path: '/audit' },
]

const ADMIN_NAV = [
  { id: 'admin-statuses',      label: 'Statuses',       icon: Tag,        path: '/admin/statuses' },
  { id: 'admin-outcomes',      label: 'Outcomes',        icon: Target,     path: '/admin/outcomes' },
  { id: 'admin-roles',         label: 'Roles & Perms',   icon: Shield,     path: '/admin/roles' },
  { id: 'admin-evidence-requirements', label: 'Evidence Requirements', icon: FileSearch, path: '/admin/evidence-requirements' },
  { id: 'admin-users',         label: 'Users',           icon: Users,      path: '/admin/users' },
  { id: 'admin-integrations',  label: 'Integrations',    icon: Cpu,        path: '/admin/integrations' },
  { id: 'admin-impact',        label: 'Platform Impact', icon: TrendingUp, path: '/admin/impact' },
  { id: 'admin-eval-scores',   label: 'AI Quality',      icon: BarChart2,  path: '/admin/eval-scores' },
  { id: 'admin-knowledge',     label: 'Knowledge Base',  icon: BookOpen,   path: '/admin/knowledge' },
]

// ── Merchant nav ─────────────────────────────────────────────────────────────

// Order Story already covers the timeline/"what happened when" view (it's the same
// Digital Twin component as the issuer side's dedicated Timeline page), so it isn't
// duplicated as a separate nav item here — one clear destination per link, not two
// that land on the same content (README §50).
const MERCHANT_CASE_NAV = [
  { id: 'merchant-workspace', label: 'Workspace',     icon: Building2,  path: '' },
  { id: 'merchant-workspace', label: 'Order Story',   icon: Map,        path: '/story' },
  { id: 'merchant-workspace', label: 'Evidence',      icon: FileSearch, path: '/evidence' },
  { id: 'merchant-workspace', label: 'Response',      icon: Send,       path: '/response' },
]

interface Props { children: ReactNode }

export function AppShell({ children }: Props) {
  const { user, clearAuth, toggleTheme, theme } = useAuthStore()
  const navigate = useNavigate()
  const location = useLocation()
  const [collapsed, setCollapsed] = useState(false)
  const tour = useTour()

  const isMerchant = user?.roles?.some(r => r.startsWith('merchant_')) ?? false
  const isAdminOnly = !isMerchant && (user?.roles?.includes('admin') ?? false)

  // Extract active dispute ID from URL
  const disputeMatch = location.pathname.match(/^\/disputes\/([^/]+)/)
  const merchantDisputeMatch = location.pathname.match(/^\/merchant\/disputes\/([^/]+)/)
  const activeDisputeId = disputeMatch?.[1] ?? null
  const activeMerchantDisputeId = merchantDisputeMatch?.[1] ?? null

  const allowedScreens = user?.screens ?? []

  // Analyst nav
  const disputeNavItems = DISPUTE_NAV.filter(n => allowedScreens.includes(n.id))
  const adminItems = ADMIN_NAV.filter(n => allowedScreens.includes(n.id))

  function handleLogout() {
    clearAuth()
    navigate('/login')
  }

  // ── Command palette (Cmd/Ctrl+K) ────────────────────────────────────────────
  const [paletteOpen, setPaletteOpen] = useState(false)
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setPaletteOpen((o) => !o)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  const paletteItems: CommandItem[] = isMerchant
    ? [
        { id: 'm-home', label: 'My Work', group: 'Go to', icon: Home, action: () => navigate('/merchant') },
        { id: 'm-disputes', label: 'Disputes', group: 'Go to', icon: LayoutDashboard, action: () => navigate('/merchant/disputes') },
        { id: 'm-alerts', label: 'Alerts', group: 'Go to', icon: Bell, action: () => navigate('/merchant/alerts') },
        { id: 'm-insights', label: 'Insights', group: 'Go to', icon: BarChart2, action: () => navigate('/merchant/insights') },
        { id: 'm-search', label: 'Search', group: 'Go to', icon: Search, action: () => navigate('/merchant/search') },
        ...(activeMerchantDisputeId ? MERCHANT_CASE_NAV.map((item, i) => ({
          id: `m-case-${i}`, label: item.label, group: 'This case', icon: item.icon,
          action: () => navigate(`/merchant/disputes/${activeMerchantDisputeId}${item.path}`),
        })) : []),
      ]
    : isAdminOnly
    ? [
        { id: 'a-home', label: 'Admin Home', group: 'Go to', icon: Settings, action: () => navigate('/admin') },
        ...adminItems.map((item) => ({
          id: item.id, label: item.label, group: 'Go to', icon: item.icon, action: () => navigate(item.path),
        })),
      ]
    : [
        { id: 'home', label: 'My Work', group: 'Go to', icon: Home, action: () => navigate('/') },
        { id: 'cases', label: 'My Cases', group: 'Go to', icon: LayoutDashboard, action: () => navigate('/disputes') },
        { id: 'search', label: 'Search', group: 'Go to', icon: Search, action: () => navigate('/search') },
        ...(activeDisputeId ? disputeNavItems.map((item) => ({
          id: `case-${item.id}`, label: item.label, group: 'This case', icon: item.icon,
          action: () => navigate(`/disputes/${activeDisputeId}${item.path}`),
        })) : []),
      ]
  paletteItems.push({
    id: 'toggle-theme', label: theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode',
    group: 'Actions', icon: theme === 'dark' ? Sun : Moon, action: toggleTheme,
  })

  return (
    <div className="flex h-screen overflow-hidden relative" style={{ background: 'var(--color-bg)' }}>
      <div className="app-mesh-bg" aria-hidden="true" />
      {/* Slim branded top hairline — a cheap, restrained "this is a designed
          product" signature (the same cue Linear/Vercel use), not a loading bar. */}
      <div className="fixed top-0 left-0 right-0 h-[3px] z-50 bg-grad-brand" aria-hidden="true" />
      {/* ── Sidebar ── */}
      <aside
        className={clsx(
          'flex flex-col border-r transition-all duration-200 shrink-0 relative z-10',
          collapsed ? 'w-14' : 'w-56'
        )}
        style={{
          background: 'var(--color-surface)', borderColor: 'var(--color-border)',
          // A floating-panel cue instead of relying on the border alone to
          // separate it from the content area — barely visible in dark mode
          // (where depth already comes from glow) but does real work in light
          // mode, where a hairline border alone reads as flat (README §68).
          boxShadow: '6px 0 24px -12px rgba(var(--shadow-tint), 0.18)',
        }}
      >
        {/* Logo */}
        <div className="border-b shrink-0" style={{ borderColor: 'var(--color-border)' }}>
          <div className={clsx('flex items-center h-14', collapsed ? 'justify-center px-2' : 'gap-3 px-3')}>
            <div
              className={clsx(
                'w-8 h-8 rounded-fluent flex items-center justify-center shrink-0 shadow-glow-brand transition-transform duration-300 hover:rotate-6',
                !isMerchant && 'bg-grad-brand'
              )}
              style={isMerchant ? { background: 'var(--color-success)' } : undefined}>
              {isMerchant
                ? <Building2 size={16} className="text-white" />
                : <Shield size={16} className="text-white" />
              }
            </div>
            {!collapsed && (
              <>
                {/* D³ — Detect, Decide, Deliver (README §69). The wordmark leads on
                    both portals so the brand reads consistently; "Merchant Hub" stays
                    as the portal-specific label analysts vs. merchants actually need
                    to tell which side they're on. Platform version moved to a native
                    tooltip instead of taking a permanent line — the tagline earns
                    that space now. */}
                <div className="min-w-0" title={!isMerchant ? 'Platform v2.72' : undefined}>
                  <div className="font-display text-sm font-semibold truncate tracking-tight" style={{ color: 'var(--color-text)' }}>
                    {isMerchant ? 'D³ Merchant' : 'D³'}
                  </div>
                  <div className="text-2xs font-mono truncate" style={{ color: 'var(--color-text-muted)' }}>
                    Detect · Decide · Deliver
                  </div>
                </div>
                <button
                  onClick={() => setCollapsed(c => !c)}
                  className="ml-auto rounded p-1 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors shrink-0"
                  style={{ color: 'var(--color-text-muted)' }}
                  aria-label="Collapse sidebar">
                  <ChevronLeft size={14} />
                </button>
              </>
            )}
          </div>
          {collapsed && (
            <div className="flex justify-center pb-2">
              <button
                onClick={() => setCollapsed(c => !c)}
                className="rounded p-1 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                style={{ color: 'var(--color-text-muted)' }}
                aria-label="Expand sidebar">
                <ChevronRight size={14} />
              </button>
            </div>
          )}
        </div>

        {/* Command palette trigger */}
        <div className={clsx('px-2 pt-2', collapsed && 'flex justify-center')}>
          <Tooltip label="Search (Ctrl+K)" disabled={!collapsed}>
            <button
              onClick={() => setPaletteOpen(true)}
              className={clsx(
                'flex items-center gap-2 h-8 rounded-fluent border text-xs transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800',
                collapsed ? 'w-8 justify-center' : 'w-full px-2.5'
              )}
              style={{ borderColor: 'var(--color-border)', color: 'var(--color-text-subtle)' }}>
              <Search size={13} className="shrink-0" />
              {!collapsed && (
                <>
                  <span className="flex-1 text-left">Search…</span>
                  <kbd className="text-2xs px-1 py-0.5 rounded font-mono flex items-center gap-0.5"
                    style={{ background: 'var(--color-surface-r)' }}>
                    <Command size={9} />K
                  </kbd>
                </>
              )}
            </button>
          </Tooltip>
        </div>

        {/* Nav */}
        <nav data-tour="sidebar-nav" className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">

          {/* ── MERCHANT NAV ── */}
          {isMerchant ? (
            <>
              {/* Global merchant nav */}
              <SidebarLink to="/merchant" icon={Home} label="My Work" collapsed={collapsed} exact />
              <SidebarLink to="/merchant/disputes" icon={LayoutDashboard} label="Disputes" collapsed={collapsed} exact />
              <SidebarLink to="/merchant/alerts" icon={Bell} label="Alerts" collapsed={collapsed} />
              <SidebarLink to="/merchant/insights" icon={BarChart2} label="Insights" collapsed={collapsed} />
              <SidebarLink to="/merchant/search" icon={Search} label="Search" collapsed={collapsed} />

              {/* Per-dispute context nav */}
              {activeMerchantDisputeId && (
                <>
                  <div className="pt-3 pb-1">
                    {!collapsed && (
                      <div className="px-2 text-2xs font-semibold uppercase tracking-wider truncate"
                        style={{ color: 'var(--color-text-subtle)' }}>
                        Case Context
                      </div>
                    )}
                    {collapsed && <div className="h-px mx-1" style={{ background: 'var(--color-border)' }} />}
                  </div>
                  {MERCHANT_CASE_NAV.map((item, i) => (
                    <SidebarLink
                      key={i}
                      to={`/merchant/disputes/${activeMerchantDisputeId}${item.path}`}
                      icon={item.icon}
                      label={item.label}
                      collapsed={collapsed}
                      exact={item.path === ''}
                    />
                  ))}
                </>
              )}
            </>
          ) : isAdminOnly ? (
            /* ── ADMIN-ONLY NAV — back-office configuration, nothing operational ── */
            <>
              <SidebarLink to="/admin" icon={Settings} label="Admin Home" collapsed={collapsed} exact />
              {adminItems.map(item => (
                <SidebarLink key={item.id} to={item.path} icon={item.icon} label={item.label} collapsed={collapsed} />
              ))}
            </>
          ) : (
            /* ── ANALYST NAV ── */
            <>
              <SidebarLink to="/" icon={Home} label="My Work" collapsed={collapsed} exact />
              <SidebarLink to="/disputes" icon={LayoutDashboard} label="My Cases" collapsed={collapsed} exact />
              <SidebarLink to="/search" icon={Search} label="Search" collapsed={collapsed} />

              {activeDisputeId && (
                <>
                  <div className="pt-3 pb-1">
                    {!collapsed && (
                      <div className="px-2 text-2xs font-semibold uppercase tracking-wider truncate"
                        style={{ color: 'var(--color-text-subtle)' }}>
                        Case Context
                      </div>
                    )}
                    {collapsed && <div className="h-px mx-1" style={{ background: 'var(--color-border)' }} />}
                  </div>
                  {disputeNavItems.map(item => (
                    <SidebarLink
                      key={item.id}
                      to={`/disputes/${activeDisputeId}${item.path}`}
                      icon={item.icon}
                      label={item.label}
                      collapsed={collapsed}
                      exact={item.path === ''}
                    />
                  ))}
                </>
              )}
            </>
          )}
        </nav>

        {/* User area */}
        <div data-tour="sidebar-user" className="border-t p-2 space-y-0.5" style={{ borderColor: 'var(--color-border)' }}>
          <Tooltip label={theme === 'dark' ? 'Light mode' : 'Dark mode'} disabled={!collapsed}>
            <button
              onClick={toggleTheme}
              className={clsx(
                'flex items-center gap-3 h-9 w-full rounded-fluent transition-colors text-sm',
                collapsed ? 'justify-center px-0' : 'px-2.5',
                'hover:bg-neutral-100 dark:hover:bg-neutral-800'
              )}
              style={{ color: 'var(--color-text-muted)' }}>
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              {!collapsed && <span>{theme === 'dark' ? 'Light mode' : 'Dark mode'}</span>}
            </button>
          </Tooltip>

          <Tooltip label="Take Product Tour" disabled={!collapsed}>
            <button
              onClick={tour.restart}
              className={clsx(
                'flex items-center gap-3 h-9 w-full rounded-fluent transition-colors text-sm',
                collapsed ? 'justify-center px-0' : 'px-2.5',
                'hover:bg-neutral-100 dark:hover:bg-neutral-800'
              )}
              style={{ color: 'var(--color-text-muted)' }}>
              <HelpCircle size={18} />
              {!collapsed && <span>Take Product Tour</span>}
            </button>
          </Tooltip>

          {!collapsed && user && (
            <div className="px-2.5 py-1.5">
              <div className="text-xs font-medium truncate" style={{ color: 'var(--color-text)' }}>
                {user.username}
              </div>
              <div className="text-2xs truncate" style={{ color: 'var(--color-text-muted)' }}>
                {user.roles.join(', ')}
              </div>
            </div>
          )}

          <Tooltip label="Sign out" disabled={!collapsed}>
            <button
              onClick={handleLogout}
              className={clsx(
                'flex items-center gap-3 h-9 w-full rounded-fluent transition-colors text-sm',
                collapsed ? 'justify-center px-0' : 'px-2.5',
                'hover:bg-neutral-100 dark:hover:bg-neutral-800'
              )}
              style={{ color: 'var(--color-text-muted)' }}>
              <LogOut size={18} />
              {!collapsed && <span>Sign out</span>}
            </button>
          </Tooltip>
        </div>
      </aside>

      {/* ── Main content ── */}
      <main className="flex-1 overflow-y-auto relative z-10">
        <div key={location.pathname} className="animate-fade-in-up">
          {children}
        </div>
      </main>
      <CommandPalette items={paletteItems} open={paletteOpen} onClose={() => setPaletteOpen(false)} />
    </div>
  )
}

function SidebarLink({
  to, icon: Icon, label, collapsed, exact = false
}: {
  to: string; icon: React.ElementType; label: string; collapsed: boolean; exact?: boolean
}) {
  return (
    <Tooltip label={label} disabled={!collapsed}>
      <NavLink
        to={to}
        end={exact}
        className={({ isActive }) =>
          clsx(
            'flex items-center gap-3 h-9 rounded-fluent transition-all duration-200 text-sm w-full',
            collapsed ? 'justify-center px-0' : 'px-2.5',
            isActive ? 'font-medium bg-grad-brand-soft shadow-fluent-sm' : 'hover:bg-neutral-100 dark:hover:bg-neutral-800'
          )
        }
        style={({ isActive }) => ({
          color: isActive ? 'var(--color-brand)' : 'var(--color-text-muted)',
        })}
      >
        <Icon size={18} className="shrink-0" />
        {!collapsed && <span className="truncate">{label}</span>}
      </NavLink>
    </Tooltip>
  )
}
