import { useEffect, useRef } from 'react'

interface Node { x: number; y: number; vx: number; vy: number }

/**
 * Animated constellation of connecting nodes — on-brand rather than decorative: this
 * platform's whole premise is an evidence *graph*, so a background of drifting,
 * connecting points reads as intentional rather than generic. Pure canvas 2D, no
 * library, ~45 nodes, capped device-pixel-ratio for perf. Colors passed in as props
 * so it can match whichever surface it's drawn over (brand gradient panel vs plain
 * dark background) without reaching into CSS vars itself.
 */
export function ParticleNetwork({
  nodeColor = 'rgba(255,255,255,0.55)',
  lineColor = 'rgba(255,255,255,0.12)',
  density = 45,
  className,
}: {
  nodeColor?: string
  lineColor?: string
  density?: number
  className?: string
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let width = 0, height = 0
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    let nodes: Node[] = []
    let frame: number

    function resize() {
      const rect = canvas!.getBoundingClientRect()
      width = rect.width
      height = rect.height
      canvas!.width = width * dpr
      canvas!.height = height * dpr
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0)
      nodes = Array.from({ length: density }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.25,
        vy: (Math.random() - 0.5) * 0.25,
      }))
    }

    function tick() {
      ctx!.clearRect(0, 0, width, height)
      for (const n of nodes) {
        n.x += n.vx
        n.y += n.vy
        if (n.x < 0 || n.x > width) n.vx *= -1
        if (n.y < 0 || n.y > height) n.vy *= -1
      }
      const maxDist = Math.min(width, height) * 0.22
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x
          const dy = nodes[i].y - nodes[j].y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < maxDist) {
            ctx!.globalAlpha = 1 - dist / maxDist
            ctx!.strokeStyle = lineColor
            ctx!.lineWidth = 1
            ctx!.beginPath()
            ctx!.moveTo(nodes[i].x, nodes[i].y)
            ctx!.lineTo(nodes[j].x, nodes[j].y)
            ctx!.stroke()
          }
        }
      }
      ctx!.globalAlpha = 1
      ctx!.fillStyle = nodeColor
      for (const n of nodes) {
        ctx!.beginPath()
        ctx!.arc(n.x, n.y, 1.6, 0, Math.PI * 2)
        ctx!.fill()
      }
      frame = requestAnimationFrame(tick)
    }

    resize()
    tick()
    window.addEventListener('resize', resize)
    return () => {
      window.removeEventListener('resize', resize)
      cancelAnimationFrame(frame)
    }
  }, [density, nodeColor, lineColor])

  return <canvas ref={canvasRef} className={className} style={{ width: '100%', height: '100%', display: 'block' }} />
}
