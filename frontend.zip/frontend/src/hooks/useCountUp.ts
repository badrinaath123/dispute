import { useEffect, useRef, useState } from 'react'

/**
 * Animates a displayed number from 0 up to `value` once, whenever `value` first
 * becomes a real number (loading states usually start as null/undefined). Purely
 * cosmetic — never used for anything the app makes a decision from.
 */
export function useCountUp(value: number | null | undefined, durationMs = 800): number {
  const [display, setDisplay] = useState(0)
  const animatedFor = useRef<number | null>(null)

  useEffect(() => {
    if (value == null || Number.isNaN(value)) return
    if (animatedFor.current === value) return
    animatedFor.current = value

    const start = performance.now()
    const from = 0
    let frame: number

    function tick(now: number) {
      const t = Math.min(1, (now - start) / durationMs)
      const eased = 1 - Math.pow(1 - t, 3)
      setDisplay(from + (value! - from) * eased)
      if (t < 1) frame = requestAnimationFrame(tick)
    }
    frame = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(frame)
  }, [value, durationMs])

  return value == null || Number.isNaN(value) ? 0 : display
}
