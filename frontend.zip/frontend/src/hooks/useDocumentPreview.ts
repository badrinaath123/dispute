import { useState } from 'react'
import toast from 'react-hot-toast'
import { disputeApi } from '@/services/api'

export interface DocPreview { url: string; name: string; mime: string }

/** Fetches an evidence document's actual file (blob, via the authenticated API client
 * — a plain <a href> can't carry the Bearer token) and holds it ready for a preview
 * modal. Shared by the issuer case view and the merchant workspace so "view the real
 * document, not just its extracted JSON" works the same way on both sides. */
export function useDocumentPreview(caseId: string | undefined) {
  const [docPreview, setDocPreview] = useState<DocPreview | null>(null)
  const [loadingDocId, setLoadingDocId] = useState<string | null>(null)
  // The modal used to only appear once the whole file had already arrived — a large
  // PDF gave zero feedback beyond a small spinner on the button that triggered it,
  // reading as "nothing is happening." Now the modal opens immediately with the
  // filename and a loading state, filled in once the blob actually arrives.
  const [pendingName, setPendingName] = useState<string | null>(null)

  async function viewDocument(documentId: string, fileName: string) {
    if (!caseId) return
    setLoadingDocId(documentId)
    setPendingName(fileName)
    try {
      const res = await disputeApi.getDocument(caseId, documentId)
      const mime = String(res.headers['content-type'] ?? 'application/octet-stream')
      const blob = new Blob([res.data], { type: mime })
      setDocPreview({ url: URL.createObjectURL(blob), name: fileName, mime })
    } catch {
      toast.error('Could not load this document')
      setPendingName(null)
    } finally {
      setLoadingDocId(null)
    }
  }

  function closeDocPreview() {
    if (docPreview) URL.revokeObjectURL(docPreview.url)
    setDocPreview(null)
    setPendingName(null)
  }

  return { docPreview, loadingDocId, pendingName, viewDocument, closeDocPreview }
}
