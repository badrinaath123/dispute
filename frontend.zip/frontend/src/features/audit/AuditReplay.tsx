import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { auditApi } from '@/services/api'
import { AuditEvent } from '@/types'
import { format } from 'date-fns'
import { type ReactNode } from 'react'
import { ChevronDown, ChevronRight, Lock, User, Bot } from 'lucide-react'

const ACTOR_ICON: Record<string, ReactNode> = {
  SYSTEM: <Bot size={14} />,
  USER:   <User size={14} />,
  AGENT:  <Bot size={14} className="text-brand-500" />,
}

const EVENT_COLOR: Record<string, string> = {
  DISPUTE_CREATED:        '#0078d4',
  EVIDENCE_INGESTED:      '#107c10',
  EVIDENCE_SUPERSEDED:    '#ca5010',
  RECOMMENDATION_CREATED: '#5c2d91',
  RECOMMENDATION_STALE:   '#d13438',
  ACTION_CREATED:         '#2b88d8',
  ACTION_APPROVED:        '#107c10',
  ACTION_REJECTED:        '#d13438',
  AGENT_RUN_STARTED:      '#0078d4',
  AGENT_RUN_COMPLETE:     '#107c10',
  SMS_SENT:               '#107c10',
  SMS_NOT_SENT:           '#767676',
}

export function AuditReplay() {
  const { id } = useParams<{ id: string }>()
  const [expanded, setExpanded] = useState<Set<string>>(new Set())
  const [replayBefore, setReplayBefore] = useState('')

  const { data: events = [] } = useQuery({
    queryKey: ['audit', id, replayBefore],
    queryFn: (): Promise<{ data: AuditEvent[] }> =>
      replayBefore
        ? auditApi.replay(id!, replayBefore) as Promise<{ data: AuditEvent[] }>
        : auditApi.list(id!, {}) as Promise<{ data: AuditEvent[] }>,
    select: (r) => r.data,
    enabled: !!id,
  })

  function toggle(eid: string) {
    setExpanded((s) => {
      const next = new Set(s)
      next.has(eid) ? next.delete(eid) : next.add(eid)
      return next
    })
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-start justify-between mb-6 gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Lock size={16} style={{ color: 'var(--color-brand)' }} />
            <h2 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
              Audit Trail
            </h2>
          </div>
          <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
            Append-only log. All mutations captured with actor, correlation ID and state version.
          </p>
        </div>

        {/* Point-in-time replay */}
        <div className="flex items-center gap-2 shrink-0">
          <label className="text-xs font-medium" style={{ color: 'var(--color-text-muted)' }}>
            Replay before
          </label>
          <input
            type="datetime-local"
            value={replayBefore}
            onChange={(e) => setReplayBefore(e.target.value)}
            className="text-xs rounded-fluent px-2 py-1 border outline-none"
            style={{
              background: 'var(--color-surface)',
              border: '1px solid var(--color-border-strong)',
              color: 'var(--color-text)',
            }}
          />
          {replayBefore && (
            <button
              onClick={() => setReplayBefore('')}
              className="text-xs px-2 py-1 rounded-fluent"
              style={{ color: 'var(--color-text-muted)', background: 'var(--color-surface-r)' }}
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {replayBefore && (
        <div
          className="rounded-fluent px-4 py-2 mb-4 text-xs flex items-center gap-2"
          style={{ background: 'rgba(202,80,16,0.1)', color: 'var(--color-medium)', border: '1px solid rgba(202,80,16,0.25)' }}
        >
          Showing state as of {format(new Date(replayBefore), "dd MMM yyyy HH:mm")} — {events.length} events
        </div>
      )}

      {events.length === 0 ? (
        <p className="text-sm" style={{ color: 'var(--color-text-muted)' }}>No audit events.</p>
      ) : (
        <div className="space-y-2">
          {events.map((ev) => {
            const isOpen = expanded.has(ev.audit_id)
            const color = EVENT_COLOR[ev.event_type] ?? '#767676'
            return (
              <div
                key={ev.audit_id}
                className="rounded-fluent-lg overflow-hidden"
                style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}
              >
                <button
                  onClick={() => toggle(ev.audit_id)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-800/50"
                >
                  {/* Color dot */}
                  <div className="w-2 h-2 rounded-full shrink-0" style={{ background: color }} />

                  {/* Actor icon */}
                  <div className="shrink-0" style={{ color: 'var(--color-text-muted)' }}>
                    {ACTOR_ICON[ev.actor_type] ?? <User size={14} />}
                  </div>

                  <div className="flex-1 min-w-0 text-left">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>
                        {ev.event_type.replace(/_/g, ' ')}
                      </span>
                      {ev.actor_id && (
                        <span className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                          by {ev.actor_id.slice(0, 8)}
                        </span>
                      )}
                      {ev.new_state_version != null && (
                        <span
                          className="text-2xs px-1.5 py-0.5 rounded font-mono"
                          style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-muted)' }}
                        >
                          v{ev.new_state_version}
                        </span>
                      )}
                    </div>
                    <div className="text-xs mt-0.5" style={{ color: 'var(--color-text-subtle)' }}>
                      {format(new Date(ev.timestamp), "dd MMM yyyy HH:mm:ss 'UTC'")}
                    </div>
                  </div>

                  {isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                </button>

                {isOpen && (
                  <div
                    className="px-4 pb-4 pt-1 border-t text-xs"
                    style={{ borderColor: 'var(--color-border)' }}
                  >
                    <div className="grid grid-cols-2 gap-2 mb-3">
                      {[
                        ['State version', ev.new_state_version != null ? `v${ev.new_state_version}` : '—'],
                        ['Actor type', ev.actor_type],
                        ['Node', ev.node_name ?? '—'],
                        ['Decision', ev.decision ?? '—'],
                      ].map(([label, value]) => (
                        <div key={label}>
                          <div className="font-medium mb-0.5" style={{ color: 'var(--color-text-muted)' }}>{label}</div>
                          <div className="font-mono" style={{ color: 'var(--color-text)' }}>{value}</div>
                        </div>
                      ))}
                    </div>
                    {ev.metadata && Object.keys(ev.metadata).length > 0 && (
                      <pre
                        className="p-3 rounded-fluent text-xs overflow-x-auto"
                        style={{ background: 'var(--color-surface-r)', color: 'var(--color-text)' }}
                      >
                        {JSON.stringify(ev.metadata, null, 2)}
                      </pre>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
