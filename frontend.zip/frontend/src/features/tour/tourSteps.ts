export interface TourStep {
  target: string
  title: string
  description: string
  route?: string
  placement?: 'top' | 'bottom' | 'left' | 'right'
}

const ANALYST_STEPS: TourStep[] = [
  {
    target: 'sidebar-nav',
    title: 'Navigation',
    description: 'Use the sidebar to move between My Work, My Cases, and Search. It adapts to your role — you only ever see the screens you have access to.',
    route: '/',
    placement: 'right',
  },
  {
    target: 'mywork-stats',
    title: 'Your Workspace',
    description: 'Your home page surfaces what needs attention right now — open cases, SLA risk, and overdue items — so you never start from a blank queue.',
    route: '/',
    placement: 'bottom',
  },
  {
    target: 'new-case-btn',
    title: 'Filing a Dispute',
    description: 'Create a new case here. If a cardholder is unclear on several transactions at once, toggle "covers multiple transactions" — one intake becomes several correctly separated, per-merchant investigations.',
    route: '/disputes',
    placement: 'bottom',
  },
  {
    target: 'cases-table',
    title: 'AI-Powered Investigation',
    description: 'Opening any case triggers the AI agent: it assesses evidence, identifies gaps automatically, generates competing hypotheses, and produces an evidence-grounded recommendation — before you have to dig for anything.',
    route: '/disputes',
    placement: 'top',
  },
  {
    target: 'cases-search',
    title: 'Search & Smart Filters',
    description: 'Search by ID, merchant, or customer, or use the quick filters — SLA Risk, Overdue, High Value — to jump straight to what matters.',
    route: '/disputes',
    placement: 'bottom',
  },
  {
    target: 'sidebar-user',
    title: 'Preferences',
    description: 'Switch between light and dark mode, and replay this tour any time from the "?" icon here.',
    route: '/disputes',
    placement: 'right',
  },
]

const MERCHANT_STEPS: TourStep[] = [
  {
    target: 'sidebar-nav',
    title: 'Navigation',
    description: 'Your workspace: My Work, Disputes, Alerts, Insights, and Search — everything scoped to your own merchant account.',
    route: '/merchant',
    placement: 'right',
  },
  {
    target: 'merchant-recommended',
    title: 'Your Workspace',
    description: "The platform investigates before you open a case. By the time you're here, evidence has already been assessed and a recommendation is ready — you review and decide, you don't start from scratch.",
    route: '/merchant',
    placement: 'bottom',
  },
  {
    target: 'merchant-summary',
    title: 'Pre-Dispute Prevention',
    description: 'Some issues are caught before they become a formal chargeback. Resolving them here (a quick refund or replacement) avoids network fees entirely.',
    route: '/merchant',
    placement: 'bottom',
  },
  {
    target: 'insights-stats',
    title: 'Performance Analytics',
    description: 'Track your real win rate, amount at stake, and dispute volume by type — computed from your actual case history, not estimates.',
    route: '/merchant/insights',
    placement: 'bottom',
  },
  {
    target: 'sidebar-user',
    title: 'Preferences',
    description: 'Switch between light and dark mode, and replay this tour any time from the "?" icon here.',
    route: '/merchant/insights',
    placement: 'right',
  },
]

const ADMIN_STEPS: TourStep[] = [
  {
    target: 'sidebar-nav',
    title: 'Navigation',
    description: 'The admin account is a back-office configuration persona — statuses, outcomes, roles, users, and integrations. It intentionally does not show the operational case queues; that keeps configuration and casework cleanly separated.',
    route: '/admin',
    placement: 'right',
  },
  {
    target: 'admin-stats',
    title: 'Configuration Dashboard',
    description: 'A live count of statuses, outcomes, roles, and users currently configured on the platform.',
    route: '/admin',
    placement: 'bottom',
  },
  {
    target: 'admin-cards',
    title: 'Lifecycle & Access Configuration',
    description: 'Configure dispute statuses and outcomes, and manage roles, permissions, and screen access — all from here.',
    route: '/admin',
    placement: 'top',
  },
  {
    target: 'impact-cards',
    title: 'Measurable Platform Value',
    description: 'Every number here is a live query — stale approvals actually prevented, recommendations that flipped when evidence changed, and more — computed from real data, not a pitch claim.',
    route: '/admin/impact',
    placement: 'top',
  },
  {
    target: 'sidebar-user',
    title: 'Preferences',
    description: 'Switch between light and dark mode, and replay this tour any time from the "?" icon here.',
    route: '/admin/impact',
    placement: 'right',
  },
]

export function getTourSteps(roles: string[] | undefined): TourStep[] {
  const isMerchant = roles?.some((r) => r.startsWith('merchant_')) ?? false
  const isAdmin = !isMerchant && (roles?.includes('admin') ?? false)
  if (isMerchant) return MERCHANT_STEPS
  if (isAdmin) return ADMIN_STEPS
  return ANALYST_STEPS
}
