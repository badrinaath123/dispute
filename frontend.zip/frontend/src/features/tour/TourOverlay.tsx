import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { X } from 'lucide-react'
import { Button } from '@/components/ui'
import { useTour } from './TourProvider'

interface Rect { top: number; left: number; width: number; height: number }

const SPOTLIGHT_PADDING = 8
const TOOLTIP_GAP = 14
const TOOLTIP_WIDTH = 320
const MAX_FIND_ATTEMPTS = 60 // ~1s at 60fps, covers route-change mount time

function findTarget(target: string): HTMLElement | null {
  return document.querySelector<HTMLElement>(`[data-tour="${target}"]`)
}

/** Picks whichever side actually fits the tooltip within the viewport. */
function computePlacement(rect: Rect, preferred: 'top' | 'bottom' | 'left' | 'right' | undefined) {
  const vw = window.innerWidth
  const vh = window.innerHeight
  const space = {
    top: rect.top,
    bottom: vh - (rect.top + rect.height),
    left: rect.left,
    right: vw - (rect.left + rect.width),
  }
  const fits = (side: keyof typeof space) =>
    side === 'left' || side === 'right' ? space[side] >= TOOLTIP_WIDTH + TOOLTIP_GAP : space[side] >= 160
  const order: (keyof typeof space)[] = preferred
    ? [preferred, ...(['bottom', 'right', 'top', 'left'] as const).filter((s) => s !== preferred)]
    : ['bottom', 'right', 'top', 'left']
  return order.find(fits) ?? 'bottom'
}

function tooltipStyle(rect: Rect, placement: 'top' | 'bottom' | 'left' | 'right'): React.CSSProperties {
  const vw = window.innerWidth
  const vh = window.innerHeight
  let top = 0
  let left = 0

  if (placement === 'bottom') { top = rect.top + rect.height + TOOLTIP_GAP; left = rect.left }
  else if (placement === 'top') { top = rect.top - TOOLTIP_GAP; left = rect.left }
  else if (placement === 'right') { top = rect.top; left = rect.left + rect.width + TOOLTIP_GAP }
  else { top = rect.top; left = rect.left - TOOLTIP_GAP }

  // Clamp horizontally within the viewport with an 8px margin.
  left = Math.max(8, Math.min(left, vw - TOOLTIP_WIDTH - 8))
  // Clamp vertically, accounting for an assumed max card height.
  const maxHeight = 220
  top = Math.max(8, Math.min(top, vh - maxHeight - 8))

  const transform =
    placement === 'top' ? 'translateY(-100%)' :
    placement === 'left' ? 'translateX(-100%)' : undefined

  return { position: 'fixed', top, left: placement === 'left' ? rect.left - TOOLTIP_GAP : left, width: TOOLTIP_WIDTH, transform }
}

export function TourOverlay() {
  const { status, currentStep, stepIndex, totalSteps, next, back, skip, close } = useTour()
  const [rect, setRect] = useState<Rect | null>(null)
  const [notFound, setNotFound] = useState(false)

  useEffect(() => {
    if (status !== 'ACTIVE' || !currentStep) {
      setRect(null)
      setNotFound(false)
      return
    }

    let attempts = 0
    let raf = 0
    setNotFound(false)

    function measure() {
      const el = findTarget(currentStep!.target)
      if (el) {
        const r = el.getBoundingClientRect()
        setRect({ top: r.top, left: r.left, width: r.width, height: r.height })
        return
      }
      attempts += 1
      if (attempts < MAX_FIND_ATTEMPTS) {
        raf = requestAnimationFrame(measure)
      } else {
        setRect(null)
        setNotFound(true)
      }
    }
    measure()

    function onViewportChange() {
      const el = findTarget(currentStep!.target)
      if (el) {
        const r = el.getBoundingClientRect()
        setRect({ top: r.top, left: r.left, width: r.width, height: r.height })
      }
    }
    window.addEventListener('resize', onViewportChange)
    window.addEventListener('scroll', onViewportChange, true)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', onViewportChange)
      window.removeEventListener('scroll', onViewportChange, true)
    }
  }, [status, currentStep])

  if (status !== 'ACTIVE' || !currentStep) return null

  const spotlightRect: Rect | null = rect && {
    top: rect.top - SPOTLIGHT_PADDING,
    left: rect.left - SPOTLIGHT_PADDING,
    width: rect.width + SPOTLIGHT_PADDING * 2,
    height: rect.height + SPOTLIGHT_PADDING * 2,
  }
  const placement = rect ? computePlacement(rect, currentStep.placement) : 'bottom'

  return createPortal(
    <div className="fixed inset-0 z-[100]" aria-live="polite">
      {/* Dimmed backdrop with a spotlight cutout over the target */}
      {spotlightRect ? (
        <div
          className="absolute rounded-fluent-md transition-all duration-300 ease-out"
          style={{
            top: spotlightRect.top,
            left: spotlightRect.left,
            width: spotlightRect.width,
            height: spotlightRect.height,
            boxShadow: '0 0 0 9999px rgba(15,15,20,0.6)',
            pointerEvents: 'none',
          }}
        />
      ) : (
        <div className="absolute inset-0" style={{ background: 'rgba(15,15,20,0.6)' }} />
      )}

      {/* Tooltip card */}
      <div
        className="rounded-fluent-lg border shadow-fluent-lg p-4 animate-fade-in"
        style={{
          ...(rect ? tooltipStyle(rect, placement) : { position: 'fixed', top: '50%', left: '50%', width: TOOLTIP_WIDTH, transform: 'translate(-50%,-50%)' }),
          background: 'var(--color-surface)',
          borderColor: 'var(--color-border)',
        }}
      >
        <div className="flex items-start justify-between gap-2 mb-1">
          <span className="text-2xs font-semibold uppercase tracking-wide" style={{ color: 'var(--color-brand)' }}>
            {stepIndex + 1} of {totalSteps}
          </span>
          <button onClick={close} aria-label="Close tour" style={{ color: 'var(--color-text-subtle)' }}>
            <X size={14} />
          </button>
        </div>
        <h3 className="text-sm font-semibold mb-1.5" style={{ color: 'var(--color-text)' }}>
          {currentStep.title}
        </h3>
        <p className="text-xs leading-relaxed mb-3" style={{ color: 'var(--color-text-muted)' }}>
          {notFound
            ? "This screen doesn't have data to show that yet — you can still continue the tour."
            : currentStep.description}
        </p>

        {/* Progress dots */}
        <div className="flex items-center gap-1 mb-3">
          {Array.from({ length: totalSteps }, (_, i) => (
            <span
              key={i}
              className="rounded-full transition-all"
              style={{
                width: i === stepIndex ? 14 : 6,
                height: 6,
                background: i <= stepIndex ? 'var(--color-brand)' : 'var(--color-border-strong)',
              }}
            />
          ))}
        </div>

        <div className="flex items-center justify-between gap-2">
          <button onClick={skip} className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>
            Skip tour
          </button>
          <div className="flex gap-2">
            {stepIndex > 0 && (
              <Button variant="secondary" size="sm" onClick={back}>Back</Button>
            )}
            <Button variant="primary" size="sm" onClick={next}>
              {stepIndex === totalSteps - 2 ? 'Finish' : 'Next'}
            </Button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  )
}
