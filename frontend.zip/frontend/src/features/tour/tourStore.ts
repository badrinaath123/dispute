import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface TourPersistedState {
  completed: boolean
  pendingStart: boolean
  markCompleted: () => void
  markSkipped: () => void
  setPendingStart: (value: boolean) => void
  /** Consume the pending-start flag exactly once (returns its prior value). */
  consumePendingStart: () => boolean
}

/**
 * Tour completion/pending-start state — persisted the same way as
 * useAuthStore (src/app/store.ts), under its own localStorage key so it's
 * independent of auth state and survives logout/login.
 *
 * `pendingStart` is set by the login page's "Take a Product Tour" toggle and
 * consumed exactly once by the app shell after a successful login — the
 * toggle explicitly controls whether the tour starts for that session, it is
 * never auto-triggered just because `completed` is false.
 */
export const useTourStore = create<TourPersistedState>()(
  persist(
    (set, get) => ({
      completed: false,
      pendingStart: false,
      markCompleted: () => set({ completed: true }),
      markSkipped: () => set({ completed: true }),
      setPendingStart: (value) => set({ pendingStart: value }),
      consumePendingStart: () => {
        const value = get().pendingStart
        if (value) set({ pendingStart: false })
        return value
      },
    }),
    { name: 'dispute-tour' }
  )
)
