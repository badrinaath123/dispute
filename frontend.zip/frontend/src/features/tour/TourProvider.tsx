import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useAuthStore } from '@/app/store'
import { useTourStore } from './tourStore'
import { getTourSteps, type TourStep } from './tourSteps'

export type TourStatus = 'NOT_STARTED' | 'WELCOME' | 'ACTIVE' | 'COMPLETED' | 'SKIPPED'

interface TourContextValue {
  status: TourStatus
  steps: TourStep[]
  stepIndex: number
  /** steps.length + 1 — the completion screen counts as the final step. */
  totalSteps: number
  currentStep: TourStep | null
  start: () => void
  next: () => void
  back: () => void
  skip: () => void
  close: () => void
  restart: () => void
  dismissWelcome: () => void
  dismissCompletion: () => void
}

const TourContext = createContext<TourContextValue | null>(null)

export function TourProvider({ children }: { children: ReactNode }) {
  const { user } = useAuthStore()
  const tourStore = useTourStore()
  const navigate = useNavigate()
  const location = useLocation()

  const steps = useMemo(() => getTourSteps(user?.roles), [user?.roles])
  const totalSteps = steps.length + 1

  const [status, setStatus] = useState<TourStatus>('NOT_STARTED')
  const [stepIndex, setStepIndex] = useState(0)

  // Consume the login-page toggle's signal exactly once per authenticated session.
  useEffect(() => {
    if (!user) return
    if (tourStore.consumePendingStart()) {
      setStatus('WELCOME')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.user_id])

  function start() {
    setStepIndex(0)
    setStatus('ACTIVE')
    const first = steps[0]
    if (first?.route && first.route !== location.pathname) {
      navigate(first.route)
    }
  }

  function goToStep(index: number) {
    if (index >= steps.length) {
      setStatus('COMPLETED')
      tourStore.markCompleted()
      return
    }
    setStepIndex(index)
    const step = steps[index]
    if (step.route && step.route !== location.pathname) {
      navigate(step.route)
    }
  }

  function next() {
    goToStep(stepIndex + 1)
  }

  function back() {
    if (stepIndex === 0) return
    goToStep(stepIndex - 1)
  }

  function skip() {
    setStatus('SKIPPED')
    tourStore.markSkipped()
  }

  function close() {
    setStatus('NOT_STARTED')
  }

  function restart() {
    setStepIndex(0)
    setStatus('WELCOME')
  }

  function dismissWelcome() {
    setStatus('NOT_STARTED')
  }

  function dismissCompletion() {
    setStatus('NOT_STARTED')
  }

  const currentStep = status === 'ACTIVE' ? steps[stepIndex] ?? null : null

  return (
    <TourContext.Provider
      value={{
        status, steps, stepIndex, totalSteps, currentStep,
        start, next, back, skip, close, restart, dismissWelcome, dismissCompletion,
      }}
    >
      {children}
    </TourContext.Provider>
  )
}

export function useTour(): TourContextValue {
  const ctx = useContext(TourContext)
  if (!ctx) throw new Error('useTour must be used within a TourProvider')
  return ctx
}
