import { Compass, PartyPopper } from 'lucide-react'
import { Button } from '@/components/ui'
import { useTour } from './TourProvider'

const LEARN_ITEMS = [
  'What this application does',
  'Where the key features are',
  'How to navigate',
  'How to run the main workflows',
]

export function TourModal() {
  const { status, start, dismissWelcome, dismissCompletion } = useTour()

  if (status !== 'WELCOME' && status !== 'COMPLETED') return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4" style={{ background: 'rgba(15,15,20,0.6)' }}>
      <div
        className="w-full max-w-sm rounded-fluent-lg border shadow-fluent-lg p-6 animate-fade-in text-center"
        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}
      >
        {status === 'WELCOME' ? (
          <>
            <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{ background: 'var(--color-brand-light)', color: 'var(--color-brand)' }}>
              <Compass size={22} />
            </div>
            <h2 className="text-lg font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
              Welcome to D³
            </h2>
            <p className="text-sm mb-4" style={{ color: 'var(--color-text-muted)' }}>
              Let's take a quick tour of the application and show you how to get the most out of it.
            </p>
            <ul className="text-left text-xs space-y-1.5 mb-5 inline-block mx-auto" style={{ color: 'var(--color-text-muted)' }}>
              {LEARN_ITEMS.map((item) => (
                <li key={item} className="flex items-center gap-2">
                  <span style={{ color: 'var(--color-success)' }}>✓</span> {item}
                </li>
              ))}
            </ul>
            <div className="flex gap-2 justify-center">
              <Button variant="secondary" onClick={dismissWelcome}>Skip</Button>
              <Button variant="primary" onClick={start}>Start Tour</Button>
            </div>
          </>
        ) : (
          <>
            <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4"
              style={{ background: 'rgba(16,124,16,0.12)', color: 'var(--color-success)' }}>
              <PartyPopper size={22} />
            </div>
            <h2 className="text-lg font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
              You're all set!
            </h2>
            <p className="text-sm mb-5" style={{ color: 'var(--color-text-muted)' }}>
              You now know the basics of D³. You can start exploring on your own —
              replay this tour any time from the "?" icon in the sidebar.
            </p>
            <Button variant="primary" onClick={dismissCompletion} className="w-full">
              Start Exploring
            </Button>
          </>
        )}
      </div>
    </div>
  )
}
