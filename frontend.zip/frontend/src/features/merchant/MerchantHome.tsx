import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import {
  ArrowRight, AlertTriangle, Clock, CheckCircle2, Zap,
  ChevronRight, Activity, Bell, TrendingUp, Shield, RefreshCw,
  FileText, AlertCircle, Sparkles
} from 'lucide-react'
import { disputeApi } from '@/services/api'
import { useAuthStore } from '@/app/store'
import type { Dispute } from '@/types'
import { formatDistanceToNow, parseISO } from 'date-fns'
import { Button } from '@/components/ui'
import { isMerchantDecided, slaDaysLabel } from '@/lib/disputeStatus'

function sla(d: Dispute) {
  return slaDaysLabel(d) ?? { label: 'No deadline', color: 'var(--color-text-muted)', urgent: false }
}

const PRIORITY_COLOR: Record<string, string> = {
  CRITICAL: '#c50f1f', HIGH: '#d13438', MEDIUM: '#ca5010', LOW: '#835b00',
}

const DISPUTE_TYPE_LABEL: Record<string, string> = {
  UNAUTHORIZED_TRANSACTION: 'Unauthorized Transaction',
  MERCHANDISE_NOT_RECEIVED: 'Merchandise Not Received',
  REFUND_NOT_PROCESSED: 'Refund Not Processed',
  MERCHANDISE_NOT_AS_DESCRIBED: 'Item Not As Described',
  DUPLICATE_TRANSACTION: 'Duplicate Transaction',
  SUBSCRIPTION_CANCELLATION: 'Subscription Cancelled',
}

function merchantWorkStatus(d: Dispute): { label: string; color: string; nextAction: string } {
  const ws = d.metadata?.work_status as string | undefined
  const meta = d.metadata as Record<string, unknown>
  // A decision the merchant already made must win over work_status — work_status
  // gets set to RESPONSE_READY at the exact moment of submission
  // (MerchantWorkspace.tsx handleSubmit), which otherwise made this say
  // "Response Ready / Submit" on a case whose response had just been submitted.
  if (d.status === 'APPROVED') return { label: 'Accepted', color: '#616161', nextAction: 'Closed' }
  if (d.status === 'REPRESENTMENT') return { label: 'Challenged', color: '#5c2d91', nextAction: 'Awaiting Issuer' }
  if (meta?.is_pre_dispute) return { label: 'Pre-Dispute Alert', color: '#835b00', nextAction: 'Resolve Now' }
  if (ws === 'EVIDENCE_NEEDED' || ws === 'ACTION_REQUIRED') return { label: 'Action Required', color: '#c50f1f', nextAction: 'Take Action' }
  if (ws === 'UNDER_REVIEW') return { label: 'Under Review', color: '#0078d4', nextAction: 'Review' }
  if (ws === 'RESPONSE_READY') return { label: 'Response Ready', color: '#107c10', nextAction: 'Submit' }
  if (ws === 'SUBMITTED') return { label: 'Submitted', color: '#616161', nextAction: 'Track' }
  return { label: 'New', color: '#ca5010', nextAction: 'Investigate' }
}

function whyNow(d: Dispute): string[] {
  const reasons: string[] = []
  const s = slaDaysLabel(d)
  if (s?.urgent) reasons.push(s.label.startsWith('Overdue') ? 'Deadline overdue' : 'Deadline critically close')
  if (d.priority === 'HIGH' || d.priority === 'CRITICAL') reasons.push(`${d.priority} priority`)
  const amt = Number(d.metadata?.amount_disputed)
  if (!isNaN(amt) && amt > 50000) reasons.push(`High value: ₹${(amt / 1000).toFixed(0)}K`)
  if ((d.metadata as any)?.recommendation_changed) reasons.push('Recommendation just changed')
  if ((d.metadata as any)?.is_pre_dispute) reasons.push('Resolve before chargeback')
  if (reasons.length === 0) reasons.push('Next in your work queue')
  return reasons
}

// ── Components ────────────────────────────────────────────────────────────────

function StatCard({ label, value, icon: Icon, color, sub }:
  { label: string; value: number | string; icon: React.ElementType; color: string; sub?: string }) {
  return (
    <div className="rounded-fluent-lg border p-4"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-medium" style={{ color: 'var(--color-text-muted)' }}>{label}</span>
        <Icon size={14} style={{ color }} />
      </div>
      <div className="text-2xl font-bold" style={{ color }}>{value}</div>
      {sub && <div className="text-xs mt-0.5" style={{ color: 'var(--color-text-muted)' }}>{sub}</div>}
    </div>
  )
}

function ActionBadge({ label, color }: { label: string; color: string }) {
  return (
    <span className="inline-flex items-center text-xs px-2 py-0.5 rounded-full font-medium"
      style={{ background: `${color}14`, color, border: `1px solid ${color}33` }}>
      {label}
    </span>
  )
}

function DisputeRow({ dispute, onClick }: { dispute: Dispute; onClick: () => void }) {
  const dsla = sla(dispute)
  const ws = merchantWorkStatus(dispute)
  const merchant = dispute.metadata?.merchant_name as string | undefined
  const amount = Number(dispute.metadata?.amount_disputed)
  const customer = dispute.metadata?.customer_name as string | undefined

  return (
    <button onClick={onClick}
      className="w-full text-left flex items-center gap-4 p-3 rounded-fluent border transition-all hover:shadow-fluent-sm group"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <div className="w-2 h-2 rounded-full shrink-0"
        style={{ background: PRIORITY_COLOR[dispute.priority] ?? '#616161' }} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>
            {dispute.dispute_id.slice(-6).toUpperCase()}
          </span>
          <span className="text-xs truncate" style={{ color: 'var(--color-text)' }}>
            {DISPUTE_TYPE_LABEL[dispute.dispute_type] ?? dispute.dispute_type}
          </span>
        </div>
        <div className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
          {customer && <span>{customer}</span>}
          {merchant && <span className="ml-2 opacity-70">{merchant}</span>}
        </div>
      </div>
      {!isNaN(amount) && amount > 0 && (
        <span className="text-sm font-semibold shrink-0" style={{ color: 'var(--color-text)' }}>
          ₹{amount.toLocaleString()}
        </span>
      )}
      <span className="text-xs shrink-0" style={{ color: dsla.urgent ? dsla.color : 'var(--color-text-muted)' }}>
        {dsla.label}
      </span>
      <ActionBadge label={ws.nextAction} color={ws.color} />
      <ChevronRight size={14} className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
        style={{ color: 'var(--color-brand)' }} />
    </button>
  )
}

// ── Main ──────────────────────────────────────────────────────────────────────

export function MerchantHome() {
  const navigate = useNavigate()
  const { user } = useAuthStore()

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['merchant-disputes'],
    queryFn: () => disputeApi.list({ page_size: 50 }),
    refetchInterval: 60_000,
  })

  const disputes: Dispute[] = useMemo(() => data?.data?.items ?? [], [data])

  // A case the merchant already decided (accepted or challenged) never belongs
  // in "what should I work on" — sorted by real days_remaining (backend-
  // computed), not a raw-minutes local recomputation.
  const sorted = useMemo(() =>
    disputes.filter(d => !isMerchantDecided(d)).sort((a, b) => {
      const aDays = a.days_remaining ?? 9999
      const bDays = b.days_remaining ?? 9999
      return aDays - bDays
    }), [disputes])

  const open = disputes.filter(d => !isMerchantDecided(d))
  const slaRisk = sorted.filter(d => d.days_remaining !== null && d.days_remaining < 1)
  const actionRequired = sorted.filter(d =>
    ['EVIDENCE_NEEDED', 'ACTION_REQUIRED'].includes((d.metadata as any)?.work_status ?? '')
  )
  const preDisputes = sorted.filter(d => (d.metadata as any)?.is_pre_dispute)
  const overdue = disputes.filter(d => d.days_remaining !== null && d.days_remaining < 0)
  const recommended = sorted[0] ?? null

  const firstName = user?.username?.split('_')[0] ?? user?.username ?? 'Merchant'
  const displayName = firstName.charAt(0).toUpperCase() + firstName.slice(1)

  function goTo(id: string) {
    navigate(`/merchant/disputes/${id}`)
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold" style={{ color: 'var(--color-text)' }}>
            Good morning, {displayName}
          </h1>
          <p className="text-sm mt-0.5" style={{ color: 'var(--color-text-muted)' }}>
            Here's what requires your attention.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {preDisputes.length > 0 && (
            <button onClick={() => navigate('/merchant/alerts')}
              className="flex items-center gap-2 px-3 py-1.5 rounded-fluent text-sm font-medium border"
              style={{ color: '#835b00', borderColor: '#835b0033', background: '#835b0010' }}>
              <Bell size={14} />
              {preDisputes.length} alert{preDisputes.length !== 1 ? 's' : ''}
            </button>
          )}
          <button onClick={() => refetch()} disabled={isFetching}
            className="flex items-center gap-2 px-3 py-1.5 rounded-fluent text-sm border transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
            style={{ color: 'var(--color-text-muted)', borderColor: 'var(--color-border)' }}>
            <RefreshCw size={14} className={isFetching ? 'animate-spin' : ''} />
            Refresh
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-20 rounded-fluent-lg border animate-pulse"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }} />
          ))}
        </div>
      ) : (
        <>
          {/* Stats row */}
          <div className="grid grid-cols-5 gap-3 mb-6">
            <StatCard label="Open Disputes" value={open.length} icon={Activity}
              color="var(--color-brand)" sub={`${disputes.length} total`} />
            <StatCard label="Action Required" value={actionRequired.length} icon={Zap}
              color={actionRequired.length > 0 ? '#c50f1f' : 'var(--color-success)'}
              sub="Need your attention" />
            <StatCard label="SLA At Risk" value={slaRisk.length} icon={AlertTriangle}
              color={slaRisk.length > 0 ? 'var(--color-medium)' : 'var(--color-success)'}
              sub="Deadline approaching" />
            <StatCard label="Overdue" value={overdue.length} icon={Clock}
              color={overdue.length > 0 ? 'var(--color-critical)' : 'var(--color-success)'}
              sub="Past deadline" />
            <StatCard label="Pre-Dispute Alerts" value={preDisputes.length} icon={Bell}
              color={preDisputes.length > 0 ? '#835b00' : 'var(--color-success)'}
              sub="Resolve before chargeback" />
          </div>

          <div className="grid grid-cols-5 gap-6">
            {/* Left: Recommended + All Disputes */}
            <div className="col-span-3 space-y-5">

              {/* Recommended next case */}
              <div data-tour="merchant-recommended">
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles size={14} style={{ color: 'var(--color-brand)' }} />
                  <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                    Recommended Next
                  </h2>
                </div>
                {!recommended ? (
                  <div className="rounded-fluent-lg border p-5 text-center"
                    style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                    <CheckCircle2 size={20} className="mx-auto mb-2" style={{ color: 'var(--color-success)' }} />
                    <p className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>
                      No open cases
                    </p>
                    <p className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>
                      Every dispute in your queue has already been resolved.
                    </p>
                  </div>
                ) : (
                  <div className="rounded-fluent-lg border p-5 cursor-pointer transition-all hover:shadow-fluent"
                    style={{
                      background: 'var(--color-surface)',
                      borderColor: 'var(--color-brand)',
                      borderWidth: '1.5px',
                    }}
                    onClick={() => goTo(recommended.dispute_id)}>
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="w-2 h-2 rounded-full"
                            style={{ background: PRIORITY_COLOR[recommended.priority] ?? '#616161' }} />
                          <span className="font-mono text-xs" style={{ color: 'var(--color-brand)' }}>
                            {recommended.dispute_id.slice(-8).toUpperCase()}
                          </span>
                          {(() => {
                            const s = sla(recommended)
                            return (
                              <span className="text-xs px-2 py-0.5 rounded-full border"
                                style={{ color: s.color, borderColor: s.urgent ? s.color : 'var(--color-border)' }}>
                                <Clock size={9} className="inline mr-1" />
                                {s.label}
                              </span>
                            )
                          })()}
                        </div>
                        <h3 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
                          {DISPUTE_TYPE_LABEL[recommended.dispute_type] ?? recommended.dispute_type}
                        </h3>
                        <div className="flex items-center gap-3 mt-0.5 text-sm" style={{ color: 'var(--color-text-muted)' }}>
                          {!!recommended.metadata?.customer_name && (
                            <span>{recommended.metadata.customer_name as string}</span>
                          )}
                          {!!recommended.metadata?.merchant_name && (
                            <span className="opacity-70">· {recommended.metadata.merchant_name as string}</span>
                          )}
                          {(() => {
                            const amt = Number(recommended.metadata?.amount_disputed)
                            return !isNaN(amt) && amt > 0
                              ? <span className="font-semibold" style={{ color: 'var(--color-text)' }}>₹{amt.toLocaleString()}</span>
                              : null
                          })()}
                        </div>
                      </div>
                      <Button
                        variant="primary"
                        className="shrink-0 ml-4"
                        onClick={e => { e.stopPropagation(); goTo(recommended.dispute_id) }}>
                        Investigate <ArrowRight size={14} />
                      </Button>
                    </div>

                    <div className="pt-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
                      <p className="text-xs font-semibold mb-2" style={{ color: 'var(--color-text-muted)' }}>
                        Why now?
                      </p>
                      <div className="space-y-1">
                        {whyNow(recommended).map((r, i) => (
                          <div key={i} className="flex items-center gap-2 text-xs" style={{ color: 'var(--color-text-muted)' }}>
                            <CheckCircle2 size={11} style={{ color: 'var(--color-brand)', flexShrink: 0 }} />
                            {r}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* All disputes list */}
              {sorted.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <FileText size={14} style={{ color: 'var(--color-text-muted)' }} />
                      <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                        All Disputes
                      </h2>
                    </div>
                    <button onClick={() => navigate('/merchant/disputes')}
                      className="text-xs" style={{ color: 'var(--color-brand)' }}>
                      View queue →
                    </button>
                  </div>
                  <div className="space-y-2">
                    {sorted.slice(0, 6).map(d => (
                      <DisputeRow key={d.dispute_id} dispute={d} onClick={() => goTo(d.dispute_id)} />
                    ))}
                    {sorted.length > 6 && (
                      <button onClick={() => navigate('/merchant/disputes')}
                        className="w-full py-2 text-xs text-center rounded-fluent border transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        style={{ color: 'var(--color-text-muted)', borderColor: 'var(--color-border)' }}>
                        View all {sorted.length} disputes
                      </button>
                    )}
                  </div>
                </div>
              )}

              {sorted.length === 0 && (
                <div className="text-center py-16 rounded-fluent-lg border"
                  style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                  <CheckCircle2 size={32} className="mx-auto mb-3" style={{ color: 'var(--color-success)' }} />
                  <p className="font-medium" style={{ color: 'var(--color-text)' }}>All clear</p>
                  <p className="text-sm mt-1" style={{ color: 'var(--color-text-muted)' }}>
                    No disputes require attention right now.
                  </p>
                </div>
              )}
            </div>

            {/* Right: SLA Risk + Action Required + Pre-Disputes */}
            <div className="col-span-2 space-y-5">

              {/* SLA At Risk */}
              {slaRisk.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <AlertTriangle size={14} style={{ color: 'var(--color-medium)' }} />
                    <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                      SLA At Risk
                    </h2>
                    <span className="ml-auto text-xs px-2 py-0.5 rounded-full"
                      style={{ background: 'rgba(202,80,16,0.1)', color: 'var(--color-medium)' }}>
                      {slaRisk.length}
                    </span>
                  </div>
                  <div className="space-y-2">
                    {slaRisk.slice(0, 4).map(d => {
                      const s = sla(d)
                      return (
                        <button key={d.dispute_id} onClick={() => goTo(d.dispute_id)}
                          className="w-full flex items-center gap-3 p-3 rounded-fluent border text-left transition-all hover:shadow-fluent-sm"
                          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                          <div className="w-1.5 h-1.5 rounded-full shrink-0"
                            style={{ background: PRIORITY_COLOR[d.priority] ?? '#616161' }} />
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>
                              {d.dispute_id.slice(-6).toUpperCase()}
                            </div>
                            <div className="text-xs truncate" style={{ color: 'var(--color-text-muted)' }}>
                              {DISPUTE_TYPE_LABEL[d.dispute_type] ?? d.dispute_type}
                            </div>
                          </div>
                          <span className="text-xs font-medium shrink-0" style={{ color: s.color }}>
                            {s.label}
                          </span>
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Action Required */}
              {actionRequired.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Zap size={14} style={{ color: 'var(--color-critical)' }} />
                    <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                      Action Required
                    </h2>
                  </div>
                  <div className="space-y-2">
                    {actionRequired.slice(0, 4).map(d => {
                      const ws = merchantWorkStatus(d)
                      return (
                        <button key={d.dispute_id} onClick={() => goTo(d.dispute_id)}
                          className="w-full flex items-center gap-3 p-3 rounded-fluent border text-left transition-all hover:shadow-fluent-sm"
                          style={{ background: 'var(--color-surface)', borderColor: `${ws.color}44` }}>
                          <AlertCircle size={14} style={{ color: ws.color, flexShrink: 0 }} />
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>
                              {d.dispute_id.slice(-6).toUpperCase()}
                            </div>
                            <div className="text-xs truncate" style={{ color: 'var(--color-text-muted)' }}>
                              ₹{Number(d.metadata?.amount_disputed || 0).toLocaleString()}
                            </div>
                          </div>
                          <ActionBadge label={ws.nextAction} color={ws.color} />
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Pre-dispute alerts */}
              {preDisputes.length > 0 && (
                <div data-tour="merchant-summary">
                  <div className="flex items-center gap-2 mb-3">
                    <Bell size={14} style={{ color: '#835b00' }} />
                    <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                      Pre-Dispute Alerts
                    </h2>
                  </div>
                  <div className="rounded-fluent-lg border p-3"
                    style={{ background: 'rgba(131,91,0,0.05)', borderColor: 'rgba(131,91,0,0.2)' }}>
                    <p className="text-xs mb-2" style={{ color: '#835b00' }}>
                      {preDisputes.length} customer complaint{preDisputes.length !== 1 ? 's' : ''} may become chargebacks.
                      Resolve now to avoid fees.
                    </p>
                    <button onClick={() => navigate('/merchant/alerts')}
                      className="text-xs font-medium px-3 py-1.5 rounded-fluent"
                      style={{ background: '#835b00', color: 'white' }}>
                      View Alerts
                    </button>
                  </div>
                </div>
              )}

              {/* Recently updated */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp size={14} style={{ color: 'var(--color-text-muted)' }} />
                  <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                    Recently Updated
                  </h2>
                </div>
                <div className="space-y-2">
                  {[...disputes]
                    .sort((a, b) => parseISO(b.updated_at).getTime() - parseISO(a.updated_at).getTime())
                    .slice(0, 3)
                    .map(d => (
                      <button key={d.dispute_id} onClick={() => goTo(d.dispute_id)}
                        className="w-full flex items-center gap-3 p-3 rounded-fluent border text-left transition-all hover:bg-neutral-50 dark:hover:bg-neutral-900"
                        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                        <div className="w-1.5 h-1.5 rounded-full shrink-0"
                          style={{ background: PRIORITY_COLOR[d.priority] ?? '#616161' }} />
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>
                            {d.dispute_id.slice(-6).toUpperCase()}
                          </div>
                          <div className="text-xs truncate" style={{ color: 'var(--color-text-muted)' }}>
                            {d.metadata?.merchant_name as string ?? DISPUTE_TYPE_LABEL[d.dispute_type]}
                          </div>
                        </div>
                        <span className="text-xs shrink-0" style={{ color: 'var(--color-text-subtle)' }}>
                          {formatDistanceToNow(parseISO(d.updated_at), { addSuffix: true })}
                        </span>
                      </button>
                    ))
                  }
                </div>
              </div>

              {/* Merchant shield score */}
              <div className="rounded-fluent-lg border p-4"
                style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                <div className="flex items-center gap-2 mb-2">
                  <Shield size={14} style={{ color: 'var(--color-brand)' }} />
                  <span className="text-xs font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                    Dispute Performance
                  </span>
                </div>
                <div className="flex items-end gap-3">
                  <div className="text-2xl font-bold" style={{ color: '#107c10' }}>72%</div>
                  <div className="text-xs mb-0.5" style={{ color: 'var(--color-text-muted)' }}>win rate (last 30d)</div>
                </div>
                <div className="mt-2 w-full h-1.5 rounded-full overflow-hidden"
                  style={{ background: 'var(--color-border)' }}>
                  <div className="h-full rounded-full" style={{ width: '72%', background: '#107c10' }} />
                </div>
                <button onClick={() => navigate('/merchant/insights')}
                  className="mt-2 text-xs" style={{ color: 'var(--color-brand)' }}>
                  View full insights →
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
