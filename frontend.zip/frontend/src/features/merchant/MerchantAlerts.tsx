import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Bell, Zap, Clock, ChevronRight, CheckCircle2, RefreshCw } from 'lucide-react'
import { disputeApi, actionApi } from '@/services/api'
import type { Dispute } from '@/types'
import { differenceInMinutes, format, parseISO } from 'date-fns'
import toast from 'react-hot-toast'
import { Button, PageHeader } from '@/components/ui'

// ── Helpers ───────────────────────────────────────────────────────────────────

function slaMinutes(d: Dispute): number | null {
  if (!d.deadline) return null
  return differenceInMinutes(parseISO(d.deadline), new Date())
}

function slaDisplay(mins: number | null): { label: string; color: string } {
  if (mins === null) return { label: 'No deadline', color: 'var(--color-text-muted)' }
  if (mins < 0) return { label: 'Overdue', color: '#c50f1f' }
  if (mins < 60) return { label: `${mins}m`, color: '#c50f1f' }
  if (mins < 240) return { label: `${Math.floor(mins / 60)}h ${mins % 60}m`, color: '#ca5010' }
  return { label: `${Math.floor(mins / 60)}h`, color: 'var(--color-text-muted)' }
}

const DISPUTE_TYPE_LABEL: Record<string, string> = {
  UNAUTHORIZED_TRANSACTION: 'Unauthorized Transaction',
  MERCHANDISE_NOT_RECEIVED: 'Merchandise Not Received',
  REFUND_NOT_PROCESSED: 'Refund Not Processed',
  MERCHANDISE_NOT_AS_DESCRIBED: 'Item Not As Described',
  DUPLICATE_TRANSACTION: 'Duplicate Transaction',
}

function severity(d: Dispute): 'high' | 'medium' | 'low' {
  const mins = slaMinutes(d)
  if (mins !== null && mins < 120) return 'high'
  const amount = Number(d.metadata?.amount_disputed ?? 0)
  if (amount > 50000) return 'high'
  if (amount > 10000 || (mins !== null && mins < 480)) return 'medium'
  return 'low'
}

const SEVERITY_CONFIG = {
  high: { label: 'High', color: '#c50f1f', bg: 'rgba(197,15,31,0.06)', border: '#c50f1f33' },
  medium: { label: 'Medium', color: '#ca5010', bg: 'rgba(202,80,16,0.06)', border: '#ca501033' },
  low: { label: 'Low', color: '#835b00', bg: 'rgba(131,91,0,0.06)', border: '#835b0033' },
}

// ── Alert Card ────────────────────────────────────────────────────────────────

function AlertCard({ dispute, onResolved }: { dispute: Dispute; onResolved: () => void }) {
  const navigate = useNavigate()
  const [resolving, setResolving] = useState(false)
  const [resolved, setResolved] = useState(false)

  const sev = severity(dispute)
  const sevCfg = SEVERITY_CONFIG[sev]
  const mins = slaMinutes(dispute)
  const sla = slaDisplay(mins)
  const amount = Number(dispute.metadata?.amount_disputed ?? 0)

  // recommendation_type lives on the Recommendation entity, not dispute.metadata
  const { data: recommendationRes } = useQuery({
    queryKey: ['recommendation', dispute.dispute_id],
    queryFn: () => disputeApi.getRecommendation(dispute.dispute_id),
    retry: false,
  })
  const rec = recommendationRes?.data?.recommendation_type as string | undefined

  const refundable = rec === 'RESOLVE_PRE_DISPUTE'

  async function handleQuickResolve() {
    setResolving(true)
    try {
      await actionApi.propose(dispute.dispute_id, {
        action_type: 'ACCEPT_DISPUTE',
        action_class: 'CLASS_B',
        idempotency_key: crypto.randomUUID(),
        input: { response_text: 'Pre-dispute resolved — refund/replacement issued before chargeback filing.' },
      })
      setResolved(true)
      toast.success('Alert resolved — chargeback avoided')
      onResolved()
    } catch {
      toast.error('Failed to resolve alert')
    } finally {
      setResolving(false)
    }
  }

  if (resolved) return null

  return (
    <div className="rounded-fluent-lg border overflow-hidden transition-all"
      style={{ borderColor: sevCfg.border, background: sevCfg.bg }}>
      <div className="px-4 py-3 flex items-start gap-4">
        {/* Icon */}
        <div className="w-10 h-10 rounded-fluent shrink-0 flex items-center justify-center mt-0.5"
          style={{ background: `${sevCfg.color}18` }}>
          <Zap size={18} style={{ color: sevCfg.color }} />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-3 mb-1">
            <div>
              <span className="text-xs px-2 py-0.5 rounded-full font-medium mr-2"
                style={{ background: `${sevCfg.color}20`, color: sevCfg.color }}>
                {sevCfg.label} priority
              </span>
              <span className="text-xs font-mono" style={{ color: 'var(--color-text-muted)' }}>
                {dispute.dispute_id.slice(-8).toUpperCase()}
              </span>
            </div>
            <div className="text-right shrink-0">
              <div className="text-base font-bold" style={{ color: 'var(--color-text)' }}>
                ₹{amount.toLocaleString()}
              </div>
              <div className="text-xs" style={{ color: sla.color }}>
                <Clock size={11} className="inline mr-0.5" />
                {sla.label}
              </div>
            </div>
          </div>

          <h3 className="text-sm font-semibold mb-0.5" style={{ color: 'var(--color-text)' }}>
            {DISPUTE_TYPE_LABEL[dispute.dispute_type] ?? dispute.dispute_type}
          </h3>

          {dispute.cardholder_claim && (
            <p className="text-xs italic mb-2" style={{ color: 'var(--color-text-muted)' }}>
              "{dispute.cardholder_claim.length > 120
                ? dispute.cardholder_claim.slice(0, 120) + '…'
                : dispute.cardholder_claim}"
            </p>
          )}

          {/* Resolution options */}
          <div className="flex items-center gap-2 flex-wrap">
            {refundable && (
              <Button
                variant="primary"
                size="sm"
                style={{ background: 'var(--color-success)' }}
                onClick={handleQuickResolve}
                loading={resolving}>
                {resolving ? 'Resolving…' : <><CheckCircle2 size={11} /> Issue Refund</>}
              </Button>
            )}
            <Button
              variant="secondary"
              size="sm"
              onClick={() => navigate(`/merchant/disputes/${dispute.dispute_id}`)}>
              <ChevronRight size={11} /> View Case
            </Button>
          </div>
        </div>
      </div>

      {/* Details strip */}
      <div className="px-4 py-2 border-t flex items-center gap-4 text-xs"
        style={{ borderColor: sevCfg.border, background: `${sevCfg.color}06` }}>
        <span style={{ color: 'var(--color-text-muted)' }}>
          Customer: <strong style={{ color: 'var(--color-text)' }}>{dispute.metadata?.customer_name as string ?? '—'}</strong>
        </span>
        <span style={{ color: 'var(--color-text-muted)' }}>
          Merchant: <strong style={{ color: 'var(--color-text)' }}>{dispute.metadata?.merchant_name as string ?? '—'}</strong>
        </span>
        {dispute.deadline && (
          <span style={{ color: 'var(--color-text-muted)' }} className="ml-auto">
            Deadline: <strong style={{ color: 'var(--color-text)' }}>
              {format(parseISO(dispute.deadline), 'd MMM HH:mm')}
            </strong>
          </span>
        )}
      </div>
    </div>
  )
}

// ── Main ─────────────────────────────────────────────────────────────────────

export function MerchantAlerts() {
  const [resolvedIds, setResolvedIds] = useState<string[]>([])
  const [filterSev, setFilterSev] = useState<'all' | 'high' | 'medium' | 'low'>('all')

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['merchant-alerts'],
    queryFn: () => disputeApi.list({ page_size: 100 }),
    refetchInterval: 30_000,
  })

  const allDisputes: Dispute[] = useMemo(() => data?.data?.items ?? [], [data])

  const alerts = useMemo(() =>
    allDisputes
      .filter(d => (d.metadata as any)?.is_pre_dispute && !resolvedIds.includes(d.dispute_id))
      .sort((a, b) => {
        const sevOrder = { high: 0, medium: 1, low: 2 }
        const diff = sevOrder[severity(a)] - sevOrder[severity(b)]
        if (diff !== 0) return diff
        const aMin = slaMinutes(a) ?? 9999
        const bMin = slaMinutes(b) ?? 9999
        return aMin - bMin
      })
  , [allDisputes, resolvedIds])

  const counts = useMemo(() => ({
    all: alerts.length,
    high: alerts.filter(d => severity(d) === 'high').length,
    medium: alerts.filter(d => severity(d) === 'medium').length,
    low: alerts.filter(d => severity(d) === 'low').length,
  }), [alerts])

  const filtered = useMemo(() =>
    filterSev === 'all' ? alerts : alerts.filter(d => severity(d) === filterSev)
  , [alerts, filterSev])

  const totalExposure = useMemo(() =>
    alerts.reduce((sum, d) => sum + Number(d.metadata?.amount_disputed ?? 0), 0)
  , [alerts])

  return (
    <div className="p-6 max-w-5xl mx-auto">

      <PageHeader
        icon={<Bell size={18} />}
        title="Pre-Dispute Alerts"
        description="Resolve these disputes before they become formal chargebacks"
        actions={
          <Button variant="secondary" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw size={14} className={isFetching ? 'animate-spin' : ''} />
            Refresh
          </Button>
        }
      />

      {/* Summary banner */}
      {alerts.length > 0 && (
        <div className="rounded-fluent-lg border p-4 mb-5 flex items-center gap-6"
          style={{ borderColor: '#835b0033', background: 'rgba(131,91,0,0.05)' }}>
          <div className="text-center">
            <div className="text-2xl font-bold" style={{ color: '#835b00' }}>{alerts.length}</div>
            <div className="text-xs" style={{ color: 'var(--color-text-muted)' }}>Active Alerts</div>
          </div>
          <div className="h-10 w-px" style={{ background: 'var(--color-border)' }} />
          <div className="text-center">
            <div className="text-2xl font-bold" style={{ color: '#c50f1f' }}>{counts.high}</div>
            <div className="text-xs" style={{ color: 'var(--color-text-muted)' }}>High Priority</div>
          </div>
          <div className="h-10 w-px" style={{ background: 'var(--color-border)' }} />
          <div className="text-center">
            <div className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>₹{totalExposure.toLocaleString()}</div>
            <div className="text-xs" style={{ color: 'var(--color-text-muted)' }}>Total Exposure</div>
          </div>
          <div className="ml-auto text-xs text-right" style={{ color: 'var(--color-text-muted)' }}>
            <p>Resolving pre-disputes avoids</p>
            <p>chargeback fees (~₹750 per dispute)</p>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        {(['all', 'high', 'medium', 'low'] as const).map(sev => (
          <button key={sev}
            onClick={() => setFilterSev(sev)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-fluent text-xs font-medium border transition-all capitalize"
            style={{
              background: filterSev === sev ? 'var(--color-brand)' : 'var(--color-surface)',
              color: filterSev === sev ? 'white' : 'var(--color-text-muted)',
              borderColor: filterSev === sev ? 'var(--color-brand)' : 'var(--color-border)',
            }}>
            {sev === 'all' ? 'All Alerts' : `${sev.charAt(0).toUpperCase() + sev.slice(1)} Priority`}
            <span className="rounded-full px-1.5 text-2xs font-bold"
              style={{
                background: filterSev === sev ? 'rgba(255,255,255,0.2)' : 'var(--color-brand-light)',
                color: filterSev === sev ? 'white' : 'var(--color-brand)',
              }}>
              {sev === 'all' ? counts.all : counts[sev]}
            </span>
          </button>
        ))}
      </div>

      {/* Alert list */}
      {isLoading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-32 rounded-fluent-lg border animate-pulse"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }} />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20 rounded-fluent-lg border"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
          <CheckCircle2 size={32} className="mx-auto mb-3" style={{ color: '#107c10' }} />
          <h3 className="font-semibold text-base mb-1" style={{ color: 'var(--color-text)' }}>
            {alerts.length === 0 ? 'No pre-dispute alerts' : 'No alerts match this filter'}
          </h3>
          <p className="text-sm" style={{ color: 'var(--color-text-muted)' }}>
            {alerts.length === 0
              ? 'All disputes have been resolved or no pre-dispute alerts exist.'
              : 'Try selecting a different priority filter.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(d => (
            <AlertCard
              key={d.dispute_id}
              dispute={d}
              onResolved={() => setResolvedIds(ids => [...ids, d.dispute_id])}
            />
          ))}
        </div>
      )}
    </div>
  )
}
