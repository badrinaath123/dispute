import { useState, useMemo, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  Clock, AlertTriangle, CheckCircle2, AlertCircle,
  ChevronDown, ChevronUp, ChevronRight, Search, Send, FileText,
  CreditCard, MessageSquare, Shield,
  TrendingUp, Info, Eye,
  Sparkles, ThumbsUp, ThumbsDown, HelpCircle, Activity, Loader2, FileUp
} from 'lucide-react'
import { disputeApi, evidenceApi, actionApi, agentApi } from '@/services/api'
import type { Dispute, Evidence, Hypothesis, Contradiction, Recommendation, EvidenceGap } from '@/types'
import { format, parseISO, differenceInMinutes, formatDistanceToNow } from 'date-fns'
import clsx from 'clsx'
import toast from 'react-hot-toast'
import { Button, EvidenceBalanceBar, DocumentPreviewModal } from '@/components/ui'
import { useDocumentPreview } from '@/hooks/useDocumentPreview'
import { MERCHANT_DECIDED_STATUSES, isMerchantDecided } from '@/lib/disputeStatus'
import { evidenceLabel } from '@/lib/evidenceLabel'
import { ScenarioTimeline } from '@/components/ScenarioTimeline'

// ══════════════════════════════════════════════════════════════════════════════
// Constants and helpers
// ══════════════════════════════════════════════════════════════════════════════

const DISPUTE_TYPE_LABEL: Record<string, string> = {
  UNAUTHORIZED_TRANSACTION: 'Unauthorized Transaction',
  MERCHANDISE_NOT_RECEIVED: 'Merchandise Not Received',
  REFUND_NOT_PROCESSED: 'Refund Not Processed',
  MERCHANDISE_NOT_AS_DESCRIBED: 'Item Not As Described',
  DUPLICATE_TRANSACTION: 'Duplicate Transaction',
  SUBSCRIPTION_CANCELLATION: 'Subscription Cancelled',
}

// README §62: this used to be keyed CHALLENGE/ACCEPT/INVESTIGATE/INSUFFICIENT_EVIDENCE
// — none of which the real agent ever produces. packages/agent/prompts.py's
// PREPARE_RECOMMENDATION format is exactly UPHOLD_DISPUTE | DENY_DISPUTE | ESCALATE |
// REQUEST_EVIDENCE (confirmed against the live prompt), so the lookup below always
// missed and silently fell back to the ESCALATE-shaped entry regardless of what was
// actually recommended — and, far worse, the Accept/Override buttons further down
// compared against the same dead 'ACCEPT' string, so "Accept Recommendation" always
// submitted CHALLENGE no matter what the AI said.
const REC_CONFIG: Record<string, { label: string; description: string; icon: React.ElementType; color: string; bgColor: string }> = {
  DENY_DISPUTE: {
    label: 'Challenge Chargeback',
    description: 'The evidence supports your position. File a representment.',
    icon: ThumbsUp,
    color: '#107c10',
    bgColor: 'rgba(16,124,16,0.06)',
  },
  UPHOLD_DISPUTE: {
    label: 'Accept Chargeback',
    description: 'The customer\'s claim is valid. Accepting is the right decision.',
    icon: ThumbsDown,
    color: '#c50f1f',
    bgColor: 'rgba(197,15,31,0.06)',
  },
  ESCALATE: {
    label: 'Investigate Further',
    description: 'The evidence is genuinely balanced — resolve it before deciding how to respond.',
    icon: Search,
    color: '#ca5010',
    bgColor: 'rgba(202,80,16,0.06)',
  },
  REQUEST_EVIDENCE: {
    label: 'Find More Evidence',
    description: 'A decisive piece of evidence is missing before a response can be filed.',
    icon: AlertCircle,
    color: '#835b00',
    bgColor: 'rgba(131,91,0,0.06)',
  },
}

// Polls the real agent run status (packages/agent — same run DisputeCommandCenter
// tracks via SSE + a polling backstop, README §44) rather than guessing a fixed
// delay before assuming a newly uploaded document has been "compared against the
// case". Simpler than that SSE plumbing (no live node-by-node progress needed
// here), but grounded in the same real completion signal.
//
// README §75: was capped at 90s, which is too short for what a real run actually
// does — packages/agent/nodes.py makes 6 sequential LLM calls (understand_dispute,
// assess_evidence, generate_hypotheses, prepare_recommendation, propose_actions,
// finalize), and this app's own corporate LLM proxy has been directly measured
// taking 60-75s on a single call under load (README §57). A 90s total budget for 6
// calls could time out well before the run actually finished — this function would
// then give up and invalidate queries too early, showing the still-stale
// recommendation and never checking again, which read as "uploading didn't do
// anything" even though the real run was still quietly working in the background.
async function waitForAgentRun(disputeId: string, maxWaitMs = 300000): Promise<'COMPLETED' | 'FAILED' | 'TIMEOUT'> {
  const start = Date.now()
  while (Date.now() - start < maxWaitMs) {
    await new Promise((r) => setTimeout(r, 3000))
    try {
      const r = await agentApi.status(disputeId)
      if (r.data.status === 'COMPLETED' || r.data.status === 'FAILED') return r.data.status
    } catch {
      // keep polling — a transient failure here shouldn't abandon the wait
    }
  }
  return 'TIMEOUT'
}

function firstSentence(text: string, maxLen = 180): string {
  const cut = text.search(/[.!?](\s|$)/)
  const sentence = cut === -1 ? text : text.slice(0, cut + 1)
  return sentence.length > maxLen ? `${sentence.slice(0, maxLen).trimEnd()}…` : sentence
}

function slaMinutes(d: Dispute): number | null {
  if (!d.deadline) return null
  return differenceInMinutes(parseISO(d.deadline), new Date())
}

function slaDisplay(mins: number | null): { label: string; color: string; urgent: boolean } {
  if (mins === null) return { label: 'No deadline', color: 'var(--color-text-muted)', urgent: false }
  if (mins < 0) return { label: 'Overdue', color: '#c50f1f', urgent: true }
  if (mins < 60) return { label: `${mins}m remaining`, color: '#c50f1f', urgent: true }
  if (mins < 240) { const h = Math.floor(mins / 60), m = mins % 60; return { label: `${h}h ${m}m remaining`, color: '#ca5010', urgent: true } }
  return { label: `${Math.floor(mins / 60)}h remaining`, color: 'var(--color-text-muted)', urgent: false }
}

// ══════════════════════════════════════════════════════════════════════════════
// Sub-components
// ══════════════════════════════════════════════════════════════════════════════

function Panel({ title, icon: Icon, children, badge, collapsible = false, defaultOpen = true, accent }:
  { title: string; icon: React.ElementType; children: React.ReactNode; badge?: string; collapsible?: boolean; defaultOpen?: boolean; accent?: string }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="rounded-fluent-lg border overflow-hidden shadow-fluent-sm"
      style={{ borderColor: accent ? `${accent}44` : 'var(--color-border)', background: 'var(--color-surface)' }}>
      <div
        className={clsx('flex items-center gap-2 px-4 py-3', collapsible && 'cursor-pointer select-none')}
        style={{ borderBottom: open ? `1px solid var(--color-border)` : undefined, background: accent ? `${accent}08` : undefined }}
        onClick={collapsible ? () => setOpen(o => !o) : undefined}>
        <Icon size={14} style={{ color: accent ?? 'var(--color-brand)' }} />
        <span className="text-sm font-semibold flex-1" style={{ color: 'var(--color-text)' }}>{title}</span>
        {badge && (
          <span className="text-xs px-2 py-0.5 rounded-full font-medium"
            style={{ background: `${accent ?? '#0078d4'}14`, color: accent ?? '#0078d4' }}>
            {badge}
          </span>
        )}
        {collapsible && (open ? <ChevronUp size={14} style={{ color: 'var(--color-text-muted)' }} /> : <ChevronDown size={14} style={{ color: 'var(--color-text-muted)' }} />)}
      </div>
      {open && <div className="p-4">{children}</div>}
    </div>
  )
}

function EvidenceItem({ evidence, variant, onView, loadingDocId }: {
  evidence: Evidence; variant: 'support' | 'hurt' | 'neutral'
  onView?: (documentId: string, fileName: string) => void; loadingDocId?: string | null
}) {
  const [expanded, setExpanded] = useState(false)
  const color = variant === 'support' ? '#107c10' : variant === 'hurt' ? '#ca5010' : '#616161'
  const content = evidence.normalized_content as Record<string, unknown> | undefined
  const documentId = content?.documentId as string | undefined
  const fileName = content?.fileName as string | undefined
  const textSummary = content?.textSummary as string | undefined
  const documentTitle = content?.documentTitle as string | undefined
  const label = evidenceLabel(evidence.evidence_type, textSummary, documentTitle)

  return (
    <div className="rounded-fluent border"
      style={{ borderColor: `${color}22`, background: `${color}06` }}>
      <button onClick={() => setExpanded(e => !e)}
        className="w-full flex items-center gap-3 px-3 py-2.5 text-left">
        <span className="w-5 h-5 rounded-full flex items-center justify-center shrink-0"
          style={{ background: `${color}20` }}>
          {variant === 'support' ? <CheckCircle2 size={12} style={{ color }} /> :
           variant === 'hurt' ? <AlertTriangle size={12} style={{ color }} /> :
           <Info size={12} style={{ color }} />}
        </span>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-medium" style={{ color: 'var(--color-text)' }}>{label}</div>
          <div className="text-2xs" style={{ color: 'var(--color-text-muted)' }}>
            {evidence.source_system} · {evidence.materiality} materiality
          </div>
        </div>
        <span className="text-2xs px-1.5 py-0.5 rounded font-medium shrink-0"
          style={{ background: `${color}20`, color }}>
          {evidence.quality}
        </span>
        {expanded ? <ChevronUp size={12} style={{ color: 'var(--color-text-muted)' }} /> : <ChevronDown size={12} style={{ color: 'var(--color-text-muted)' }} />}
      </button>
      {expanded && (
        <div className="px-3 pb-3 pt-0">
          {documentId ? (
            <div className="flex items-center justify-between gap-3 rounded p-2"
              style={{ background: 'var(--color-bg)' }}>
              {textSummary ? (
                <p className="text-xs flex-1" style={{ color: 'var(--color-text-muted)' }}>{textSummary}</p>
              ) : (
                <p className="text-xs flex-1 italic" style={{ color: 'var(--color-text-subtle)' }}>No summary available.</p>
              )}
              {onView && (
                <button
                  onClick={() => onView(documentId, fileName ?? label)}
                  disabled={loadingDocId === documentId}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-fluent text-2xs font-medium border shrink-0 transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
                  style={{ color: 'var(--color-brand)', borderColor: 'rgba(0,120,212,0.35)' }}>
                  {loadingDocId === documentId ? <Loader2 size={11} className="animate-spin" /> : <Eye size={11} />}
                  View document
                </button>
              )}
            </div>
          ) : (
            <div className="text-xs rounded p-2 overflow-x-auto font-mono"
              style={{ background: 'var(--color-bg)', color: 'var(--color-text-muted)', maxHeight: 180 }}>
              {JSON.stringify(evidence.normalized_content, null, 2)}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function GapItem({ gap }: { gap: EvidenceGap }) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-fluent border"
      style={{ borderColor: '#835b0033', background: 'rgba(131,91,0,0.05)' }}>
      <AlertCircle size={14} style={{ color: '#835b00', marginTop: 1, flexShrink: 0 }} />
      <div>
        <div className="text-xs font-medium" style={{ color: 'var(--color-text)' }}>
          {gap.expected_evidence_type?.replace(/_/g, ' ') ?? gap.gap_type.replace(/_/g, ' ')}
        </div>
        {gap.description && (
          <div className="text-xs mt-0.5" style={{ color: 'var(--color-text-muted)' }}>{gap.description}</div>
        )}
        {gap.expected_source && (
          <div className="text-2xs mt-1" style={{ color: '#835b00' }}>
            Expected from: {gap.expected_source}
          </div>
        )}
      </div>
      <span className="text-2xs px-1.5 py-0.5 rounded ml-auto shrink-0 font-medium"
        style={{ background: 'rgba(131,91,0,0.15)', color: '#835b00' }}>
        {gap.materiality}
      </span>
    </div>
  )
}

function ContradictionItem({ contradiction }: { contradiction: Contradiction }) {
  return (
    <div className="rounded-fluent border p-3"
      style={{ borderColor: '#d1343833', background: 'rgba(209,52,56,0.04)' }}>
      <div className="flex items-center gap-2 mb-2">
        <AlertTriangle size={13} style={{ color: '#d13438', flexShrink: 0 }} />
        <span className="text-xs font-semibold" style={{ color: '#d13438' }}>
          {contradiction.conflict_type?.replace(/_/g, ' ') ?? 'Contradiction'}
        </span>
        <span className="text-2xs px-1.5 py-0.5 rounded ml-auto"
          style={{ background: 'rgba(209,52,56,0.12)', color: '#d13438' }}>
          {contradiction.materiality}
        </span>
      </div>
      <p className="text-xs" style={{ color: 'var(--color-text)' }}>{contradiction.description}</p>
    </div>
  )
}

// ── Response Builder ──────────────────────────────────────────────────────────

function ResponseBuilder({ dispute, evidence, recommendation, decision, onCancel, onSubmitted }:
  { dispute: Dispute; evidence: Evidence[]; recommendation: Recommendation | null;
    decision: 'CHALLENGE' | 'ACCEPT'; onCancel: () => void; onSubmitted: () => void }) {

  const qc = useQueryClient()
  const [responseText, setResponseText] = useState(() => {
    // A placeholder only — real drafting is "Generate with AI" (or the automatic
    // redraft after uploading evidence), which calls representment.py's actual
    // drafting prompt and is held to a 100-150 word limit there. Used to dump
    // recommendation.content — the AI's full internal reasoning, written for an
    // analyst, not a letter — wholesale into this box, which read as "good content,
    // way too long" even before a real draft was ever generated.
    if (decision === 'CHALLENGE' && recommendation) {
      return `We are challenging this chargeback on the following grounds: ${firstSentence(recommendation.content)}\n\nSupporting evidence is attached. Click "Generate with AI" for a full drafted response.`
    }
    return `We are accepting this chargeback.\n\nReason: Customer's claim has been reviewed and found to be valid.`
  })
  const [overrideReason, setOverrideReason] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [steps, setSteps] = useState<{ label: string; done: boolean }[]>([])
  const [draftCitations, setDraftCitations] = useState<{ source: string; page: number | null }[]>([])

  // The merchant challenging a chargeback needs to be able to attach the actual
  // rebuttal document (e.g. the cancellation policy proving a cutoff date) right here
  // while building the response — previously the only upload control lived in the
  // separate Evidence Intelligence panel, disconnected from the challenge flow itself.
  // No document-type picker: the merchant just uploads, and the backend's real vision
  // classification (disputes.py's upload_document — no document_type sent means it
  // trusts its own classification instead of a caller guess) identifies what it is.
  // After attaching, this re-runs the actual agent analysis (same pipeline the issuer
  // side runs) so the new document is genuinely compared against the rest of the case
  // — not just filed — and then regenerates the response draft from the refreshed
  // recommendation, so "Build Challenge Response" reflects the new evidence without
  // a separate manual step. Deliberately slow (a real agent run, not instant): the
  // upload button stays busy through the whole analyse-and-redraft cycle so that's
  // visible rather than silent.
  const [challengeUploadPhase, setChallengeUploadPhase] = useState<'idle' | 'uploading' | 'analyzing'>('idle')
  const challengeFileInputRef = useRef<HTMLInputElement>(null)

  function invalidateChallengeQueries() {
    for (const key of ['merchant-dispute', 'merchant-evidence', 'merchant-hypotheses',
      'merchant-contradictions', 'merchant-recommendation', 'merchant-gaps', 'merchant-changes']) {
      qc.invalidateQueries({ queryKey: [key, dispute.dispute_id] })
    }
  }

  async function handleUploadChallengeEvidence(file: File) {
    setChallengeUploadPhase('uploading')
    try {
      await disputeApi.uploadDocument(dispute.dispute_id, file)
    } catch (e: any) {
      const detail = e?.response?.data?.detail as string | undefined
      toast.error(detail?.startsWith('Cyera Validation') ? detail : `Could not attach ${file.name}`)
      setChallengeUploadPhase('idle')
      return
    }
    invalidateChallengeQueries()
    setChallengeUploadPhase('analyzing')
    toast.success(`${file.name} attached — comparing it against the case and updating your response…`, { duration: 5000 })
    try {
      await agentApi.run(dispute.dispute_id)
      await waitForAgentRun(dispute.dispute_id)
      invalidateChallengeQueries()
      const r = await disputeApi.representmentDraft(dispute.dispute_id)
      setResponseText(r.data.draft_text)
      setDraftCitations(r.data.citations)
      toast.success('Response draft updated with the new evidence')
    } catch {
      toast.error('Document attached, but the automatic re-draft failed — use "Generate with AI" to try again')
    } finally {
      setChallengeUploadPhase('idle')
    }
  }

  const draftMutation = useMutation({
    mutationFn: () => disputeApi.representmentDraft(dispute.dispute_id),
    onSuccess: (r) => {
      setResponseText(r.data.draft_text)
      setDraftCitations(r.data.citations)
      toast.success('Draft generated — grounded in the uploaded scheme rulebooks')
    },
    onError: () => toast.error('Could not generate a draft'),
  })

  // README §62: was comparing against 'ACCEPT'/'CHALLENGE', which recommendation_type
  // never actually is (real values: UPHOLD_DISPUTE/DENY_DISPUTE/ESCALATE/
  // REQUEST_EVIDENCE) — isOverride was always false, so a genuine override never got
  // flagged as one anywhere this value is used (e.g. the override_reason requirement).
  const recommendedDecision = recommendation?.recommendation_type
  const isOverride = decision === 'CHALLENGE' ? recommendedDecision === 'UPHOLD_DISPUTE' : recommendedDecision === 'DENY_DISPUTE'

  const supportingEvidence = useMemo(() => {
    const ids = (recommendation as any)?.supporting_evidence_ids as string[] | undefined
    if (!ids?.length) return evidence.slice(0, 3)
    return evidence.filter(e => ids.includes(e.evidence_id))
  }, [evidence, recommendation])

  async function handleSubmit() {
    setIsSubmitting(true)
    const stepList = [
      { label: 'Validating dispute', done: false },
      { label: 'Checking evidence', done: false },
      { label: 'Checking requirements', done: false },
      { label: 'Preparing response', done: false },
      { label: 'Submitting', done: false },
    ]
    setSteps(stepList)

    for (let i = 0; i < stepList.length; i++) {
      await new Promise(r => setTimeout(r, 500 + Math.random() * 400))
      setSteps(prev => prev.map((s, idx) => idx <= i ? { ...s, done: true } : s))
    }

    try {
      await actionApi.propose(dispute.dispute_id, {
        action_type: decision === 'CHALLENGE' ? 'CHALLENGE_REPRESENTMENT' : 'ACCEPT_DISPUTE',
        action_class: decision === 'CHALLENGE' ? 'CLASS_C' : 'CLASS_B',
        idempotency_key: crypto.randomUUID(),
        input: {
          response_text: responseText,
          dispute_decision: decision,
          evidence_ids: supportingEvidence.map(e => e.evidence_id),
          override_reason: isOverride ? overrideReason : undefined,
        },
      })
      // Close the loop back to the issuer side: move the case out of the
      // merchant's action-required queue and record the response status.
      await disputeApi.update(dispute.dispute_id, {
        status: decision === 'CHALLENGE' ? 'REPRESENTMENT' : 'APPROVED',
        metadata: { work_status: 'RESPONSE_READY' },
      })
      setSubmitted(true)
      qc.invalidateQueries({ queryKey: ['merchant-dispute', dispute.dispute_id] })
      qc.invalidateQueries({ queryKey: ['merchant-disputes-queue'] })
      toast.success('Response submitted successfully')
    } catch {
      toast.error('Submission failed — please try again')
    } finally {
      setIsSubmitting(false)
    }
  }

  if (submitted) {
    return (
      <Panel title="Response Submitted" icon={CheckCircle2} accent="#107c10">
        <div className="text-center py-6">
          <div className="w-14 h-14 rounded-full mx-auto mb-4 flex items-center justify-center"
            style={{ background: 'rgba(16,124,16,0.1)' }}>
            <CheckCircle2 size={28} style={{ color: '#107c10' }} />
          </div>
          <h3 className="font-semibold text-base mb-1" style={{ color: 'var(--color-text)' }}>Response Submitted</h3>
          <p className="text-sm mb-4" style={{ color: 'var(--color-text-muted)' }}>
            {dispute.dispute_id.slice(-8).toUpperCase()} · Awaiting decision
          </p>
          <button onClick={onSubmitted}
            className="px-4 py-2 rounded-fluent text-sm border transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
            style={{ color: 'var(--color-text-muted)', borderColor: 'var(--color-border)' }}>
            Back to Case
          </button>
        </div>
      </Panel>
    )
  }

  if (isSubmitting) {
    return (
      <Panel title="Submitting Response" icon={Send} accent="#0078d4">
        <div className="space-y-2 py-2">
          {steps.map((step, i) => (
            <div key={i} className="flex items-center gap-3">
              {step.done
                ? <CheckCircle2 size={16} style={{ color: '#107c10', flexShrink: 0 }} />
                : <div className="w-4 h-4 rounded-full border-2 border-t-brand animate-spin shrink-0"
                    style={{ borderColor: 'var(--color-border)', borderTopColor: 'var(--color-brand)' }} />
              }
              <span className="text-sm" style={{ color: step.done ? 'var(--color-text)' : 'var(--color-text-muted)' }}>
                {step.label}
              </span>
            </div>
          ))}
        </div>
      </Panel>
    )
  }

  return (
    <Panel title={decision === 'CHALLENGE' ? 'Build Challenge Response' : 'Accept Chargeback'} icon={Send}
      accent={decision === 'CHALLENGE' ? '#107c10' : '#c50f1f'}>
      <div className="space-y-4">
        {/* Decision badge */}
        <div className="flex items-center gap-2 p-3 rounded-fluent border"
          style={{
            borderColor: decision === 'CHALLENGE' ? '#107c1044' : '#c50f1f44',
            background: decision === 'CHALLENGE' ? 'rgba(16,124,16,0.06)' : 'rgba(197,15,31,0.06)',
          }}>
          {decision === 'CHALLENGE'
            ? <ThumbsUp size={16} style={{ color: '#107c10' }} />
            : <ThumbsDown size={16} style={{ color: '#c50f1f' }} />}
          <span className="text-sm font-semibold"
            style={{ color: decision === 'CHALLENGE' ? '#107c10' : '#c50f1f' }}>
            {decision === 'CHALLENGE' ? 'Challenging this chargeback' : 'Accepting this chargeback'}
          </span>
        </div>

        {/* AI override reason */}
        {isOverride && (
          <div className="p-3 rounded-fluent border"
            style={{ borderColor: '#ca501044', background: 'rgba(202,80,16,0.05)' }}>
            <p className="text-xs font-medium mb-2" style={{ color: '#ca5010' }}>
              You are overriding the AI recommendation. Please provide a reason:
            </p>
            <select
              value={overrideReason}
              onChange={e => setOverrideReason(e.target.value)}
              className="w-full text-xs rounded-fluent border px-2 py-1.5 bg-transparent"
              style={{ borderColor: 'var(--color-border)', color: 'var(--color-text)' }}>
              <option value="">Select reason…</option>
              <option value="NEW_EVIDENCE">New evidence not yet in system</option>
              <option value="BUSINESS_DECISION">Business / relationship decision</option>
              <option value="AI_INCORRECT">AI assessment is incorrect</option>
              <option value="POLICY">Policy or compliance requirement</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
        )}

        {/* Supporting evidence */}
        {decision === 'CHALLENGE' && (
          <div>
            <p className="text-xs font-semibold mb-2" style={{ color: 'var(--color-text-muted)' }}>
              Supporting Evidence
            </p>

            {supportingEvidence.length > 0 && (
              <div className="space-y-1.5 mb-3">
                {supportingEvidence.map(e => (
                  <div key={e.evidence_id} className="flex items-center gap-2 text-xs">
                    <CheckCircle2 size={12} style={{ color: '#107c10', flexShrink: 0 }} />
                    <span style={{ color: 'var(--color-text)' }}>
                      {evidenceLabel(
                        e.evidence_type,
                        (e.normalized_content as Record<string, unknown> | undefined)?.textSummary as string | undefined,
                        (e.normalized_content as Record<string, unknown> | undefined)?.documentTitle as string | undefined,
                      )}
                    </span>
                    <span className="ml-auto" style={{ color: 'var(--color-text-muted)' }}>{e.quality}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Upload a new document to back this challenge — no type picker, the
                backend's real vision classification identifies what it is. It goes
                through the same extraction/evaluation as any other evidence upload
                and lands in the case's evidence (the digital twin), then triggers a
                real re-analysis and redraft (see handleUploadChallengeEvidence). */}
            <div className="flex items-center gap-2">
              <input ref={challengeFileInputRef} type="file" className="hidden"
                accept="application/pdf,image/png,image/jpeg,image/webp"
                onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) handleUploadChallengeEvidence(f) }} />
              <Button type="button" variant="secondary" size="sm" disabled={challengeUploadPhase !== 'idle'}
                onClick={() => challengeFileInputRef.current?.click()}>
                {challengeUploadPhase === 'idle' && <><FileUp size={12} /> Upload Document</>}
                {challengeUploadPhase === 'uploading' && <><Loader2 size={12} className="animate-spin" /> Uploading…</>}
                {challengeUploadPhase === 'analyzing' && <><Loader2 size={12} className="animate-spin" /> Comparing against the case…</>}
              </Button>
              {challengeUploadPhase === 'idle' && (
                <span className="text-2xs" style={{ color: 'var(--color-text-subtle)' }}>
                  We'll identify what it is — no need to label it yourself.
                </span>
              )}
              {challengeUploadPhase === 'analyzing' && (
                <span className="text-2xs" style={{ color: 'var(--color-text-subtle)' }}>
                  This re-runs the full case analysis — can take a few minutes.
                </span>
              )}
            </div>
          </div>
        )}

        {/* Response text */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <p className="text-xs font-semibold" style={{ color: 'var(--color-text-muted)' }}>
              Response Text
            </p>
            <div className="flex items-center gap-2">
              <span className="text-2xs" style={{ color: 'var(--color-brand)' }}>AI-drafted · editable</span>
              {decision === 'CHALLENGE' && (
                <button
                  type="button"
                  onClick={() => draftMutation.mutate()}
                  disabled={draftMutation.isPending}
                  className="text-2xs font-semibold px-2 py-0.5 rounded-fluent border flex items-center gap-1"
                  style={{ borderColor: 'var(--color-brand)', color: 'var(--color-brand)' }}
                >
                  <Sparkles size={10} />
                  {draftMutation.isPending ? 'Generating…' : 'Generate with AI'}
                </button>
              )}
            </div>
          </div>
          <textarea
            value={responseText}
            onChange={e => setResponseText(e.target.value)}
            rows={6}
            className="w-full text-xs rounded-fluent border px-3 py-2 resize-none outline-none transition-colors"
            style={{
              borderColor: 'var(--color-border)',
              background: 'var(--color-bg)',
              color: 'var(--color-text)',
            }}
          />
          {draftCitations.length > 0 && (
            <div className="mt-1.5 flex flex-wrap gap-1">
              {draftCitations.map((c, i) => (
                <span key={i} className="text-2xs px-1.5 py-0.5 rounded-fluent border"
                  style={{ borderColor: 'var(--color-border)', color: 'var(--color-text-subtle)' }}>
                  {c.source}{c.page ? `, p.${c.page}` : ''}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Readiness check */}
        <div className="rounded-fluent border p-3" style={{ borderColor: 'var(--color-border)', background: 'var(--color-bg)' }}>
          <p className="text-xs font-semibold mb-2" style={{ color: 'var(--color-text-muted)' }}>
            Response Readiness
          </p>
          {[
            { label: 'Correct dispute reason', ok: true },
            { label: 'Response text provided', ok: responseText.length > 20 },
            { label: 'Supporting evidence selected', ok: decision !== 'CHALLENGE' || supportingEvidence.length > 0 },
            { label: 'Override reason provided', ok: !isOverride || overrideReason.length > 0 },
          ].map((item, i) => (
            <div key={i} className="flex items-center gap-2 text-xs py-0.5">
              {item.ok
                ? <CheckCircle2 size={12} style={{ color: '#107c10' }} />
                : <AlertCircle size={12} style={{ color: '#835b00' }} />}
              <span style={{ color: item.ok ? 'var(--color-text)' : '#835b00' }}>{item.label}</span>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          <Button
            variant="primary"
            onClick={handleSubmit}
            disabled={isOverride && !overrideReason}
            style={{ background: decision === 'CHALLENGE' ? 'var(--color-success)' : 'var(--color-critical)' }}>
            <Send size={14} />
            {decision === 'CHALLENGE' ? 'Submit Challenge' : 'Accept Dispute'}
          </Button>
          <Button variant="secondary" onClick={onCancel}>
            Back
          </Button>
        </div>
      </div>
    </Panel>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// Main Workspace
// ══════════════════════════════════════════════════════════════════════════════

interface Props { initialTab?: 'workspace' | 'story' | 'evidence' | 'response' | 'timeline' }

export function MerchantWorkspace({ initialTab }: Props) {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const qc = useQueryClient()

  const [showResponse, setShowResponse] = useState(initialTab === 'response')
  const [userDecision, setUserDecision] = useState<'CHALLENGE' | 'ACCEPT' | null>(null)
  const [investigating, setInvestigating] = useState(false)
  const [uploadPhase, setUploadPhase] = useState<'idle' | 'uploading' | 'analyzing'>('idle')
  const evidenceFileInputRef = useRef<HTMLInputElement>(null)
  const { docPreview, loadingDocId, pendingName, viewDocument, closeDocPreview } = useDocumentPreview(id)

  // The sidebar's "Order Story" / "Evidence" / "Response" links all resolve to this
  // same component (one continuous workspace, not separate pages) — initialTab was
  // previously only read once at mount, so clicking between them after the first
  // load did nothing. React to every change instead: jump to the matching section
  // (and open the response builder only when a decision already exists to attach it to).
  useEffect(() => {
    setShowResponse(initialTab === 'response')
    if (initialTab === 'story' || initialTab === 'evidence') {
      const el = document.getElementById(`section-${initialTab}`)
      el?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }, [initialTab])

  // ── Data queries ─────────────────────────────────────────────────────────

  const { data: disputeData, isLoading: disputeLoading } = useQuery({
    queryKey: ['merchant-dispute', id],
    queryFn: () => disputeApi.get(id!),
    enabled: !!id,
  })

  const { data: evidenceData } = useQuery({
    queryKey: ['merchant-evidence', id],
    queryFn: () => evidenceApi.list(id!),
    enabled: !!id,
  })

  const { data: hypothesesData } = useQuery({
    queryKey: ['merchant-hypotheses', id],
    queryFn: () => disputeApi.getHypotheses(id!),
    enabled: !!id,
  })

  const { data: contradictionsData } = useQuery({
    queryKey: ['merchant-contradictions', id],
    queryFn: () => disputeApi.getContradictions(id!),
    enabled: !!id,
  })

  const { data: recommendationData } = useQuery({
    queryKey: ['merchant-recommendation', id],
    queryFn: () => disputeApi.getRecommendation(id!),
    enabled: !!id,
  })

  const { data: gapsData } = useQuery({
    queryKey: ['merchant-gaps', id],
    queryFn: () => disputeApi.getGaps(id!),
    enabled: !!id,
  })

  useQuery({
    queryKey: ['merchant-changes', id],
    queryFn: () => disputeApi.getChanges(id!),
    enabled: !!id,
  })

  // ── Derived data ─────────────────────────────────────────────────────────

  const dispute = disputeData?.data as Dispute | undefined
  const evidence: Evidence[] = useMemo(() => evidenceData?.data ?? [], [evidenceData])
  const hypotheses: Hypothesis[] = useMemo(() => hypothesesData?.data ?? [], [hypothesesData])
  const contradictions: Contradiction[] = useMemo(() => contradictionsData?.data ?? [], [contradictionsData])
  const recommendation: Recommendation | null = useMemo(() => {
    const recs = recommendationData?.data
    if (!recs) return null
    if (Array.isArray(recs)) return recs.find((r: Recommendation) => r.is_current) ?? recs[0] ?? null
    return recs
  }, [recommendationData])
  const gaps: EvidenceGap[] = useMemo(() => (gapsData?.data ?? []).filter((g: EvidenceGap) => g.status === 'OPEN'), [gapsData])

  const primaryHypothesis: Hypothesis | null = useMemo(() =>
    hypotheses.find(h => h.status === 'ACTIVE') ?? hypotheses[0] ?? null
  , [hypotheses])

  const supportingEvidence = useMemo(() => {
    if (!primaryHypothesis) return []
    return evidence.filter(e => primaryHypothesis.supporting_evidence_ids.includes(e.evidence_id))
  }, [evidence, primaryHypothesis])

  const weakeningEvidence = useMemo(() => {
    if (!primaryHypothesis) return []
    return evidence.filter(e => primaryHypothesis.weakening_evidence_ids.includes(e.evidence_id))
  }, [evidence, primaryHypothesis])

  const neutralEvidence = useMemo(() => {
    if (!primaryHypothesis) return []
    const usedIds = [...primaryHypothesis.supporting_evidence_ids, ...primaryHypothesis.weakening_evidence_ids]
    return evidence.filter(e => !usedIds.includes(e.evidence_id))
  }, [evidence, primaryHypothesis])

  const recConfig = recommendation ? (REC_CONFIG[recommendation.recommendation_type] ?? REC_CONFIG.ESCALATE) : null
  // The AI only clearly recommends a side for UPHOLD_DISPUTE (accept) or DENY_DISPUTE
  // (challenge) — ESCALATE/REQUEST_EVIDENCE are its own honest "not decisive" signal,
  // so there's nothing real to frame as "the recommendation" to accept or override.
  const recommendedAction: 'ACCEPT' | 'CHALLENGE' | null =
    recommendation?.recommendation_type === 'UPHOLD_DISPUTE' ? 'ACCEPT'
    : recommendation?.recommendation_type === 'DENY_DISPUTE' ? 'CHALLENGE'
    : null
  const hasChanged = (dispute?.metadata as any)?.recommendation_changed

  // ── Actions ──────────────────────────────────────────────────────────────

  // Was `queryKey: ['merchant-', id] as any` — that key never matches any real query
  // (they're all ['merchant-evidence', id], ['merchant-gaps', id], etc., not prefixed
  // by the literal string "merchant-" as its own array element), so nothing ever
  // actually refetched after an investigation. Fixed to invalidate every query this
  // screen actually reads, reused by the new evidence-upload handler below too.
  function invalidateCaseQueries() {
    for (const key of ['merchant-dispute', 'merchant-evidence', 'merchant-hypotheses',
      'merchant-contradictions', 'merchant-recommendation', 'merchant-gaps', 'merchant-changes']) {
      qc.invalidateQueries({ queryKey: [key, id] })
    }
  }

  async function handleInvestigate() {
    if (!id) return
    setInvestigating(true)
    try {
      await agentApi.run(id)
      toast.success('Investigation started — results will appear shortly')
      setTimeout(() => {
        invalidateCaseQueries()
        setInvestigating(false)
      }, 3000)
    } catch {
      toast.error('Could not start investigation')
      setInvestigating(false)
    }
  }

  // No document-type picker: the merchant just uploads (e.g. the missing cancellation
  // policy) and the backend's real vision classification (disputes.py's
  // upload_document — no document_type sent means it trusts its own classification
  // instead of a caller guess) identifies what it is. After attaching, this re-runs
  // the real agent analysis so the new document is actually compared against the rest
  // of the case, not just filed — the "Order Story" / Digital Twin timeline below is
  // built live from this same evidence data (ScenarioTimeline), so once analysis
  // lands the document appears there with its real content, at its real business-
  // event date, not a generic "document uploaded" entry.
  async function handleUploadEvidence(file: File) {
    if (!id) return
    setUploadPhase('uploading')
    try {
      await disputeApi.uploadDocument(id, file)
    } catch (e: any) {
      const detail = e?.response?.data?.detail as string | undefined
      toast.error(detail?.startsWith('Cyera Validation') ? detail : `Could not attach ${file.name}`)
      setUploadPhase('idle')
      return
    }
    invalidateCaseQueries()
    setUploadPhase('analyzing')
    toast.success(`${file.name} attached — comparing it against the case…`, { duration: 4000 })
    try {
      await agentApi.run(id)
      const outcome = await waitForAgentRun(id)
      invalidateCaseQueries()
      if (outcome === 'COMPLETED') toast.success('Case re-assessed with the new document')
      else if (outcome === 'FAILED') toast.error('Re-assessment hit an issue — the document is still attached')
    } catch {
      // Best-effort background analysis — the document is already attached either way.
    } finally {
      setUploadPhase('idle')
    }
  }

  function handleDecide(decision: 'CHALLENGE' | 'ACCEPT') {
    setUserDecision(decision)
    setShowResponse(true)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  if (disputeLoading) {
    return (
      <div className="p-6 max-w-7xl mx-auto space-y-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-32 rounded-fluent-lg border animate-pulse"
            style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }} />
        ))}
      </div>
    )
  }

  if (!dispute) {
    return (
      <div className="p-6 max-w-7xl mx-auto">
        <div className="text-center py-16 rounded-fluent-lg border"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
          <AlertCircle size={28} className="mx-auto mb-3" style={{ color: 'var(--color-text-muted)' }} />
          <p className="font-medium" style={{ color: 'var(--color-text)' }}>Case not found</p>
          <button onClick={() => navigate('/merchant/disputes')}
            className="mt-3 text-sm" style={{ color: 'var(--color-brand)' }}>
            Back to queue
          </button>
        </div>
      </div>
    )
  }

  const sla = slaDisplay(slaMinutes(dispute))
  const amount = Number(dispute.metadata?.amount_disputed ?? 0)
  const isPreDispute = (dispute.metadata as any)?.is_pre_dispute

  return (
    <div className="p-6 max-w-7xl mx-auto">

      {/* ── Case Header ───────────────────────────────────────────────────── */}
      <div className="rounded-fluent-lg border mb-5 overflow-hidden"
        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        <div className="px-5 py-4">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 mb-3 text-xs" style={{ color: 'var(--color-text-muted)' }}>
            <button onClick={() => navigate('/merchant/disputes')} className="hover:underline">Disputes</button>
            <ChevronRight size={12} />
            <span style={{ color: 'var(--color-text)' }}>{dispute.dispute_id.slice(-8).toUpperCase()}</span>
          </div>

          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 flex-wrap mb-2">
                {/* Recommendation badge — most prominent */}
                {recConfig && (
                  <span className="flex items-center gap-1.5 px-3 py-1 rounded-fluent text-sm font-semibold"
                    style={{ background: recConfig.bgColor, color: recConfig.color }}>
                    <recConfig.icon size={14} />
                    {recConfig.label}
                  </span>
                )}
                {isPreDispute && (
                  <span className="flex items-center gap-1.5 px-3 py-1 rounded-fluent text-sm font-semibold"
                    style={{ background: 'rgba(131,91,0,0.08)', color: '#835b00' }}>
                    ⚡ Pre-Dispute Alert
                  </span>
                )}
              </div>
              <h1 className="text-xl font-bold mb-1" style={{ color: 'var(--color-text)' }}>
                {DISPUTE_TYPE_LABEL[dispute.dispute_type] ?? dispute.dispute_type}
              </h1>
              <div className="flex items-center gap-4 text-sm flex-wrap" style={{ color: 'var(--color-text-muted)' }}>
                {dispute.metadata?.customer_name && (
                  <span>{dispute.metadata.customer_name as string}</span>
                )}
                {dispute.metadata?.merchant_name && (
                  <span className="opacity-70">· {dispute.metadata.merchant_name as string}</span>
                )}
                {(dispute.metadata as any)?.order_id && (
                  <span className="opacity-70">· Order {(dispute.metadata as any).order_id}</span>
                )}
                {amount > 0 && (
                  <span className="font-semibold text-base" style={{ color: 'var(--color-text)' }}>
                    ₹{amount.toLocaleString()}
                  </span>
                )}
              </div>
            </div>

            {/* SLA + actions */}
            <div className="flex flex-col items-end gap-3 shrink-0">
              <div className="text-right">
                <div className="text-xs font-medium" style={{ color: sla.urgent ? sla.color : 'var(--color-text-muted)' }}>
                  <Clock size={11} className="inline mr-1" />
                  {sla.label}
                </div>
                <div className="text-2xs mt-0.5" style={{ color: 'var(--color-text-muted)' }}>
                  {dispute.dispute_id.slice(-8).toUpperCase()} · {dispute.lifecycle_stage.replace(/_/g, ' ')}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {MERCHANT_DECIDED_STATUSES.includes(dispute.status) ? (
                  <span className="flex items-center gap-1.5 px-2.5 h-7 rounded-fluent text-xs font-medium"
                    style={{
                      color: dispute.status === 'APPROVED' ? 'var(--color-critical)' : 'var(--color-success)',
                      background: dispute.status === 'APPROVED' ? 'rgba(197,15,31,0.06)' : 'rgba(16,124,16,0.06)',
                    }}>
                    {dispute.status === 'APPROVED'
                      ? <><ThumbsDown size={12} /> Accepted — response submitted</>
                      : <><ThumbsUp size={12} /> Challenged — response submitted</>}
                  </span>
                ) : (
                  <>
                    <Button variant="secondary" size="sm" onClick={handleInvestigate} loading={investigating}>
                      {!investigating && <Search size={12} />}
                      {investigating ? 'Investigating…' : 'Find Evidence'}
                    </Button>
                    <Button variant="primary" size="sm" style={{ background: 'var(--color-success)' }}
                      onClick={() => handleDecide('CHALLENGE')}>
                      <ThumbsUp size={12} /> Challenge
                    </Button>
                    <button
                      onClick={() => handleDecide('ACCEPT')}
                      className="flex items-center gap-1.5 px-2.5 h-7 rounded-fluent text-xs font-medium border"
                      style={{ color: 'var(--color-critical)', borderColor: 'rgba(197,15,31,0.35)' }}>
                      <ThumbsDown size={12} /> Accept
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Chargeback notification */}
        {dispute.status === 'CHARGEBACK' && (
          <div className="px-5 py-2 border-t flex items-center gap-2"
            style={{ borderColor: 'rgba(197,15,31,0.2)', background: 'rgba(197,15,31,0.06)' }}>
            <AlertTriangle size={13} style={{ color: 'var(--color-critical)', flexShrink: 0 }} />
            <span className="text-xs" style={{ color: 'var(--color-critical)' }}>
              <strong>Charged back by the issuer</strong>
              {(dispute.metadata as any)?.chargeback_issued_at && (
                <> on {format(parseISO((dispute.metadata as any).chargeback_issued_at), 'd MMM yyyy · HH:mm')}</>
              )} — challenge or accept below before the response deadline.
            </span>
          </div>
        )}

        {/* Changed notification */}
        {hasChanged && (
          <div className="px-5 py-2 border-t flex items-center gap-2"
            style={{ borderColor: '#ca501033', background: 'rgba(202,80,16,0.06)' }}>
            <TrendingUp size={13} style={{ color: '#ca5010', flexShrink: 0 }} />
            <span className="text-xs" style={{ color: '#ca5010' }}>
              <strong>Recommendation changed</strong> — new evidence was retrieved. Review the updated assessment.
            </span>
          </div>
        )}
      </div>

      {/* ── Main grid ────────────────────────────────────────────────────── */}
      {showResponse && userDecision ? (
        <ResponseBuilder
          dispute={dispute}
          evidence={evidence}
          recommendation={recommendation}
          decision={userDecision}
          onCancel={() => { setShowResponse(false); setUserDecision(null) }}
          onSubmitted={() => { setShowResponse(false); setUserDecision(null) }}
        />
      ) : (
        <div className="grid grid-cols-5 gap-5">

          {/* ── Left column (3/5) ─────────────────────────────────────── */}
          <div className="col-span-3 space-y-4">

            {/* Customer Claim */}
            <Panel title="Customer Claim" icon={MessageSquare} accent="#d13438">
              <div className="rounded-fluent p-4 mb-3"
                style={{ background: 'rgba(209,52,56,0.04)', border: '1px solid rgba(209,52,56,0.15)' }}>
                <p className="text-sm italic" style={{ color: 'var(--color-text)' }}>
                  "{dispute.cardholder_claim}"
                </p>
              </div>
              <div className="flex items-center gap-4 text-xs" style={{ color: 'var(--color-text-muted)' }}>
                <span>
                  Reason: <strong style={{ color: 'var(--color-text)' }}>
                    {DISPUTE_TYPE_LABEL[dispute.dispute_type] ?? dispute.dispute_type}
                  </strong>
                </span>
                {(dispute.metadata as any)?.reason_code && (
                  <span>Code: <strong style={{ color: 'var(--color-text)' }}>
                    {(dispute.metadata as any).reason_code}
                  </strong></span>
                )}
                <span>Filed: <strong style={{ color: 'var(--color-text)' }}>
                  {format(parseISO(dispute.created_at), 'd MMM yyyy')}
                </strong></span>
              </div>
            </Panel>

            {/* Order Story — the "Digital Twin" scenario reconstruction, built from
                this case's own real evidence/business-event-time data, identical to
                the issuer's version of the same shared component. Always open —
                this is the sidebar's "Order Story" destination, so hiding it by
                default made that nav link look broken. */}
            <div id="section-story">
              <Panel title="Order Story" icon={Activity} badge="Digital Twin">
                <ScenarioTimeline dispute={dispute} evidence={evidence} contradictions={contradictions} />
              </Panel>
            </div>

            {/* Transaction Details */}
            {evidence.some(e => e.evidence_type === 'TRANSACTION_RECEIPT') && (
              <Panel title="Transaction Details" icon={CreditCard} collapsible defaultOpen>
                {evidence.filter(e => e.evidence_type === 'TRANSACTION_RECEIPT').slice(0, 1).map(e => (
                  <div key={e.evidence_id} className="grid grid-cols-2 gap-3 text-xs">
                    {Object.entries(e.normalized_content).filter(([k]) =>
                      ['amount', 'currency', 'auth_code', 'channel', 'avs_result', 'cvv_result',
                       'posted_at', 'card_last_four', 'approval_code'].includes(k)
                    ).map(([k, v]) => (
                      <div key={k}>
                        <div className="font-medium capitalize" style={{ color: 'var(--color-text-muted)' }}>
                          {k.replace(/_/g, ' ')}
                        </div>
                        <div style={{ color: 'var(--color-text)' }}>
                          {(() => {
                            if (typeof v === 'string' && v.includes('T') && v.length > 10) {
                              const parsed = parseISO(v)
                              if (!isNaN(parsed.getTime())) return format(parsed, 'd MMM yyyy HH:mm')
                            }
                            return String(v)
                          })()}
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
                {evidence.some(e => e.evidence_type === 'AUTHENTICATION_LOG') && (
                  <div className="mt-3 pt-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
                    <div className="text-xs font-medium mb-2" style={{ color: 'var(--color-text-muted)' }}>
                      Authentication
                    </div>
                    {evidence.filter(e => e.evidence_type === 'AUTHENTICATION_LOG').slice(0, 1).map(e => (
                      <div key={e.evidence_id} className="grid grid-cols-2 gap-3 text-xs">
                        {Object.entries(e.normalized_content).filter(([k]) =>
                          ['method', 'result', 'eci', 'risk_score', 'risk_level', 'cardholder_authenticated',
                           'chip_verified', 'pin_verified', 'liability_shift'].includes(k)
                        ).map(([k, v]) => (
                          <div key={k}>
                            <div className="font-medium capitalize" style={{ color: 'var(--color-text-muted)' }}>
                              {k.replace(/_/g, ' ')}
                            </div>
                            <div style={{ color: 'var(--color-text)' }}>
                              {typeof v === 'boolean' ? (v ? 'Yes' : 'No') : String(v)}
                            </div>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                )}
              </Panel>
            )}

            {/* Evidence Intelligence */}
            <div id="section-evidence" />
            <Panel title="Evidence Intelligence" icon={Shield}
              badge={`${supportingEvidence.length + weakeningEvidence.length + gaps.length} items`}>
              <div className="space-y-4">
                {/* Upload evidence — the merchant's own documents (source_type=MERCHANT,
                    disputes.py:922) so contradiction detection has both sides to
                    compare (README §43, §60). No type picker: just upload, and the
                    real vision classification identifies what it is, then a real
                    agent re-run compares it against the rest of the case (README §67). */}
                <div className="flex items-center gap-2 pb-3 border-b" style={{ borderColor: 'var(--color-border)' }}>
                  <input ref={evidenceFileInputRef} type="file" className="hidden"
                    accept="application/pdf,image/png,image/jpeg,image/webp"
                    onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) handleUploadEvidence(f) }} />
                  <Button type="button" variant="secondary" size="sm" disabled={uploadPhase !== 'idle'}
                    onClick={() => evidenceFileInputRef.current?.click()}>
                    {uploadPhase === 'idle' && <><FileUp size={12} /> Upload Document</>}
                    {uploadPhase === 'uploading' && <><Loader2 size={12} className="animate-spin" /> Uploading…</>}
                    {uploadPhase === 'analyzing' && <><Loader2 size={12} className="animate-spin" /> Comparing against the case…</>}
                  </Button>
                  {uploadPhase === 'idle' && (
                    <span className="text-2xs" style={{ color: 'var(--color-text-subtle)' }}>
                      We'll identify what it is — no need to label it yourself.
                    </span>
                  )}
                  {uploadPhase === 'analyzing' && (
                    <span className="text-2xs" style={{ color: 'var(--color-text-subtle)' }}>
                      This re-runs the full case analysis — can take a few minutes.
                    </span>
                  )}
                </div>

                {/* Supports us */}
                {supportingEvidence.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle2 size={13} style={{ color: '#107c10' }} />
                      <span className="text-xs font-semibold uppercase tracking-wide" style={{ color: '#107c10' }}>
                        What Supports Us
                      </span>
                      <span className="text-2xs px-1.5 py-0.5 rounded-full ml-auto"
                        style={{ background: 'rgba(16,124,16,0.1)', color: '#107c10' }}>
                        {supportingEvidence.length}
                      </span>
                    </div>
                    <div className="space-y-2">
                      {supportingEvidence.map(e => <EvidenceItem key={e.evidence_id} evidence={e} variant="support" onView={viewDocument} loadingDocId={loadingDocId} />)}
                    </div>
                  </div>
                )}

                {/* May hurt us */}
                {weakeningEvidence.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle size={13} style={{ color: '#ca5010' }} />
                      <span className="text-xs font-semibold uppercase tracking-wide" style={{ color: '#ca5010' }}>
                        What May Hurt Us
                      </span>
                      <span className="text-2xs px-1.5 py-0.5 rounded-full ml-auto"
                        style={{ background: 'rgba(202,80,16,0.1)', color: '#ca5010' }}>
                        {weakeningEvidence.length}
                      </span>
                    </div>
                    <div className="space-y-2">
                      {weakeningEvidence.map(e => <EvidenceItem key={e.evidence_id} evidence={e} variant="hurt" onView={viewDocument} loadingDocId={loadingDocId} />)}
                    </div>
                  </div>
                )}

                {/* Missing */}
                {gaps.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle size={13} style={{ color: '#835b00' }} />
                      <span className="text-xs font-semibold uppercase tracking-wide" style={{ color: '#835b00' }}>
                        What Is Missing
                      </span>
                      <span className="text-2xs px-1.5 py-0.5 rounded-full ml-auto"
                        style={{ background: 'rgba(131,91,0,0.12)', color: '#835b00' }}>
                        {gaps.length}
                      </span>
                    </div>
                    <div className="space-y-2">
                      {gaps.map(g => <GapItem key={g.gap_id} gap={g} />)}
                    </div>
                    <button onClick={handleInvestigate} disabled={investigating}
                      className="mt-2 flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-fluent border transition-colors"
                      style={{ color: '#835b00', borderColor: '#835b0044' }}>
                      <Search size={12} />
                      {investigating ? 'Searching…' : 'Find Missing Evidence'}
                    </button>
                  </div>
                )}

                {/* Other evidence */}
                {neutralEvidence.length > 0 && hypotheses.length === 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Info size={13} style={{ color: 'var(--color-text-muted)' }} />
                      <span className="text-xs font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                        Available Evidence
                      </span>
                    </div>
                    <div className="space-y-2">
                      {neutralEvidence.map(e => <EvidenceItem key={e.evidence_id} evidence={e} variant="neutral" onView={viewDocument} loadingDocId={loadingDocId} />)}
                    </div>
                  </div>
                )}

                {supportingEvidence.length === 0 && weakeningEvidence.length === 0 && gaps.length === 0 && evidence.length === 0 && (
                  <div className="text-center py-4">
                    <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                      No evidence retrieved yet.{' '}
                      <button onClick={handleInvestigate} className="underline" style={{ color: 'var(--color-brand)' }}>
                        Start investigation
                      </button>
                    </p>
                  </div>
                )}
              </div>
            </Panel>

            {/* Contradictions */}
            {contradictions.length > 0 && (
              <Panel title="Contradictions Detected" icon={AlertTriangle}
                badge={`${contradictions.length}`} accent="#d13438">
                <div className="space-y-3">
                  {contradictions.map(c => <ContradictionItem key={c.contradiction_id} contradiction={c} />)}
                </div>
                <p className="text-xs mt-3" style={{ color: 'var(--color-text-muted)' }}>
                  Contradictions require investigation before filing a response.
                  The system has not resolved which source is correct — that decision requires human review.
                </p>
              </Panel>
            )}

            {/* All evidence (collapsed by default) */}
            {evidence.length > 0 && (
              <Panel title={`All Evidence (${evidence.length})`} icon={FileText} collapsible defaultOpen={false}>
                <div className="space-y-2">
                  {evidence.map(e => (
                    <EvidenceItem
                      key={e.evidence_id}
                      evidence={e}
                      onView={viewDocument}
                      loadingDocId={loadingDocId}
                      variant={primaryHypothesis?.supporting_evidence_ids.includes(e.evidence_id) ? 'support'
                        : primaryHypothesis?.weakening_evidence_ids.includes(e.evidence_id) ? 'hurt' : 'neutral'}
                    />
                  ))}
                </div>
              </Panel>
            )}
          </div>

          {/* ── Right column (2/5) ──────────────────────────────────────── */}
          <div className="col-span-2 space-y-4">

            {/* AI Recommendation */}
            {recConfig && recommendation && (
              <div className="rounded-fluent-lg border overflow-hidden"
                style={{ borderColor: `${recConfig.color}44`, background: recConfig.bgColor }}>
                <div className="px-4 py-3 border-b"
                  style={{ borderColor: `${recConfig.color}22` }}>
                  <div className="flex items-center gap-2">
                    <Sparkles size={14} style={{ color: recConfig.color }} />
                    <span className="text-xs font-semibold uppercase tracking-wide"
                      style={{ color: 'var(--color-text-muted)' }}>
                      AI Recommendation
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <recConfig.icon size={18} style={{ color: recConfig.color }} />
                    <span className="text-base font-bold" style={{ color: recConfig.color }}>
                      {recConfig.label}
                    </span>
                  </div>
                  <p className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>
                    {recConfig.description}
                  </p>
                  {recommendation.created_at && (
                    <p className="text-2xs mt-2 italic" style={{ color: 'var(--color-text-subtle)' }}>
                      Ready {formatDistanceToNow(parseISO(recommendation.created_at))} ago — before you opened this case.
                    </p>
                  )}
                </div>
                <div className="p-4">
                  <p className="text-xs mb-3" style={{ color: 'var(--color-text)' }}>
                    {recommendation.content.split('\n')[0]}
                  </p>
                  <div className="mb-3">
                    <EvidenceBalanceBar supporting={supportingEvidence.length} contradicting={weakeningEvidence.length} />
                  </div>
                  <div className="mt-3 flex items-center gap-1.5 text-xs"
                    style={{ color: 'var(--color-text-muted)' }}>
                    <span>Confidence:</span>
                    <span className="font-medium" style={{ color: 'var(--color-text)' }}>
                      {recommendation.confidence_descriptor}
                    </span>
                    {recommendation.confidence_score > 0 && (
                      <span className="ml-auto">{Math.round(recommendation.confidence_score * 100)}%</span>
                    )}
                  </div>
                  <div className="mt-2 h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--color-border)' }}>
                    <div className="h-full rounded-full" style={{
                      width: `${Math.round(recommendation.confidence_score * 100)}%`,
                      background: recConfig.color,
                    }} />
                  </div>
                </div>
                {/* Decision buttons — hidden once this case already has a submitted
                    decision (dispute.status is a MERCHANT_DECIDED_STATUSES value);
                    showing them after the fact wrongly implied nothing had been
                    decided yet. */}
                {isMerchantDecided(dispute) ? (
                  <div className="px-4 pb-4">
                    <div className="flex items-center gap-2 text-xs px-3 py-2.5 rounded-fluent"
                      style={{ background: 'rgba(16,124,16,0.08)', color: 'var(--color-success)' }}>
                      <CheckCircle2 size={13} />
                      Decision already submitted — {dispute.status === 'REPRESENTMENT' ? 'you challenged this chargeback' : 'you accepted this chargeback'}.
                    </div>
                  </div>
                ) : recommendedAction ? (
                  <div className="px-4 pb-4 flex flex-col gap-2">
                    <button
                      onClick={() => handleDecide(recommendedAction)}
                      className="w-full py-2 rounded-fluent text-sm font-medium text-white transition-opacity"
                      style={{ background: recConfig.color }}>
                      Accept Recommendation
                    </button>
                    <button
                      onClick={() => handleDecide(recommendedAction === 'ACCEPT' ? 'CHALLENGE' : 'ACCEPT')}
                      className="w-full py-2 rounded-fluent text-sm border transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
                      style={{ color: 'var(--color-text-muted)', borderColor: 'var(--color-border)' }}>
                      Override Recommendation
                    </button>
                  </div>
                ) : (
                  // ESCALATE / REQUEST_EVIDENCE — the AI itself says the evidence isn't
                  // decisive yet. No "recommendation" to accept or override in that
                  // case, so both options are shown plainly instead of implying either
                  // one is what the AI told you to do.
                  <div className="px-4 pb-4">
                    <p className="text-xs mb-2" style={{ color: 'var(--color-text-muted)' }}>
                      The AI hasn't reached a decisive recommendation yet — decide based on the evidence above.
                    </p>
                    <div className="flex flex-col gap-2">
                      <button onClick={() => handleDecide('ACCEPT')}
                        className="w-full py-2 rounded-fluent text-sm border transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        style={{ color: 'var(--color-text)', borderColor: 'var(--color-border)' }}>
                        Accept Chargeback
                      </button>
                      <button onClick={() => handleDecide('CHALLENGE')}
                        className="w-full py-2 rounded-fluent text-sm border transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        style={{ color: 'var(--color-text)', borderColor: 'var(--color-border)' }}>
                        Challenge Chargeback
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Case Assessment */}
            <Panel title="Case Assessment" icon={Activity}>
              <div className="space-y-3">
                {[
                  {
                    label: 'Merchant Position',
                    value: supportingEvidence.length > weakeningEvidence.length + gaps.length ? 'Strong'
                      : weakeningEvidence.length > supportingEvidence.length ? 'Weak' : 'Moderate',
                    color: supportingEvidence.length > weakeningEvidence.length + gaps.length ? '#107c10'
                      : weakeningEvidence.length > supportingEvidence.length ? '#c50f1f' : '#ca5010',
                  },
                  {
                    label: 'Supporting Evidence',
                    value: `${supportingEvidence.length} item${supportingEvidence.length !== 1 ? 's' : ''}`,
                    color: '#107c10',
                  },
                  {
                    label: 'Contradicting Evidence',
                    value: `${weakeningEvidence.length} item${weakeningEvidence.length !== 1 ? 's' : ''}`,
                    color: weakeningEvidence.length > 0 ? '#ca5010' : '#107c10',
                  },
                  {
                    label: 'Evidence Gaps',
                    value: gaps.length === 0 ? 'None' : `${gaps.length} gap${gaps.length !== 1 ? 's' : ''}`,
                    color: gaps.length === 0 ? '#107c10' : '#835b00',
                  },
                  {
                    label: 'Contradictions',
                    value: contradictions.length === 0 ? 'None' : `${contradictions.length} detected`,
                    color: contradictions.length === 0 ? '#107c10' : '#d13438',
                  },
                ].map(item => (
                  <div key={item.label} className="flex items-center justify-between text-xs">
                    <span style={{ color: 'var(--color-text-muted)' }}>{item.label}</span>
                    <span className="font-semibold" style={{ color: item.color }}>{item.value}</span>
                  </div>
                ))}
              </div>
            </Panel>

            {/* Dispute Economics */}
            <Panel title="Dispute Economics" icon={TrendingUp}>
              <div className="space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span style={{ color: 'var(--color-text-muted)' }}>Disputed Amount</span>
                  <span className="font-bold text-sm" style={{ color: 'var(--color-text)' }}>
                    ₹{amount.toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span style={{ color: 'var(--color-text-muted)' }}>Potential Fee</span>
                  <span style={{ color: 'var(--color-text)' }}>₹750</span>
                </div>
                <div className="h-px" style={{ background: 'var(--color-border)' }} />
                <div className="flex items-center justify-between">
                  <span style={{ color: 'var(--color-text-muted)' }}>Total Exposure</span>
                  <span className="font-semibold" style={{ color: '#c50f1f' }}>
                    ₹{(amount + 750).toLocaleString()}
                  </span>
                </div>
                {recommendation && (
                  <>
                    <div className="h-px" style={{ background: 'var(--color-border)' }} />
                    <div className="flex items-center justify-between">
                      <span style={{ color: 'var(--color-text-muted)' }}>Recovery Likelihood</span>
                      <span className="font-semibold" style={{
                        color: recommendation.confidence_score > 0.7 ? '#107c10'
                          : recommendation.confidence_score > 0.4 ? '#ca5010' : '#c50f1f'
                      }}>
                        {recommendation.confidence_score > 0.7 ? 'High'
                          : recommendation.confidence_score > 0.4 ? 'Moderate' : 'Low'}
                      </span>
                    </div>
                    {recommendation.recommendation_type === 'DENY_DISPUTE' && (
                      <div className="flex items-center justify-between">
                        <span style={{ color: 'var(--color-text-muted)' }}>Est. Recovery</span>
                        <span className="font-semibold" style={{ color: '#107c10' }}>
                          ₹{Math.round(amount * recommendation.confidence_score * 0.85).toLocaleString()}
                          {' '}–{' '}
                          ₹{Math.round(amount * recommendation.confidence_score).toLocaleString()}
                        </span>
                      </div>
                    )}
                  </>
                )}
              </div>
            </Panel>

            {/* Similar Cases */}
            <Panel title="Similar Cases" icon={Eye} collapsible defaultOpen>
              <div className="space-y-2">
                <div className="flex items-center gap-4 text-xs mb-3">
                  <div>
                    <div className="text-lg font-bold" style={{ color: '#107c10' }}>72%</div>
                    <div style={{ color: 'var(--color-text-muted)' }}>Merchant Won</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold" style={{ color: '#c50f1f' }}>28%</div>
                    <div style={{ color: 'var(--color-text-muted)' }}>Merchant Lost</div>
                  </div>
                  <div className="ml-auto text-right">
                    <div className="text-lg font-bold" style={{ color: 'var(--color-text)' }}>18</div>
                    <div style={{ color: 'var(--color-text-muted)' }}>similar cases</div>
                  </div>
                </div>
                <div className="h-2 rounded-full overflow-hidden" style={{ background: '#c50f1f20' }}>
                  <div className="h-full rounded-full" style={{ width: '72%', background: '#107c10' }} />
                </div>
                <div className="pt-2 text-xs" style={{ color: 'var(--color-text-muted)' }}>
                  Most effective evidence in wins:{' '}
                  <span style={{ color: 'var(--color-text)' }}>
                    {dispute.dispute_type === 'UNAUTHORIZED_TRANSACTION' ? 'Authentication Record'
                      : dispute.dispute_type === 'MERCHANDISE_NOT_RECEIVED' ? 'Delivery Confirmation'
                      : 'Refund Record'}
                  </span>
                </div>
              </div>
            </Panel>

            {/* Hypothesis reasoning */}
            {primaryHypothesis && (
              <Panel title="AI Reasoning" icon={Sparkles} collapsible defaultOpen={false}>
                <p className="text-xs" style={{ color: 'var(--color-text-muted)', lineHeight: 1.7 }}>
                  {(primaryHypothesis as any).reasoning ?? primaryHypothesis.description}
                </p>
                {primaryHypothesis.unresolved_questions.length > 0 && (
                  <div className="mt-3 pt-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
                    <div className="text-xs font-medium mb-2" style={{ color: 'var(--color-text-muted)' }}>
                      Unresolved Questions
                    </div>
                    {primaryHypothesis.unresolved_questions.map((q, i) => (
                      <div key={i} className="flex items-start gap-2 text-xs mb-1">
                        <HelpCircle size={11} style={{ color: '#835b00', marginTop: 1, flexShrink: 0 }} />
                        <span style={{ color: 'var(--color-text-muted)' }}>{q}</span>
                      </div>
                    ))}
                  </div>
                )}
              </Panel>
            )}

            {/* No AI data yet — prompt investigation */}
            {!recommendation && !investigating && (
              <div className="rounded-fluent-lg border p-5 text-center"
                style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', borderStyle: 'dashed' }}>
                <Sparkles size={22} className="mx-auto mb-2" style={{ color: 'var(--color-brand)' }} />
                <p className="text-sm font-medium mb-1" style={{ color: 'var(--color-text)' }}>
                  Investigation not started
                </p>
                <p className="text-xs mb-3" style={{ color: 'var(--color-text-muted)' }}>
                  Start the AI investigation to reconstruct the order story,
                  retrieve evidence, and receive a recommendation.
                </p>
                <Button variant="primary" onClick={handleInvestigate}>
                  Investigate
                </Button>
              </div>
            )}
          </div>
        </div>
      )}
      <DocumentPreviewModal preview={docPreview} pendingName={pendingName} onClose={closeDocPreview} />
    </div>
  )
}
