import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import {
  ChevronRight, Search,
  CheckCircle2, RefreshCw
} from 'lucide-react'
import { disputeApi } from '@/services/api'
import type { Dispute } from '@/types'
import { Button, PageHeader } from '@/components/ui'
import { slaDaysLabel, isMerchantDecided } from '@/lib/disputeStatus'

const DISPUTE_TYPE_LABEL: Record<string, string> = {
  UNAUTHORIZED_TRANSACTION: 'Unauthorized Transaction',
  MERCHANDISE_NOT_RECEIVED: 'Merchandise Not Received',
  REFUND_NOT_PROCESSED: 'Refund Not Processed',
  MERCHANDISE_NOT_AS_DESCRIBED: 'Item Not As Described',
  DUPLICATE_TRANSACTION: 'Duplicate Transaction',
  SUBSCRIPTION_CANCELLATION: 'Subscription Cancelled',
}

const PRIORITY_COLOR: Record<string, string> = {
  CRITICAL: '#c50f1f', HIGH: '#d13438', MEDIUM: '#ca5010', LOW: '#835b00',
}

type Filter = 'all' | 'action_required' | 'sla_risk' | 'new' | 'submitted' | 'pre_dispute' | 'chargeback'

function getNextAction(d: Dispute): { label: string; color: string } {
  const ws = (d.metadata as any)?.work_status as string | undefined
  const isPreDispute = (d.metadata as any)?.is_pre_dispute
  // A decision the merchant already made (APPROVED = accepted, REPRESENTMENT =
  // challenged) must win over work_status — work_status gets set to
  // RESPONSE_READY at the moment of submission (MerchantWorkspace.tsx
  // handleSubmit), which otherwise made this function say "Submit Response"
  // right after the response had just been submitted.
  if (d.status === 'APPROVED') return { label: 'Accepted — closed', color: '#616161' }
  if (d.status === 'REPRESENTMENT') return { label: 'Submitted — awaiting issuer', color: '#5c2d91' }
  if (isPreDispute) return { label: 'Resolve Alert', color: '#835b00' }
  if (d.status === 'CHARGEBACK') return { label: 'Respond to Chargeback', color: '#c50f1f' }
  if (ws === 'EVIDENCE_NEEDED') return { label: 'Find Evidence', color: '#c50f1f' }
  if (ws === 'ACTION_REQUIRED') return { label: 'Take Action', color: '#c50f1f' }
  if (ws === 'RESPONSE_READY') return { label: 'Submit Response', color: '#107c10' }
  if (d.status === 'UNDER_INVESTIGATION') return { label: 'Review', color: '#0078d4' }
  if (d.status === 'OPEN') return { label: 'Investigate', color: '#ca5010' }
  return { label: 'Track', color: '#616161' }
}

function getEvidenceStrength(d: Dispute): { label: string; color: string } | null {
  const recType = (d.metadata as any)?.recommendation_type as string | undefined
  if (!recType) return null
  if (recType === 'CHALLENGE') return { label: 'Strong', color: '#107c10' }
  if (recType === 'ACCEPT') return { label: 'Weak', color: '#c50f1f' }
  if (recType === 'INVESTIGATE') return { label: 'Moderate', color: '#ca5010' }
  return { label: 'Unknown', color: '#616161' }
}

// ── Component ─────────────────────────────────────────────────────────────────

function FilterChip({ label, count, active, onClick }: {
  label: string; count: number; active: boolean; onClick: () => void
}) {
  return (
    <button onClick={onClick}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-fluent text-xs font-medium border transition-all"
      style={{
        background: active ? 'var(--color-brand)' : 'var(--color-surface)',
        color: active ? 'white' : 'var(--color-text-muted)',
        borderColor: active ? 'var(--color-brand)' : 'var(--color-border)',
      }}>
      {label}
      {count > 0 && (
        <span className="rounded-full px-1.5 py-0.5 text-2xs font-bold"
          style={{
            background: active ? 'rgba(255,255,255,0.2)' : 'var(--color-brand-light)',
            color: active ? 'white' : 'var(--color-brand)',
          }}>
          {count}
        </span>
      )}
    </button>
  )
}

export function MerchantDisputeQueue() {
  const navigate = useNavigate()
  const [activeFilter, setActiveFilter] = useState<Filter>('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [sortMode, setSortMode] = useState<'priority' | 'updated'>('priority')

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['merchant-disputes-queue'],
    queryFn: () => disputeApi.list({ page_size: 100 }),
    refetchInterval: 30_000,
  })

  const disputes: Dispute[] = useMemo(() => data?.data?.items ?? [], [data])

  const counts = useMemo(() => ({
    all: disputes.length,
    action_required: disputes.filter(d =>
      ['EVIDENCE_NEEDED', 'ACTION_REQUIRED'].includes((d.metadata as any)?.work_status ?? '')
    ).length,
    sla_risk: disputes.filter(d => d.days_remaining !== null && d.days_remaining < 1).length,
    new: disputes.filter(d => d.status === 'OPEN').length,
    submitted: disputes.filter(d => d.status === 'APPROVED').length,
    pre_dispute: disputes.filter(d => (d.metadata as any)?.is_pre_dispute).length,
    chargeback: disputes.filter(d => d.status === 'CHARGEBACK').length,
  }), [disputes])

  const filtered = useMemo(() => {
    let list = [...disputes]
    switch (activeFilter) {
      case 'action_required':
        list = list.filter(d => ['EVIDENCE_NEEDED', 'ACTION_REQUIRED'].includes((d.metadata as any)?.work_status ?? ''))
        break
      case 'sla_risk':
        list = list.filter(d => d.days_remaining !== null && d.days_remaining < 1)
        break
      case 'new':
        list = list.filter(d => d.status === 'OPEN')
        break
      case 'submitted':
        list = list.filter(d => d.status === 'APPROVED')
        break
      case 'pre_dispute':
        list = list.filter(d => (d.metadata as any)?.is_pre_dispute)
        break
      case 'chargeback':
        list = list.filter(d => d.status === 'CHARGEBACK')
        break
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase()
      list = list.filter(d =>
        d.dispute_id.toLowerCase().includes(q) ||
        (d.metadata?.customer_name as string ?? '').toLowerCase().includes(q) ||
        (d.metadata?.merchant_name as string ?? '').toLowerCase().includes(q) ||
        DISPUTE_TYPE_LABEL[d.dispute_type]?.toLowerCase().includes(q)
      )
    }
    // Sort by decided-status first (a case the merchant already accepted/challenged
    // never belongs above one still needing a response, regardless of its SLA
    // urgency), then by the chosen sort mode — SLA/priority urgency (default) or
    // most-recently-updated.
    return list.sort((a, b) => {
      const decidedDelta = Number(isMerchantDecided(a)) - Number(isMerchantDecided(b))
      if (decidedDelta !== 0) return decidedDelta
      if (sortMode === 'updated') {
        return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
      }
      const aDays = a.days_remaining ?? 9999
      const bDays = b.days_remaining ?? 9999
      return aDays - bDays
    })
  }, [disputes, activeFilter, searchQuery, sortMode])

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader
        title="Dispute Queue"
        description={`${counts.all} dispute${counts.all !== 1 ? 's' : ''} · prioritised by SLA and urgency`}
        actions={
          <Button variant="secondary" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw size={14} className={isFetching ? 'animate-spin' : ''} />
            Refresh
          </Button>
        }
      />

      {/* Filters */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <FilterChip label="All" count={counts.all} active={activeFilter === 'all'} onClick={() => setActiveFilter('all')} />
        <FilterChip label="Action Required" count={counts.action_required} active={activeFilter === 'action_required'} onClick={() => setActiveFilter('action_required')} />
        <FilterChip label="Chargebacks" count={counts.chargeback} active={activeFilter === 'chargeback'} onClick={() => setActiveFilter('chargeback')} />
        <FilterChip label="SLA At Risk" count={counts.sla_risk} active={activeFilter === 'sla_risk'} onClick={() => setActiveFilter('sla_risk')} />
        <FilterChip label="New" count={counts.new} active={activeFilter === 'new'} onClick={() => setActiveFilter('new')} />
        <FilterChip label="Pre-Dispute Alerts" count={counts.pre_dispute} active={activeFilter === 'pre_dispute'} onClick={() => setActiveFilter('pre_dispute')} />

        {/* Sort — was always SLA/priority-first with no alternative. */}
        <div className="ml-auto flex items-center rounded-fluent border overflow-hidden shrink-0"
          style={{ borderColor: 'var(--color-border)' }}>
          {(['priority', 'updated'] as const).map((mode) => (
            <button key={mode} onClick={() => setSortMode(mode)}
              className="px-3 py-1.5 text-xs transition-colors"
              style={{
                background: sortMode === mode ? 'rgba(16,124,16,0.08)' : 'var(--color-surface)',
                color: sortMode === mode ? 'var(--color-success)' : 'var(--color-text-muted)',
                fontWeight: sortMode === mode ? 600 : 400,
              }}>
              {mode === 'priority' ? 'Priority' : 'Latest Updated'}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 rounded-fluent border px-3 py-1.5"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
          <Search size={13} style={{ color: 'var(--color-text-muted)' }} />
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search disputes..."
            className="text-xs bg-transparent outline-none w-40"
            style={{ color: 'var(--color-text)' }}
          />
        </div>
      </div>

      {/* Table */}
      {isLoading ? (
        <div className="space-y-2">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-16 rounded-fluent border animate-pulse"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }} />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 rounded-fluent-lg border"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
          <CheckCircle2 size={28} className="mx-auto mb-3" style={{ color: 'var(--color-success)' }} />
          <p className="font-medium" style={{ color: 'var(--color-text)' }}>No disputes match this filter</p>
        </div>
      ) : (
        <div className="rounded-fluent-lg border overflow-hidden"
          style={{ borderColor: 'var(--color-border)' }}>
          {/* Table header */}
          <div className="grid grid-cols-12 gap-4 px-4 py-2 text-xs font-semibold uppercase tracking-wide border-b"
            style={{
              color: 'var(--color-text-muted)',
              borderColor: 'var(--color-border)',
              background: 'var(--color-surface-r)',
            }}>
            <div className="col-span-3">Dispute</div>
            <div className="col-span-2">Reason</div>
            <div className="col-span-2">Customer</div>
            <div className="col-span-1 text-right">Amount</div>
            <div className="col-span-1">Response Due</div>
            <div className="col-span-1">Evidence</div>
            <div className="col-span-2 text-right">Next Action</div>
          </div>

          {/* Table rows */}
          <div className="divide-y" style={{ borderColor: 'var(--color-border)' }}>
            {filtered.map(d => {
              const dsla = slaDaysLabel(d)
              const isPreDispute = (d.metadata as any)?.is_pre_dispute
              const amount = Number(d.metadata?.amount_disputed ?? 0)
              const nextAction = getNextAction(d)
              const evidenceStrength = getEvidenceStrength(d)
              const customer = d.metadata?.customer_name as string | undefined
              const slaDisplay = dsla?.label ?? '—'

              return (
                <button key={d.dispute_id}
                  onClick={() => navigate(`/merchant/disputes/${d.dispute_id}`)}
                  className="w-full grid grid-cols-12 gap-4 px-4 py-3 text-left transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-900 group"
                  style={{ background: 'var(--color-surface)' }}>

                  {/* Dispute ID */}
                  <div className="col-span-3 flex items-center gap-2 min-w-0">
                    <div className="w-2 h-2 rounded-full shrink-0"
                      style={{ background: PRIORITY_COLOR[d.priority] ?? '#616161' }} />
                    <div className="min-w-0">
                      <div className="text-xs font-mono font-medium" style={{ color: 'var(--color-brand)' }}>
                        {d.dispute_id.slice(-8).toUpperCase()}
                      </div>
                      {isPreDispute && (
                        <div className="text-2xs" style={{ color: '#835b00' }}>⚡ Pre-Dispute Alert</div>
                      )}
                      {d.status === 'CHARGEBACK' && (
                        <div className="text-2xs font-medium" style={{ color: '#c50f1f' }}>Charged Back</div>
                      )}
                    </div>
                  </div>

                  {/* Reason */}
                  <div className="col-span-2 flex items-center">
                    <span className="text-xs truncate" style={{ color: 'var(--color-text)' }}>
                      {DISPUTE_TYPE_LABEL[d.dispute_type] ?? d.dispute_type}
                    </span>
                  </div>

                  {/* Customer */}
                  <div className="col-span-2 flex items-center">
                    <span className="text-xs truncate" style={{ color: 'var(--color-text-muted)' }}>
                      {customer ?? '—'}
                    </span>
                  </div>

                  {/* Amount */}
                  <div className="col-span-1 flex items-center justify-end">
                    <span className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>
                      {amount > 0 ? `₹${amount.toLocaleString()}` : '—'}
                    </span>
                  </div>

                  {/* SLA */}
                  <div className="col-span-1 flex items-center">
                    <span className="text-xs font-medium"
                      style={{ color: dsla ? dsla.color : 'var(--color-text-muted)' }}>
                      {slaDisplay}
                    </span>
                  </div>

                  {/* Evidence */}
                  <div className="col-span-1 flex items-center">
                    {evidenceStrength ? (
                      <span className="text-xs font-medium px-2 py-0.5 rounded-full"
                        style={{ background: `${evidenceStrength.color}14`, color: evidenceStrength.color }}>
                        {evidenceStrength.label}
                      </span>
                    ) : (
                      <span className="text-xs" style={{ color: 'var(--color-text-muted)' }}>—</span>
                    )}
                  </div>

                  {/* Next Action */}
                  <div className="col-span-2 flex items-center justify-end gap-2">
                    <span className="text-xs font-medium px-2.5 py-1 rounded-fluent border"
                      style={{
                        color: nextAction.color,
                        borderColor: `${nextAction.color}33`,
                        background: `${nextAction.color}0d`,
                      }}>
                      {nextAction.label}
                    </span>
                    <ChevronRight size={13} className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                      style={{ color: 'var(--color-brand)' }} />
                  </div>
                </button>
              )
            })}
          </div>
        </div>
      )}

      {/* Footer hint */}
      {filtered.length > 0 && (
        <p className="text-xs mt-3 text-center" style={{ color: 'var(--color-text-subtle)' }}>
          {filtered.length} dispute{filtered.length !== 1 ? 's' : ''} · sorted by deadline urgency
        </p>
      )}
    </div>
  )
}
