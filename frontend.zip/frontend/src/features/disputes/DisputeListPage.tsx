import { useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { Plus, Clock, RefreshCw, Search, X, ChevronDown, SearchCheck, Trash2, Check } from 'lucide-react'
import { disputeApi, platformApi } from '@/services/api'
import type { Dispute, PlatformImpact } from '@/types'
import { formatDistanceToNow } from 'date-fns'
import clsx from 'clsx'
import toast from 'react-hot-toast'
import { Button, PageHeader, ScoreRing } from '@/components/ui'
import { isIssuerResolved } from '@/lib/disputeStatus'

// ── Constants ─────────────────────────────────────────────────────────────────

const PRIORITY_DOT: Record<string, string> = {
  CRITICAL: 'bg-red-600', HIGH: 'bg-red-400', MEDIUM: 'bg-amber-400', LOW: 'bg-neutral-400',
}
const PRIORITY_LABEL_COLOR: Record<string, string> = {
  CRITICAL: '#c50f1f', HIGH: '#d13438', MEDIUM: '#ca5010', LOW: '#835b00',
}
const STATUS_STYLE: Record<string, { bg: string; text: string }> = {
  OPEN:                { bg: 'rgba(0,120,212,0.1)',   text: 'var(--color-brand)' },
  UNDER_INVESTIGATION: { bg: 'rgba(202,80,16,0.1)',   text: 'var(--color-medium)' },
  PENDING_DECISION:    { bg: 'rgba(92,45,145,0.1)',   text: '#5c2d91' },
  APPROVED:            { bg: 'rgba(16,124,16,0.1)',   text: 'var(--color-success)' },
  REJECTED:            { bg: 'rgba(197,15,31,0.1)',   text: 'var(--color-critical)' },
  ESCALATED:           { bg: 'rgba(202,80,16,0.12)',  text: '#ca5010' },
  CLOSED:              { bg: 'var(--color-surface-r)', text: 'var(--color-text-muted)' },
  CHARGEBACK:          { bg: 'rgba(197,15,31,0.1)',   text: 'var(--color-critical)' },
  REPRESENTMENT:       { bg: 'rgba(92,45,145,0.1)',   text: '#5c2d91' },
}
const DISPUTE_TYPES = [
  'UNAUTHORIZED_TRANSACTION', 'DUPLICATE_TRANSACTION', 'MERCHANDISE_NOT_RECEIVED',
  'MERCHANDISE_NOT_AS_DESCRIBED', 'REFUND_NOT_PROCESSED', 'SUBSCRIPTION_CANCELLATION',
  'CASH_WITHDRAWAL_DISPUTE', 'PROCESSING_ERROR',
]
const STAGES_NEEDING_ACTION = ['EVIDENCE_COLLECTION', 'REPRESENTMENT', 'PRE_ARBITRATION', 'ARBITRATION']

type SmartChip = 'sla_risk' | 'overdue' | 'high_value' | 'needs_action' | 'critical' | null

// SLA is shown and filtered in days — d.days_remaining comes straight from
// the backend's priority-score computation (packages/intelligence/
// priority_scoring.py), so this page never recomputes it from d.deadline itself.
function slaDaysLabel(d: Dispute): { label: string; color: string; urgent: boolean } | null {
  if (d.days_remaining == null) return null
  const days = d.days_remaining
  if (days < 0) {
    return { label: `Overdue ${Math.ceil(Math.abs(days))}d`, color: 'var(--color-critical)', urgent: true }
  }
  const whole = Math.ceil(days)
  return {
    label: `${whole}d left`,
    color: days < 1 ? 'var(--color-critical)' : days < 3 ? 'var(--color-medium)' : 'var(--color-text-subtle)',
    urgent: days < 1,
  }
}

function scoreStyle(score: number): { bg: string; text: string } {
  if (score >= 80) return { bg: 'rgba(197,15,31,0.12)', text: 'var(--color-critical)' }
  if (score >= 50) return { bg: 'rgba(202,80,16,0.12)', text: 'var(--color-medium)' }
  if (score >= 20) return { bg: 'rgba(131,91,0,0.12)', text: '#835b00' }
  return { bg: 'var(--color-surface-r)', text: 'var(--color-text-muted)' }
}

// ── Chip component ────────────────────────────────────────────────────────────

function Chip({ label, active, color = 'var(--color-brand)', count, onClick }: {
  label: string; active: boolean; color?: string; count?: number; onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-all"
      style={{
        background: active ? `${color}18` : 'var(--color-surface)',
        borderColor: active ? color : 'var(--color-border)',
        color: active ? color : 'var(--color-text-muted)',
      }}>
      {label}
      {count !== undefined && count > 0 && (
        <span className="text-2xs px-1 rounded-full font-semibold"
          style={{
            background: active ? color : 'var(--color-surface-r)',
            color: active ? 'white' : 'var(--color-text-muted)',
          }}>
          {count}
        </span>
      )}
    </button>
  )
}

// ── Main Component ────────────────────────────────────────────────────────────

export function DisputeListPage() {
  const navigate = useNavigate()
  const qc = useQueryClient()
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [priorityFilter, setPriorityFilter] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [smartChip, setSmartChip] = useState<SmartChip>(null)
  const [sortMode, setSortMode] = useState<'priority' | 'updated'>('priority')
  const [page, setPage] = useState(1)
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null)
  const PAGE_SIZE = 20

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['disputes'],
    queryFn: () => disputeApi.list({ page_size: 200 }),
    select: (r) => r.data as { items: Dispute[]; total: number },
    refetchInterval: 30_000,
  })

  const archiveMutation = useMutation({
    mutationFn: (id: string) => disputeApi.archive(id),
    onSuccess: () => {
      toast.success('Case deleted')
      setConfirmDeleteId(null)
      qc.invalidateQueries({ queryKey: ['disputes'] })
    },
    onError: (e: any) => toast.error(e?.response?.data?.detail ?? 'Could not delete this case'),
  })

  const allItems = data?.items ?? []

  // Smart chip counts
  const chipCounts = useMemo(() => ({
    sla_risk:    allItems.filter((d) => d.days_remaining !== null && d.days_remaining >= 0 && d.days_remaining < 1).length,
    overdue:     allItems.filter((d) => d.days_remaining !== null && d.days_remaining < 0).length,
    high_value:  allItems.filter((d) => Number(d.metadata?.amount_disputed) > 10000).length,
    needs_action:allItems.filter((d) => STAGES_NEEDING_ACTION.includes(d.lifecycle_stage)).length,
    critical:    allItems.filter((d) => d.priority === 'CRITICAL').length,
  }), [allItems])

  // Filter pipeline — always sorted by status group first (open/active cases
  // before resolved ones — an APPROVED case with a high score doesn't need
  // anyone's attention anymore, so it never belongs above a real open case),
  // then by priority score within each group, as the final step regardless
  // of which filters are active.
  const filtered = useMemo(() => {
    let items = allItems

    // Smart chip
    if (smartChip === 'sla_risk')    items = items.filter((d) => d.days_remaining !== null && d.days_remaining >= 0 && d.days_remaining < 1)
    if (smartChip === 'overdue')     items = items.filter((d) => d.days_remaining !== null && d.days_remaining < 0)
    if (smartChip === 'high_value')  items = items.filter((d) => Number(d.metadata?.amount_disputed) > 10000)
    if (smartChip === 'needs_action')items = items.filter((d) => STAGES_NEEDING_ACTION.includes(d.lifecycle_stage))
    if (smartChip === 'critical')    items = items.filter((d) => d.priority === 'CRITICAL')

    // Status
    if (statusFilter)   items = items.filter((d) => d.status === statusFilter)
    // Priority
    if (priorityFilter) items = items.filter((d) => d.priority === priorityFilter)
    // Type
    if (typeFilter)     items = items.filter((d) => d.dispute_type === typeFilter)

    // Search
    if (search.trim()) {
      const q = search.trim().toLowerCase()
      items = items.filter((d) =>
        d.dispute_id.toLowerCase().includes(q) ||
        d.dispute_type.toLowerCase().includes(q) ||
        String(d.metadata?.merchant_name ?? '').toLowerCase().includes(q) ||
        String(d.metadata?.customer_name ?? '').toLowerCase().includes(q) ||
        String(d.transaction_reference ?? '').toLowerCase().includes(q)
      )
    }

    return items.slice().sort((a, b) => {
      const resolvedDelta = Number(isIssuerResolved(a)) - Number(isIssuerResolved(b))
      if (resolvedDelta !== 0) return resolvedDelta
      return sortMode === 'updated'
        ? new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
        : b.priority_score - a.priority_score
    })
  }, [allItems, search, statusFilter, priorityFilter, typeFilter, smartChip, sortMode])

  // Pagination
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE)
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)

  function clearFilters() {
    setSearch(''); setStatusFilter(''); setPriorityFilter(''); setTypeFilter(''); setSmartChip(null); setPage(1)
  }
  const hasFilters = !!search || !!statusFilter || !!priorityFilter || !!typeFilter || smartChip !== null

  function toggleChip(chip: NonNullable<SmartChip>) {
    setSmartChip((c) => c === chip ? null : chip)
    setPage(1)
  }

  const uniqueStatuses = [...new Set(allItems.map((d) => d.status))].sort()

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader
        title="My Cases"
        description={
          filtered.length === allItems.length
            ? `${allItems.length} cases`
            : `${filtered.length} of ${allItems.length} cases`
        }
        actions={
          <>
            <Button variant="secondary" size="sm" onClick={() => refetch()}>
              <RefreshCw size={13} className={isFetching ? 'animate-spin' : ''} />
              Refresh
            </Button>
            <Button data-tour="new-case-btn" variant="primary" size="sm" onClick={() => navigate('/disputes/new')}>
              <Plus size={13} />
              New Case
            </Button>
          </>
        }
      />

      <GapsFoundBanner />

      {/* Filter bar */}
      <div data-tour="cases-search" className="rounded-fluent-lg border p-4 mb-4 space-y-3"
        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        {/* Search + dropdowns */}
        <div className="flex gap-3 flex-wrap">
          <div className="flex items-center gap-2 px-3 py-2 rounded-fluent border flex-1 min-w-48"
            style={{ background: 'var(--color-surface-r)', borderColor: 'var(--color-border)' }}>
            <Search size={13} style={{ color: 'var(--color-text-muted)' }} />
            <input
              className="flex-1 text-sm outline-none bg-transparent"
              style={{ color: 'var(--color-text)' }}
              placeholder="Search by ID, merchant, customer, type…"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1) }}
            />
            {search && (
              <button onClick={() => setSearch('')}>
                <X size={12} style={{ color: 'var(--color-text-subtle)' }} />
              </button>
            )}
          </div>

          <Select label="Status" value={statusFilter}
            options={uniqueStatuses}
            onChange={(v) => { setStatusFilter(v); setPage(1) }} />
          <Select label="Priority" value={priorityFilter}
            options={['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']}
            onChange={(v) => { setPriorityFilter(v); setPage(1) }} />
          <Select label="Type" value={typeFilter}
            options={DISPUTE_TYPES}
            optionLabel={(t) => t.replace(/_/g, ' ')}
            onChange={(v) => { setTypeFilter(v); setPage(1) }} />

          {/* Sort — was always priority-first with no alternative; a segmented
              toggle rather than the Select above since there's no "no sort" state
              to fall back to (always one of the two). */}
          <div className="flex items-center rounded-fluent border overflow-hidden shrink-0"
            style={{ borderColor: 'var(--color-border)' }}>
            {(['priority', 'updated'] as const).map((mode) => (
              <button key={mode} onClick={() => setSortMode(mode)}
                className="px-3 py-2 text-sm transition-colors"
                style={{
                  background: sortMode === mode ? 'rgba(0,120,212,0.06)' : 'var(--color-surface-r)',
                  color: sortMode === mode ? 'var(--color-brand)' : 'var(--color-text-muted)',
                  fontWeight: sortMode === mode ? 600 : 400,
                }}>
                {mode === 'priority' ? 'Priority' : 'Latest Updated'}
              </button>
            ))}
          </div>

          {hasFilters && (
            <button onClick={clearFilters}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-fluent text-xs border"
              style={{ color: 'var(--color-text-muted)', borderColor: 'var(--color-border)' }}>
              <X size={11} /> Clear
            </button>
          )}
        </div>

        {/* Smart chips */}
        <div className="flex gap-2 flex-wrap">
          <span className="text-xs self-center shrink-0" style={{ color: 'var(--color-text-subtle)' }}>Quick filters:</span>
          <Chip label="SLA Risk" active={smartChip === 'sla_risk'} color="var(--color-medium)"
            count={chipCounts.sla_risk} onClick={() => toggleChip('sla_risk')} />
          <Chip label="Overdue" active={smartChip === 'overdue'} color="var(--color-critical)"
            count={chipCounts.overdue} onClick={() => toggleChip('overdue')} />
          <Chip label="Critical" active={smartChip === 'critical'} color="#c50f1f"
            count={chipCounts.critical} onClick={() => toggleChip('critical')} />
          <Chip label="High Value" active={smartChip === 'high_value'} color="#5c2d91"
            count={chipCounts.high_value} onClick={() => toggleChip('high_value')} />
          <Chip label="Needs Action" active={smartChip === 'needs_action'} color="var(--color-brand)"
            count={chipCounts.needs_action} onClick={() => toggleChip('needs_action')} />
        </div>
      </div>

      {/* Table */}
      <div data-tour="cases-table" className="rounded-fluent-lg overflow-hidden shadow-fluent-sm"
        style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--color-border)', background: 'var(--color-surface-r)' }}>
                {['Case', 'Type', 'Merchant', 'Amount', 'Status', 'Stage', 'Score', 'SLA', 'Updated', ''].map((h) => (
                  <th key={h} className="text-left px-4 py-2.5 font-medium text-xs uppercase tracking-wide whitespace-nowrap"
                    style={{ color: 'var(--color-text-muted)' }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={10} className="text-center py-12" style={{ color: 'var(--color-text-muted)' }}>Loading…</td>
                </tr>
              ) : paged.length === 0 ? (
                <tr>
                  <td colSpan={10} className="text-center py-16">
                    <p className="text-sm font-medium mb-1" style={{ color: 'var(--color-text-muted)' }}>
                      {hasFilters ? 'No cases match your filters.' : 'No cases yet.'}
                    </p>
                    {hasFilters && (
                      <button onClick={clearFilters} className="text-xs" style={{ color: 'var(--color-brand)' }}>
                        Clear filters
                      </button>
                    )}
                  </td>
                </tr>
              ) : (
                paged.map((d) => {
                  const sla = slaDaysLabel(d)
                  const score = scoreStyle(d.priority_score)
                  const amount = Number(d.metadata?.amount_disputed)
                  const statusStyle = STATUS_STYLE[d.status] ?? STATUS_STYLE.CLOSED
                  return (
                    <tr key={d.dispute_id}
                      className="group cursor-pointer transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-800/40"
                      style={{ borderBottom: '1px solid var(--color-border)' }}
                      onClick={() => navigate(`/disputes/${d.dispute_id}`)}>
                      {/* Case */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <span className={clsx('inline-block w-2 h-2 rounded-full shrink-0', PRIORITY_DOT[d.priority] ?? 'bg-neutral-400')} />
                          <span className="font-mono text-xs" style={{ color: 'var(--color-brand)' }}>
                            {d.dispute_id.slice(0, 8).toUpperCase()}
                          </span>
                          {d.priority === 'CRITICAL' && (
                            <span className="text-2xs px-1 rounded font-bold"
                              style={{ background: 'rgba(197,15,31,0.1)', color: PRIORITY_LABEL_COLOR.CRITICAL }}>
                              CRIT
                            </span>
                          )}
                        </div>
                      </td>
                      {/* Type */}
                      <td className="px-4 py-3 text-sm max-w-xs" style={{ color: 'var(--color-text)' }}>
                        <span className="line-clamp-1">{d.dispute_type.replace(/_/g, ' ')}</span>
                      </td>
                      {/* Merchant */}
                      <td className="px-4 py-3 text-sm max-w-xs" style={{ color: 'var(--color-text)' }}>
                        {d.metadata?.merchant_name
                          ? <span className="line-clamp-1">{String(d.metadata.merchant_name)}</span>
                          : <span style={{ color: 'var(--color-text-subtle)' }}>—</span>}
                      </td>
                      {/* Amount */}
                      <td className="px-4 py-3 text-sm font-medium whitespace-nowrap" style={{ color: 'var(--color-text)' }}>
                        {!isNaN(amount) && amount > 0
                          ? `₹${amount.toLocaleString()}`
                          : <span style={{ color: 'var(--color-text-subtle)' }}>—</span>}
                      </td>
                      {/* Status */}
                      <td className="px-4 py-3">
                        <span className="text-xs px-2 py-0.5 rounded font-medium whitespace-nowrap"
                          style={{ background: statusStyle.bg, color: statusStyle.text }}>
                          {d.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                      {/* Stage */}
                      <td className="px-4 py-3 text-xs whitespace-nowrap" style={{ color: 'var(--color-text-muted)' }}>
                        {d.lifecycle_stage.replace(/_/g, ' ')}
                      </td>
                      {/* Priority Score */}
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span
                          className="relative inline-flex items-center justify-center"
                          style={{ width: 28, height: 28 }}
                          title="Deterministic 0-100 triage score — weighs time-to-deadline, disputed amount, and card tier">
                          <ScoreRing value={d.priority_score} color={score.text} />
                          <span className="absolute text-[9px] font-bold" style={{ color: score.text }}>
                            {d.priority_score}
                          </span>
                        </span>
                      </td>
                      {/* SLA — shown in days, never hours/minutes */}
                      <td className="px-4 py-3 whitespace-nowrap">
                        {sla ? (
                          <span className="flex items-center gap-1 text-xs font-medium" style={{ color: sla.color }}>
                            <Clock size={11} />
                            {sla.label}
                          </span>
                        ) : <span style={{ color: 'var(--color-text-subtle)' }}>—</span>}
                      </td>
                      {/* Updated */}
                      <td className="px-4 py-3 text-xs whitespace-nowrap" style={{ color: 'var(--color-text-subtle)' }}>
                        {formatDistanceToNow(new Date(d.updated_at), { addSuffix: true })}
                      </td>
                      {/* Delete — soft-archives the case, doesn't touch its audit trail */}
                      <td className="px-4 py-3 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                        {confirmDeleteId === d.dispute_id ? (
                          <div className="flex items-center gap-1">
                            <button
                              title="Confirm delete"
                              onClick={() => archiveMutation.mutate(d.dispute_id)}
                              disabled={archiveMutation.isPending}
                              className="p-1 rounded-fluent"
                              style={{ color: 'var(--color-critical)', background: 'rgba(197,15,31,0.08)' }}>
                              <Check size={13} />
                            </button>
                            <button
                              title="Cancel"
                              onClick={() => setConfirmDeleteId(null)}
                              className="p-1 rounded-fluent"
                              style={{ color: 'var(--color-text-muted)' }}>
                              <X size={13} />
                            </button>
                          </div>
                        ) : (
                          <button
                            title="Delete case"
                            onClick={() => setConfirmDeleteId(d.dispute_id)}
                            className="p-1 rounded-fluent opacity-0 group-hover:opacity-100 transition-opacity hover:bg-neutral-100 dark:hover:bg-neutral-800"
                            style={{ color: 'var(--color-text-subtle)' }}>
                            <Trash2 size={13} />
                          </button>
                        )}
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination footer */}
        {filtered.length > PAGE_SIZE && (
          <div className="flex items-center justify-between px-4 py-3 border-t"
            style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-r)' }}>
            <span className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
              Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)} of {filtered.length}
            </span>
            <div className="flex gap-1">
              <Button variant="secondary" size="sm" disabled={page === 1}
                onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                const pg = i + 1
                return (
                  <button key={pg} onClick={() => setPage(pg)}
                    className="w-7 h-7 rounded-fluent text-xs border transition-colors"
                    style={{
                      background: page === pg ? 'var(--color-brand)' : 'transparent',
                      borderColor: page === pg ? 'var(--color-brand)' : 'var(--color-border)',
                      color: page === pg ? 'white' : 'var(--color-text-muted)',
                    }}>
                    {pg}
                  </button>
                )
              })}
              {totalPages > 7 && (
                <span className="self-center text-xs px-1" style={{ color: 'var(--color-text-subtle)' }}>…{totalPages}</span>
              )}
              <Button variant="secondary" size="sm" disabled={page === totalPages}
                onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ── Select dropdown helper ─────────────────────────────────────────────────────

function Select({ label, value, options, optionLabel, onChange }: {
  label: string; value: string; options: string[]
  optionLabel?: (v: string) => string; onChange: (v: string) => void
}) {
  return (
    <div className="relative">
      <div className="flex items-center gap-1.5 px-3 py-2 rounded-fluent border cursor-pointer"
        style={{
          background: value ? 'rgba(0,120,212,0.06)' : 'var(--color-surface-r)',
          borderColor: value ? 'var(--color-brand)' : 'var(--color-border)',
        }}>
        <select
          className="text-sm outline-none bg-transparent cursor-pointer appearance-none pr-5"
          style={{ color: value ? 'var(--color-brand)' : 'var(--color-text-muted)' }}
          value={value}
          onChange={(e) => onChange(e.target.value)}>
          <option value="">{label}</option>
          {options.map((o) => (
            <option key={o} value={o}>{optionLabel ? optionLabel(o) : o}</option>
          ))}
        </select>
        <ChevronDown size={12} className="absolute right-2 pointer-events-none"
          style={{ color: value ? 'var(--color-brand)' : 'var(--color-text-muted)' }} />
      </div>
    </div>
  )
}

// ── Gap-finding value callout ────────────────────────────────────────────────
// One line, computed live from real data (README §19) — how many evidence
// gaps the agent found across this queue without a human having to ask.

function GapsFoundBanner() {
  const { data } = useQuery({
    queryKey: ['platform-impact'],
    queryFn: () => platformApi.impact(),
    select: (r) => r.data as PlatformImpact,
  })
  const gaps = data?.evidence_gaps_auto_identified
  if (!gaps || gaps.gaps_identified_total === 0) return null

  return (
    <div className="flex items-center gap-2 text-xs px-3 py-2 rounded-fluent mb-4"
      style={{ background: 'rgba(16,124,16,0.06)', border: '1px solid rgba(16,124,16,0.25)', color: 'var(--color-success)' }}>
      <SearchCheck size={13} className="shrink-0" />
      <strong>{gaps.gaps_identified_total} evidence gap{gaps.gaps_identified_total === 1 ? '' : 's'}</strong>
      &nbsp;identified automatically across this queue — {gaps.gaps_open} still open — without a human having to request them first.
    </div>
  )
}
