import { useEffect, useRef, useState, type ReactNode } from 'react'
import { useParams, NavLink, Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  AlertTriangle, Bot, CheckCircle, CheckCircle2, Clock, XCircle, Zap,
  ArrowRight, HelpCircle, Search, TrendingUp, RefreshCw,
  ChevronDown, ChevronRight, FileText, AlertCircle, Layers, Eye, Loader2, Sparkles,
  Mail, Send, UploadCloud, FileUp
} from 'lucide-react'
import { disputeApi, agentApi, evidenceApi, claimApi, platformApi } from '@/services/api'
import { connectAgentStream, SSEEvent } from '@/services/sse'
import type { Dispute, Evidence, Recommendation, Hypothesis, Contradiction, EvidenceGap, Claim, Precedents, EvalScoreEntry } from '@/types'
import { ISSUER_RESOLVED_STATUSES } from '@/lib/disputeStatus'
import { evidenceLabel } from '@/lib/evidenceLabel'
import { ScenarioTimeline } from '@/components/ScenarioTimeline'
import { formatDistanceToNow, parseISO } from 'date-fns'
import toast from 'react-hot-toast'
import clsx from 'clsx'
import { Button, DocumentPreviewModal } from '@/components/ui'
import { useDocumentPreview } from '@/hooks/useDocumentPreview'

// ── Constants ─────────────────────────────────────────────────────────────────

const TABS = [
  { label: 'Case Workspace', path: '' },
  { label: 'Evidence', path: '/evidence' },
  { label: 'Timeline', path: '/timeline' },
  { label: 'Hypotheses', path: '/hypotheses' },
  { label: 'Approvals', path: '/approvals' },
  { label: 'Audit', path: '/audit' },
]

// Mirrors the actual LangGraph pipeline in packages/agent/graph.py — keep in
// sync with that node list (9 nodes as of GRAPH_VERSION 1.1.0).
const GRAPH_NODES = [
  { key: 'load_case_state',        label: 'Loading case' },
  { key: 'retrieve_context',       label: 'Retrieving policy & precedent context' },
  { key: 'understand_dispute',     label: 'Understanding dispute' },
  { key: 'assess_evidence',        label: 'Assessing evidence' },
  { key: 'identify_gaps',          label: 'Identifying gaps' },
  { key: 'generate_hypotheses',    label: 'Generating hypotheses' },
  { key: 'prepare_recommendation', label: 'Preparing recommendation' },
  { key: 'propose_actions',        label: 'Proposing actions' },
  { key: 'finalize',               label: 'Finalizing' },
]

// README §62: keyed by action_type-shaped values (CHALLENGE_REPRESENTMENT,
// ACCEPT_DISPUTE, SEND_NOTIFICATION, ...) but looked up below using
// recommendation.recommendation_type, which is only ever UPHOLD_DISPUTE |
// DENY_DISPUTE | ESCALATE | REQUEST_EVIDENCE (packages/agent/prompts.py's
// PREPARE_RECOMMENDATION format). ESCALATE/REQUEST_EVIDENCE happened to overlap by
// coincidence; UPHOLD_DISPUTE/DENY_DISPUTE — the two decisive, most common real
// outcomes — never matched anything, so the "Recommended Action" panel silently
// never appeared for them. Re-keyed to the real enum; the 4 action_type-only
// entries this never actually reached were removed.
const NBA_MAP: Record<string, { label: string; description: string; color: string }> = {
  REQUEST_EVIDENCE: { label: 'Request Missing Evidence',  description: 'Obtain the information identified as critical to the assessment.',  color: 'var(--color-brand)' },
  UPHOLD_DISPUTE:   { label: 'Accept Customer Claim',      description: 'Evidence strongly supports the customer. Accept the dispute.',       color: 'var(--color-success)' },
  DENY_DISPUTE:     { label: 'Reject Customer Claim',      description: 'Current evidence does not support the customer claim.',              color: 'var(--color-critical)' },
  ESCALATE:         { label: 'Escalate to Supervisor',     description: 'This case requires senior review before a decision can be made.',    color: 'var(--color-medium)' },
}

const PRIORITY_COLOR: Record<string, string> = {
  CRITICAL: '#c50f1f', HIGH: '#d13438', MEDIUM: '#ca5010', LOW: '#835b00',
}

const MATERIALITY_COLOR: Record<string, string> = {
  HIGH: '#d13438', MEDIUM: '#ca5010', LOW: '#835b00', UNKNOWN: '#616161',
}

// ── Helpers ───────────────────────────────────────────────────────────────────

// SLA is shown in days, not hours/minutes — dispute.days_remaining comes
// straight from the backend's priority-score computation (packages/
// intelligence/priority_scoring.py), same source DisputeListPage uses, so
// this never recomputes it from dispute.deadline itself.
function slaInfo(dispute: Dispute) {
  if (dispute.days_remaining == null) return null
  const days = dispute.days_remaining
  const overdue = days < 0
  const urgent = days < 1
  const color = overdue || urgent ? 'var(--color-critical)' : days < 3 ? 'var(--color-medium)' : 'var(--color-text-muted)'
  const label = overdue ? `Overdue ${Math.ceil(Math.abs(days))}d` : `${Math.ceil(days)}d remaining`
  return { overdue, color, label, urgent }
}

function formatIntakeSeconds(seconds: number): string {
  if (seconds < 60) return `${seconds}s`
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}m ${s}s`
}

const INTAKE_METHOD_LABEL: Record<string, string> = {
  ai_assisted: 'AI-Assisted', manual: 'Manual Entry', sample: 'Sample Data',
}

// ── Main Component ────────────────────────────────────────────────────────────

export function DisputeCommandCenter() {
  const { id } = useParams<{ id: string }>()
  const qc = useQueryClient()
  const [agentNodes, setAgentNodes] = useState<Record<string, 'pending' | 'running' | 'complete'>>({})
  const [agentRunning, setAgentRunning] = useState(false)
  // The 9-step grid used to sit inline at the top of the page, pushing the rest of
  // the workspace down and reading as a wall of small text rather than something
  // actively happening. A modal makes the wait itself the focus — dismissable (it
  // never cancels the real run, which keeps going via the SSE/polling below either
  // way) rather than trapping the analyst on the page.
  const [showAgentModal, setShowAgentModal] = useState(false)
  const [agentOutcome, setAgentOutcome] = useState<'RUNNING' | 'COMPLETED' | 'FAILED' | null>(null)
  const [staleAlert, setStaleAlert] = useState<string | null>(null)
  const [showStory, setShowStory] = useState(true)
  const disconnectSSE = useRef<(() => void) | null>(null)

  const { data: dispute, isError: disputeNotFound } = useQuery({
    queryKey: ['dispute', id],
    queryFn: () => disputeApi.get(id!),
    select: (r) => r.data as Dispute,
    enabled: !!id,
    retry: false,
    refetchInterval: (query) => (query.state.error ? false : 30_000),
  })

  const { data: recommendation, refetch: refetchRec } = useQuery({
    queryKey: ['recommendation', id],
    queryFn: () => disputeApi.getRecommendation(id!),
    select: (r) => r.data as Recommendation,
    enabled: !!id,
    retry: false,
  })

  const { data: evidence = [], refetch: refetchEvidence } = useQuery({
    queryKey: ['evidence', id],
    queryFn: () => evidenceApi.list(id!, { current_only: true }),
    select: (r) => r.data as Evidence[],
    enabled: !!id,
  })

  const { data: hypotheses = [] } = useQuery({
    queryKey: ['hypotheses', id],
    queryFn: () => disputeApi.getHypotheses(id!),
    select: (r) => r.data as Hypothesis[],
    enabled: !!id,
    retry: false,
  })

  const { data: precedents } = useQuery({
    queryKey: ['precedents', id],
    queryFn: () => disputeApi.getPrecedents(id!),
    select: (r) => r.data as Precedents,
    enabled: !!id,
    retry: false,
  })

  const { data: contradictions = [] } = useQuery({
    queryKey: ['contradictions', id],
    queryFn: () => disputeApi.getContradictions(id!),
    select: (r) => r.data as Contradiction[],
    enabled: !!id,
    retry: false,
  })

  const { data: gaps = [], refetch: refetchGaps } = useQuery({
    queryKey: ['gaps', id],
    queryFn: () => disputeApi.getGaps(id!),
    select: (r) => r.data as EvidenceGap[],
    enabled: !!id,
    retry: false,
  })

  // If this case is one sub-case of a multi-transaction claim, fetch the
  // siblings so the analyst can see and jump to the other transactions.
  const { data: claim } = useQuery({
    queryKey: ['claim', dispute?.claim_id],
    queryFn: () => claimApi.get(dispute!.claim_id!),
    select: (r) => r.data as Claim,
    enabled: !!dispute?.claim_id,
    retry: false,
  })

  // Shared by both the SSE handler and the polling backstop below — a run can
  // finish exactly once, however the UI finds out about it.
  const agentDoneHandledRef = useRef(false)
  function handleAgentDone(outcome: 'COMPLETED' | 'FAILED') {
    if (agentDoneHandledRef.current) return
    agentDoneHandledRef.current = true
    setAgentRunning(false)
    setAgentOutcome(outcome)
    if (outcome === 'COMPLETED') {
      refetchRec()
      refetchGaps()
      qc.invalidateQueries({ queryKey: ['hypotheses', id] })
      qc.invalidateQueries({ queryKey: ['contradictions', id] })
      qc.invalidateQueries({ queryKey: ['dispute', id] })
      toast.success('Agent analysis complete')
      // Let the modal show the "done" state for a beat instead of vanishing the
      // instant the last step lands — then close on its own; a failure stays open
      // so the analyst has to actually see and dismiss it, not miss it.
      setTimeout(() => setShowAgentModal(false), 1400)
    } else {
      toast.error('Agent analysis encountered an issue. Your existing case information is still available.')
    }
  }

  // SSE subscription
  useEffect(() => {
    if (!id) return
    const disconnect = connectAgentStream(id, (event: SSEEvent) => {
      if (event.type === 'node_start') {
        setAgentNodes((prev) => ({ ...prev, [event.node as string]: 'running' }))
      } else if (event.type === 'node_complete') {
        setAgentNodes((prev) => ({ ...prev, [event.node as string]: 'complete' }))
      } else if (event.type === 'COMPLETE') {
        handleAgentDone('COMPLETED')
      } else if (event.type === 'FAILED') {
        handleAgentDone('FAILED')
      } else if (event.type === 'EVIDENCE_CHANGED') {
        setStaleAlert(event.detail as string ?? 'New evidence has been received.')
        refetchEvidence()
        refetchRec()
        refetchGaps()
        qc.invalidateQueries({ queryKey: ['dispute', id] })
        toast('New information received — case assessment updated', { icon: '⚡' })
      }
    })
    disconnectSSE.current = disconnect
    return () => disconnect()
  }, [id])

  // Polling backstop — a long-lived SSE connection through a corporate proxy can
  // silently drop mid-run without the browser ever firing an error (observed live:
  // node progress reaches 9/9 but the terminal COMPLETE event never arrives, and
  // the UI is stuck on "Analysing…" until a manual page refresh). While a run is
  // in flight, also poll the run's actual status directly — whichever signal
  // arrives first wins (handleAgentDone only acts once), so this never fights the
  // SSE path, it only covers for it.
  useEffect(() => {
    if (!agentRunning || !id) return
    const interval = setInterval(async () => {
      try {
        const r = await agentApi.status(id)
        if (r.data.status === 'COMPLETED' || r.data.status === 'FAILED') {
          handleAgentDone(r.data.status)
        }
      } catch {
        // best-effort — the SSE path or the next poll will catch it
      }
    }, 4000)
    return () => clearInterval(interval)
  }, [agentRunning, id])

  async function runAgent() {
    if (!id) return
    setAgentNodes({})
    agentDoneHandledRef.current = false
    setAgentOutcome('RUNNING')
    setShowAgentModal(true)
    setAgentRunning(true)
    try {
      await agentApi.run(id)
    } catch {
      setAgentRunning(false)
      setAgentOutcome(null)
      setShowAgentModal(false)
      toast.error('Could not start analysis')
    }
  }

  const chargebackMutation = useMutation({
    mutationFn: () => disputeApi.chargeback(id!),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['dispute', id] })
      toast.success('Charged back — now visible in the merchant analyst queue as action-required')
    },
    onError: () => toast.error('Could not issue the chargeback'),
  })

  // "Reject Customer Claim" (DENY_DISPUTE's recommended action) had no real handler —
  // clicking it always fell through to the generic "Action panel coming" placeholder
  // toast. REJECTED is a real, live-active status (Admin → Statuses), its own
  // description literally read "recognized by the platform's resolved-case logic; not
  // yet reachable through any UI action today" — this closes that gap the same way
  // Accept (the header's "Send Chargeback to Merchant") already does for the opposite
  // recommendation, via the same generic PATCH /disputes/:id path MerchantWorkspace's
  // accept/challenge flow already uses, rather than a dedicated endpoint.
  const rejectMutation = useMutation({
    mutationFn: () => disputeApi.update(id!, { status: 'REJECTED', metadata: { rejected_at: new Date().toISOString() } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['dispute', id] })
      toast.success("Customer claim rejected — case closed, no chargeback issued")
    },
    onError: () => toast.error('Could not reject this claim'),
  })

  const { docPreview, loadingDocId, pendingName, viewDocument, closeDocPreview } = useDocumentPreview(id)

  const [uploadingCaseEvidence, setUploadingCaseEvidence] = useState(false)
  const caseFileInputRef = useRef<HTMLInputElement>(null)
  const [showEvidenceRequestAction, setShowEvidenceRequestAction] = useState(false)

  // No document-type picker: the analyst just uploads and the backend's real vision
  // classification (disputes.py's upload_document — omitting document_type entirely
  // means it trusts its own classification instead of a caller guess) identifies
  // what it is, mirroring the merchant side's own upload control (README §67). After
  // attaching, this reuses runAgent() — the same real analysis run + AgentAnalysisModal
  // (§70) the "Analyse Case" button triggers — so the new document is genuinely
  // compared against the rest of the case, not just filed.
  async function handleUploadCaseEvidence(file: File) {
    if (!id) return
    setUploadingCaseEvidence(true)
    try {
      await disputeApi.uploadDocument(id, file)
      toast.success(`${file.name} attached — analysing…`)
      qc.invalidateQueries({ queryKey: ['dispute', id] })
      qc.invalidateQueries({ queryKey: ['evidence', id] })
      qc.invalidateQueries({ queryKey: ['contradictions', id] })
      qc.invalidateQueries({ queryKey: ['gaps', id] })
      await runAgent()
    } catch (e: any) {
      const detail = e?.response?.data?.detail as string | undefined
      toast.error(detail?.startsWith('Cyera Validation') ? detail : `Could not attach ${file.name}`)
    } finally {
      setUploadingCaseEvidence(false)
    }
  }

  if (disputeNotFound) return <CaseNotFound />
  if (!dispute) return <LoadingSkeleton />

  const sla = slaInfo(dispute)
  const meta = (dispute.metadata ?? {}) as Record<string, string>
  const openGaps = gaps.filter((g) => g.status === 'OPEN')
  const nba = recommendation?.recommendation_type ? NBA_MAP[recommendation.recommendation_type] : null

  return (
    <div className="flex flex-col h-full">
      {/* ── Case Header ── */}
      <div className="px-6 pt-5 pb-0 border-b shrink-0"
        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className="font-mono text-xs px-2 py-0.5 rounded"
                style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-muted)' }}>
                {dispute.dispute_id.slice(0, 12).toUpperCase()}…
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full border"
                style={{
                  color: PRIORITY_COLOR[dispute.priority] ?? 'var(--color-text-muted)',
                  borderColor: `${PRIORITY_COLOR[dispute.priority] ?? 'transparent'}40`,
                  background: `${PRIORITY_COLOR[dispute.priority] ?? '#616161'}14`,
                }}>
                {dispute.priority}
              </span>
              <span className="text-xs px-2 py-0.5 rounded border"
                style={{ color: 'var(--color-brand)', borderColor: 'rgba(0,120,212,0.3)', background: 'rgba(0,120,212,0.08)' }}>
                {dispute.status}
              </span>
              <span className="text-xs px-2 py-0.5 rounded border"
                style={{ color: 'var(--color-text-muted)', borderColor: 'var(--color-border)', background: 'var(--color-surface-r)' }}>
                {dispute.lifecycle_stage.replace(/_/g, ' ')}
              </span>
              {sla && (
                <span className="flex items-center gap-1 text-xs font-medium"
                  style={{ color: sla.color }}>
                  <Clock size={11} />
                  {sla.label}
                </span>
              )}
              {meta.creation_seconds && (
                <span className="text-2xs px-2 py-0.5 rounded-full"
                  style={{ background: 'rgba(16,124,16,0.08)', color: 'var(--color-success)' }}
                  title="Time to raise this case, self-measured in New Case">
                  Created in {formatIntakeSeconds(Number(meta.creation_seconds))}
                  {meta.intake_method ? ` · ${INTAKE_METHOD_LABEL[meta.intake_method as string] ?? meta.intake_method}` : ''}
                </span>
              )}
            </div>
            <h1 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>
              {dispute.dispute_type.replace(/_/g, ' ')}
            </h1>
            <p className="text-sm mt-0.5 line-clamp-1" style={{ color: 'var(--color-text-muted)' }}>
              {meta.merchant_name && <span className="mr-2">{meta.merchant_name}</span>}
              {meta.amount_disputed && (
                <span className="font-medium" style={{ color: 'var(--color-text)' }}>
                  ₹{Number(meta.amount_disputed).toLocaleString()}
                </span>
              )}
              {meta.customer_name && <span className="ml-2">· {meta.customer_name}</span>}
            </p>
          </div>

          <div className="flex items-center gap-2 ml-4 shrink-0">
            {!ISSUER_RESOLVED_STATUSES.includes(dispute.status) && dispute.status !== 'CHARGEBACK' && (
              <Button variant="secondary" onClick={() => chargebackMutation.mutate()} loading={chargebackMutation.isPending}
                style={{ color: 'var(--color-critical)', borderColor: 'rgba(197,15,31,0.35)' }}>
                {!chargebackMutation.isPending && <Zap size={14} />}
                {chargebackMutation.isPending ? 'Sending…' : 'Send Chargeback to Merchant'}
              </Button>
            )}
            {!ISSUER_RESOLVED_STATUSES.includes(dispute.status) && (
              <>
                {/* Button.tsx disables itself while loading, so a dismissed modal needs
                    its own re-open affordance rather than relying on this click. */}
                {agentRunning && !showAgentModal && (
                  <button onClick={() => setShowAgentModal(true)}
                    className="text-xs font-medium underline underline-offset-2"
                    style={{ color: 'var(--color-brand)' }}>
                    View progress
                  </button>
                )}
                <Button variant="primary" onClick={runAgent} loading={agentRunning}>
                  {agentRunning
                    ? 'Analysing…'
                    : <><Bot size={14} /> Analyse Case</>}
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Resolved banner — merchant accepted the chargeback (or the case is
            otherwise terminal); nothing further to send or analyse */}
        {ISSUER_RESOLVED_STATUSES.includes(dispute.status) && (
          <div className="flex items-center gap-2 text-xs px-3 py-2 rounded-fluent mb-3 border"
            style={{ background: 'rgba(16,124,16,0.06)', borderColor: 'rgba(16,124,16,0.25)', color: 'var(--color-success)' }}>
            <CheckCircle size={13} />
            <strong>Resolved — {
              dispute.status === 'APPROVED' ? 'merchant accepted the chargeback'
              : dispute.status === 'REJECTED' ? "the customer's claim was rejected; no chargeback was issued"
              : dispute.status.toLowerCase()
            }.</strong>
            &nbsp;This case is closed; no further action is available here.
          </div>
        )}

        {/* Representment banner — merchant contested instead of accepting */}
        {dispute.status === 'REPRESENTMENT' && (
          <>
            <div className="flex items-center gap-2 text-xs px-3 py-2 rounded-fluent mb-3 border"
              style={{ background: 'rgba(92,45,145,0.06)', borderColor: 'rgba(92,45,145,0.25)', color: '#5c2d91' }}>
              <FileText size={13} />
              <strong>Merchant submitted a representment</strong>
              &nbsp;— they are contesting this chargeback. Review their response and evidence, then re-run analysis if needed.
            </div>
            <EvidenceRequestPanel
              disputeId={dispute.dispute_id}
              requestedAt={(dispute.metadata as any)?.evidence_requested_at}
              onDone={() => qc.invalidateQueries({ queryKey: ['dispute', id] })}
            />
          </>
        )}

        {/* Chargeback issued banner */}
        {dispute.status === 'CHARGEBACK' && (
          <div className="flex items-center gap-2 text-xs px-3 py-2 rounded-fluent mb-3 border"
            style={{ background: 'rgba(197,15,31,0.06)', borderColor: 'rgba(197,15,31,0.25)', color: 'var(--color-critical)' }}>
            <Zap size={13} />
            <strong>Charged back to the merchant</strong>
            {meta.chargeback_issued_at && (
              <span className="opacity-80">
                &nbsp;on {new Date(meta.chargeback_issued_at).toLocaleString()}
              </span>
            )}
            — awaiting their response.
          </div>
        )}

        {/* Stale / New evidence banner */}
        {staleAlert && (
          <div className="flex items-center gap-2 text-xs px-3 py-2 rounded-fluent mb-3 border"
            style={{ background: 'rgba(202,80,16,0.1)', borderColor: 'rgba(202,80,16,0.3)', color: 'var(--color-medium)' }}>
            <Zap size={13} />
            <strong>New evidence received:</strong>&nbsp;{staleAlert}
            <button onClick={() => setStaleAlert(null)} className="ml-auto">
              <XCircle size={13} />
            </button>
          </div>
        )}

        {/* Multi-transaction claim: sibling sub-cases */}
        {claim && claim.sub_cases.length > 1 && (
          <div className="rounded-fluent mb-3 px-3 py-2"
            style={{ background: 'rgba(92,45,145,0.06)', border: '1px solid rgba(92,45,145,0.25)' }}>
            <div className="flex items-center gap-1.5 text-xs font-medium mb-1.5" style={{ color: '#5c2d91' }}>
              <Layers size={12} />
              Part of one claim covering {claim.sub_cases.length} transactions — {claim.status === 'RESOLVED' ? 'all resolved' : 'in progress'}
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              {claim.sub_cases.map((sc) => (
                <Link
                  key={sc.dispute_id}
                  to={`/disputes/${sc.dispute_id}`}
                  className={clsx(
                    'text-2xs px-2 py-1 rounded-fluent border transition-colors',
                    sc.dispute_id === dispute.dispute_id ? 'font-semibold' : 'hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  )}
                  style={{
                    borderColor: sc.dispute_id === dispute.dispute_id ? '#5c2d91' : 'var(--color-border)',
                    background: sc.dispute_id === dispute.dispute_id ? 'rgba(92,45,145,0.12)' : 'var(--color-surface)',
                    color: sc.dispute_id === dispute.dispute_id ? '#5c2d91' : 'var(--color-text-muted)',
                  }}>
                  {sc.metadata.merchant_name ? String(sc.metadata.merchant_name) : sc.transaction_reference ?? `Txn ${sc.claim_sequence}`}
                  <span className="ml-1 opacity-70">· {sc.status.replace(/_/g, ' ')}</span>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Tabs */}
        <nav className="flex gap-0 -mb-px overflow-x-auto">
          {TABS.map((tab) => (
            <NavLink key={tab.path} to={`/disputes/${id}${tab.path}`} end={tab.path === ''}
              className={({ isActive }) =>
                clsx('px-4 py-2 text-sm border-b-2 transition-colors whitespace-nowrap shrink-0',
                  isActive ? 'font-medium border-brand-500' : 'border-transparent hover:border-neutral-300')
              }
              style={({ isActive }) => ({ color: isActive ? 'var(--color-brand)' : 'var(--color-text-muted)' })}>
              {tab.label}
            </NavLink>
          ))}
        </nav>
      </div>

      {/* ── Workspace Body ── */}
      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-0 h-full">

          {/* ── Left: 5-Question Flow ── */}
          <div className="xl:col-span-2 p-6 space-y-5 border-r"
            style={{ borderColor: 'var(--color-border)' }}>

            {/* ① WHAT HAPPENED? */}
            <Section
              question="What happened?"
              icon={<FileText size={15} />}
              color="var(--color-brand)"
              badge={<span className="text-2xs px-1.5 py-0.5 rounded-full font-medium"
                style={{ background: 'rgba(0,120,212,0.1)', color: 'var(--color-brand)' }}>Digital Twin</span>}
              defaultOpen={showStory}
              onToggle={setShowStory}
            >
              {dispute.cardholder_claim && (
                <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--color-text)' }}>
                  The customer states: "{dispute.cardholder_claim}"
                </p>
              )}
              <ScenarioTimeline dispute={dispute} evidence={evidence} contradictions={contradictions} />
            </Section>

            {/* Evidence — documents attached to this case via document storage */}
            <Section question="Evidence" icon={<FileText size={15} />} color="#107c10"
              badge={dispute.evidence?.length ? <span className="text-2xs px-1.5 py-0.5 rounded-full font-semibold"
                style={{ background: 'rgba(16,124,16,0.1)', color: '#107c10' }}>{dispute.evidence.length}</span> : undefined}>
              {/* No type picker — just upload, and the real vision classification
                  identifies what it is (README §67, §70). Previously the only way to
                  add evidence after creation was §52's panel, gated to REPRESENTMENT-
                  status cases only. */}
              <div className="flex items-center gap-2 pb-3 mb-2 border-b" style={{ borderColor: 'var(--color-border)' }}>
                <input ref={caseFileInputRef} type="file" className="hidden"
                  accept="application/pdf,image/png,image/jpeg,image/webp"
                  onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) handleUploadCaseEvidence(f) }} />
                <Button variant="secondary" size="sm" disabled={uploadingCaseEvidence}
                  onClick={() => caseFileInputRef.current?.click()}>
                  {uploadingCaseEvidence ? <Loader2 size={12} className="animate-spin" /> : <FileUp size={12} />}
                  {uploadingCaseEvidence ? 'Uploading…' : 'Upload Document'}
                </Button>
                {!uploadingCaseEvidence && (
                  <span className="text-2xs" style={{ color: 'var(--color-text-subtle)' }}>
                    We'll identify what it is — no need to label it yourself.
                  </span>
                )}
              </div>
              {!dispute.evidence || dispute.evidence.length === 0 ? (
                <SmartEmpty icon={<FileText size={20} />} message="No documents attached yet."
                  sub="Upload one above, or via New Case." />
              ) : (
                <div className="space-y-2">
                  {dispute.evidence.map((doc) => {
                    const fullEvidence = evidence.find((e) => e.evidence_id === doc.evidenceId)
                    return (
                    <div key={doc.evidenceId}
                      className="flex items-center justify-between gap-3 px-3 py-2.5 rounded-fluent"
                      style={{ background: 'var(--color-surface-r)' }}>
                      <div className="flex items-center gap-2 min-w-0">
                        <CheckCircle2 size={14} style={{ color: '#107c10', flexShrink: 0 }} />
                        <div className="min-w-0">
                          <div className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>
                            {evidenceLabel(
                              doc.documentType,
                              fullEvidence?.normalized_content?.textSummary as string | undefined,
                              fullEvidence?.normalized_content?.documentTitle as string | undefined,
                            )}
                          </div>
                          <div className="text-xs truncate" style={{ color: 'var(--color-text-muted)' }}>
                            {doc.fileName}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => viewDocument(doc.documentId, doc.fileName)}
                        disabled={loadingDocId === doc.documentId}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-fluent text-xs font-medium border shrink-0 transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        style={{ color: 'var(--color-brand)', borderColor: 'rgba(0,120,212,0.35)' }}>
                        {loadingDocId === doc.documentId
                          ? <Loader2 size={12} className="animate-spin" />
                          : <Eye size={12} />}
                        View
                      </button>
                    </div>
                    )
                  })}
                </div>
              )}
            </Section>

            {/* ② WHAT DO WE KNOW? */}
            <Section question="What do we know?" icon={<Search size={15} />} color="#5c2d91">
              {evidence.length === 0 ? (
                <SmartEmpty icon={<FileText size={20} />}
                  message="No evidence has been collected yet."
                  sub="Run the agent or ingest evidence to begin building the case." />
              ) : (
                <div className="space-y-2">
                  {evidence.map((ev) => (
                    <div key={ev.evidence_id}
                      className="flex items-center justify-between px-3 py-2 rounded-fluent"
                      style={{ background: 'var(--color-surface-r)' }}>
                      <div className="flex items-center gap-2 min-w-0">
                        <CheckCircle size={13} style={{ color: 'var(--color-success)', flexShrink: 0 }} />
                        <span className="text-sm truncate" style={{ color: 'var(--color-text)' }}>
                          {evidenceLabel(ev.evidence_type, ev.normalized_content?.textSummary as string | undefined, ev.normalized_content?.documentTitle as string | undefined)}
                        </span>
                        <span className="text-xs shrink-0" style={{ color: 'var(--color-text-subtle)' }}>
                          from {ev.source_type.replace(/_/g, ' ')}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        {ev.version > 1 && (
                          <span className="text-2xs px-1.5 py-0.5 rounded font-medium bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400">
                            v{ev.version}
                          </span>
                        )}
                        <span className="text-2xs px-1.5 py-0.5 rounded font-medium"
                          style={{
                            background: `${MATERIALITY_COLOR[ev.materiality]}18`,
                            color: MATERIALITY_COLOR[ev.materiality],
                          }}>
                          {ev.materiality}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Contradictions */}
              {contradictions.length > 0 && (
                <div className="mt-4">
                  <div className="text-xs font-semibold mb-2 flex items-center gap-1.5"
                    style={{ color: 'var(--color-medium)' }}>
                    <AlertTriangle size={12} />
                    Evidence Contradictions ({contradictions.length})
                  </div>
                  {contradictions.map((c) => (
                    <div key={c.contradiction_id}
                      className="px-3 py-2.5 rounded-fluent border-l-2 mb-2 text-sm"
                      style={{
                        background: 'rgba(202,80,16,0.06)',
                        borderLeftColor: 'var(--color-medium)',
                        color: 'var(--color-text)',
                      }}>
                      <div className="font-medium text-xs mb-0.5" style={{ color: 'var(--color-medium)' }}>
                        CONTRADICTION · {c.conflict_type.replace(/_/g, ' ')} · {c.materiality}
                      </div>
                      {c.description}
                    </div>
                  ))}
                </div>
              )}
            </Section>

            {/* ③ WHAT'S MISSING? */}
            <Section question="What's missing?" icon={<HelpCircle size={15} />}
              color={openGaps.length > 0 ? 'var(--color-medium)' : 'var(--color-success)'}
              badge={openGaps.length > 0
                ? <span className="text-xs px-2 py-0.5 rounded-full font-semibold"
                    style={{ background: 'rgba(202,80,16,0.12)', color: 'var(--color-medium)' }}>
                    {openGaps.length} open gap{openGaps.length !== 1 ? 's' : ''}
                  </span>
                : undefined}>
              {openGaps.length === 0 ? (
                <SmartEmpty icon={<CheckCircle2 size={20} style={{ color: 'var(--color-success)' }} />}
                  message="No evidence gaps identified."
                  sub={hypotheses.length === 0
                    ? 'Run the agent to analyse the case and identify any missing information.'
                    : 'All information required for the current assessment is available.'} />
              ) : (
                <div className="space-y-2">
                  {openGaps.map((gap) => (
                    <div key={gap.gap_id}
                      className="flex items-start gap-3 px-3 py-3 rounded-fluent"
                      style={{
                        background: gap.materiality === 'HIGH' ? 'rgba(197,15,31,0.06)' : 'rgba(202,80,16,0.06)',
                      }}>
                      <div className="mt-0.5 shrink-0">
                        {gap.materiality === 'HIGH'
                          ? <AlertCircle size={14} style={{ color: 'var(--color-critical)' }} />
                          : <AlertTriangle size={14} style={{ color: 'var(--color-medium)' }} />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-semibold mb-0.5"
                          style={{ color: gap.materiality === 'HIGH' ? 'var(--color-critical)' : 'var(--color-medium)' }}>
                          {gap.materiality} PRIORITY · {gap.gap_type.replace(/_/g, ' ')}
                        </div>
                        <p className="text-sm" style={{ color: 'var(--color-text)' }}>{gap.description}</p>
                        {gap.expected_evidence_type && (
                          <p className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>
                            Expected: {gap.expected_evidence_type.replace(/_/g, ' ')}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Section>

            {/* ④ WHAT DOES IT TELL US? */}
            <Section question="What does the evidence tell us?" icon={<TrendingUp size={15} />} color="#107c10">
              {hypotheses.length === 0 ? (
                <SmartEmpty icon={<Bot size={20} />}
                  message="No assessment available yet."
                  sub="Run the agent to generate hypotheses and assess the evidence." />
              ) : (
                <div className="space-y-3">
                  {hypotheses.slice(0, 3).map((h, i) => (
                    <div key={h.hypothesis_id}
                      className="px-3 py-3 rounded-fluent border"
                      style={{
                        background: 'var(--color-surface-r)',
                        borderColor: i === 0 ? 'var(--color-brand)' : 'var(--color-border)',
                        borderWidth: i === 0 ? '1.5px' : '1px',
                      }}>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          {i === 0 && (
                            <span className="text-2xs px-1.5 py-0.5 rounded-full font-semibold"
                              style={{ background: 'rgba(0,120,212,0.12)', color: 'var(--color-brand)' }}>
                              LEADING
                            </span>
                          )}
                          <span className="text-xs px-1.5 py-0.5 rounded font-medium"
                            style={{
                              background: h.status === 'SUPPORTED' ? 'rgba(16,124,16,0.1)' : h.status === 'REFUTED' ? 'rgba(197,15,31,0.1)' : 'var(--color-surface-r)',
                              color: h.status === 'SUPPORTED' ? 'var(--color-success)' : h.status === 'REFUTED' ? 'var(--color-critical)' : 'var(--color-text-muted)',
                            }}>
                            {h.status}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <div className="w-20 h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--color-border)' }}>
                            <div className="h-full rounded-full" style={{
                              width: `${Math.round(h.confidence_score * 100)}%`,
                              background: h.confidence_score > 0.7 ? 'var(--color-success)' : h.confidence_score > 0.4 ? 'var(--color-medium)' : 'var(--color-high)',
                            }} />
                          </div>
                          <span className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                            {Math.round(h.confidence_score * 100)}%
                          </span>
                        </div>
                      </div>
                      <p className="text-sm" style={{ color: 'var(--color-text)' }}>{h.description}</p>
                      {h.unresolved_questions?.length > 0 && (
                        <div className="mt-2">
                          {h.unresolved_questions.slice(0, 2).map((q, qi) => (
                            <p key={qi} className="text-xs mt-0.5" style={{ color: 'var(--color-text-muted)' }}>
                              ? {q}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </Section>

            {/* ⑤ WHAT SHOULD I DO? */}
            <Section question="What should I do?" icon={<Zap size={15} />}
              color="var(--color-brand)"
              badge={recommendation && !recommendation.is_stale
                ? <span className="text-2xs px-1.5 py-0.5 rounded-full font-semibold"
                    style={{ background: 'rgba(16,124,16,0.1)', color: 'var(--color-success)' }}>CURRENT</span>
                : recommendation?.is_stale
                ? <span className="text-2xs px-1.5 py-0.5 rounded-full font-semibold"
                    style={{ background: 'rgba(202,80,16,0.1)', color: 'var(--color-medium)' }}>NEEDS UPDATE</span>
                : undefined}>
              {!recommendation ? (
                <SmartEmpty icon={<Zap size={20} />}
                  message="No recommendation available."
                  sub="Run the agent to generate an intelligent recommendation." />
              ) : (
                <div>
                  {recommendation.is_stale && (
                    <div className="flex items-center gap-2 text-xs px-3 py-2 rounded-fluent mb-3 border"
                      style={{ background: 'rgba(202,80,16,0.08)', borderColor: 'rgba(202,80,16,0.25)', color: 'var(--color-medium)' }}>
                      <AlertTriangle size={12} />
                      {recommendation.stale_reason ?? 'New information has been received. Re-running the agent will refresh this recommendation.'}
                    </div>
                  )}
                  {recommendation.change_reason && (
                    <div className="text-xs px-3 py-2 rounded-fluent mb-3"
                      style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-muted)' }}>
                      <strong>Changed because:</strong> {recommendation.change_reason}
                    </div>
                  )}

                  <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--color-text)' }}>
                    {recommendation.content}
                  </p>

                  {/* NBA action */}
                  {nba && (
                    <div className="p-4 rounded-fluent-lg border mb-4"
                      style={{ background: `${nba.color}08`, borderColor: `${nba.color}30` }}>
                      <div className="text-xs font-semibold mb-1" style={{ color: 'var(--color-text-muted)' }}>
                        RECOMMENDED ACTION
                      </div>
                      <div className="text-base font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
                        {nba.label}
                      </div>
                      <p className="text-sm mb-3" style={{ color: 'var(--color-text-muted)' }}>
                        {nba.description}
                      </p>
                      {!showEvidenceRequestAction && (
                        <div className="flex gap-2">
                          <button className="flex items-center gap-2 px-4 py-2 rounded-fluent text-sm font-medium text-white disabled:opacity-60"
                            style={{ background: nba.color }}
                            disabled={chargebackMutation.isPending || rejectMutation.isPending}
                            onClick={() => {
                              if (recommendation.recommendation_type === 'REQUEST_EVIDENCE') {
                                setShowEvidenceRequestAction(true)
                              } else if (recommendation.recommendation_type === 'DENY_DISPUTE') {
                                // "Reject Customer Claim" — closes the case as REJECTED
                                // (a real, live status; no chargeback is ever issued).
                                rejectMutation.mutate()
                              } else if (recommendation.recommendation_type === 'UPHOLD_DISPUTE') {
                                // "Accept Customer Claim" — the same chargeback the
                                // header's "Send Chargeback to Merchant" button issues;
                                // reused rather than building a second path to the
                                // same real action.
                                chargebackMutation.mutate()
                              } else {
                                toast('Action panel coming — use the sidebar tabs to take specific actions', { icon: '🚀' })
                              }
                            }}>
                            {chargebackMutation.isPending ? 'Charging back…' : rejectMutation.isPending ? 'Rejecting…' : <>{nba.label} <ArrowRight size={13} /></>}
                          </button>
                          <Button variant="secondary"
                            onClick={() => toast('Override captured — please document your reasoning', { icon: '📝' })}>
                            Override
                          </Button>
                        </div>
                      )}

                      {/* Clicking "Request Missing Evidence" above drops straight into the
                          real draft/send-to-cardholder flow (same panel §52 already built
                          for the REPRESENTMENT banner) instead of a "coming soon" toast. */}
                      {showEvidenceRequestAction && recommendation.recommendation_type === 'REQUEST_EVIDENCE' && (
                        <EvidenceRequestPanel
                          disputeId={dispute.dispute_id}
                          requestedAt={meta.evidence_requested_at}
                          onDone={() => {
                            qc.invalidateQueries({ queryKey: ['dispute', id] })
                            qc.invalidateQueries({ queryKey: ['evidence', id] })
                            setShowEvidenceRequestAction(false)
                          }}
                        />
                      )}
                    </div>
                  )}

                  {/* Confidence */}
                  <div className="flex items-center gap-3">
                    <div>
                      <div className="text-xs mb-1" style={{ color: 'var(--color-text-muted)' }}>Confidence</div>
                      <div className="flex items-center gap-2">
                        <div className="w-28 h-2 rounded-full overflow-hidden" style={{ background: 'var(--color-border)' }}>
                          <div className="h-full rounded-full confidence-bar" style={{
                            width: `${Math.round(recommendation.confidence_score * 100)}%`,
                            background: recommendation.confidence_score > 0.7 ? 'var(--color-success)'
                              : recommendation.confidence_score > 0.4 ? 'var(--color-medium)' : 'var(--color-high)',
                          }} />
                        </div>
                        <span className="text-xs font-medium" style={{ color: 'var(--color-text)' }}>
                          {recommendation.confidence_descriptor}
                        </span>
                      </div>
                    </div>
                    <span className="text-xs ml-auto" style={{ color: 'var(--color-text-subtle)' }}>
                      v{recommendation.version} · {formatDistanceToNow(parseISO(recommendation.created_at), { addSuffix: true })}
                    </span>
                  </div>

                  {recommendation.uncertainty_statement && (
                    <p className="text-xs mt-3 italic" style={{ color: 'var(--color-text-subtle)' }}>
                      {recommendation.uncertainty_statement}
                    </p>
                  )}
                </div>
              )}
            </Section>

            {/* ⑥ ASK THE CASE (README §21 — source-grounded case Q&A) */}
            <AskCaseSection disputeId={id!} />
          </div>

          {/* ── Right: Case Intelligence Panel ── */}
          <div className="p-6 space-y-5 shrink-0">
            {/* Case health */}
            <CaseHealthCard
              evidence={evidence}
              gaps={openGaps}
              contradictions={contradictions}
              recommendation={recommendation}
              sla={sla}
            />

            {/* Case Info */}
            <InfoCard title="Case Details">
              <InfoRow label="ID" value={<code style={{ fontFamily: 'monospace', fontSize: '11px' }}>{dispute.dispute_id.slice(0, 12)}…</code>} />
              <InfoRow label="Stage" value={dispute.lifecycle_stage.replace(/_/g, ' ')} />
              <InfoRow label="Status" value={dispute.status} />
              <InfoRow label="Version" value={`v${dispute.current_state_version}`} />
              {meta.transaction_reference || dispute.transaction_reference ? (
                <InfoRow label="Txn Ref" value={<code style={{ fontSize: '11px' }}>{dispute.transaction_reference ?? meta.transaction_reference}</code>} />
              ) : null}
            </InfoCard>

            {/* Similar past cases (README §21 — precedent retrieval) */}
            <InfoCard title="Similar Past Cases">
              {precedents && precedents.entries.length > 0 ? (
                <div className="space-y-2">
                  {precedents.entries.map((p) => {
                    const outcomeColor = p.outcome === 'WON' ? 'var(--color-success)'
                      : p.outcome === 'LOST' ? 'var(--color-critical)'
                      : 'var(--color-text-subtle)'
                    return (
                      <Link
                        key={p.dispute_id}
                        to={`/disputes/${p.dispute_id}`}
                        className="flex items-center justify-between gap-2 py-1.5 border-b last:border-0 text-xs hover:opacity-80"
                        style={{ borderColor: 'var(--color-border)' }}
                      >
                        <div className="min-w-0">
                          <div className="font-mono" style={{ color: 'var(--color-brand)' }}>
                            {p.dispute_id.slice(-8).toUpperCase()}
                          </div>
                          <div style={{ color: 'var(--color-text-muted)' }}>
                            {p.recommendation_type} · {Math.round(p.similarity * 100)}% similar
                          </div>
                        </div>
                        <span className="shrink-0 font-medium" style={{ color: outcomeColor }}>
                          {p.outcome ?? 'PENDING'}
                        </span>
                      </Link>
                    )
                  })}
                </div>
              ) : (
                <p className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>
                  {precedents?.note ?? 'No similar past cases in this dataset yet.'}
                </p>
              )}
            </InfoCard>

            {/* Suggested reason code (README §21 — RAG-grounded, not authoritative) */}
            <SuggestedReasonCodeCard disputeId={dispute.dispute_id} />

            {/* Transaction / Merchant */}
            {(meta.merchant_name || meta.amount_disputed || meta.customer_name) && (
              <InfoCard title="Transaction">
                {meta.customer_name && <InfoRow label="Customer" value={meta.customer_name} />}
                {meta.merchant_name && <InfoRow label="Merchant" value={meta.merchant_name} />}
                {meta.amount_disputed && <InfoRow label="Amount" value={`₹${Number(meta.amount_disputed).toLocaleString()}`} />}
                {meta.merchant_category && <InfoRow label="Category" value={meta.merchant_category} />}
                {meta.reason_code && <InfoRow label="Reason Code" value={meta.reason_code} />}
                {meta.source && <InfoRow label="Source" value={meta.source.replace(/_/g, ' ')} />}
              </InfoCard>
            )}

            {/* SLA Intelligence */}
            {sla && (
              <InfoCard title="SLA">
                <div className="text-center py-2">
                  <div className="text-2xl font-bold mb-1" style={{ color: sla.color }}>
                    {sla.label}
                  </div>
                  {sla.urgent && (
                    <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                      {sla.overdue
                        ? 'This case has exceeded its SLA deadline.'
                        : 'Complete the investigation promptly to meet the deadline.'}
                    </p>
                  )}
                </div>
              </InfoCard>
            )}
          </div>
        </div>
      </div>

      <DocumentPreviewModal preview={docPreview} pendingName={pendingName} onClose={closeDocPreview} />

      {showAgentModal && (
        <AgentAnalysisModal nodes={agentNodes} outcome={agentOutcome} onClose={() => setShowAgentModal(false)} />
      )}
    </div>
  )
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function Section({
  question, icon, color, badge, children, defaultOpen = true, onToggle
}: {
  question: string; icon: ReactNode; color: string; badge?: ReactNode
  children: ReactNode; defaultOpen?: boolean; onToggle?: (v: boolean) => void
}) {
  const [open, setOpen] = useState(defaultOpen)
  function toggle() { const next = !open; setOpen(next); onToggle?.(next) }
  return (
    <div className="rounded-fluent-lg border overflow-hidden shadow-fluent-sm"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <button className="w-full flex items-center gap-3 px-4 py-3 text-left"
        style={{ background: 'var(--color-surface)' }}
        onClick={toggle}>
        <span className="w-7 h-7 rounded-fluent flex items-center justify-center shrink-0"
          style={{ background: `${color}18`, color }}>
          {icon}
        </span>
        <span className="text-sm font-semibold flex-1" style={{ color: 'var(--color-text)' }}>
          {question}
        </span>
        {badge}
        {open ? <ChevronDown size={14} style={{ color: 'var(--color-text-muted)' }} />
               : <ChevronRight size={14} style={{ color: 'var(--color-text-muted)' }} />}
      </button>
      {open && (
        <div className="px-4 pb-4 border-t" style={{ borderColor: 'var(--color-border)' }}>
          <div className="pt-3">{children}</div>
        </div>
      )}
    </div>
  )
}

function CaseHealthCard({ evidence, gaps, contradictions, recommendation, sla }: {
  evidence: Evidence[]; gaps: EvidenceGap[]; contradictions: Contradiction[]
  recommendation?: Recommendation; sla: ReturnType<typeof slaInfo>
}) {
  const scores = [
    { label: 'Evidence', ok: evidence.length > 0, warn: evidence.length < 2 },
    { label: 'Gaps', ok: gaps.length === 0, warn: gaps.length > 0 },
    { label: 'Contradictions', ok: contradictions.length === 0, warn: contradictions.length > 0 },
    { label: 'Assessment', ok: !!recommendation && !recommendation.is_stale, warn: recommendation?.is_stale },
    { label: 'SLA', ok: !sla || !sla.urgent, warn: sla?.urgent && !sla.overdue, bad: sla?.overdue },
  ]
  const bad = scores.filter((s) => s.bad || (!s.ok && !s.warn)).length
  const warn = scores.filter((s) => s.warn).length
  const overall = bad > 0 ? { label: 'Needs Attention', color: 'var(--color-critical)' }
    : warn > 0 ? { label: 'Under Review', color: 'var(--color-medium)' }
    : { label: 'On Track', color: 'var(--color-success)' }

  return (
    <div className="rounded-fluent-lg border p-4"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-xs font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
          Case Health
        </h3>
        <span className="text-xs font-semibold" style={{ color: overall.color }}>{overall.label}</span>
      </div>
      <div className="space-y-1.5">
        {scores.map((s) => {
          const color = s.bad ? 'var(--color-critical)' : s.ok ? 'var(--color-success)' : 'var(--color-medium)'
          const icon = s.bad || (!s.ok && !s.warn)
            ? <XCircle size={13} style={{ color }} />
            : s.warn ? <AlertTriangle size={13} style={{ color }} />
            : <CheckCircle size={13} style={{ color }} />
          return (
            <div key={s.label} className="flex items-center justify-between">
              <span className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{s.label}</span>
              {icon}
            </div>
          )
        })}
      </div>
    </div>
  )
}

function InfoCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="rounded-fluent-lg border p-4"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <h3 className="text-xs font-semibold uppercase tracking-wide mb-3"
        style={{ color: 'var(--color-text-muted)' }}>{title}</h3>
      <dl className="space-y-2 text-sm">{children}</dl>
    </div>
  )
}

function InfoRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex justify-between gap-2">
      <dt className="shrink-0" style={{ color: 'var(--color-text-muted)' }}>{label}</dt>
      <dd className="font-medium text-right truncate" style={{ color: 'var(--color-text)' }}>{value}</dd>
    </div>
  )
}

interface Citation { source: string; page: number | null; title: string }

function CitationList({ citations }: { citations: Citation[] }) {
  if (citations.length === 0) return null
  return (
    <div className="mt-2 flex flex-wrap gap-1">
      {citations.map((c, i) => (
        <span key={i} className="text-2xs px-1.5 py-0.5 rounded-fluent border"
          style={{ borderColor: 'var(--color-border)', color: 'var(--color-text-subtle)' }}>
          {c.source === 'platform_policy' ? 'platform policy' : `${c.source}${c.page ? `, p.${c.page}` : ''}`}
        </span>
      ))}
    </div>
  )
}

function SuggestedReasonCodeCard({ disputeId }: { disputeId: string }) {
  const [result, setResult] = useState<{
    suggested_code: string; confidence: number; rationale: string
    citation: Citation | null; disclaimer: string
    standard_reference: { network: string; code: string; label: string } | null
  } | null>(null)
  const mutation = useMutation({
    mutationFn: () => disputeApi.classifyReasonCode(disputeId),
    onSuccess: (r) => setResult(r.data),
    onError: () => toast.error('Could not generate a reason-code suggestion'),
  })

  return (
    <InfoCard title="Suggested Reason Code">
      {!result ? (
        <div>
          <p className="text-xs mb-3" style={{ color: 'var(--color-text-subtle)' }}>
            RAG-grounded suggestion from the uploaded scheme rulebooks — not a certified classification.
          </p>
          <Button variant="secondary" size="sm" loading={mutation.isPending} onClick={() => mutation.mutate()}>
            Suggest
          </Button>
        </div>
      ) : result.suggested_code === 'NONE_CONFIDENT' ? (
        <div>
          <p className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>{result.rationale}</p>
          {/* README §76: the uploaded scheme rulebooks (a small seed corpus, README
              §17.2) genuinely don't ground a code for every claim — that's an honest
              "not confident" from the RAG path, not a bug. When it happens, fall back
              to a deterministic standard-network reference table instead of leaving
              the analyst with nothing. Visually and textually distinct from an AI/RAG
              suggestion — this is a lookup table, never claimed as model output. */}
          {result.standard_reference && (
            <div className="mt-3 pt-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
              <div className="text-2xs font-semibold uppercase tracking-wide mb-1" style={{ color: 'var(--color-text-subtle)' }}>
                Standard network reference (not AI-suggested)
              </div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-semibold" style={{ color: 'var(--color-text)' }}>
                  {result.standard_reference.network} {result.standard_reference.code}
                </span>
                <span className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                  {result.standard_reference.label}
                </span>
              </div>
              <p className="text-2xs mt-1 italic" style={{ color: 'var(--color-text-subtle)' }}>
                Standard classification for this dispute type from a fixed reference table — verify against current network rules before use.
              </p>
            </div>
          )}
        </div>
      ) : (
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <span className="font-mono text-base font-semibold" style={{ color: 'var(--color-brand)' }}>
              {result.suggested_code}
            </span>
            <span className="text-2xs" style={{ color: 'var(--color-text-muted)' }}>
              {Math.round(result.confidence * 100)}% confidence
            </span>
          </div>
          <p className="text-xs leading-relaxed mb-2" style={{ color: 'var(--color-text-muted)' }}>{result.rationale}</p>
          {result.citation && <CitationList citations={[result.citation]} />}
          <p className="text-2xs mt-2 italic" style={{ color: 'var(--color-text-subtle)' }}>{result.disclaimer}</p>
        </div>
      )}
    </InfoCard>
  )
}

function AskCaseSection({ disputeId }: { disputeId: string }) {
  const [question, setQuestion] = useState('')
  const [result, setResult] = useState<{ answer: string; can_answer: boolean; citations: Citation[] } | null>(null)
  const [evalScores, setEvalScores] = useState<EvalScoreEntry[] | 'pending' | null>(null)
  const askedAtRef = useRef(0)
  const askedQuestionRef = useRef('')
  const pollTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const mutation = useMutation({
    mutationFn: (q: string) => disputeApi.askCase(disputeId, q),
    onSuccess: (r) => {
      setResult(r.data)
      setEvalScores('pending')
      pollForEvalScores()
    },
    onError: () => toast.error('Could not answer that question'),
  })

  // The DeepEval judge runs in a background task *after* the answer above is
  // already back (README §30) — never on the analyst's critical path — so the
  // score for this exact question only shows up a couple seconds later. Poll
  // briefly; if ENABLE_DEEPEVAL is off nothing ever arrives and this just stops.
  function pollForEvalScores(attempt = 0) {
    if (attempt >= 6) { setEvalScores(null); return }
    pollTimerRef.current = setTimeout(async () => {
      try {
        const r = await platformApi.evalScores()
        const rows: EvalScoreEntry[] = r.data.filter((row: EvalScoreEntry) =>
          row.feature === 'case_qa' &&
          row.case_id === disputeId &&
          row.input_text === askedQuestionRef.current &&
          new Date(row.created_at).getTime() >= askedAtRef.current
        )
        if (rows.length > 0) { setEvalScores(rows); return }
      } catch { /* best-effort — never surface a polling failure to the analyst */ }
      pollForEvalScores(attempt + 1)
    }, 2500)
  }

  useEffect(() => () => { if (pollTimerRef.current) clearTimeout(pollTimerRef.current) }, [])

  return (
    <Section question="Ask the case" icon={<HelpCircle size={15} />} color="#5c2d91" defaultOpen={false}>
      <p className="text-xs mb-3" style={{ color: 'var(--color-text-muted)' }}>
        Ask a question about this case — grounded in the case's own evidence/recommendation and the uploaded scheme
        rulebooks. Answers only from that context; it will say so if it can't answer.
      </p>
      <form
        className="flex gap-2 mb-3"
        onSubmit={(e) => {
          e.preventDefault()
          const q = question.trim()
          if (!q) return
          askedAtRef.current = Date.now() - 5000
          askedQuestionRef.current = q
          mutation.mutate(q)
        }}
      >
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="e.g. What evidence would strengthen our position?"
          className="flex-1 h-9 text-sm px-3 rounded-fluent border outline-none"
          style={{ background: 'var(--color-surface-r)', borderColor: 'var(--color-border-strong)', color: 'var(--color-text)' }}
        />
        <Button type="submit" variant="secondary" size="sm" loading={mutation.isPending}>Ask</Button>
      </form>
      {result && (
        <div className="rounded-fluent border p-3" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-r)' }}>
          <p className="text-sm leading-relaxed" style={{ color: result.can_answer ? 'var(--color-text)' : 'var(--color-text-subtle)' }}>
            {result.answer}
          </p>
          <CitationList citations={result.citations} />
          {evalScores === 'pending' && (
            <div className="flex items-center gap-1.5 mt-2.5 text-2xs" style={{ color: 'var(--color-text-subtle)' }}>
              <Loader2 size={10} className="animate-spin" /> Judging answer quality…
            </div>
          )}
          {Array.isArray(evalScores) && evalScores.length > 0 && (
            <div className="flex items-center gap-1.5 mt-2.5 flex-wrap">
              {evalScores.map((s) => (
                <span key={s.eval_id} title={s.reason ?? undefined}
                  className="flex items-center gap-1 text-2xs font-medium px-1.5 py-0.5 rounded-full"
                  style={{
                    background: s.passed ? 'rgba(16,124,16,0.1)' : 'rgba(197,15,31,0.08)',
                    color: s.passed ? 'var(--color-success)' : 'var(--color-critical)',
                  }}>
                  <Sparkles size={9} /> {s.metric} {s.score !== null ? s.score.toFixed(2) : '—'}
                </span>
              ))}
            </div>
          )}
        </div>
      )}
    </Section>
  )
}

function EvidenceRequestPanel({ disputeId, requestedAt, onDone }: {
  disputeId: string; requestedAt: string | null | undefined; onDone: () => void
}) {
  const [draft, setDraft] = useState<string | null>(null)
  const [drafting, setDrafting] = useState(false)
  const [sending, setSending] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  async function handleDraft() {
    setDrafting(true)
    try {
      const r = await disputeApi.draftEvidenceRequest(disputeId)
      setDraft(r.data.draft_text)
    } catch {
      toast.error('Could not generate a draft')
    } finally {
      setDrafting(false)
    }
  }

  async function handleSend() {
    if (!draft) return
    setSending(true)
    try {
      await disputeApi.sendEvidenceRequest(disputeId, draft)
      toast.success('Marked as sent to the cardholder')
      setDraft(null)
      onDone()
    } catch {
      toast.error('Could not send this request')
    } finally {
      setSending(false)
    }
  }

  async function handleUpload(file: File) {
    setUploading(true)
    try {
      await disputeApi.uploadDocument(disputeId, file)
      toast.success(`${file.name} attached as evidence`)
      onDone()
    } catch {
      toast.error(`Could not attach ${file.name}`)
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="rounded-fluent-lg border p-4 mb-3"
      style={{ background: 'rgba(92,45,145,0.04)', borderColor: 'rgba(92,45,145,0.25)' }}>
      <div className="flex items-center gap-2 mb-2">
        <Mail size={14} style={{ color: '#5c2d91' }} />
        <span className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>
          Ask the cardholder for more evidence
        </span>
      </div>

      {requestedAt ? (
        <p className="text-xs mb-3" style={{ color: 'var(--color-text-muted)' }}>
          Requested {formatDistanceToNow(parseISO(requestedAt))} ago — you can send another request or attach
          evidence yourself below if you already have it.
        </p>
      ) : (
        <p className="text-xs mb-3" style={{ color: 'var(--color-text-muted)' }}>
          Already have the document? Attach it directly below — no need to email first.
        </p>
      )}

      {draft ? (
        <div className="mb-3">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            rows={5}
            className="w-full text-xs rounded-fluent border p-2.5 resize-none"
            style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)', color: 'var(--color-text)' }}
          />
          <div className="flex gap-2 mt-2">
            <Button variant="primary" size="sm" onClick={handleSend} loading={sending}>
              <Send size={12} /> Send to Cardholder
            </Button>
            <Button variant="secondary" size="sm" onClick={() => setDraft(null)}>Discard</Button>
          </div>
        </div>
      ) : (
        <Button variant="secondary" size="sm" onClick={handleDraft} loading={drafting} className="mb-3">
          <Mail size={12} /> Draft Evidence Request
        </Button>
      )}

      <div className="pt-2 border-t" style={{ borderColor: 'rgba(92,45,145,0.15)' }}>
        <input ref={fileInputRef} type="file" className="hidden"
          accept="application/pdf,image/png,image/jpeg,image/webp"
          onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) handleUpload(f) }} />
        <Button variant="secondary" size="sm" className="mt-2" onClick={() => fileInputRef.current?.click()} loading={uploading}>
          <UploadCloud size={12} /> Upload Additional Evidence
        </Button>
      </div>
    </div>
  )
}

// Replaces the old inline 3-col grid of all 9 steps (README §55/§61) that used to
// sit at the top of the page pushing the rest of the workspace down — a modal makes
// the wait itself the moment, with the same big-glow-icon/scanline language already
// established for New Case's own long-running wait (§64's CreatingCaseOverlay), just
// sized for a dialog instead of a full-page takeover. Dismissable at any point (the
// backdrop click and the X both only hide the modal) because the real run keeps
// going via the SSE subscription + polling backstop above regardless of whether this
// is on screen — closing it never cancels anything, and "View progress" (rendered
// next to the header button while running) reopens it.
function AgentAnalysisModal({ nodes, outcome, onClose }: {
  nodes: Record<string, 'pending' | 'running' | 'complete'>
  outcome: 'RUNNING' | 'COMPLETED' | 'FAILED' | null
  onClose: () => void
}) {
  const completed = GRAPH_NODES.filter(({ key }) => nodes[key] === 'complete').length
  const pct = outcome === 'COMPLETED' ? 100 : Math.round((completed / GRAPH_NODES.length) * 100)
  const currentStep = GRAPH_NODES.find(({ key }) => nodes[key] === 'running')

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.5)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="w-full max-w-md rounded-fluent-xl overflow-hidden animate-fade-in-up relative shadow-fluent-xl"
        style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}>
        <button onClick={onClose} className="absolute top-3 right-3 z-10" aria-label="Close (analysis keeps running in the background)">
          <XCircle size={18} style={{ color: 'var(--color-text-muted)' }} />
        </button>

        <div className="p-7 text-center">
          <div className={clsx(
            'relative w-16 h-16 mx-auto mb-5 rounded-fluent-xl flex items-center justify-center overflow-hidden shadow-glow-brand',
            outcome === 'FAILED' ? '' : 'bg-grad-brand'
          )} style={outcome === 'FAILED' ? { background: 'var(--color-critical)' } : undefined}>
            {outcome === 'RUNNING' && (
              <div className="absolute left-0 right-0 h-1 animate-scanline bg-white/70" aria-hidden="true" />
            )}
            {outcome === 'COMPLETED'
              ? <CheckCircle2 size={30} className="text-white animate-fade-in" />
              : outcome === 'FAILED'
              ? <AlertTriangle size={30} className="text-white" />
              : <Bot size={28} className="text-white animate-pulse" />}
          </div>

          <h2 className="font-display text-lg font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
            {outcome === 'COMPLETED' ? 'Analysis complete' : outcome === 'FAILED' ? 'Analysis hit an issue' : 'Analysing Case…'}
          </h2>
          <p className="text-sm mb-5 min-h-[1.25rem]" style={{ color: 'var(--color-text-muted)' }}>
            {outcome === 'COMPLETED'
              ? 'Recommendation, hypotheses, and evidence gaps are up to date.'
              : outcome === 'FAILED'
              ? 'Your existing case information is still available and unaffected.'
              : currentStep?.label ?? 'Starting up…'}
          </p>

          <div className="h-1.5 rounded-full overflow-hidden mb-5" style={{ background: 'var(--color-surface-r)' }}>
            <div className={clsx('h-full rounded-full transition-all duration-500 ease-out', outcome === 'FAILED' ? '' : 'bg-grad-brand')}
              style={{ width: `${pct}%`, background: outcome === 'FAILED' ? 'var(--color-critical)' : undefined }} />
          </div>

          <div className="space-y-1 text-left max-h-56 overflow-y-auto">
            {GRAPH_NODES.map(({ key, label }, idx) => {
              const status = nodes[key] ?? 'pending'
              return (
                <div key={key}
                  className={clsx(
                    'flex items-center gap-2 min-w-0 rounded px-1.5 py-1 transition-colors duration-300',
                    status === 'running' && 'bg-grad-brand-soft'
                  )}>
                  {status === 'complete'
                    ? <CheckCircle size={13} className="shrink-0" style={{ color: 'var(--color-success)' }} />
                    : status === 'running'
                    ? <RefreshCw size={13} className="shrink-0 animate-spin" style={{ color: 'var(--color-brand)' }} />
                    : <span className="w-3.5 h-3.5 rounded-full shrink-0 flex items-center justify-center text-[8px] font-bold"
                        style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-subtle)' }}>{idx + 1}</span>}
                  <span className="text-xs truncate" style={{
                    color: status === 'pending' ? 'var(--color-text-subtle)' : 'var(--color-text)',
                    fontWeight: status === 'running' ? 600 : 400,
                  }}>{label}</span>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

function SmartEmpty({ icon, message, sub }: { icon: ReactNode; message: string; sub?: string }) {
  return (
    <div className="py-6 text-center">
      <div className="flex justify-center mb-2" style={{ color: 'var(--color-text-subtle)' }}>{icon}</div>
      <p className="text-sm font-medium" style={{ color: 'var(--color-text-muted)' }}>{message}</p>
      {sub && <p className="text-xs mt-1" style={{ color: 'var(--color-text-subtle)' }}>{sub}</p>}
    </div>
  )
}

function CaseNotFound() {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="text-center py-16 rounded-fluent-lg border"
        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        <AlertCircle size={28} className="mx-auto mb-3" style={{ color: 'var(--color-text-muted)' }} />
        <p className="font-medium" style={{ color: 'var(--color-text)' }}>Case not found</p>
        <p className="text-sm mt-1" style={{ color: 'var(--color-text-muted)' }}>
          This case no longer exists — it may have been removed or the link is out of date.
        </p>
        <Link to="/disputes" className="inline-block mt-3 text-sm" style={{ color: 'var(--color-brand)' }}>
          Back to My Cases
        </Link>
      </div>
    </div>
  )
}

function LoadingSkeleton() {
  const shimmer = {
    backgroundImage: 'linear-gradient(90deg, var(--color-surface) 0%, var(--color-surface-r) 50%, var(--color-surface) 100%)',
    backgroundSize: '200% 100%',
  }
  return (
    <div className="p-6 space-y-4">
      <div className="h-20 rounded-fluent-lg animate-shimmer border" style={{ ...shimmer, borderColor: 'var(--color-border)' }} />
      {[1, 2, 3, 4].map((n) => (
        <div key={n} className="h-32 rounded-fluent-lg animate-shimmer border"
          style={{ ...shimmer, borderColor: 'var(--color-border)', animationDelay: `${n * 80}ms` }} />
      ))}
    </div>
  )
}
