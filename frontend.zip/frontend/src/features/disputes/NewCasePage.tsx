import { useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { X, Plus, Trash2, FileUp, Sparkles, Loader2, FileText, CheckCircle2, Timer, Mail, ArrowLeft, ScanLine } from 'lucide-react'
import { disputeApi, claimApi, adminApi } from '@/services/api'
import type { EvidenceRequirement } from '@/types'
import { Field, Input, Select, Textarea, Button, ScoreRing } from '@/components/ui'
import toast from 'react-hot-toast'
import clsx from 'clsx'

interface ExtractedTransaction {
  dispute_type: string | null
  transaction_reference: string | null
  merchant_name: string | null
  amount_disputed: string | null
  transaction_date: string | null
  posting_date: string | null
}

// The vision model is told to return ISO "YYYY-MM-DD" (packages/intelligence/
// document_understanding.py's prompt), but defensively normalize anyway —
// <input type="date"> silently rejects anything else (no error, field just
// renders empty), so a natural-language date that slips through would look
// like "extraction didn't work" when it actually did.
function toISODate(value: string | null | undefined): string {
  if (!value) return ''
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value
  const d = new Date(value)
  if (isNaN(d.getTime())) return ''
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

interface DocumentExtraction {
  document_type: string
  customer_name: string | null
  masked_card_number: string | null
  card_tier: string | null
  authentication_status: string | null
  narrative: string
  return_date: string | null
  expected_refund_amount: string | null
  expected_refund_date: string | null
  refund_reference_number: string | null
  merchant_response: string | null
  merchant_contact_date: string | null
  transactions: ExtractedTransaction[]
  confidence: number
  notes: string
}

interface UploadedDoc {
  file: File
  documentType: string
  confidence: number
}

function titleCase(s: string): string {
  return s.replace(/_/g, ' ').replace(/\w\S*/g, (w) => w[0].toUpperCase() + w.slice(1).toLowerCase())
}

// README §56: narrowed to the 3 CFPB-ranked categories this build focuses on
// (Cancelled Recurring Transaction 40%, Service Not Received 21%, Credit Not
// Processed 18%) — mirrors packages/intelligence/document_understanding.py's own
// DISPUTE_TYPES exactly. A smaller, correct set beats a larger one the classifier
// occasionally mis-fires on (real cases of subscription-cancellation documents being
// classified as UNAUTHORIZED_TRANSACTION went away once that option was removed).
const DISPUTE_TYPES = [
  { value: 'SUBSCRIPTION_CANCELLATION',     label: 'Subscription Cancellation' },
  { value: 'MERCHANDISE_NOT_RECEIVED',      label: 'Merchandise Not Received' },
  { value: 'REFUND_NOT_PROCESSED',          label: 'Refund Not Processed' },
]

interface TransactionRow {
  dispute_type: string
  transaction_reference: string
  merchant_name: string
  amount_disputed: string
}

function emptyRow(): TransactionRow {
  return { dispute_type: '', transaction_reference: '', merchant_name: '', amount_disputed: '' }
}

// The full case-detail contract (README §24: cardholder/transaction/dispute)
// mapped onto this form's single-transaction fields.
const EMPTY_FORM = {
  dispute_type: '',
  cardholder_claim: '',
  priority: 'MEDIUM',
  // Cardholder
  customer_name: '',
  customer_phone: '',
  masked_card_number: '',
  authentication_status: '',
  card_tier: '',
  // Transaction
  transaction_reference: '',
  merchant_name: '',
  merchant_id: '',
  merchant_category_code: '',
  transaction_channel: 'ECOMMERCE',
  currency: 'INR',
  amount_disputed: '',
  transaction_date: '',
  posting_date: '',
  // Dispute details
  return_date: '',
  expected_refund_amount: '',
  expected_refund_date: '',
  merchant_contacted: false,
  merchant_contact_date: '',
  merchant_response: '',
  refund_reference_number: '',
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-xs font-semibold uppercase tracking-wide pt-1" style={{ color: 'var(--color-text-subtle)' }}>
      {children}
    </div>
  )
}

// A file that's mid-extraction — the "scanning" moment. Was a hairline bar swept
// across a translucent-white row (`rgba(255,255,255,0.5)`, ignoring the theme
// entirely) — nearly invisible against a light page and actively wrong in dark
// mode, and too small to read as "something is happening" during a real
// vision-model call that can run 60-75s. Rebuilt on the same big-glow-icon +
// contained-scanline language CreatingCaseOverlay (§64) already established, with
// the same real cycling phase text rather than a single static "Scanning…" label
// for the whole wait.
const SCAN_PHASES = ['Uploading…', 'Reading the document…', 'Analysing content…']

function ScanningCard({ fileName }: { fileName: string }) {
  const [phase, setPhase] = useState(0)
  useEffect(() => {
    const id = setInterval(() => setPhase((p) => Math.min(p + 1, SCAN_PHASES.length - 1)), 2500)
    return () => clearInterval(id)
  }, [])
  return (
    <div className="flex items-center gap-3 px-3 py-2.5 rounded-fluent-lg border shadow-fluent-sm"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <div className="relative w-10 h-10 rounded-fluent flex items-center justify-center shrink-0 overflow-hidden bg-grad-brand shadow-glow-brand">
        <div className="absolute left-0 right-0 h-1 animate-scanline bg-white/70" aria-hidden="true" />
        <ScanLine size={18} className="text-white animate-pulse" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-sm font-medium truncate" style={{ color: 'var(--color-text)' }}>{fileName}</div>
        <div className="text-xs font-medium" style={{ color: 'var(--color-brand)' }}>{SCAN_PHASES[phase]}</div>
      </div>
    </div>
  )
}

// Full-screen takeover shown for the entire submit — case creation, then each
// document's real vision-model extraction (README §64). Replaces a blank white/dark
// screen (a real complaint on its own) and, more importantly, means the Command
// Center is only ever shown fully populated instead of evidence trickling in one
// document every 10-15s against an otherwise-empty page.
function CreatingCaseOverlay({ progress }: { progress: { current: number; total: number; fileName: string } | null }) {
  const pct = progress ? Math.round(((progress.current - 1) / progress.total) * 100) : 0
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6" style={{ background: 'var(--color-bg)' }}>
      <div className="app-mesh-bg" aria-hidden="true" />
      <div className="relative z-10 w-full max-w-sm text-center animate-fade-in-up">
        <div className="relative w-20 h-20 mx-auto mb-6 rounded-fluent-xl flex items-center justify-center overflow-hidden bg-grad-brand shadow-glow-brand">
          <div className="absolute left-0 right-0 h-1 animate-scanline bg-white/70" aria-hidden="true" />
          <Sparkles size={32} className="text-white animate-pulse" />
        </div>
        <h2 className="font-display text-xl font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
          {progress ? 'Analysing your documents…' : 'Creating your case…'}
        </h2>
        <p className="text-sm mb-5" style={{ color: 'var(--color-text-muted)' }}>
          {progress
            ? `Reading document ${progress.current} of ${progress.total} — ${progress.fileName}`
            : 'Setting up the case record'}
        </p>
        {progress && (
          <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--color-surface-r)' }}>
            <div className="h-full bg-grad-brand rounded-full transition-all duration-700 ease-out" style={{ width: `${pct}%` }} />
          </div>
        )}
        <p className="text-xs mt-6" style={{ color: 'var(--color-text-subtle)' }}>
          This can take a little while for each document — worth the wait so everything is ready at once.
        </p>
      </div>
    </div>
  )
}

// A deliberately lightweight, deterministic heuristic — NOT the real agent — so this
// shows up instantly as documents are uploaded rather than waiting on an LLM call at
// case-creation time. Required documents matter far more than optional ones; the real,
// thorough assessment happens once the case exists via "Analyse Case" (the actual
// LangGraph agent, README §9). Never shown as a claim of the case's real merit.
function computeCaseStrength(requirements: EvidenceRequirement[], uploadedDocs: UploadedDoc[]) {
  const haveTypes = new Set(uploadedDocs.map((d) => d.documentType))
  const required = requirements.filter((r) => r.is_required)
  const optional = requirements.filter((r) => !r.is_required)
  const requiredHave = required.filter((r) => haveTypes.has(r.evidence_type)).length
  const optionalHave = optional.filter((r) => haveTypes.has(r.evidence_type)).length
  const requiredScore = required.length > 0 ? requiredHave / required.length : 1
  const optionalScore = optional.length > 0 ? optionalHave / optional.length : 0
  const score = Math.round(requiredScore * 80 + optionalScore * 20)
  const missingRequired = required.filter((r) => !haveTypes.has(r.evidence_type))
  const missingOptional = optional.filter((r) => !haveTypes.has(r.evidence_type))
  return { score, missingRequired, missingOptional }
}

function CaseStrengthPanel({ requirements, uploadedDocs, cardholderClaim }: {
  requirements: EvidenceRequirement[]; uploadedDocs: UploadedDoc[]; cardholderClaim: string
}) {
  const [drafting, setDrafting] = useState(false)
  const [draft, setDraft] = useState<string | null>(null)
  const { score, missingRequired, missingOptional } = computeCaseStrength(requirements, uploadedDocs)
  const color = score >= 75 ? 'var(--color-success)' : score >= 40 ? 'var(--color-medium)' : 'var(--color-critical)'
  const label = score >= 75 ? 'Strong' : score >= 40 ? 'Moderate' : 'Weak'
  const nextBestMissing = missingRequired[0] ?? missingOptional[0] ?? null

  async function handleDraftRequest() {
    setDrafting(true)
    try {
      const items = missingRequired.map((r) => titleCase(r.evidence_type))
      const r = await disputeApi.draftMissingDocumentRequest(cardholderClaim, items)
      setDraft(r.data.draft_text)
    } catch {
      toast.error('Could not generate a draft')
    } finally {
      setDrafting(false)
    }
  }

  return (
    <div className="rounded-fluent-lg border p-4 flex flex-col gap-2 shadow-fluent-sm"
      style={{ borderColor: `${color}44`, background: `${color}08` }}>
      <div className="flex items-center gap-3">
        <span className="relative inline-flex items-center justify-center shrink-0" style={{ width: 44, height: 44 }}>
          <ScoreRing value={score} size={44} color={color} />
          <span className="absolute font-display text-sm font-bold" style={{ color }}>{score}</span>
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-semibold" style={{ color }}>Case Strength: {label}</div>
          <p className="text-xs mt-0.5" style={{ color: 'var(--color-text-muted)' }}>
            {nextBestMissing
              ? `Upload ${titleCase(nextBestMissing.evidence_type)} to strengthen this case`
              : 'All configured documents for this dispute type are present'}
          </p>
        </div>
      </div>
      <p className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>
        A quick estimate from the documents on hand, not the real analysis — the full
        AI investigation runs once the case is created.
      </p>

      {missingRequired.length > 0 && (
        <div className="pt-2 border-t" style={{ borderColor: `${color}22` }}>
          {draft ? (
            <div>
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                rows={5}
                className="w-full text-xs rounded-fluent border p-2.5 resize-none"
                style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)', color: 'var(--color-text)' }}
              />
              <div className="flex gap-2 mt-1.5">
                <Button type="button" variant="secondary" size="sm"
                  onClick={() => { navigator.clipboard.writeText(draft); toast.success('Copied') }}>
                  Copy
                </Button>
                <Button type="button" variant="ghost" size="sm" onClick={() => setDraft(null)}>Discard</Button>
              </div>
            </div>
          ) : (
            <Button type="button" variant="secondary" size="sm" loading={drafting} onClick={handleDraftRequest} className="w-full">
              <Mail size={12} /> Draft request to cardholder for missing documents
            </Button>
          )}
        </div>
      )}
    </div>
  )
}

export function NewCasePage() {
  const navigate = useNavigate()
  const [form, setForm] = useState({ ...EMPTY_FORM })
  const [submitting, setSubmitting] = useState(false)
  // Drives the full-screen "creating your case" takeover below — shown for the whole
  // submit, including document attachment, so the analyst lands on a fully-populated
  // Command Center instead of watching evidence trickle in one document every 10-15s
  // (each is a real vision-model call) against an otherwise-blank screen.
  const [attachProgress, setAttachProgress] = useState<{ current: number; total: number; fileName: string } | null>(null)

  // Live intake-time stopwatch (page open -> submit) + whether the analyst
  // actually used a real AI extraction/prediction for this case, vs. typed
  // everything by hand — saved onto the case itself and aggregated on the
  // Platform Impact page as a genuine AI-assisted-vs-manual comparison
  // (never a fabricated "manual entry used to take N minutes" baseline).
  const openedAtRef = useRef(Date.now())
  const [elapsedSeconds, setElapsedSeconds] = useState(0)
  const [usedAi, setUsedAi] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsedSeconds(Math.floor((Date.now() - openedAtRef.current) / 1000))
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  function formatElapsed(seconds: number): string {
    const m = Math.floor(seconds / 60)
    const s = seconds % 60
    return `${m}:${s.toString().padStart(2, '0')}`
  }

  // Multi-transaction claim: set automatically when an uploaded letter mentions
  // several distinct charges (README §58 — the manual checkbox that used to let an
  // analyst opt into this by hand was removed; the AI-detected path stays, since
  // it's a real signal from the letter, not a manual choice).
  const [isMultiTransaction, setIsMultiTransaction] = useState(false)
  const [transactions, setTransactions] = useState<TransactionRow[]>([emptyRow(), emptyRow()])

  function set<K extends keyof typeof EMPTY_FORM>(field: K, value: typeof EMPTY_FORM[K]) {
    setForm((f) => ({ ...f, [field]: value }))
  }

  // Document Understanding — upload one or more letters/scans up front, pre-
  // fill the form below from all of them combined. Each document is
  // independently classified (invoice, tracking, letter, etc.) by the vision
  // model, not picked by the analyst. Never auto-submits — the analyst always
  // reviews/edits before creating the case.
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [uploadedDocs, setUploadedDocs] = useState<UploadedDoc[]>([])
  const [pendingFiles, setPendingFiles] = useState<File[]>([])
  const [extracting, setExtracting] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const supportingFileInputRef = useRef<HTMLInputElement>(null)

  // "What happened?" -> AI predicts dispute type + priority (text-only, no
  // document needed) -> that drives which evidence documents get asked for.
  const [classifying, setClassifying] = useState(false)
  const [classifyReasoning, setClassifyReasoning] = useState('')

  // Per-dispute-type required/optional evidence, loaded from the admin-
  // editable checklist (Admin -> Evidence Requirements) once the dispute type
  // is known. Cross-matched against whatever's been uploaded and AI-classified
  // from either upload zone (README §55/§56) — not separate per-slot uploads.
  const [requirements, setRequirements] = useState<EvidenceRequirement[] | null>(null)
  const [loadingRequirements, setLoadingRequirements] = useState(false)

  // Fill-if-empty merge — a supporting document (invoice, tracking slip) won't
  // restate fields an earlier document (the cardholder's own letter) already
  // gave, so later documents never overwrite what's already filled in. Also
  // pulls the primary transaction's own fields (date, posting date, merchant,
  // amount, reference) — a document uploaded straight into a specific evidence
  // slot (e.g. Transaction Receipt) never goes through applyTransactions, so
  // without this its transaction-level fields never reached the form at all.
  function mergeFields(result: DocumentExtraction) {
    const t = result.transactions?.[0]
    setForm((f) => ({
      ...f,
      cardholder_claim: f.cardholder_claim || result.narrative || '',
      customer_name: f.customer_name || result.customer_name || '',
      masked_card_number: f.masked_card_number || result.masked_card_number || '',
      card_tier: f.card_tier || result.card_tier || '',
      // Uploading a document is real evidence a transaction actually happened;
      // default to Authenticated rather than leaving this blank, same as
      // Channel/Currency already default instead of forcing a manual pick for
      // every case. The document itself still wins when it explicitly states
      // otherwise (result.authentication_status, checked first).
      authentication_status: f.authentication_status || result.authentication_status || 'AUTHENTICATED',
      transaction_reference: f.transaction_reference || t?.transaction_reference || '',
      merchant_name: f.merchant_name || t?.merchant_name || '',
      amount_disputed: f.amount_disputed || t?.amount_disputed || '',
      transaction_date: f.transaction_date || toISODate(t?.transaction_date) || '',
      posting_date: f.posting_date || toISODate(t?.posting_date) || '',
      return_date: f.return_date || toISODate(result.return_date) || '',
      expected_refund_amount: f.expected_refund_amount || result.expected_refund_amount || '',
      expected_refund_date: f.expected_refund_date || toISODate(result.expected_refund_date) || '',
      refund_reference_number: f.refund_reference_number || result.refund_reference_number || '',
      merchant_response: f.merchant_response || result.merchant_response || '',
      merchant_contact_date: f.merchant_contact_date || toISODate(result.merchant_contact_date) || '',
      merchant_contacted: f.merchant_contacted || !!(result.merchant_response || result.merchant_contact_date),
    }))
  }

  async function loadRequirements(disputeType: string): Promise<EvidenceRequirement[]> {
    setLoadingRequirements(true)
    try {
      const r = await adminApi.listEvidenceRequirements()
      const rows = (r.data as EvidenceRequirement[])
        .filter((x) => x.dispute_type === disputeType && x.is_active)
        .sort((a, b) => a.sort_order - b.sort_order)
      setRequirements(rows)
      return rows
    } catch {
      setRequirements([])
      return []
    } finally {
      setLoadingRequirements(false)
    }
  }

  async function selectDisputeType(disputeType: string) {
    set('dispute_type', disputeType)
    if (disputeType) await loadRequirements(disputeType)
  }

  function applyTransactions(txns: ExtractedTransaction[]): string | null {
    if (txns.length > 1) {
      setIsMultiTransaction(true)
      setTransactions(txns.map((t) => ({
        dispute_type: t.dispute_type ?? '',
        transaction_reference: t.transaction_reference ?? '',
        merchant_name: t.merchant_name ?? '',
        amount_disputed: t.amount_disputed ?? '',
      })))
      return null
    } else if (txns.length === 1) {
      const t = txns[0]
      setForm((f) => ({
        ...f,
        dispute_type: f.dispute_type || t.dispute_type || '',
        transaction_reference: f.transaction_reference || t.transaction_reference || '',
        merchant_name: f.merchant_name || t.merchant_name || '',
        amount_disputed: f.amount_disputed || t.amount_disputed || '',
        transaction_date: f.transaction_date || toISODate(t.transaction_date) || '',
        posting_date: f.posting_date || toISODate(t.posting_date) || '',
      }))
      return t.dispute_type
    }
    return null
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? [])
    e.target.value = ''
    await processFiles(files)
  }

  async function processFiles(files: File[]) {
    if (files.length === 0) return

    setExtracting(true)
    setPendingFiles((p) => [...p, ...files])
    const batchTxns: ExtractedTransaction[] = []
    const lowConfidence: string[] = []
    const newDocs: UploadedDoc[] = []
    let failures = 0

    for (const file of files) {
      try {
        const r = await disputeApi.extractFromDocument(file)
        const result = r.data as DocumentExtraction
        mergeFields(result)
        batchTxns.push(...result.transactions)
        const doc: UploadedDoc = { file, documentType: result.document_type, confidence: result.confidence }
        newDocs.push(doc)
        setUploadedDocs((docs) => [...docs, doc])
        if (result.confidence < 0.6) lowConfidence.push(file.name)
      } catch (e: any) {
        const detail = e?.response?.data?.detail as string | undefined
        if (detail?.startsWith('Cyera Validation')) {
          toast.error(`${file.name}: ${detail}`, { duration: 8000 })
        } else {
          failures++
        }
      } finally {
        setPendingFiles((p) => p.filter((f) => f !== file))
      }
    }
    let predictedType: string | null = null
    if (batchTxns.length > 0) predictedType = applyTransactions(batchTxns)
    let reqs = requirements
    if (predictedType && !form.dispute_type) reqs = await loadRequirements(predictedType)

    setExtracting(false)
    if (files.length - failures > 0) setUsedAi(true)
    if (failures > 0) toast.error(`Could not extract ${failures} of ${files.length} document(s)`)
    if (lowConfidence.length > 0) {
      toast(`Low confidence on: ${lowConfidence.join(', ')} — review those fields carefully`, { icon: '⚠️' })
    } else if (files.length > failures) {
      toast.success(`Extracted from ${files.length - failures} document${files.length - failures !== 1 ? 's' : ''} — review before creating the case`)
    }

    // Proactive "still missing" nudge — analyzes what was just uploaded against the
    // known requirements right away, instead of only finding out at submit time.
    if (newDocs.length > 0 && reqs && reqs.length > 0) {
      const haveTypes = new Set([...uploadedDocs.map((d) => d.documentType), ...newDocs.map((d) => d.documentType)])
      const missing = reqs.filter((r) => r.is_required && !haveTypes.has(r.evidence_type))
      if (missing.length > 0) {
        toast(`Still missing: ${missing.map((m) => titleCase(m.evidence_type)).join(', ')}`, { icon: '📋', duration: 6000 })
      }
    }
  }

  function removeDoc(i: number) {
    setUploadedDocs((docs) => docs.filter((_, idx) => idx !== i))
  }

  // "What happened?" -> predict dispute type + priority from the narrative
  // text alone (no document needed yet) — packages/intelligence/claim_classifier.py.
  async function analyzeClaim() {
    if (!form.cardholder_claim.trim()) return
    setClassifying(true)
    setClassifyReasoning('')
    try {
      const r = await disputeApi.classifyClaim(form.cardholder_claim)
      const { dispute_type, priority, confidence, reasoning } = r.data
      setClassifyReasoning(reasoning || '')
      if (dispute_type) {
        setUsedAi(true)
        setForm((f) => ({ ...f, dispute_type, priority: priority || f.priority }))
        await loadRequirements(dispute_type)
        if (confidence < 0.6) {
          toast(`Predicted with low confidence — please double-check the dispute type.${reasoning ? ` ${reasoning}` : ''}`, { icon: '⚠️' })
        } else {
          toast.success('Dispute type and priority predicted — review below')
        }
      } else {
        toast('Could not confidently predict a dispute type from that description — please select one manually below', { icon: '⚠️' })
      }
    } catch {
      toast.error('Could not analyze the claim')
    } finally {
      setClassifying(false)
    }
  }

  function setTxn(i: number, field: keyof TransactionRow, value: string) {
    setTransactions((rows) => rows.map((r, idx) => (idx === i ? { ...r, [field]: value } : r)))
  }

  function addTxn() {
    setTransactions((rows) => [...rows, emptyRow()])
  }

  function removeTxn(i: number) {
    setTransactions((rows) => (rows.length > 2 ? rows.filter((_, idx) => idx !== i) : rows))
  }

  // Builds the metadata blob matching the case-detail contract's field names
  // (packages/persistence — DisputeModel.metadata_, read by _to_case_detail()).
  function buildMetadata(): Record<string, string | boolean> {
    const m: Record<string, string | boolean> = {}
    const put = (key: string, value: string) => { if (value.trim()) m[key] = value.trim() }
    put('customer_name', form.customer_name)
    put('customer_phone', form.customer_phone)
    put('masked_card_number', form.masked_card_number)
    put('authentication_status', form.authentication_status)
    put('card_tier', form.card_tier)
    put('merchant_name', form.merchant_name)
    put('merchant_id', form.merchant_id)
    put('merchant_category_code', form.merchant_category_code)
    put('transaction_channel', form.transaction_channel)
    put('currency', form.currency)
    put('amount_disputed', form.amount_disputed)
    put('transaction_date', form.transaction_date)
    put('posting_date', form.posting_date)
    put('return_date', form.return_date)
    put('expected_refund_amount', form.expected_refund_amount)
    put('expected_refund_date', form.expected_refund_date)
    put('refund_reference_number', form.refund_reference_number)
    if (form.merchant_contacted) {
      m.merchant_contacted = true
      put('merchant_contact_date', form.merchant_contact_date)
      put('merchant_response', form.merchant_response)
    }
    return m
  }

  async function attachDocumentsIfAny(disputeId: string) {
    let failures = 0

    for (let i = 0; i < uploadedDocs.length; i++) {
      const doc = uploadedDocs[i]
      setAttachProgress({ current: i + 1, total: uploadedDocs.length, fileName: doc.file.name })
      try {
        const type = doc.documentType === 'OTHER' ? 'SUPPORTING_DOCUMENT' : doc.documentType
        await disputeApi.uploadDocument(disputeId, doc.file, type)
      } catch (e: any) {
        const detail = e?.response?.data?.detail as string | undefined
        if (detail?.startsWith('Cyera Validation')) toast.error(detail, { duration: 8000 })
        else failures++
      }
    }
    if (failures > 0) toast(`Case created, but ${failures} document(s) could not be attached as evidence`, { icon: '⚠️' })
  }

  const requiredMissing = (requirements ?? [])
    .filter((r) => r.is_required && !uploadedDocs.some((d) => d.documentType === r.evidence_type))

  // Real, self-measured — never a fabricated "manual entry used to take N
  // minutes" baseline.
  function intakeMetadata(): { creation_seconds: string; intake_method: string } {
    return {
      creation_seconds: String(Math.floor((Date.now() - openedAtRef.current) / 1000)),
      intake_method: usedAi ? 'ai_assisted' : 'manual',
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    if (isMultiTransaction) {
      if (!form.cardholder_claim.trim()) {
        toast.error('Cardholder claim is required')
        return
      }
      if (transactions.some((t) => !t.dispute_type || !t.transaction_reference.trim())) {
        toast.error('Every transaction needs a dispute type and a transaction reference')
        return
      }
      setSubmitting(true)
      try {
        const res = await claimApi.create({
          cardholder_claim: form.cardholder_claim.trim(),
          priority: form.priority,
          // No deadline field — auto-assigned server-side (packages/intelligence/priority_scoring.py)
          transactions: transactions.map((t) => ({
            dispute_type: t.dispute_type,
            transaction_reference: t.transaction_reference.trim(),
            metadata: {
              ...(t.merchant_name ? { merchant_name: t.merchant_name } : {}),
              ...(t.amount_disputed ? { amount_disputed: t.amount_disputed } : {}),
              ...(form.customer_name ? { customer_name: form.customer_name } : {}),
              ...(form.customer_phone ? { customer_phone: form.customer_phone } : {}),
              ...intakeMetadata(),
            },
          })),
        })
        const { dispute_ids } = res.data
        toast.success(`Claim created — ${dispute_ids.length} sub-cases`)
        navigate(`/disputes/${dispute_ids[0]}`)
      } catch {
        toast.error('Failed to create claim')
      } finally {
        setSubmitting(false)
      }
      return
    }

    if (!form.dispute_type || !form.cardholder_claim.trim()) {
      toast.error('Describe what happened and confirm a dispute type first')
      return
    }
    if (requiredMissing.length > 0) {
      toast.error(`Please upload the required document${requiredMissing.length !== 1 ? 's' : ''}: ${requiredMissing.map((r) => titleCase(r.evidence_type)).join(', ')}`)
      return
    }
    setSubmitting(true)
    try {
      const res = await disputeApi.create({
        dispute_type: form.dispute_type,
        cardholder_claim: form.cardholder_claim.trim(),
        priority: form.priority,
        transaction_reference: form.transaction_reference || undefined,
        // No deadline field — auto-assigned server-side (packages/intelligence/priority_scoring.py)
        metadata: { ...buildMetadata(), ...intakeMetadata() },
      })
      const dispute = res.data
      // Awaited on purpose (README §64) — navigating immediately and attaching
      // documents in the background used to mean the Command Center rendered before
      // any evidence existed, then evidence trickled in one document every 10-15s
      // (each a real vision-model call), which read as broken/half-loaded rather than
      // "still working." Waiting here, with the full-screen progress takeover below,
      // means the Command Center is fully populated the moment it's first shown.
      await attachDocumentsIfAny(dispute.dispute_id)
      toast.success('Case created')
      navigate(`/disputes/${dispute.dispute_id}`)
    } catch {
      toast.error('Failed to create case')
    } finally {
      setSubmitting(false)
      setAttachProgress(null)
    }
  }

  const showGuidedSections = !isMultiTransaction && !!form.dispute_type

  if (submitting) return <CreatingCaseOverlay progress={attachProgress} />

  return (
    <div className="min-h-screen p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-6">
        <div className="flex items-center gap-3 min-w-0">
          <button type="button" onClick={() => navigate('/disputes')}
            className="rounded-fluent p-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors shrink-0">
            <ArrowLeft size={18} style={{ color: 'var(--color-text-muted)' }} />
          </button>
          <div className="w-10 h-10 rounded-fluent-lg flex items-center justify-center shrink-0 bg-grad-brand shadow-glow-brand">
            <Plus size={20} className="text-white" />
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-2xl font-bold tracking-tight" style={{ color: 'var(--color-text)' }}>New Case</h1>
            <p className="text-sm" style={{ color: 'var(--color-text-muted)' }}>
              Upload the cardholder's letter to auto-fill everything — or describe what happened below.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <span className="flex items-center gap-1.5 text-sm font-mono px-3 py-1.5 rounded-fluent"
            style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-muted)' }}
            title="Time to raise this case — saved with it, shown on Platform Impact">
            <Timer size={14} />
            {formatElapsed(elapsedSeconds)}
          </span>
        </div>
      </div>
      <div className="h-px mb-6" style={{ background: 'var(--color-border)' }} />

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* ── Left column — the form itself ─────────────────────────────── */}
          <div className="lg:col-span-3 space-y-5">
            {/* Cardholder Letter — the primary upload that drives everything: classifies
                the dispute type, pre-fills the form, and surfaces the Required
                Documents checklist in the sidebar. Real drag-and-drop with an animated
                glow, not just a click target. */}
            <div
              className={clsx(
                'rounded-fluent-lg p-5 space-y-3 border-2 border-dashed transition-all duration-300',
                isDragging && 'scale-[1.01] shadow-glow-brand',
                extracting && 'animate-pulse-slow'
              )}
              style={{
                background: isDragging ? 'color-mix(in srgb, var(--color-brand) 22%, var(--color-brand-light))' : 'var(--color-brand-light)',
                borderColor: isDragging ? 'var(--color-brand)' : 'color-mix(in srgb, var(--color-brand) 45%, transparent)',
              }}
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={(e) => {
                e.preventDefault()
                setIsDragging(false)
                processFiles(Array.from(e.dataTransfer.files))
              }}
            >
              <div className="flex items-center gap-3">
                <input ref={fileInputRef} type="file" multiple accept="application/pdf,image/png,image/jpeg,image/webp"
                  className="hidden" onChange={handleFileChange} />
                <div className={clsx(
                  'w-11 h-11 rounded-fluent flex items-center justify-center shrink-0 bg-grad-brand shadow-glow-brand transition-transform duration-300',
                  isDragging && 'scale-110'
                )}>
                  {extracting ? <Loader2 size={18} className="animate-spin text-white" /> : <Sparkles size={18} className="text-white" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
                    {extracting ? 'Reading the letter…' : uploadedDocs.length > 0
                      ? `${uploadedDocs.length} document${uploadedDocs.length !== 1 ? 's' : ''} uploaded`
                      : 'Upload the cardholder\'s letter'}
                  </div>
                  <div className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                    {uploadedDocs.length > 0
                      ? 'Each is attached as evidence once the case is created'
                      : 'Drag & drop, or click — AI reads it, fills the form, and figures out what other documents this case needs'}
                  </div>
                </div>
                <Button type="button" variant="secondary" disabled={extracting}
                  onClick={() => fileInputRef.current?.click()}>
                  <FileUp size={14} /> {uploadedDocs.length > 0 ? 'Add More' : 'Upload'}
                </Button>
              </div>

              {(pendingFiles.length > 0 || uploadedDocs.length > 0) && (
                <div className="space-y-1.5 pt-1">
                  {pendingFiles.map((f, i) => <ScanningCard key={`pending-${i}-${f.name}`} fileName={f.name} />)}
                  {uploadedDocs.map((doc, i) => {
                    // A genuinely unreadable upload (blank/corrupt scan) comes back as
                    // OTHER with near-zero confidence — flagged quietly, not as an alarming
                    // error, since a real-but-uncategorized document (OTHER with real
                    // confidence) is normal and shouldn't look broken.
                    const unclassified = doc.documentType === 'OTHER' && doc.confidence < 0.3
                    return (
                      <div key={i} className="flex items-center gap-2 text-xs px-2.5 py-2 rounded-fluent border"
                        style={{
                          background: unclassified ? 'rgba(197,15,31,0.06)' : 'var(--color-surface)',
                          borderColor: unclassified ? 'rgba(197,15,31,0.2)' : 'var(--color-border)',
                        }}>
                        {unclassified
                          ? <FileText size={13} style={{ color: 'var(--color-text-subtle)', flexShrink: 0 }} />
                          : <CheckCircle2 size={13} style={{ color: 'var(--color-success)', flexShrink: 0 }} />}
                        <span className="font-medium truncate" style={{ color: unclassified ? 'var(--color-text-subtle)' : 'var(--color-text)' }}>
                          {unclassified ? 'Could not read this file' : titleCase(doc.documentType)}
                        </span>
                        <span className="truncate" style={{ color: 'var(--color-text-muted)' }}>
                          {doc.file.name}
                        </span>
                        {!unclassified && (
                          <span className="text-2xs px-1.5 py-0.5 rounded-full font-semibold shrink-0"
                            style={{
                              background: doc.confidence >= 0.6 ? 'rgba(16,124,16,0.12)' : 'rgba(202,80,16,0.12)',
                              color: doc.confidence >= 0.6 ? 'var(--color-success)' : 'var(--color-medium)',
                            }}>
                            {Math.round(doc.confidence * 100)}% confidence
                          </span>
                        )}
                        <button type="button" onClick={() => removeDoc(i)} className="ml-auto shrink-0">
                          <X size={12} style={{ color: 'var(--color-text-muted)' }} />
                        </button>
                      </div>
                    )
                  })}
                </div>
              )}
            </div>

            {!isMultiTransaction && (
              <>
                {/* ── Cardholder — always visible first ── */}
                <SectionLabel>Cardholder</SectionLabel>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Customer Name">
                    <Input type="text" placeholder="Full name as on account"
                      value={form.customer_name} onChange={(e) => set('customer_name', e.target.value)} />
                  </Field>
                  <Field label="Card Number (masked)">
                    <Input type="text" placeholder="****1234"
                      value={form.masked_card_number} onChange={(e) => set('masked_card_number', e.target.value)} />
                  </Field>
                </div>
                <Field label="Customer Phone">
                  <Input type="tel" placeholder="+15551234567 (for SMS updates)"
                    value={form.customer_phone} onChange={(e) => set('customer_phone', e.target.value)} />
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Authentication Status">
                    <Select value={form.authentication_status} onChange={(e) => set('authentication_status', e.target.value)}>
                      <option value="">Not specified</option>
                      <option value="AUTHENTICATED">Authenticated</option>
                      <option value="NOT_AUTHENTICATED">Not Authenticated</option>
                    </Select>
                  </Field>
                  <Field label="Card Tier">
                    <Select value={form.card_tier} onChange={(e) => set('card_tier', e.target.value)}>
                      <option value="">Not specified</option>
                      <option value="PLATINUM">Platinum</option>
                      <option value="GOLD">Gold</option>
                      <option value="CLASSIC">Classic</option>
                    </Select>
                  </Field>
                </div>
              </>
            )}

            {/* Cardholder claim — shared narrative in both modes */}
            <Field label="Cardholder Claim" required>
              <Textarea
                className="h-24"
                placeholder="Describe the customer's claim in detail…"
                value={form.cardholder_claim}
                onChange={(e) => set('cardholder_claim', e.target.value)}
                required
              />
            </Field>

            {!isMultiTransaction && !form.dispute_type && (
              <div className="rounded-fluent p-3.5 space-y-2" style={{ background: 'var(--color-surface-r)', border: '1px solid var(--color-border)' }}>
                <Button type="button" variant="primary" size="sm" onClick={analyzeClaim}
                  disabled={!form.cardholder_claim.trim() || classifying} loading={classifying}>
                  {!classifying && <Sparkles size={13} />}
                  {classifying ? 'Analysing…' : 'Analyze — Predict Dispute Type & Priority'}
                </Button>
                {classifyReasoning && (
                  <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{classifyReasoning}</p>
                )}
                <div className="flex items-center gap-2 pt-1">
                  <span className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>or select manually:</span>
                  <Select value={form.dispute_type} onChange={(e) => selectDisputeType(e.target.value)}>
                    <option value="">Select type…</option>
                    {DISPUTE_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>{t.label}</option>
                    ))}
                  </Select>
                </div>
              </div>
            )}

            {isMultiTransaction && (
              <div className="space-y-3">
                <label className="block text-sm font-medium" style={{ color: 'var(--color-text-muted)' }}>
                  Transactions<span className="ml-0.5" style={{ color: 'var(--color-critical)' }}>*</span>
                </label>
                {transactions.map((row, i) => (
                  <div key={i} className="rounded-fluent p-3 space-y-2"
                    style={{ background: 'var(--color-surface-r)', border: '1px solid var(--color-border)' }}>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold" style={{ color: 'var(--color-text-subtle)' }}>
                        Transaction {i + 1}
                      </span>
                      {transactions.length > 2 && (
                        <button type="button" onClick={() => removeTxn(i)}
                          className="rounded p-1 hover:bg-neutral-100 dark:hover:bg-neutral-800">
                          <Trash2 size={12} style={{ color: 'var(--color-critical)' }} />
                        </button>
                      )}
                    </div>
                    <Select
                      value={row.dispute_type}
                      onChange={(e) => setTxn(i, 'dispute_type', e.target.value)}
                      required>
                      <option value="">Select type…</option>
                      {DISPUTE_TYPES.map((t) => (
                        <option key={t.value} value={t.value}>{t.label}</option>
                      ))}
                    </Select>
                    <Input type="text"
                      placeholder="Transaction reference (TXN-XXXXXXXXX)"
                      value={row.transaction_reference}
                      onChange={(e) => setTxn(i, 'transaction_reference', e.target.value)}
                      required
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <Input type="text"
                        placeholder="Merchant name"
                        value={row.merchant_name}
                        onChange={(e) => setTxn(i, 'merchant_name', e.target.value)}
                      />
                      <Input type="number"
                        placeholder="Amount"
                        min={0}
                        step="0.01"
                        value={row.amount_disputed}
                        onChange={(e) => setTxn(i, 'amount_disputed', e.target.value)}
                      />
                    </div>
                  </div>
                ))}
                <Button type="button" variant="secondary" size="sm" onClick={addTxn}>
                  <Plus size={12} /> Add another transaction
                </Button>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Customer Name">
                    <Input type="text" placeholder="Full name as on account"
                      value={form.customer_name} onChange={(e) => set('customer_name', e.target.value)} />
                  </Field>
                  <Field label="Customer Phone">
                    <Input type="tel" placeholder="+15551234567 (for SMS updates)"
                      value={form.customer_phone} onChange={(e) => set('customer_phone', e.target.value)} />
                  </Field>
                </div>
              </div>
            )}

            {showGuidedSections && (
              <>
                {/* Dispute type + priority — pre-filled by Analyze, still editable */}
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Dispute Type" required>
                    <Select value={form.dispute_type} onChange={(e) => selectDisputeType(e.target.value)} required>
                      <option value="">Select type…</option>
                      {DISPUTE_TYPES.map((t) => (
                        <option key={t.value} value={t.value}>{t.label}</option>
                      ))}
                    </Select>
                  </Field>
                  <Field label="Priority">
                    <Select value={form.priority} onChange={(e) => set('priority', e.target.value)}>
                      <option value="CRITICAL">Critical</option>
                      <option value="HIGH">High</option>
                      <option value="MEDIUM">Medium</option>
                      <option value="LOW">Low</option>
                    </Select>
                  </Field>
                </div>
                <p className="text-xs -mt-2" style={{ color: 'var(--color-text-subtle)' }}>
                  The SLA deadline and triage priority score are calculated automatically — priority above just seeds it.
                </p>

                {/* ── Transaction ── */}
                <SectionLabel>Transaction</SectionLabel>
                <Field label="Transaction Reference">
                  <Input type="text" placeholder="TXN-XXXXXXXXX"
                    value={form.transaction_reference} onChange={(e) => set('transaction_reference', e.target.value)} />
                </Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Merchant Name">
                    <Input type="text" placeholder="e.g. Amazon India"
                      value={form.merchant_name} onChange={(e) => set('merchant_name', e.target.value)} />
                  </Field>
                  <Field label="Merchant ID">
                    <Input type="text" placeholder="e.g. AMAZON-IN-001"
                      value={form.merchant_id} onChange={(e) => set('merchant_id', e.target.value)} />
                  </Field>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Amount Disputed">
                    <Input type="number" placeholder="0.00" min={0} step="0.01"
                      value={form.amount_disputed} onChange={(e) => set('amount_disputed', e.target.value)} />
                  </Field>
                  <Field label="Currency">
                    <Select value={form.currency} onChange={(e) => set('currency', e.target.value)}>
                      <option value="INR">INR</option>
                      <option value="USD">USD</option>
                      <option value="EUR">EUR</option>
                      <option value="GBP">GBP</option>
                    </Select>
                  </Field>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Merchant Category Code">
                    <Input type="text" placeholder="e.g. 5691"
                      value={form.merchant_category_code} onChange={(e) => set('merchant_category_code', e.target.value)} />
                  </Field>
                  <Field label="Channel">
                    <Select value={form.transaction_channel} onChange={(e) => set('transaction_channel', e.target.value)}>
                      <option value="ECOMMERCE">E-commerce</option>
                      <option value="IN_STORE">In-store</option>
                      <option value="RECURRING">Recurring</option>
                      <option value="ATM">ATM</option>
                    </Select>
                  </Field>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Transaction Date">
                    <Input type="date" value={form.transaction_date} onChange={(e) => set('transaction_date', e.target.value)} />
                  </Field>
                  <Field label="Posting Date">
                    <Input type="date" value={form.posting_date} onChange={(e) => set('posting_date', e.target.value)} />
                  </Field>
                </div>

                {/* ── Dispute details ── */}
                <SectionLabel>Dispute Details</SectionLabel>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Return Date">
                    <Input type="date" value={form.return_date} onChange={(e) => set('return_date', e.target.value)} />
                  </Field>
                  <Field label="Refund Reference #">
                    <Input type="text" placeholder="REF-XXXXXXX"
                      value={form.refund_reference_number} onChange={(e) => set('refund_reference_number', e.target.value)} />
                  </Field>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Expected Refund Amount">
                    <Input type="number" placeholder="0.00" min={0} step="0.01"
                      value={form.expected_refund_amount} onChange={(e) => set('expected_refund_amount', e.target.value)} />
                  </Field>
                  <Field label="Expected Refund Date">
                    <Input type="date" value={form.expected_refund_date} onChange={(e) => set('expected_refund_date', e.target.value)} />
                  </Field>
                </div>
                <label className="flex items-center gap-2 text-sm cursor-pointer select-none" style={{ color: 'var(--color-text-muted)' }}>
                  <input type="checkbox" checked={form.merchant_contacted}
                    onChange={(e) => set('merchant_contacted', e.target.checked)} />
                  Merchant was contacted about this dispute
                </label>
                {form.merchant_contacted && (
                  <>
                    <Field label="Merchant Contact Date">
                      <Input type="date" value={form.merchant_contact_date} onChange={(e) => set('merchant_contact_date', e.target.value)} />
                    </Field>
                    <Field label="Merchant Response">
                      <Textarea className="h-16" placeholder="What did the merchant say?"
                        value={form.merchant_response} onChange={(e) => set('merchant_response', e.target.value)} />
                    </Field>
                  </>
                )}
              </>
            )}
          </div>

          {/* ── Right column — required documents, live and sticky ─────────── */}
          <div className="lg:col-span-2">
            <div className="lg:sticky lg:top-6 space-y-4">
              {showGuidedSections ? (
                <>
                  <div className="flex items-center justify-between">
                    <SectionLabel>Required Documents</SectionLabel>
                    {requirements && requirements.length > 0 && (
                      <>
                        <input ref={supportingFileInputRef} type="file" multiple accept="application/pdf,image/png,image/jpeg,image/webp"
                          className="hidden" onChange={handleFileChange} />
                        <button type="button" disabled={extracting}
                          onClick={() => supportingFileInputRef.current?.click()}
                          className="flex items-center gap-1 text-xs font-medium disabled:opacity-50"
                          style={{ color: 'var(--color-brand)' }}>
                          {extracting ? <Loader2 size={12} className="animate-spin" /> : <FileUp size={12} />}
                          Add supporting documents
                        </button>
                      </>
                    )}
                  </div>
                  {requirements && requirements.length > 0 && uploadedDocs.length > 0 && (
                    <CaseStrengthPanel requirements={requirements} uploadedDocs={uploadedDocs} cardholderClaim={form.cardholder_claim} />
                  )}
                  {loadingRequirements ? (
                    <p className="text-sm" style={{ color: 'var(--color-text-muted)' }}>Loading requirements…</p>
                  ) : requirements && requirements.length > 0 ? (
                    <div className="space-y-1.5">
                      {requirements.map((req) => {
                        const match = uploadedDocs.find((d) => d.documentType === req.evidence_type)
                        return (
                          <div key={req.requirement_id} className="flex items-center gap-2.5 rounded-fluent px-3 py-2.5 border"
                            style={{
                              borderColor: match ? 'var(--color-success)' : req.is_required ? 'rgba(197,15,31,0.35)' : 'var(--color-border)',
                              background: match ? 'rgba(16,124,16,0.04)' : 'var(--color-surface-r)',
                            }}>
                            {match
                              ? <CheckCircle2 size={16} style={{ color: 'var(--color-success)', flexShrink: 0 }} />
                              : <span className="w-4 h-4 rounded-full border shrink-0" style={{ borderColor: 'var(--color-text-subtle)' }} />}
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-semibold truncate" style={{ color: 'var(--color-text)' }}>
                                  {titleCase(req.evidence_type)}
                                </span>
                                <span className="text-xs px-1.5 py-0.5 rounded-full font-medium shrink-0"
                                  style={{
                                    background: req.is_required ? 'rgba(197,15,31,0.1)' : 'var(--color-surface)',
                                    color: req.is_required ? 'var(--color-critical)' : 'var(--color-text-muted)',
                                  }}>
                                  {req.is_required ? 'Required' : 'Optional'}
                                </span>
                              </div>
                              <p className="text-xs mt-0.5 truncate" style={{ color: match ? 'var(--color-success)' : 'var(--color-text-muted)' }}>
                                {match ? `Matched: ${match.file.name}` : req.description}
                              </p>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  ) : (
                    <p className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>
                      No specific documents are configured for this dispute type yet — use the upload box on the left for any supporting evidence.
                    </p>
                  )}
                </>
              ) : (
                <div className="rounded-fluent-lg border border-dashed p-5 text-center"
                  style={{ borderColor: 'var(--color-border)' }}>
                  <FileText size={22} className="mx-auto mb-2" style={{ color: 'var(--color-text-subtle)' }} />
                  <p className="text-sm font-medium" style={{ color: 'var(--color-text-muted)' }}>
                    Required documents will show up here
                  </p>
                  <p className="text-xs mt-1" style={{ color: 'var(--color-text-subtle)' }}>
                    Upload the cardholder's letter, or select a dispute type, to see this case's checklist.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-2 pt-6 mt-6 border-t" style={{ borderColor: 'var(--color-border)' }}>
          <Button type="button" variant="secondary" onClick={() => navigate('/disputes')}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" loading={submitting}>
            {submitting ? 'Creating…' : isMultiTransaction ? 'Create Claim' : 'Create Case'}
          </Button>
        </div>
      </form>
    </div>
  )
}
