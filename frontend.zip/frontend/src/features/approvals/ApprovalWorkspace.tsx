import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { actionApi } from '@/services/api'
import { Action } from '@/types'
import { format } from 'date-fns'
import { type ReactNode } from 'react'
import { CheckCircle, Clock, XCircle, AlertTriangle, Shield } from 'lucide-react'
import toast from 'react-hot-toast'
import clsx from 'clsx'
import { useAuthStore } from '@/app/store'
import { Button, Textarea } from '@/components/ui'

const STATUS_ICON: Record<string, ReactNode> = {
  PENDING_APPROVAL: <Clock size={16} className="text-amber-500" />,
  APPROVED: <CheckCircle size={16} className="text-green-500" />,
  REJECTED: <XCircle size={16} className="text-red-500" />,
  EXECUTED: <CheckCircle size={16} className="text-blue-500" />,
  STALE: <AlertTriangle size={16} className="text-neutral-400" />,
}

export function ApprovalWorkspace() {
  const { id } = useParams<{ id: string }>()
  const qc = useQueryClient()
  const { user } = useAuthStore()
  const [notes, setNotes] = useState<Record<string, string>>({})

  const { data: actions = [] } = useQuery({
    queryKey: ['actions', id],
    queryFn: () => actionApi.list(id!),
    select: (r) => r.data as Action[],
    enabled: !!id,
    refetchInterval: 15_000,
  })

  const approveMutation = useMutation({
    mutationFn: ({ actionId, decision }: { actionId: string; decision: 'APPROVED' | 'REJECTED' }) =>
      actionApi.approve(id!, actionId, decision, notes[actionId] ?? ''),
    onSuccess: (_, vars) => {
      toast.success(`Action ${vars.decision.toLowerCase()}`)
      qc.invalidateQueries({ queryKey: ['actions', id] })
    },
    onError: () => toast.error('Approval failed'),
  })

  const canApprove = user?.permissions?.includes('action:approve')
  const pending = actions.filter((a) => a.status === 'PENDING_APPROVAL')
  const historical = actions.filter((a) => a.status !== 'PENDING_APPROVAL')

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-2 mb-1">
        <Shield size={18} style={{ color: 'var(--color-brand)' }} />
        <h2 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
          Approval Workspace
        </h2>
      </div>
      <p className="text-xs mb-6" style={{ color: 'var(--color-text-muted)' }}>
        CLASS_C actions require supervisor approval before execution.
      </p>

      {!canApprove && (
        <div
          className="rounded-fluent px-4 py-3 mb-6 flex items-center gap-2 text-sm"
          style={{ background: 'var(--color-surface-r)', border: '1px solid var(--color-border)', color: 'var(--color-text-muted)' }}
        >
          <Shield size={14} />
          Your role does not have approval authority. Actions shown read-only.
        </div>
      )}

      {/* Pending */}
      {pending.length > 0 && (
        <div className="mb-8">
          <h3 className="text-sm font-semibold mb-3" style={{ color: 'var(--color-text)' }}>
            Awaiting Decision — {pending.length}
          </h3>
          <div className="space-y-4">
            {pending.map((action) => (
              <div
                key={action.action_id}
                className="rounded-fluent-lg p-4 shadow-fluent-sm ring-1 ring-amber-400/40"
                style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    {STATUS_ICON['PENDING_APPROVAL']}
                    <span className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>
                      {action.action_type.replace(/_/g, ' ')}
                    </span>
                    <span className="text-2xs px-1.5 py-0.5 rounded bg-red-100 text-red-700 font-medium">
                      {action.action_class}
                    </span>
                  </div>
                  <span className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>
                    {format(new Date(action.created_at), 'dd MMM HH:mm')}
                  </span>
                </div>

                {action.input && Object.keys(action.input).length > 0 && (
                  <p className="text-xs mb-3 px-3 py-2 rounded-fluent"
                    style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-muted)' }}>
                    {String((action.input as Record<string, unknown>).description ?? action.action_type.replace(/_/g, ' '))}
                  </p>
                )}

                {canApprove && (
                  <>
                    <Textarea
                      className="mb-2 h-16 text-xs"
                      placeholder="Reviewer notes (optional)…"
                      value={notes[action.action_id] ?? ''}
                      onChange={(e) =>
                        setNotes((n) => ({ ...n, [action.action_id]: e.target.value }))
                      }
                    />
                    <div className="flex gap-2">
                      <Button
                        variant="primary"
                        size="sm"
                        style={{ background: 'var(--color-success)' }}
                        onClick={() =>
                          approveMutation.mutate({ actionId: action.action_id, decision: 'APPROVED' })
                        }
                        loading={approveMutation.isPending}
                      >
                        <CheckCircle size={14} />
                        Approve
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() =>
                          approveMutation.mutate({ actionId: action.action_id, decision: 'REJECTED' })
                        }
                        loading={approveMutation.isPending}
                      >
                        <XCircle size={14} />
                        Reject
                      </Button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Historical */}
      {historical.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold mb-3" style={{ color: 'var(--color-text)' }}>
            History
          </h3>
          <div className="space-y-2">
            {historical.map((action) => (
              <div
                key={action.action_id}
                className="flex items-center justify-between px-4 py-3 rounded-fluent"
                style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}
              >
                <div className="flex items-center gap-2">
                  {STATUS_ICON[action.status] ?? <Clock size={16} />}
                  <div>
                    <span className="text-sm" style={{ color: 'var(--color-text)' }}>
                      {action.action_type.replace(/_/g, ' ')}
                    </span>
                    <span className="ml-2 text-2xs px-1.5 py-0.5 rounded bg-neutral-100 text-neutral-600">
                      {action.action_class}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={clsx(
                    'text-xs px-2 py-0.5 rounded font-medium',
                    action.status === 'APPROVED' ? 'bg-green-100 text-green-700'
                    : action.status === 'REJECTED' ? 'bg-red-100 text-red-700'
                    : action.status === 'EXECUTED' ? 'bg-blue-100 text-blue-700'
                    : 'bg-neutral-100 text-neutral-600'
                  )}>
                    {action.status}
                  </span>
                  <span className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>
                    {format(new Date(action.created_at), 'dd MMM HH:mm')}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {actions.length === 0 && (
        <div
          className="rounded-fluent-lg p-8 text-center"
          style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}
        >
          <Shield size={32} className="mx-auto mb-3" style={{ color: 'var(--color-text-subtle)' }} />
          <p className="text-sm" style={{ color: 'var(--color-text-muted)' }}>
            No actions yet. Agent proposes CLASS_C actions during analysis.
          </p>
        </div>
      )}
    </div>
  )
}
