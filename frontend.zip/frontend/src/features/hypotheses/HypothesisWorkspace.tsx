import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { disputeApi } from '@/services/api'
import { Hypothesis } from '@/types'
import { AlertTriangle, CheckCircle, HelpCircle, XCircle } from 'lucide-react'
import clsx from 'clsx'
import { type ReactNode } from 'react'

const STATUS_ICON: Record<string, ReactNode> = {
  PROPOSED:    <HelpCircle size={16} className="text-blue-500" />,
  SUPPORTED:   <CheckCircle size={16} className="text-green-500" />,
  REFUTED:     <XCircle size={16} className="text-red-500" />,
  INDETERMINATE: <AlertTriangle size={16} className="text-amber-500" />,
}

function ConfidenceBar({ value }: { value: number }) {
  const pct = Math.round(value * 100)
  const color = value > 0.7 ? '#107c10' : value > 0.4 ? '#ca5010' : '#d13438'
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: 'var(--color-border)' }}>
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, background: color }}
        />
      </div>
      <span className="text-xs w-8 text-right tabular-nums" style={{ color: 'var(--color-text-muted)' }}>
        {pct}%
      </span>
    </div>
  )
}

export function HypothesisWorkspace() {
  const { id } = useParams<{ id: string }>()

  const { data: hypotheses = [] } = useQuery({
    queryKey: ['hypotheses', id],
    queryFn: () => disputeApi.getHypotheses(id!),
    select: (r) => (r.data as Hypothesis[]).sort((a, b) => b.confidence_score - a.confidence_score),
    enabled: !!id,
  })

  const { data: contradictions = [] } = useQuery({
    queryKey: ['contradictions', id],
    queryFn: () => disputeApi.getContradictions(id!),
    select: (r) => r.data as any[],
    enabled: !!id,
  })

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h2 className="text-base font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
        Hypothesis Workspace
      </h2>
      <p className="text-xs mb-6" style={{ color: 'var(--color-text-muted)' }}>
        Competing interpretations ranked by confidence. Agent assigns and updates.
      </p>

      {hypotheses.length === 0 ? (
        <div
          className="rounded-fluent-lg p-8 text-center"
          style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}
        >
          <HelpCircle size={32} className="mx-auto mb-3" style={{ color: 'var(--color-text-subtle)' }} />
          <p className="text-sm" style={{ color: 'var(--color-text-muted)' }}>
            No hypotheses yet. Run the agent to generate competing interpretations.
          </p>
        </div>
      ) : (
        <div className="space-y-4 mb-8">
          {hypotheses.map((h, idx) => (
            <div
              key={h.hypothesis_id}
              className={clsx(
                'rounded-fluent-lg p-4 shadow-fluent-sm',
                idx === 0 ? 'ring-2 ring-brand-500/30' : ''
              )}
              style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)' }}
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-2 min-w-0">
                  {STATUS_ICON[h.status] ?? <HelpCircle size={16} />}
                  <h3 className="text-sm font-semibold truncate" style={{ color: 'var(--color-text)' }}>
                    {h.description}
                  </h3>
                  {idx === 0 && (
                    <span className="text-2xs px-1.5 py-0.5 rounded font-medium bg-brand-100 text-brand-700 dark:bg-brand-900/30 dark:text-brand-300 shrink-0">
                      LEADING
                    </span>
                  )}
                </div>
                <span className={clsx(
                  'text-xs px-2 py-0.5 rounded shrink-0',
                  h.status === 'SUPPORTED'   ? 'bg-green-100 text-green-700'
                  : h.status === 'REFUTED'   ? 'bg-red-100 text-red-700'
                  : h.status === 'PROPOSED'  ? 'bg-blue-100 text-blue-700'
                  : 'bg-amber-100 text-amber-700'
                )}>
                  {h.status}
                </span>
              </div>

              <ConfidenceBar value={h.confidence_score} />

              {h.confidence_descriptor && (
                <p className="text-xs mt-2 italic" style={{ color: 'var(--color-text-muted)' }}>
                  {h.confidence_descriptor}
                </p>
              )}

              {/* Supporting/refuting evidence */}
              {(h.supporting_evidence_ids?.length > 0 || h.weakening_evidence_ids?.length > 0) && (
                <div className="mt-3 flex gap-4 text-xs" style={{ color: 'var(--color-text-subtle)' }}>
                  {h.supporting_evidence_ids?.length > 0 && (
                    <span className="flex items-center gap-1 text-green-600">
                      <CheckCircle size={10} />
                      {h.supporting_evidence_ids.length} supporting
                    </span>
                  )}
                  {h.weakening_evidence_ids?.length > 0 && (
                    <span className="flex items-center gap-1 text-red-600">
                      <XCircle size={10} />
                      {h.weakening_evidence_ids.length} weakening
                    </span>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Contradictions */}
      {contradictions.length > 0 && (
        <>
          <h3 className="text-sm font-semibold mb-3" style={{ color: 'var(--color-text)' }}>
            Evidence Contradictions
          </h3>
          <div className="space-y-3">
            {contradictions.map((c: any) => (
              <div
                key={c.contradiction_id}
                className="rounded-fluent p-3 border-l-4"
                style={{
                  background: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderLeftColor: '#ca5010',
                }}
              >
                <div className="flex items-center gap-2 mb-1">
                  <AlertTriangle size={14} style={{ color: '#ca5010' }} />
                  <span className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>
                    {c.conflict_type.replace(/_/g, ' ')}
                  </span>
                </div>
                <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                  {c.description}
                </p>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
