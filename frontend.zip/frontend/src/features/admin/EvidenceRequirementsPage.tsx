import { useEffect, useMemo, useRef, useState } from 'react'
import { Plus, Pencil, Trash2, ArrowLeft, CheckCircle2, FileUp, Sparkles, X } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { adminApi } from '@/services/api'
import type { EvidenceRequirement } from '@/types'
import { Field, Input, Textarea, Button } from '@/components/ui'
import toast from 'react-hot-toast'

const DISPUTE_TYPE_HINTS = [
  'UNAUTHORIZED_TRANSACTION', 'DUPLICATE_TRANSACTION', 'MERCHANDISE_NOT_RECEIVED',
  'MERCHANDISE_NOT_AS_DESCRIBED', 'REFUND_NOT_PROCESSED', 'SUBSCRIPTION_CANCELLATION',
  'CASH_WITHDRAWAL_DISPUTE', 'PROCESSING_ERROR',
]

const EMPTY = {
  dispute_type: '', evidence_type: '', description: '', is_required: true, sort_order: 0, is_active: true,
}

interface ExtractedRow {
  evidence_type: string
  description: string
  is_required: boolean
  selected: boolean
}

export function EvidenceRequirementsPage() {
  const navigate = useNavigate()
  const [items, setItems] = useState<EvidenceRequirement[]>([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState<string | null>(null)
  const [form, setForm] = useState({ ...EMPTY })
  const [saving, setSaving] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  // Upload -> extract candidate requirements from a reference document
  const [showUpload, setShowUpload] = useState(false)
  const [uploadDisputeType, setUploadDisputeType] = useState('')
  const [uploadFile, setUploadFile] = useState<File | null>(null)
  const [extracting, setExtracting] = useState(false)
  const [extracted, setExtracted] = useState<ExtractedRow[] | null>(null)
  const [extractionNotes, setExtractionNotes] = useState('')
  const [committing, setCommitting] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  async function load() {
    setLoading(true)
    try { const r = await adminApi.listEvidenceRequirements(); setItems(r.data) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  function startCreate() { setShowUpload(false); setEditing('new'); setForm({ ...EMPTY }); setError(null) }

  function startEdit(item: EvidenceRequirement) {
    setShowUpload(false)
    setEditing(item.requirement_id)
    setForm({
      dispute_type: item.dispute_type, evidence_type: item.evidence_type, description: item.description,
      is_required: item.is_required, sort_order: item.sort_order, is_active: item.is_active,
    })
    setError(null)
  }

  function cancel() { setEditing(null); setConfirmDelete(null); setError(null) }

  const f = (field: string, value: any) => setForm((p) => ({ ...p, [field]: value }))

  async function save() {
    setSaving(true); setError(null)
    try {
      editing === 'new'
        ? await adminApi.createEvidenceRequirement(form)
        : await adminApi.updateEvidenceRequirement(editing!, form)
      setEditing(null); await load()
    } catch (e: any) {
      setError(e?.response?.data?.detail ?? 'Save failed')
    } finally { setSaving(false) }
  }

  async function handleDelete(id: string) {
    try { await adminApi.deleteEvidenceRequirement(id); setConfirmDelete(null); await load() }
    catch (e: any) { setError(e?.response?.data?.detail ?? 'Failed') }
  }

  function startUpload() {
    setEditing(null)
    setShowUpload(true)
    setUploadDisputeType('')
    setUploadFile(null)
    setExtracted(null)
    setExtractionNotes('')
    setError(null)
  }

  function cancelUpload() {
    setShowUpload(false)
    setUploadFile(null)
    setExtracted(null)
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (file) setUploadFile(file)
  }

  async function runExtraction() {
    if (!uploadFile || !uploadDisputeType.trim()) return
    setExtracting(true)
    setExtracted(null)
    try {
      const r = await adminApi.extractEvidenceRequirements(uploadFile, uploadDisputeType.trim().toUpperCase())
      const rows: ExtractedRow[] = r.data.requirements.map((row: any) => ({ ...row, selected: true }))
      setExtracted(rows)
      setExtractionNotes(r.data.notes || '')
      if (rows.length === 0) {
        toast('No evidence requirements found in this document', { icon: '⚠️' })
      } else if (r.data.confidence < 0.6) {
        toast(`Extracted with low confidence — review each row carefully.${r.data.notes ? ` ${r.data.notes}` : ''}`, { icon: '⚠️' })
      } else {
        toast.success(`Found ${rows.length} candidate requirement${rows.length !== 1 ? 's' : ''} — review before adding`)
      }
    } catch (e: any) {
      toast.error(e?.response?.data?.detail ?? 'Could not extract from this document')
    } finally {
      setExtracting(false)
    }
  }

  function toggleExtractedRow(i: number) {
    setExtracted((rows) => rows ? rows.map((r, idx) => idx === i ? { ...r, selected: !r.selected } : r) : rows)
  }

  async function commitExtracted() {
    if (!extracted) return
    const selected = extracted.filter((r) => r.selected)
    if (selected.length === 0) return
    setCommitting(true)
    let added = 0, skipped = 0
    for (let i = 0; i < selected.length; i++) {
      const row = selected[i]
      try {
        await adminApi.createEvidenceRequirement({
          dispute_type: uploadDisputeType.trim().toUpperCase(),
          evidence_type: row.evidence_type,
          description: row.description,
          is_required: row.is_required,
          sort_order: (i + 1) * 10,
          is_active: true,
        })
        added++
      } catch {
        skipped++
      }
    }
    setCommitting(false)
    if (added > 0) toast.success(`Added ${added} requirement${added !== 1 ? 's' : ''}`)
    if (skipped > 0) toast(`${skipped} skipped — already existed for this dispute type`, { icon: '⚠️' })
    cancelUpload()
    await load()
  }

  const grouped = useMemo(() => {
    const g: Record<string, EvidenceRequirement[]> = {}
    for (const item of items) (g[item.dispute_type] ??= []).push(item)
    return Object.entries(g).sort(([a], [b]) => a.localeCompare(b))
  }, [items])

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <Button variant="ghost" size="sm" onClick={() => navigate('/admin')}>
          <ArrowLeft size={16} />
        </Button>
        <div className="flex-1">
          <h1 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>Evidence Requirements</h1>
          <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
            Which evidence types each dispute type expects — read by the agent's gap analysis
            and the evidence-completeness check as a deterministic safety net under the AI's own reasoning.
          </p>
        </div>
        {!editing && !showUpload && (
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={startUpload}>
              <FileUp size={14} /> Upload
            </Button>
            <Button variant="primary" size="sm" onClick={startCreate}>
              <Plus size={14} /> Add Requirement
            </Button>
          </div>
        )}
      </div>
      <p className="text-2xs mb-6" style={{ color: 'var(--color-text-subtle)' }}>
        This platform's own synthesized checklist based on standard dispute-investigation practice — not extracted
        from a card network's official rulebook. Fully editable below.
      </p>

      {error && (
        <div className="mb-4 px-4 py-2.5 rounded-fluent text-sm border"
          style={{ background: 'rgba(197,15,31,0.08)', color: 'var(--color-critical)', borderColor: 'rgba(197,15,31,0.2)' }}>
          {error}
        </div>
      )}

      {/* Upload panel — extract candidate requirements from a reference document */}
      {showUpload && (
        <div className="mb-6 p-5 rounded-fluent-lg border"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-brand)' }}>
          <div className="flex items-center justify-between mb-1">
            <h3 className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>
              Upload a Reference Document
            </h3>
            <button onClick={cancelUpload} className="rounded p-1 hover:bg-neutral-100 dark:hover:bg-neutral-800">
              <X size={14} style={{ color: 'var(--color-text-muted)' }} />
            </button>
          </div>
          <p className="text-xs mb-4" style={{ color: 'var(--color-text-muted)' }}>
            Upload a scheme rulebook excerpt, internal SOP page, or checklist that describes what
            evidence is needed for a dispute type — gemini-2.5-flash reads it and proposes candidate
            requirement rows below for you to review before anything is saved.
          </p>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <Field label="Dispute Type" required>
              <Input value={uploadDisputeType} placeholder="e.g. SUBSCRIPTION_CANCELLATION"
                list="dispute-type-hints"
                onChange={(e) => setUploadDisputeType(e.target.value.toUpperCase().replace(/\s+/g, '_'))} />
              <datalist id="dispute-type-hints">
                {DISPUTE_TYPE_HINTS.map((d) => <option key={d} value={d} />)}
              </datalist>
            </Field>
            <Field label="Document">
              <input ref={fileInputRef} type="file" accept="application/pdf,image/png,image/jpeg,image/webp"
                className="hidden" onChange={handleFileChange} />
              <button type="button" onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-fluent border text-sm"
                style={{ borderColor: 'var(--color-border)', color: uploadFile ? 'var(--color-text)' : 'var(--color-text-muted)' }}>
                <FileUp size={13} />
                {uploadFile ? uploadFile.name : 'Choose a file…'}
              </button>
            </Field>
          </div>

          <Button variant="primary" size="sm" onClick={runExtraction}
            disabled={!uploadFile || !uploadDisputeType.trim() || extracting} loading={extracting}>
            {!extracting && <Sparkles size={13} />}
            {extracting ? 'Reading document…' : 'Extract Requirements'}
          </Button>

          {/* Extraction results — reviewable, nothing saved until "Add Selected" */}
          {extracted && (
            <div className="mt-5 pt-4 border-t" style={{ borderColor: 'var(--color-border)' }}>
              {extracted.length === 0 ? (
                <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                  No evidence requirements were found in this document.
                  {extractionNotes && <span> {extractionNotes}</span>}
                </p>
              ) : (
                <>
                  <p className="text-xs font-semibold mb-2" style={{ color: 'var(--color-text-muted)' }}>
                    Review before adding — uncheck anything that doesn't belong:
                  </p>
                  <div className="space-y-1.5 mb-4">
                    {extracted.map((row, i) => (
                      <label key={i}
                        className="flex items-start gap-2.5 px-3 py-2 rounded-fluent cursor-pointer"
                        style={{ background: 'var(--color-surface-r)', opacity: row.selected ? 1 : 0.5 }}>
                        <input type="checkbox" checked={row.selected} onChange={() => toggleExtractedRow(i)}
                          className="w-4 h-4 rounded accent-brand-500 mt-0.5" />
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <code className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>
                              {row.evidence_type}
                            </code>
                            <span className="text-2xs px-1.5 py-0.5 rounded-full"
                              style={{
                                background: row.is_required ? 'rgba(16,124,16,0.1)' : 'var(--color-surface)',
                                color: row.is_required ? 'var(--color-success)' : 'var(--color-text-muted)',
                              }}>
                              {row.is_required ? 'Required' : 'Optional'}
                            </span>
                          </div>
                          <p className="text-xs mt-0.5" style={{ color: 'var(--color-text-muted)' }}>{row.description}</p>
                        </div>
                      </label>
                    ))}
                  </div>
                  {extractionNotes && (
                    <p className="text-2xs mb-3" style={{ color: 'var(--color-text-subtle)' }}>Note: {extractionNotes}</p>
                  )}
                  <div className="flex gap-2">
                    <Button variant="primary" size="sm" onClick={commitExtracted}
                      disabled={!extracted.some((r) => r.selected)} loading={committing}>
                      Add Selected
                    </Button>
                    <Button variant="secondary" size="sm" onClick={cancelUpload}>
                      Cancel
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* Inline form */}
      {editing && (
        <div className="mb-6 p-5 rounded-fluent-lg border"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-brand)' }}>
          <h3 className="text-sm font-semibold mb-4" style={{ color: 'var(--color-text)' }}>
            {editing === 'new' ? 'New Requirement' : 'Edit Requirement'}
          </h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <Field label="Dispute Type" required>
              <Input value={form.dispute_type} placeholder="e.g. SUBSCRIPTION_CANCELLATION"
                list="dispute-type-hints"
                onChange={(e) => f('dispute_type', e.target.value.toUpperCase().replace(/\s+/g, '_'))} />
              <datalist id="dispute-type-hints">
                {DISPUTE_TYPE_HINTS.map((d) => <option key={d} value={d} />)}
              </datalist>
            </Field>
            <Field label="Evidence Type" required>
              <Input value={form.evidence_type} placeholder="e.g. CANCELLATION_CONFIRMATION"
                onChange={(e) => f('evidence_type', e.target.value.toUpperCase().replace(/\s+/g, '_'))} />
            </Field>
          </div>
          <Field label="Description" required>
            <Textarea rows={2} placeholder="What this evidence should show, and why it matters"
              value={form.description} onChange={(e) => f('description', e.target.value)} />
          </Field>
          <div className="grid grid-cols-3 gap-4 mt-4">
            <Field label="Sort Order">
              <Input type="number" value={form.sort_order}
                onChange={(e) => f('sort_order', Number(e.target.value))} />
            </Field>
            <div className="flex items-end pb-1">
              <label className="flex items-center gap-2 cursor-pointer text-sm" style={{ color: 'var(--color-text-muted)' }}>
                <input type="checkbox" checked={form.is_required} onChange={(e) => f('is_required', e.target.checked)}
                  className="w-4 h-4 rounded accent-brand-500" />
                Required (counts toward completeness %)
              </label>
            </div>
            <div className="flex items-end pb-1">
              <label className="flex items-center gap-2 cursor-pointer text-sm" style={{ color: 'var(--color-text-muted)' }}>
                <input type="checkbox" checked={form.is_active} onChange={(e) => f('is_active', e.target.checked)}
                  className="w-4 h-4 rounded accent-brand-500" />
                Active
              </label>
            </div>
          </div>
          <div className="flex gap-2 mt-5">
            <Button variant="primary" size="sm" onClick={save}
              disabled={!form.dispute_type || !form.evidence_type || !form.description} loading={saving}>
              Save
            </Button>
            <Button variant="secondary" size="sm" onClick={cancel}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {/* Grouped table */}
      {loading ? (
        <div className="py-12 text-center text-sm" style={{ color: 'var(--color-text-muted)' }}>Loading…</div>
      ) : grouped.length === 0 ? (
        <div className="py-12 text-center text-sm" style={{ color: 'var(--color-text-muted)' }}>
          No evidence requirements configured yet.
        </div>
      ) : (
        <div className="space-y-5">
          {grouped.map(([disputeType, rows]) => (
            <div key={disputeType} className="rounded-fluent-lg border overflow-hidden"
              style={{ borderColor: 'var(--color-border)' }}>
              <div className="px-4 py-2.5 text-xs font-semibold"
                style={{ background: 'var(--color-surface-r)', color: 'var(--color-text)' }}>
                {disputeType.replace(/_/g, ' ')}
              </div>
              <div className="divide-y" style={{ borderColor: 'var(--color-border)' }}>
                {rows.sort((a, b) => a.sort_order - b.sort_order).map((r) => (
                  <div key={r.requirement_id}
                    className="flex items-start gap-3 px-4 py-3"
                    style={{ background: 'var(--color-surface)', opacity: r.is_active ? 1 : 0.5 }}>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <code className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>
                          {r.evidence_type}
                        </code>
                        {r.is_required ? (
                          <span className="flex items-center gap-1 text-2xs font-medium px-1.5 py-0.5 rounded-full"
                            style={{ background: 'rgba(16,124,16,0.1)', color: 'var(--color-success)' }}>
                            <CheckCircle2 size={9} /> Required
                          </span>
                        ) : (
                          <span className="text-2xs px-1.5 py-0.5 rounded-full"
                            style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-muted)' }}>
                            Optional
                          </span>
                        )}
                        {!r.is_active && (
                          <span className="text-2xs" style={{ color: 'var(--color-text-subtle)' }}>Inactive</span>
                        )}
                      </div>
                      <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{r.description}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Button variant="secondary" size="sm" onClick={() => startEdit(r)}>
                        <Pencil size={11} />
                      </Button>
                      {confirmDelete === r.requirement_id ? (
                        <>
                          <Button variant="destructive" size="sm" onClick={() => handleDelete(r.requirement_id)}>
                            Confirm
                          </Button>
                          <Button variant="secondary" size="sm" onClick={cancel}>
                            Cancel
                          </Button>
                        </>
                      ) : (
                        <Button variant="destructive" size="sm" onClick={() => setConfirmDelete(r.requirement_id)}>
                          <Trash2 size={11} />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
