import { type ReactNode } from 'react'
import { useQuery } from '@tanstack/react-query'
import { adminApi } from '@/services/api'
import { Cpu, Database, Shield, Zap, CheckCircle, XCircle, Server, Activity, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui'

interface SystemInfo {
  ai: { model: string; base_url: string; max_steps: number; max_runtime_seconds: number }
  features: {
    demo_mode: boolean
    vector_store: {
      deps_available: boolean
      faiss_installed: boolean
      faiss_enabled_flag: boolean
      embed_model: string
      collections: Record<'evidence' | 'regulatory' | 'precedent', { vectors: number }>
    }
    sms_notifications: { enabled: boolean; configured: boolean }
  }
  auth: { algorithm: string; expiry_hours: number }
  database: { url: string }
}

function InfoCard({ title, icon, children }: { title: string; icon: ReactNode; children: ReactNode }) {
  return (
    <div className="rounded-fluent-lg border p-5"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <div className="flex items-center gap-2 mb-4">
        <span style={{ color: 'var(--color-brand)' }}>{icon}</span>
        <h3 className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>{title}</h3>
      </div>
      <dl className="space-y-2.5">{children}</dl>
    </div>
  )
}

function Row({ label, value, mono = false }: { label: string; value: ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <dt className="text-xs shrink-0" style={{ color: 'var(--color-text-muted)' }}>{label}</dt>
      <dd className={`text-xs font-medium text-right truncate max-w-xs ${mono ? 'font-mono' : ''}`}
        style={{ color: 'var(--color-text)' }}>{value}</dd>
    </div>
  )
}

function FeatureFlag({ label, enabled, description }: { label: string; enabled: boolean; description: string }) {
  return (
    <div className="flex items-center justify-between px-3 py-2.5 rounded-fluent"
      style={{ background: 'var(--color-surface-r)' }}>
      <div>
        <div className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>{label}</div>
        <div className="text-xs mt-0.5" style={{ color: 'var(--color-text-muted)' }}>{description}</div>
      </div>
      <div className={`flex items-center gap-1.5 text-xs font-semibold shrink-0 ml-4`}
        style={{ color: enabled ? 'var(--color-success)' : 'var(--color-text-subtle)' }}>
        {enabled ? <CheckCircle size={14} /> : <XCircle size={14} />}
        {enabled ? 'ON' : 'OFF'}
      </div>
    </div>
  )
}

export function IntegrationsPage() {
  const { data: sys, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['admin-system'],
    queryFn: () => adminApi.getSystem(),
    select: (r) => r.data as SystemInfo,
  })

  const { data: health } = useQuery({
    queryKey: ['health'],
    queryFn: () => fetch('/api/v1/health').then(r => r.json()),
    refetchInterval: 30_000,
  })

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2">
          <Server size={18} style={{ color: 'var(--color-brand)' }} />
          <h2 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
            System & Integrations
          </h2>
        </div>
        <Button variant="secondary" size="sm" onClick={() => refetch()}>
          <RefreshCw size={12} className={isFetching ? 'animate-spin' : ''} />
          Refresh
        </Button>
      </div>
      <p className="text-xs mb-6" style={{ color: 'var(--color-text-muted)' }}>
        Runtime configuration, AI model settings, and feature flags.
      </p>

      {/* Health banner */}
      {health && (
        <div className="flex items-center gap-3 px-4 py-3 rounded-fluent-lg border mb-6"
          style={{
            background: health.status === 'ok' ? 'rgba(16,124,16,0.06)' : 'rgba(197,15,31,0.06)',
            borderColor: health.status === 'ok' ? 'rgba(16,124,16,0.3)' : 'rgba(197,15,31,0.3)',
          }}>
          <Activity size={16} style={{ color: health.status === 'ok' ? 'var(--color-success)' : 'var(--color-critical)' }} />
          <div>
            <span className="text-sm font-semibold" style={{ color: health.status === 'ok' ? 'var(--color-success)' : 'var(--color-critical)' }}>
              API {health.status === 'ok' ? 'Healthy' : 'Degraded'}
            </span>
            <span className="ml-3 text-xs" style={{ color: 'var(--color-text-muted)' }}>
              v{health.version} · uptime {Math.floor(health.uptime_seconds / 3600)}h {Math.floor((health.uptime_seconds % 3600) / 60)}m
            </span>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="grid grid-cols-2 gap-4">
          {[1,2,3,4].map(n => (
            <div key={n} className="h-48 rounded-fluent-lg animate-pulse" style={{ background: 'var(--color-surface)' }} />
          ))}
        </div>
      ) : sys ? (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* AI Model */}
            <InfoCard title="AI Model" icon={<Cpu size={16} />}>
              <Row label="Model" value={sys.ai.model} mono />
              <Row label="Base URL" value={sys.ai.base_url.replace('https://', '')} mono />
              <Row label="Max Steps" value={sys.ai.max_steps} />
              <Row label="Max Runtime" value={`${sys.ai.max_runtime_seconds}s`} />
            </InfoCard>

            {/* Database */}
            <InfoCard title="Database" icon={<Database size={16} />}>
              <Row label="Engine" value="SQLite (aiosqlite)" />
              <Row label="Path" value={sys.database.url} mono />
              <Row label="ORM" value="SQLAlchemy 2.0 async" />
              <Row label="Mode" value="Async I/O" />
            </InfoCard>

            {/* Auth */}
            <InfoCard title="Authentication" icon={<Shield size={16} />}>
              <Row label="Protocol" value="JWT Bearer (OAuth2)" />
              <Row label="Algorithm" value={sys.auth.algorithm} mono />
              <Row label="Token Expiry" value={`${sys.auth.expiry_hours} hours`} />
              <Row label="RBAC" value="Role-based, 21 permissions" />
            </InfoCard>

            {/* Stack */}
            <InfoCard title="Platform Stack" icon={<Zap size={16} />}>
              <Row label="API" value="FastAPI 0.115 + Uvicorn" />
              <Row label="Agent" value="LangGraph 0.2 (8 nodes)" />
              <Row label="Frontend" value="React 18 + Vite + Tailwind" />
              <Row label="State" value="Zustand + TanStack Query v5" />
            </InfoCard>
          </div>

          {/* Feature Flags */}
          <div className="rounded-fluent-lg border p-5"
            style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
            <div className="flex items-center gap-2 mb-4">
              <Zap size={16} style={{ color: 'var(--color-brand)' }} />
              <h3 className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>Feature Flags</h3>
              <span className="text-xs ml-2" style={{ color: 'var(--color-text-subtle)' }}>Read-only — configure via .env</span>
            </div>
            <div className="space-y-2">
              <FeatureFlag label="Demo Mode" enabled={sys.features.demo_mode}
                description="Enables mock data and relaxes some validation rules for demonstrations." />
              <FeatureFlag label="Vector Store" enabled={sys.features.vector_store.deps_available}
                description={
                  `${sys.features.vector_store.embed_model} · evidence ${sys.features.vector_store.collections.evidence.vectors} · ` +
                  `regulatory ${sys.features.vector_store.collections.regulatory.vectors} · precedent ${sys.features.vector_store.collections.precedent.vectors} vectors`
                } />
            </div>
          </div>

          {/* External Integrations (static) */}
          <div className="rounded-fluent-lg border p-5"
            style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
            <div className="flex items-center gap-2 mb-4">
              <Server size={16} style={{ color: 'var(--color-brand)' }} />
              <h3 className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>External Systems</h3>
            </div>
            <div className="space-y-2">
              {[
                { name: 'LiteLLM Proxy', status: 'configured', detail: sys.ai.base_url.replace('https://', ''), color: 'var(--color-success)' },
                { name: 'Azure OpenAI', status: 'via proxy', detail: sys.ai.model, color: 'var(--color-success)' },
                { name: 'Merchant API', status: 'mock', detail: 'Demo mode — returns synthetic data', color: 'var(--color-medium)' },
                { name: 'Network Gateway', status: 'mock', detail: 'Demo mode — reason codes from fixture', color: 'var(--color-medium)' },
                (() => {
                  const sms = sys.features.sms_notifications
                  if (sms.enabled && sms.configured) {
                    return { name: 'Twilio SMS', status: 'active', detail: 'Chargeback issued + case resolved notify the cardholder', color: 'var(--color-success)' }
                  }
                  if (!sms.configured) {
                    return { name: 'Twilio SMS', status: 'not configured', detail: 'Set TWILIO_ACCOUNT_SID/AUTH_TOKEN/FROM_NUMBER in .env', color: 'var(--color-text-subtle)' }
                  }
                  return { name: 'Twilio SMS', status: 'off', detail: 'Configured but ENABLE_SMS_NOTIFICATIONS is false', color: 'var(--color-medium)' }
                })(),
              ].map(item => (
                <div key={item.name} className="flex items-center justify-between px-3 py-2.5 rounded-fluent"
                  style={{ background: 'var(--color-surface-r)' }}>
                  <div>
                    <div className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>{item.name}</div>
                    <div className="text-xs mt-0.5 font-mono" style={{ color: 'var(--color-text-subtle)' }}>{item.detail}</div>
                  </div>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
                    style={{ background: `${item.color}14`, color: item.color }}>
                    {item.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  )
}
