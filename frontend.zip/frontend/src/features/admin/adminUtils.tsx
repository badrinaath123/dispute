import type { StatusColor } from '@/types'

const COLOR_MAP: Record<StatusColor, { bg: string; text: string; border: string; label: string }> = {
  neutral: { bg: '#f5f5f5',                   text: '#616161', border: '#e8e8e8', label: 'Neutral' },
  info:    { bg: 'rgba(0,120,212,0.1)',         text: '#0078d4', border: 'rgba(0,120,212,0.25)', label: 'Info (Blue)' },
  warning: { bg: 'rgba(202,80,16,0.1)',         text: '#ca5010', border: 'rgba(202,80,16,0.25)', label: 'Warning (Orange)' },
  success: { bg: 'rgba(16,124,16,0.1)',         text: '#107c10', border: 'rgba(16,124,16,0.25)', label: 'Success (Green)' },
  error:   { bg: 'rgba(197,15,31,0.1)',         text: '#c50f1f', border: 'rgba(197,15,31,0.25)', label: 'Error (Red)' },
  brand:   { bg: 'rgba(0,120,212,0.12)',        text: '#005a9e', border: 'rgba(0,120,212,0.3)',  label: 'Brand' },
}

export function ColorBadge({ color, label }: { color: StatusColor; label: string }) {
  const c = COLOR_MAP[color] ?? COLOR_MAP.neutral
  return (
    <span
      className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border"
      style={{ background: c.bg, color: c.text, borderColor: c.border }}
    >
      {label}
    </span>
  )
}

export function ColorDot({ color }: { color: StatusColor }) {
  const c = COLOR_MAP[color] ?? COLOR_MAP.neutral
  return (
    <span
      className="inline-block w-2.5 h-2.5 rounded-full border"
      style={{ background: c.bg, borderColor: c.border, boxShadow: `0 0 0 1px ${c.text}` }}
    />
  )
}

export const COLOR_OPTIONS: { value: StatusColor; label: string }[] = Object.entries(COLOR_MAP).map(
  ([value, { label }]) => ({ value: value as StatusColor, label })
)

export const DARK_MAP: Record<StatusColor, { bg: string; text: string; border: string }> = {
  neutral: { bg: '#252525', text: '#ababab', border: '#303030' },
  info:    { bg: 'rgba(71,158,245,0.15)',  text: '#479ef5', border: 'rgba(71,158,245,0.3)' },
  warning: { bg: 'rgba(244,191,171,0.15)', text: '#f4bfab', border: 'rgba(244,191,171,0.3)' },
  success: { bg: 'rgba(84,176,84,0.15)',   text: '#54b054', border: 'rgba(84,176,84,0.3)' },
  error:   { bg: 'rgba(241,112,123,0.15)', text: '#f1707b', border: 'rgba(241,112,123,0.3)' },
  brand:   { bg: 'rgba(71,158,245,0.15)',  text: '#479ef5', border: 'rgba(71,158,245,0.3)' },
}
