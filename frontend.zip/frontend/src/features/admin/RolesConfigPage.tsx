import { useEffect, useState } from 'react'
import { Plus, ChevronDown, ChevronRight, CheckCircle, XCircle, ArrowLeft, Pencil } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { adminApi } from '@/services/api'
import type { RoleConfig, PermissionCategory } from '@/types'
import { Field, Input, Textarea, Button } from '@/components/ui'

const ALL_SCREENS = [
  'dispute-command-center', 'evidence-explorer', 'timeline', 'hypotheses',
  'next-best-action', 'approval-workspace',
  'audit', 'audit-replay', 'admin-statuses', 'admin-outcomes', 'admin-roles',
]

const EMPTY = {
  code: '', display_name: '', description: '', is_active: true,
  permissions: [] as string[], allowed_screens: [] as string[],
}

export function RolesConfigPage() {
  const navigate = useNavigate()
  const [roles, setRoles] = useState<RoleConfig[]>([])
  const [permsCategories, setPermsCategories] = useState<PermissionCategory[]>([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [editing, setEditing] = useState<string | null>(null)
  const [form, setForm] = useState({ ...EMPTY })
  const [saving, setSaving] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  async function load() {
    setLoading(true)
    try {
      const [rolesR, permsR] = await Promise.all([adminApi.listRoles(), adminApi.permissions()])
      setRoles(rolesR.data)
      setPermsCategories(permsR.data?.categories ?? permsR.data)
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  function startCreate() {
    setEditing('new'); setForm({ ...EMPTY }); setExpanded(null); setError(null)
  }

  function startEdit(role: RoleConfig) {
    setEditing(role.role_id)
    setForm({
      code: role.code, display_name: role.display_name, description: role.description,
      is_active: role.is_active,
      permissions: [...role.permissions],
      allowed_screens: [...role.allowed_screens],
    })
    setExpanded(null); setError(null)
  }

  function cancel() { setEditing(null); setConfirmDelete(null); setError(null) }

  const f = (field: string, value: any) => setForm((p) => ({ ...p, [field]: value }))

  function togglePerm(perm: string) {
    setForm((p) => ({
      ...p,
      permissions: p.permissions.includes(perm)
        ? p.permissions.filter((x) => x !== perm)
        : [...p.permissions, perm],
    }))
  }

  function toggleScreen(screen: string) {
    setForm((p) => ({
      ...p,
      allowed_screens: p.allowed_screens.includes(screen)
        ? p.allowed_screens.filter((x) => x !== screen)
        : [...p.allowed_screens, screen],
    }))
  }

  async function save() {
    setSaving(true); setError(null)
    try {
      editing === 'new'
        ? await adminApi.createRole(form)
        : await adminApi.updateRole(editing!, form)
      setEditing(null); await load()
    } catch (e: any) {
      setError(e?.response?.data?.detail ?? 'Save failed')
    } finally { setSaving(false) }
  }

  async function handleDeactivate(id: string) {
    try { await adminApi.deleteRole(id); setConfirmDelete(null); await load() }
    catch (e: any) { setError(e?.response?.data?.detail ?? 'Failed') }
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="sm" onClick={() => navigate('/admin')}>
          <ArrowLeft size={16} />
        </Button>
        <div className="flex-1">
          <h1 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>Roles & Permissions</h1>
          <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
            Configure user roles with granular permission sets and screen access.
          </p>
        </div>
        {!editing && (
          <Button variant="primary" size="sm" onClick={startCreate}>
            <Plus size={14} /> Add Role
          </Button>
        )}
      </div>

      {error && (
        <div className="mb-4 px-4 py-2.5 rounded-fluent text-sm border"
          style={{ background: 'rgba(197,15,31,0.08)', color: 'var(--color-critical)', borderColor: 'rgba(197,15,31,0.2)' }}>
          {error}
        </div>
      )}

      {/* Inline form */}
      {editing && (
        <div className="mb-6 p-5 rounded-fluent-lg border"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-brand)' }}>
          <h3 className="text-sm font-semibold mb-4" style={{ color: 'var(--color-text)' }}>
            {editing === 'new' ? 'New Role' : 'Edit Role'}
          </h3>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <Field label="Code" required>
              <Input value={form.code} placeholder="e.g. ANALYST"
                onChange={(e) => f('code', e.target.value.toUpperCase().replace(/\s+/g, '_'))} />
            </Field>
            <Field label="Display Name" required>
              <Input value={form.display_name} placeholder="e.g. Dispute Analyst"
                onChange={(e) => f('display_name', e.target.value)} />
            </Field>
          </div>
          <div className="mb-4">
            <Field label="Description">
              <Textarea rows={2} value={form.description}
                onChange={(e) => f('description', e.target.value)} />
            </Field>
          </div>
          <div className="mb-4">
            <label className="flex items-center gap-2 cursor-pointer text-sm" style={{ color: 'var(--color-text-muted)' }}>
              <input type="checkbox" checked={form.is_active} onChange={(e) => f('is_active', e.target.checked)}
                className="w-4 h-4 rounded accent-brand-500" />
              Active
            </label>
          </div>

          {/* Permission matrix */}
          {permsCategories.length > 0 && (
            <div className="mb-5">
              <div className="text-xs font-semibold uppercase tracking-wide mb-3"
                style={{ color: 'var(--color-text-muted)' }}>Permissions</div>
              <div className="space-y-4">
                {permsCategories.map((cat) => (
                  <div key={cat.category}>
                    <div className="text-xs font-medium mb-2 px-1" style={{ color: 'var(--color-text)' }}>
                      {cat.category}
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {cat.permissions.map((perm) => {
                        const checked = form.permissions.includes(perm)
                        return (
                          <label key={perm}
                            className="flex items-center gap-2 px-2.5 py-1.5 rounded-fluent border cursor-pointer text-xs transition-colors"
                            style={{
                              borderColor: checked ? 'var(--color-brand)' : 'var(--color-border)',
                              background: checked ? 'rgba(0,120,212,0.06)' : 'var(--color-surface-r)',
                              color: checked ? 'var(--color-brand)' : 'var(--color-text-muted)',
                            }}>
                            <input type="checkbox" checked={checked} onChange={() => togglePerm(perm)}
                              className="w-3.5 h-3.5 rounded accent-brand-500 shrink-0" />
                            <code style={{ fontFamily: 'monospace', fontSize: '11px' }}>{perm}</code>
                          </label>
                        )
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Screen access */}
          <div className="mb-5">
            <div className="text-xs font-semibold uppercase tracking-wide mb-3"
              style={{ color: 'var(--color-text-muted)' }}>Screen Access</div>
            <div className="flex flex-wrap gap-2">
              {ALL_SCREENS.map((screen) => {
                const active = form.allowed_screens.includes(screen)
                return (
                  <button key={screen} type="button" onClick={() => toggleScreen(screen)}
                    className="px-2.5 py-1 rounded-full text-xs border transition-all"
                    style={{
                      borderColor: active ? 'var(--color-brand)' : 'var(--color-border)',
                      background: active ? 'rgba(0,120,212,0.1)' : 'var(--color-surface-r)',
                      color: active ? 'var(--color-brand)' : 'var(--color-text-muted)',
                      fontWeight: active ? 600 : 400,
                    }}>
                    {screen}
                  </button>
                )
              })}
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="primary" size="sm" onClick={save} disabled={!form.code || !form.display_name} loading={saving}>
              Save
            </Button>
            <Button variant="secondary" size="sm" onClick={cancel}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {/* Roles table */}
      <div className="rounded-fluent-lg border overflow-hidden"
        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ borderBottom: '1px solid var(--color-border)', background: 'var(--color-surface-r)' }}>
              {['', 'Code', 'Display Name', 'Permissions', 'Screens', 'Status', ''].map((h) => (
                <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide"
                  style={{ color: 'var(--color-text-muted)' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="px-4 py-8 text-center text-sm"
                style={{ color: 'var(--color-text-muted)' }}>Loading…</td></tr>
            ) : roles.length === 0 ? (
              <tr><td colSpan={7} className="px-4 py-8 text-center text-sm"
                style={{ color: 'var(--color-text-muted)' }}>No roles yet.</td></tr>
            ) : roles.map((role) => (
              <>
                <tr key={role.role_id}
                  className="border-t transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-900 cursor-pointer"
                  style={{ borderColor: 'var(--color-border)', opacity: role.is_active ? 1 : 0.55 }}
                  onClick={() => setExpanded((e) => e === role.role_id ? null : role.role_id)}>
                  <td className="px-4 py-3 w-8">
                    {expanded === role.role_id
                      ? <ChevronDown size={14} style={{ color: 'var(--color-text-muted)' }} />
                      : <ChevronRight size={14} style={{ color: 'var(--color-text-muted)' }} />}
                  </td>
                  <td className="px-4 py-3">
                    <code className="text-xs px-1.5 py-0.5 rounded-fluent"
                      style={{ background: 'var(--color-surface-r)', color: 'var(--color-brand)', fontFamily: 'monospace' }}>
                      {role.code}
                    </code>
                  </td>
                  <td className="px-4 py-3 font-medium" style={{ color: 'var(--color-text)' }}>
                    {role.display_name}
                    {role.description && (
                      <div className="text-xs font-normal mt-0.5 max-w-xs truncate"
                        style={{ color: 'var(--color-text-muted)' }}>{role.description}</div>
                    )}
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: 'var(--color-text-muted)' }}>
                    {role.permissions.length} permission{role.permissions.length !== 1 ? 's' : ''}
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: 'var(--color-text-muted)' }}>
                    {role.allowed_screens.length} screen{role.allowed_screens.length !== 1 ? 's' : ''}
                  </td>
                  <td className="px-4 py-3">
                    {role.is_active
                      ? <span className="flex items-center gap-1 text-xs" style={{ color: 'var(--color-success)' }}><CheckCircle size={12} /> Active</span>
                      : <span className="flex items-center gap-1 text-xs" style={{ color: 'var(--color-text-muted)' }}><XCircle size={12} /> Inactive</span>}
                  </td>
                  <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                    {confirmDelete === role.role_id ? (
                      <span className="flex justify-end gap-2">
                        <Button variant="destructive" size="sm" onClick={() => handleDeactivate(role.role_id)}>
                          Confirm
                        </Button>
                        <Button variant="secondary" size="sm" onClick={cancel}>
                          Cancel
                        </Button>
                      </span>
                    ) : (
                      <span className="flex justify-end gap-2">
                        <Button variant="secondary" size="sm" onClick={() => startEdit(role)}>
                          <Pencil size={12} />
                        </Button>
                        {role.is_active && (
                          <Button variant="destructive" size="sm" onClick={() => setConfirmDelete(role.role_id)}>
                            Deactivate
                          </Button>
                        )}
                      </span>
                    )}
                  </td>
                </tr>

                {/* Expanded detail */}
                {expanded === role.role_id && (
                  <tr key={`${role.role_id}-detail`}
                    style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-r)' }}
                    className="border-t">
                    <td colSpan={7} className="px-6 py-4">
                      <div className="grid grid-cols-2 gap-6">
                        {/* Permissions */}
                        <div>
                          <div className="text-xs font-semibold uppercase tracking-wide mb-3"
                            style={{ color: 'var(--color-text-muted)' }}>Permissions</div>
                          {role.permissions.length === 0 ? (
                            <p className="text-xs italic" style={{ color: 'var(--color-text-muted)' }}>No permissions assigned.</p>
                          ) : (
                            <div className="flex flex-wrap gap-1.5">
                              {role.permissions.map((p) => (
                                <code key={p}
                                  className="text-xs px-2 py-0.5 rounded-fluent border"
                                  style={{ background: 'rgba(0,120,212,0.08)', color: 'var(--color-brand)', borderColor: 'rgba(0,120,212,0.2)', fontFamily: 'monospace' }}>
                                  {p}
                                </code>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Screen access */}
                        <div>
                          <div className="text-xs font-semibold uppercase tracking-wide mb-3"
                            style={{ color: 'var(--color-text-muted)' }}>Screen Access</div>
                          {role.allowed_screens.length === 0 ? (
                            <p className="text-xs italic" style={{ color: 'var(--color-text-muted)' }}>No screens assigned.</p>
                          ) : (
                            <div className="flex flex-wrap gap-1.5">
                              {role.allowed_screens.map((s) => (
                                <span key={s}
                                  className="text-xs px-2 py-0.5 rounded-full border"
                                  style={{ background: 'rgba(16,124,16,0.08)', color: 'var(--color-success)', borderColor: 'rgba(16,124,16,0.2)' }}>
                                  {s}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
