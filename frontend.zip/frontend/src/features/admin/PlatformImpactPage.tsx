import { useQuery } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { TrendingUp, ShieldCheck, RefreshCw, Clock, SearchCheck, Layers, Info, Timer, DollarSign } from 'lucide-react'
import { platformApi } from '@/services/api'
import type { PlatformImpact } from '@/types'
import { Button, PageHeader } from '@/components/ui'

export function PlatformImpactPage() {
  const navigate = useNavigate()
  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['platform-impact'],
    queryFn: () => platformApi.impact(),
    select: (r) => r.data as PlatformImpact,
  })

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <PageHeader
        icon={<TrendingUp size={18} />}
        title="Platform Impact"
        description="What the architecture actually prevented, computed, or accelerated — not a pitch claim"
        actions={
          <Button variant="secondary" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw size={12} className={isFetching ? 'animate-spin' : ''} />
            Refresh
          </Button>
        }
      />

      {/* Methodology label */}
      <div className="flex items-center gap-2 text-xs px-3 py-2 rounded-fluent mb-6"
        style={{ background: 'var(--color-surface-r)', border: '1px solid var(--color-border)', color: 'var(--color-text-muted)' }}>
        <Info size={13} className="shrink-0" />
        Computed from this demo's data — see <code className="mx-1 font-mono">GET /api/v1/platform/impact</code> for methodology.
        {data && <span className="ml-auto shrink-0">as of {new Date(data.generated_at).toLocaleTimeString()}</span>}
      </div>

      {isLoading && (
        <div className="text-sm" style={{ color: 'var(--color-text-muted)' }}>Loading…</div>
      )}

      {data && (
        <div data-tour="impact-cards" className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <MetricCard
            icon={ShieldCheck}
            color="#c50f1f"
            title="Stale approvals prevented"
            value={data.stale_approvals_prevented.count}
            explanation={
              data.stale_approvals_prevented.count > 0
                ? `${data.stale_approvals_prevented.count} action${data.stale_approvals_prevented.count === 1 ? '' : 's'} blocked — Z2 stale-approval invalidation prevented execution against evidence the approver never saw.`
                : 'Z2 stale-approval invalidation is active and enforced; this dataset just hasn’t triggered it yet.'
            }
            note={data.stale_approvals_prevented.note}
            detail={data.stale_approvals_prevented.entries.map((e) => (
              <button key={e.approval_id} onClick={() => navigate(`/disputes/${e.dispute_id}`)}
                className="block text-left text-2xs hover:underline" style={{ color: 'var(--color-brand)' }}>
                {e.dispute_id} — reviewed at state v{e.state_version_reviewed}, {e.stale_reason}
              </button>
            ))}
          />

          <MetricCard
            icon={RefreshCw}
            color="#ca5010"
            title="Recommendations that flipped"
            value={data.recommendations_that_flipped.count}
            explanation="Cases where new evidence changed the answer after it was first given — the living-recommendation model (README §2.3 / §9) in action, not a static one-shot verdict."
            note={data.recommendations_that_flipped.note}
            detail={<>
              {data.recommendations_that_flipped.entries.slice(0, 5).map((e) => (
                <button key={e.recommendation_id} onClick={() => navigate(`/disputes/${e.dispute_id}`)}
                  className="block w-full text-left text-2xs truncate hover:underline" style={{ color: 'var(--color-brand)' }}
                  title={e.change_reason ?? undefined}>
                  {e.dispute_id.slice(-8).toUpperCase()} → v{e.version} ({e.recommendation_type})
                  {e.change_reason ? `: ${e.change_reason}` : ''}
                </button>
              ))}
              {data.recommendations_that_flipped.entries.length > 5 && (
                <div className="text-2xs pt-1" style={{ color: 'var(--color-text-subtle)' }}>
                  +{data.recommendations_that_flipped.entries.length - 5} more
                </div>
              )}
            </>}
          />

          <MetricCard
            icon={Clock}
            color="var(--color-brand)"
            title="Mean time to first recommendation"
            value={data.mean_time_to_recommendation.mean_human ?? '—'}
            explanation="How long between a case being opened and the platform producing its first evidence-grounded recommendation — the 'answer-first' principle (README §1), measured."
            note={data.mean_time_to_recommendation.note}
          />

          <MetricCard
            icon={SearchCheck}
            color="#107c10"
            title="Evidence gaps auto-identified"
            value={data.evidence_gaps_auto_identified.gaps_identified_total}
            explanation={`${data.evidence_gaps_auto_identified.gaps_open} still open, out of ${data.evidence_gaps_auto_identified.evidence_items_total} evidence items ingested — every one of these was found by the agent, not requested by a human first.`}
            note={data.evidence_gaps_auto_identified.note}
          />

          <MetricCard
            icon={Layers}
            color="#5c2d91"
            title="Multi-transaction claims processed"
            value={data.multi_transaction_claims_processed.claims_with_multiple_sub_cases}
            explanation={`${data.multi_transaction_claims_processed.total_sub_cases_across_them} independently-investigated sub-cases across those claims — one cardholder story, correctly split into per-merchant investigations (README §5.11).`}
            note={data.multi_transaction_claims_processed.note}
            detail={data.multi_transaction_claims_processed.entries.map((e) => (
              <div key={e.claim_id} className="text-2xs" style={{ color: 'var(--color-text-muted)' }}>
                Claim {e.claim_id.slice(0, 8)}… — {e.sub_case_count} sub-cases:{' '}
                {e.dispute_ids.map((id, i) => (
                  <span key={id}>
                    {i > 0 && ', '}
                    <button onClick={() => navigate(`/disputes/${id}`)} className="hover:underline" style={{ color: 'var(--color-brand)' }}>
                      {id.slice(0, 8)}…
                    </button>
                  </span>
                ))}
              </div>
            ))}
          />

          <MetricCard
            icon={Timer}
            color="#107c10"
            title="Case intake time — AI-assisted vs. manual"
            value={
              data.case_intake_time.ai_assisted.mean_human && data.case_intake_time.manual.mean_human
                ? `${data.case_intake_time.ai_assisted.mean_human} vs ${data.case_intake_time.manual.mean_human}`
                : data.case_intake_time.ai_assisted.mean_human ?? data.case_intake_time.manual.mean_human ?? '—'
            }
            explanation={
              `AI-assisted: ${data.case_intake_time.ai_assisted.sample_size} case${data.case_intake_time.ai_assisted.sample_size === 1 ? '' : 's'} measured` +
              (data.case_intake_time.ai_assisted.mean_human ? `, averaging ${data.case_intake_time.ai_assisted.mean_human}` : '') +
              `. Manual entry: ${data.case_intake_time.manual.sample_size} case${data.case_intake_time.manual.sample_size === 1 ? '' : 's'}` +
              (data.case_intake_time.manual.mean_human ? `, averaging ${data.case_intake_time.manual.mean_human}` : '') +
              '. A live stopwatch in New Case measures every case from modal-open to submit — real elapsed time, not an estimate.'
            }
            note={data.case_intake_time.note}
            detail={data.case_intake_time.sample_data_excluded_count > 0 ? (
              <div className="text-2xs" style={{ color: 'var(--color-text-muted)' }}>
                {data.case_intake_time.sample_data_excluded_count} case{data.case_intake_time.sample_data_excluded_count === 1 ? '' : 's'} created via
                "Use Sample Data" excluded from this comparison — no real extraction happened, so it's neither AI-assisted nor manual.
              </div>
            ) : undefined}
          />

          <MetricCard
            icon={DollarSign}
            color="#107c10"
            title="AI spend — real token usage"
            value={`$${data.ai_spend.total_cost_usd.toFixed(4)}`}
            explanation={
              `${data.ai_spend.total_calls} LLM/embedding call${data.ai_spend.total_calls === 1 ? '' : 's'} metered so far — ` +
              `${data.ai_spend.total_input_tokens.toLocaleString()} input + ${data.ai_spend.total_output_tokens.toLocaleString()} output tokens, ` +
              `from the provider's own reported usage on every real call this session, not an estimated call count.`
            }
            note={data.ai_spend.note}
            detail={data.ai_spend.by_model.length > 0 ? (
              <div className="space-y-1">
                {data.ai_spend.by_model.map((m) => (
                  <div key={m.model} className="flex items-center justify-between text-2xs" style={{ color: 'var(--color-text-muted)' }}>
                    <span className="font-mono truncate mr-2">{m.model}</span>
                    <span className="shrink-0">
                      {m.call_count} call{m.call_count === 1 ? '' : 's'} · {m.priced ? `$${m.cost_usd.toFixed(4)}` : 'unpriced'}
                    </span>
                  </div>
                ))}
              </div>
            ) : undefined}
          />
        </div>
      )}
    </div>
  )
}

function MetricCard({
  icon: Icon, color, title, value, explanation, note, detail,
}: {
  icon: React.ElementType
  color: string
  title: string
  value: number | string
  explanation: string
  note?: string | null
  detail?: React.ReactNode
}) {
  return (
    <div className="rounded-fluent-lg p-5 border"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
      <div className="flex items-center gap-2 mb-3">
        <div className="w-8 h-8 rounded-fluent flex items-center justify-center shrink-0"
          style={{ background: `${color}14`, color }}>
          <Icon size={16} />
        </div>
        <div className="text-xs font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
          {title}
        </div>
      </div>
      <div className="text-3xl font-bold mb-2" style={{ color: 'var(--color-text)' }}>
        {value}
      </div>
      <p className="text-xs mb-2" style={{ color: 'var(--color-text-muted)' }}>
        {explanation}
      </p>
      {note && (
        <p className="text-2xs italic mb-2" style={{ color: 'var(--color-text-subtle)' }}>
          {note}
        </p>
      )}
      {detail && <div className="space-y-1 mt-2 pt-2 border-t" style={{ borderColor: 'var(--color-border)' }}>{detail}</div>}
    </div>
  )
}
