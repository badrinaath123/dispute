import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { adminApi } from '@/services/api'
import { Users, CheckCircle, XCircle, ToggleLeft, ToggleRight, ChevronDown, ChevronRight } from 'lucide-react'
import { format } from 'date-fns'
import toast from 'react-hot-toast'
import clsx from 'clsx'
import { useAuthStore } from '@/app/store'
import { PageHeader, Skeleton } from '@/components/ui'

interface User {
  user_id: string; username: string; email: string; tenant_id: string
  roles: string[]; is_active: boolean; created_at: string; screens: string[]
}

const ROLE_COLOR: Record<string, string> = {
  admin: '#c50f1f',
  issuer_analyst: 'var(--color-brand)',
  merchant_analyst: '#107c10',
}

export function UsersConfigPage() {
  const qc = useQueryClient()
  const { user: currentUser } = useAuthStore()
  const [expanded, setExpanded] = useState<string | null>(null)

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => adminApi.listUsers(),
    select: (r) => r.data as User[],
  })

  const toggleMutation = useMutation({
    mutationFn: (userId: string) => adminApi.toggleUser(userId),
    onSuccess: (res) => {
      const u = res.data as User
      toast.success(`${u.username} ${u.is_active ? 'activated' : 'deactivated'}`)
      qc.invalidateQueries({ queryKey: ['admin-users'] })
    },
    onError: (err: any) => {
      toast.error(err?.response?.data?.detail ?? 'Action failed')
    },
  })

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader
        icon={<Users size={18} />}
        title="Users"
        description={`${users.length} registered users · Toggle active status or view screen access.`}
      />

      {isLoading ? (
        <div className="space-y-2">
          {[1,2,3].map(n => (
            <Skeleton key={n} className="h-14" />
          ))}
        </div>
      ) : (
        <div className="rounded-fluent-lg border overflow-hidden"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: 'var(--color-surface-r)', borderBottom: '1px solid var(--color-border)' }}>
                {['', 'Username', 'Email', 'Role', 'Status', 'Created', 'Active'].map(h => (
                  <th key={h} className="text-left px-4 py-2.5 text-xs font-semibold uppercase tracking-wide"
                    style={{ color: 'var(--color-text-muted)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {users.map((u) => {
                const isSelf = u.user_id === currentUser?.user_id
                const isExpanded = expanded === u.user_id
                return [
                  <tr key={`row-${u.user_id}`}
                    className={clsx('transition-colors', !isSelf && 'hover:bg-neutral-50 dark:hover:bg-neutral-800/40')}
                    style={{ borderBottom: '1px solid var(--color-border)', opacity: u.is_active ? 1 : 0.6 }}>
                    <td className="px-3 py-3 w-8">
                      <button onClick={() => setExpanded(e => e === u.user_id ? null : u.user_id)}
                        style={{ color: 'var(--color-text-muted)' }}>
                        {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                      </button>
                    </td>
                    <td className="px-4 py-3 font-medium" style={{ color: 'var(--color-text)' }}>
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white"
                          style={{ background: ROLE_COLOR[u.roles[0]] ?? '#616161' }}>
                          {u.username[0].toUpperCase()}
                        </div>
                        {u.username}
                        {isSelf && <span className="text-2xs px-1.5 py-0.5 rounded font-medium"
                          style={{ background: 'rgba(0,120,212,0.1)', color: 'var(--color-brand)' }}>You</span>}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-text-muted)' }}>{u.email}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1 flex-wrap">
                        {u.roles.map(role => (
                          <span key={role} className="text-xs px-2 py-0.5 rounded-full font-medium"
                            style={{
                              background: `${ROLE_COLOR[role] ?? '#616161'}14`,
                              color: ROLE_COLOR[role] ?? 'var(--color-text-muted)',
                            }}>
                            {role.replace(/_/g, ' ')}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 text-xs font-medium"
                        style={{ color: u.is_active ? 'var(--color-success)' : 'var(--color-text-subtle)' }}>
                        {u.is_active ? <CheckCircle size={13} /> : <XCircle size={13} />}
                        {u.is_active ? 'Active' : 'Inactive'}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs" style={{ color: 'var(--color-text-subtle)' }}>
                      {format(new Date(u.created_at), 'dd MMM yyyy')}
                    </td>
                    <td className="px-4 py-3">
                      {!isSelf && (
                        <button
                          onClick={() => toggleMutation.mutate(u.user_id)}
                          disabled={toggleMutation.isPending}
                          title={u.is_active ? 'Deactivate user' : 'Activate user'}
                          style={{ color: u.is_active ? 'var(--color-success)' : 'var(--color-text-subtle)' }}>
                          {u.is_active
                            ? <ToggleRight size={22} />
                            : <ToggleLeft size={22} />}
                        </button>
                      )}
                    </td>
                  </tr>,
                  isExpanded && (
                    <tr key={`exp-${u.user_id}`}
                      style={{ background: 'var(--color-surface-r)', borderBottom: '1px solid var(--color-border)' }}>
                      <td colSpan={7} className="px-6 py-4">
                        <div className="text-xs font-semibold mb-2" style={{ color: 'var(--color-text-muted)' }}>
                          Screen Access ({u.screens.length})
                        </div>
                        <div className="flex gap-2 flex-wrap">
                          {u.screens.length === 0
                            ? <span style={{ color: 'var(--color-text-subtle)' }}>No screen access</span>
                            : u.screens.map(s => (
                              <span key={s} className="text-xs px-2 py-0.5 rounded font-medium"
                                style={{ background: 'rgba(0,120,212,0.08)', color: 'var(--color-brand)' }}>
                                {s}
                              </span>
                            ))}
                        </div>
                      </td>
                    </tr>
                  )
                ]
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
