import { useEffect, useState } from 'react'
import { Pencil, CheckCircle, XCircle, ArrowLeft, Info } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { adminApi } from '@/services/api'
import type { StatusConfig, StatusColor } from '@/types'
import { ColorBadge, COLOR_OPTIONS } from './adminUtils'
import { Field, Input, Select, Textarea, Button } from '@/components/ui'
import clsx from 'clsx'

const EMPTY: Omit<StatusConfig, 'status_id' | 'created_at' | 'updated_at' | 'created_by'> = {
  code: '', display_name: '', description: '', category: 'WORKFLOW',
  sort_order: 0, is_active: true, color: 'neutral', is_initial: false, is_terminal: false,
}

export function StatusConfigPage() {
  const navigate = useNavigate()
  const [items, setItems] = useState<StatusConfig[]>([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState<string | null>(null)  // status_id
  const [form, setForm] = useState({ ...EMPTY })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function load() {
    setLoading(true)
    try {
      const r = await adminApi.listStatuses()
      setItems(r.data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  function startEdit(item: StatusConfig) {
    setEditing(item.status_id)
    setForm({
      code: item.code, display_name: item.display_name, description: item.description,
      category: item.category, sort_order: item.sort_order, is_active: item.is_active,
      color: item.color, is_initial: item.is_initial, is_terminal: item.is_terminal,
    })
    setError(null)
  }

  function cancel() { setEditing(null); setError(null) }

  async function save() {
    setSaving(true); setError(null)
    try {
      await adminApi.updateStatus(editing!, form)
      setEditing(null)
      await load()
    } catch (e: any) {
      setError(e?.response?.data?.detail ?? 'Save failed')
    } finally {
      setSaving(false)
    }
  }

  const f = (field: string, value: any) => setForm((p) => ({ ...p, [field]: value }))

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="sm" onClick={() => navigate('/admin')}>
          <ArrowLeft size={16} />
        </Button>
        <div className="flex-1">
          <h1 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>Dispute Statuses</h1>
          <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
            The exact status codes this platform's own logic actually recognizes — dispute
            creation, chargeback, merchant accept/challenge, and SLA/priority scoring all
            key off these codes.
          </p>
        </div>
      </div>

      <div className="flex items-start gap-2 mb-4 px-3 py-2.5 rounded-fluent text-xs"
        style={{ background: 'var(--color-surface-r)', border: '1px solid var(--color-border)', color: 'var(--color-text-muted)' }}>
        <Info size={13} className="shrink-0 mt-0.5" />
        This list is fixed to those real codes, so adding or removing one is disabled — a
        new code would have no application behavior behind it. Display name, description,
        color, and flags are fully editable.
      </div>

      {/* Error */}
      {error && (
        <div className="mb-4 px-4 py-2.5 rounded-fluent text-sm border"
          style={{ background: 'rgba(197,15,31,0.08)', color: 'var(--color-critical)', borderColor: 'rgba(197,15,31,0.2)' }}>
          {error}
        </div>
      )}

      {/* Inline form */}
      {editing && (
        <div className="mb-6 p-5 rounded-fluent-lg border"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-brand)' }}>
          <h3 className="text-sm font-semibold mb-4" style={{ color: 'var(--color-text)' }}>
            Edit Status
          </h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <Field label="Code">
              <Input value={form.code} disabled title="The code is fixed — it matches a real dispute status this app's logic uses." />
            </Field>
            <Field label="Display Name" required>
              <Input value={form.display_name}
                placeholder="e.g. Under Review"
                onChange={(e) => f('display_name', e.target.value)} />
            </Field>
          </div>
          <Field label="Description">
            <Textarea rows={2} value={form.description}
              onChange={(e) => f('description', e.target.value)} />
          </Field>
          <div className="grid grid-cols-3 gap-4 mt-4">
            <Field label="Category">
              <Select value={form.category} onChange={(e) => f('category', e.target.value)}>
                <option value="WORKFLOW">WORKFLOW</option>
                <option value="TERMINAL">TERMINAL</option>
              </Select>
            </Field>
            <Field label="Sort Order">
              <Input type="number" value={form.sort_order}
                onChange={(e) => f('sort_order', Number(e.target.value))} />
            </Field>
            <Field label="Badge Color">
              <Select value={form.color}
                onChange={(e) => f('color', e.target.value as StatusColor)}>
                {COLOR_OPTIONS.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
              </Select>
            </Field>
          </div>
          <div className="flex items-center gap-6 mt-4">
            {[
              { key: 'is_active', label: 'Active' },
              { key: 'is_initial', label: 'Initial Status' },
              { key: 'is_terminal', label: 'Terminal Status' },
            ].map(({ key, label }) => (
              <label key={key} className="flex items-center gap-2 cursor-pointer text-sm"
                style={{ color: 'var(--color-text-muted)' }}>
                <input type="checkbox" checked={(form as any)[key]}
                  onChange={(e) => f(key, e.target.checked)}
                  className="w-4 h-4 rounded accent-brand-500" />
                {label}
              </label>
            ))}
          </div>
          <div className="flex gap-2 mt-5">
            <Button variant="primary" size="sm"
              onClick={save}
              disabled={!form.code || !form.display_name}
              loading={saving}
            >
              Save
            </Button>
            <Button variant="secondary" size="sm" onClick={cancel}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="rounded-fluent-lg border overflow-hidden"
        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ borderBottom: '1px solid var(--color-border)', background: 'var(--color-surface-r)' }}>
              {['#', 'Code', 'Display Name', 'Description', 'Category', 'Color', 'Flags', 'Status', ''].map((h) => (
                <th key={h} className="px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide"
                  style={{ color: 'var(--color-text-muted)' }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={9} className="px-4 py-8 text-center text-sm" style={{ color: 'var(--color-text-muted)' }}>Loading…</td></tr>
            ) : items.length === 0 ? (
              <tr><td colSpan={9} className="px-4 py-8 text-center text-sm" style={{ color: 'var(--color-text-muted)' }}>No statuses configured.</td></tr>
            ) : items.map((s) => (
              <tr key={s.status_id}
                className="border-t transition-colors hover:bg-neutral-50 dark:hover:bg-neutral-900"
                style={{ borderColor: 'var(--color-border)', opacity: s.is_active ? 1 : 0.55 }}>
                <td className="px-4 py-3 text-xs" style={{ color: 'var(--color-text-muted)' }}>{s.sort_order}</td>
                <td className="px-4 py-3">
                  <code className="text-xs px-1.5 py-0.5 rounded-fluent"
                    style={{ background: 'var(--color-surface-r)', color: 'var(--color-brand)', fontFamily: 'monospace' }}>
                    {s.code}
                  </code>
                </td>
                <td className="px-4 py-3 font-medium" style={{ color: 'var(--color-text)' }}>{s.display_name}</td>
                <td className="px-4 py-3 text-xs max-w-xs truncate" style={{ color: 'var(--color-text-muted)' }}>{s.description}</td>
                <td className="px-4 py-3">
                  <span className={clsx(
                    'text-xs px-2 py-0.5 rounded-full font-medium border',
                    s.category === 'TERMINAL'
                      ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800'
                      : 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-900/20 dark:text-blue-400 dark:border-blue-800'
                  )}>
                    {s.category}
                  </span>
                </td>
                <td className="px-4 py-3"><ColorBadge color={s.color} label={s.color} /></td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    {s.is_initial  && <span className="text-xs px-1.5 py-0.5 rounded-full bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800">INITIAL</span>}
                    {s.is_terminal && <span className="text-xs px-1.5 py-0.5 rounded-full bg-red-50 text-red-700 border border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800">TERMINAL</span>}
                  </div>
                </td>
                <td className="px-4 py-3">
                  {s.is_active
                    ? <span className="flex items-center gap-1 text-xs" style={{ color: 'var(--color-success)' }}><CheckCircle size={12} /> Active</span>
                    : <span className="flex items-center gap-1 text-xs" style={{ color: 'var(--color-text-muted)' }}><XCircle size={12} /> Inactive</span>}
                </td>
                <td className="px-4 py-3 text-right">
                  <Button variant="secondary" size="sm" onClick={() => startEdit(s)}>
                    <Pencil size={12} />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

