import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, CheckCircle2, XCircle, HelpCircle } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { platformApi } from '@/services/api'
import type { EvalScoreEntry } from '@/types'
import { Button } from '@/components/ui'

function scoreColor(score: number | null) {
  if (score === null) return 'var(--color-text-muted)'
  if (score >= 0.7) return 'var(--color-success)'
  if (score >= 0.4) return 'var(--color-warning)'
  return 'var(--color-critical)'
}

function PassBadge({ passed }: { passed: boolean | null }) {
  if (passed === null) {
    return (
      <span className="flex items-center gap-1 text-2xs font-medium px-1.5 py-0.5 rounded-full"
        style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-muted)' }}>
        <HelpCircle size={9} /> Unknown
      </span>
    )
  }
  return passed ? (
    <span className="flex items-center gap-1 text-2xs font-medium px-1.5 py-0.5 rounded-full"
      style={{ background: 'rgba(16,124,16,0.1)', color: 'var(--color-success)' }}>
      <CheckCircle2 size={9} /> Pass
    </span>
  ) : (
    <span className="flex items-center gap-1 text-2xs font-medium px-1.5 py-0.5 rounded-full"
      style={{ background: 'rgba(197,15,31,0.08)', color: 'var(--color-critical)' }}>
      <XCircle size={9} /> Fail
    </span>
  )
}

export function EvalScoresPage() {
  const navigate = useNavigate()
  const [items, setItems] = useState<EvalScoreEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [featureFilter, setFeatureFilter] = useState<string>('ALL')

  useEffect(() => {
    (async () => {
      setLoading(true)
      try { const r = await platformApi.evalScores(); setItems(r.data) }
      finally { setLoading(false) }
    })()
  }, [])

  const features = useMemo(() => {
    const s = new Set(items.map((i) => i.feature))
    return ['ALL', ...Array.from(s).sort()]
  }, [items])

  const filtered = useMemo(
    () => featureFilter === 'ALL' ? items : items.filter((i) => i.feature === featureFilter),
    [items, featureFilter]
  )

  const passRate = useMemo(() => {
    const scored = filtered.filter((i) => i.passed !== null)
    if (scored.length === 0) return null
    return Math.round((scored.filter((i) => i.passed).length / scored.length) * 100)
  }, [filtered])

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center gap-3 mb-2">
        <Button variant="ghost" size="sm" onClick={() => navigate('/admin')}>
          <ArrowLeft size={16} />
        </Button>
        <div className="flex-1">
          <h1 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>AI Quality — Live Scores</h1>
          <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
            Every individual DeepEval judgment of a real AI answer in this app (README §30) — scored
            after the analyst already has their response, never on the critical path. The aggregate of
            exactly these rows is what Platform Impact shows under AI Quality.
          </p>
        </div>
      </div>

      {!loading && items.length > 0 && (
        <div className="flex items-center gap-3 mb-4">
          <select value={featureFilter} onChange={(e) => setFeatureFilter(e.target.value)}
            className="text-xs px-2.5 py-1.5 rounded-fluent border"
            style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface)', color: 'var(--color-text)' }}>
            {features.map((f) => <option key={f} value={f}>{f === 'ALL' ? 'All features' : f}</option>)}
          </select>
          {passRate !== null && (
            <span className="text-2xs" style={{ color: 'var(--color-text-muted)' }}>
              {filtered.length} score{filtered.length !== 1 ? 's' : ''} · {passRate}% passing
            </span>
          )}
        </div>
      )}

      {loading ? (
        <div className="py-12 text-center text-sm" style={{ color: 'var(--color-text-muted)' }}>Loading…</div>
      ) : items.length === 0 ? (
        <div className="py-12 text-center text-sm" style={{ color: 'var(--color-text-muted)' }}>
          No live scores yet. This fills in as analysts use AI features that are wired for evaluation
          (currently: Ask the Case). Set <code>ENABLE_DEEPEVAL=true</code> and ask a question on a case to see one.
        </div>
      ) : (
        <div className="rounded-fluent-lg border overflow-hidden" style={{ borderColor: 'var(--color-border)' }}>
          <div className="divide-y" style={{ borderColor: 'var(--color-border)' }}>
            {filtered.map((row) => {
              const isOpen = expanded === row.eval_id
              return (
                <div key={row.eval_id} className="px-4 py-3" style={{ background: 'var(--color-surface)' }}>
                  <button type="button" className="w-full flex items-start gap-3 text-left"
                    onClick={() => setExpanded(isOpen ? null : row.eval_id)}>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <code className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>{row.metric}</code>
                        <span className="text-2xs px-1.5 py-0.5 rounded-full"
                          style={{ background: 'var(--color-surface-r)', color: 'var(--color-text-muted)' }}>
                          {row.feature}
                        </span>
                        <PassBadge passed={row.passed} />
                        {row.case_id && (
                          <span className="text-2xs" style={{ color: 'var(--color-text-subtle)' }}>
                            case {row.case_id}
                          </span>
                        )}
                        <span className="text-2xs ml-auto shrink-0" style={{ color: 'var(--color-text-subtle)' }}>
                          {new Date(row.created_at).toLocaleString()}
                        </span>
                      </div>
                      {row.input_text && (
                        <p className="text-xs truncate" style={{ color: 'var(--color-text-muted)' }}>
                          {row.input_text}
                        </p>
                      )}
                    </div>
                    <div className="shrink-0 text-sm font-semibold tabular-nums"
                      style={{ color: scoreColor(row.score) }}>
                      {row.score !== null ? row.score.toFixed(2) : '—'}
                    </div>
                  </button>
                  {isOpen && row.reason && (
                    <div className="mt-2 pl-0.5 text-xs" style={{ color: 'var(--color-text-muted)' }}>
                      <span className="font-medium" style={{ color: 'var(--color-text)' }}>Judge's reasoning: </span>
                      {row.reason}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
