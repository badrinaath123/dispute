import { useRef, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { BookOpen, Upload, Trash2, FileText, Search, Loader2, CheckCircle2, XCircle } from 'lucide-react'
import toast from 'react-hot-toast'
import { adminApi } from '@/services/api'
import { Button, Badge, PageHeader, EmptyState, Input, Select } from '@/components/ui'

type Network = 'VISA' | 'MASTERCARD' | 'OTHER'
type DocType = 'RULES' | 'DISPUTE_GUIDE' | 'INTERNAL_POLICY' | 'REGULATORY' | 'OTHER'

interface RegulatoryDocument {
  document_id: string
  filename: string
  uploaded_by: string
  uploaded_at: string
  status: 'PENDING' | 'PROCESSING' | 'READY' | 'FAILED'
  page_count: number | null
  chunks_indexed: number
  error: string | null
  network: Network
  doc_type: DocType
}

interface SearchHit {
  title: string
  text: string
  source: string
  page: number | null
  similarity: number
  network: Network | null
  doc_type: DocType | null
}

const DOC_TYPE_LABEL: Record<DocType, string> = {
  RULES: 'Rules',
  DISPUTE_GUIDE: 'Dispute / Chargeback Guide',
  INTERNAL_POLICY: 'Internal SOP / Policy',
  REGULATORY: 'Regulatory Reference (e.g. Reg Z)',
  OTHER: 'Other',
}

function StatusBadge({ status }: { status: RegulatoryDocument['status'] }) {
  if (status === 'READY') return <Badge variant="success"><CheckCircle2 size={11} />Ready</Badge>
  if (status === 'FAILED') return <Badge variant="error"><XCircle size={11} />Failed</Badge>
  return <Badge variant="warning"><Loader2 size={11} className="animate-spin" />{status === 'PROCESSING' ? 'Processing' : 'Pending'}</Badge>
}

export function KnowledgeBasePage() {
  const queryClient = useQueryClient()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [pendingFile, setPendingFile] = useState<File | null>(null)
  const [uploadNetwork, setUploadNetwork] = useState<Network>('VISA')
  const [uploadDocType, setUploadDocType] = useState<DocType>('RULES')
  const [query, setQuery] = useState('')
  const [searchNetwork, setSearchNetwork] = useState<Network | ''>('')
  const [hits, setHits] = useState<SearchHit[] | null>(null)

  const { data: documents = [], isLoading } = useQuery({
    queryKey: ['regulatory-documents'],
    queryFn: () => adminApi.listRegulatoryDocuments(),
    select: (r) => r.data as RegulatoryDocument[],
    refetchInterval: (query) => {
      // refetchInterval's `query.state.data` is the raw queryFn result (the axios
      // response), NOT the `select`-transformed value — must unwrap `.data` here too.
      const docs = ((query.state.data as { data?: RegulatoryDocument[] } | undefined)?.data) ?? []
      const stillWorking = Array.isArray(docs) && docs.some((d) => d.status === 'PENDING' || d.status === 'PROCESSING')
      return stillWorking ? 2000 : false
    },
  })

  const uploadMutation = useMutation({
    mutationFn: ({ file, network, docType }: { file: File; network: Network; docType: DocType }) =>
      adminApi.uploadRegulatoryDocument(file, network, docType),
    onSuccess: () => {
      toast.success('Upload started — extraction and embedding run in the background.')
      queryClient.invalidateQueries({ queryKey: ['regulatory-documents'] })
      setPendingFile(null)
    },
    onError: () => toast.error('Upload failed'),
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => adminApi.deleteRegulatoryDocument(id),
    onSuccess: () => {
      toast.success('Document removed')
      queryClient.invalidateQueries({ queryKey: ['regulatory-documents'] })
    },
    onError: () => toast.error('Delete failed'),
  })

  const searchMutation = useMutation({
    mutationFn: (q: string) => adminApi.searchRegulatoryContext(q, 5, searchNetwork || undefined),
    onSuccess: (r) => setHits(r.data as SearchHit[]),
    onError: () => toast.error('Search failed'),
  })

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) setPendingFile(file)
    e.target.value = ''
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <PageHeader
        icon={<BookOpen size={18} />}
        title="Knowledge Base"
        description="Upload chargeback / card-scheme rulebook PDFs. Each page is chunked and embedded so the agent's gap-finding and the evidence-completeness check can retrieve real, cited passages instead of only platform-authored policy text."
        actions={
          <>
            <input ref={fileInputRef} type="file" accept="application/pdf" className="hidden" onChange={handleFileChange} />
            <Button variant="primary" size="sm" onClick={() => fileInputRef.current?.click()} loading={uploadMutation.isPending}>
              <Upload size={14} />
              Upload PDF
            </Button>
          </>
        }
      />

      {pendingFile && (
        <div className="rounded-fluent-lg border p-4 mb-6 flex items-center gap-4 flex-wrap"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-brand)' }}>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-medium truncate" style={{ color: 'var(--color-text)' }}>{pendingFile.name}</div>
            <div className="text-2xs" style={{ color: 'var(--color-text-subtle)' }}>Tag this document before it's indexed</div>
          </div>
          <Select value={uploadNetwork} onChange={(e) => setUploadNetwork(e.target.value as Network)} className="w-40">
            <option value="VISA">Visa</option>
            <option value="MASTERCARD">Mastercard</option>
            <option value="OTHER">Other</option>
          </Select>
          <Select value={uploadDocType} onChange={(e) => setUploadDocType(e.target.value as DocType)} className="w-56">
            <option value="RULES">Rules</option>
            <option value="DISPUTE_GUIDE">Dispute / Chargeback Guide</option>
            <option value="INTERNAL_POLICY">Internal SOP / Policy</option>
            <option value="REGULATORY">Regulatory Reference (e.g. Reg Z)</option>
            <option value="OTHER">Other</option>
          </Select>
          <Button variant="secondary" size="sm" onClick={() => setPendingFile(null)}>Cancel</Button>
          <Button variant="primary" size="sm" loading={uploadMutation.isPending}
            onClick={() => uploadMutation.mutate({ file: pendingFile, network: uploadNetwork, docType: uploadDocType })}>
            Confirm Upload
          </Button>
        </div>
      )}

      {/* Documents table */}
      {isLoading ? null : documents.length === 0 ? (
        <EmptyState
          icon={<FileText size={32} />}
          title="No documents uploaded yet"
          description="Upload a chargeback guide or scheme rulebook PDF — large documents (hundreds of pages) are processed in the background; this page updates automatically while that runs."
        />
      ) : (
        <div className="rounded-fluent-lg border overflow-hidden mb-6" style={{ borderColor: 'var(--color-border)' }}>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs font-semibold uppercase tracking-wide text-left"
                style={{ color: 'var(--color-text-muted)', background: 'var(--color-surface-r)' }}>
                <th className="px-4 py-2.5">Document</th>
                <th className="px-4 py-2.5">Network</th>
                <th className="px-4 py-2.5">Type</th>
                <th className="px-4 py-2.5">Status</th>
                <th className="px-4 py-2.5">Pages</th>
                <th className="px-4 py-2.5">Chunks Indexed</th>
                <th className="px-4 py-2.5">Uploaded</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody className="divide-y" style={{ borderColor: 'var(--color-border)' }}>
              {documents.map((d) => (
                <tr key={d.document_id} style={{ background: 'var(--color-surface)' }}>
                  <td className="px-4 py-3">
                    <div className="font-medium" style={{ color: 'var(--color-text)' }}>{d.filename}</div>
                    {d.status === 'FAILED' && d.error && (
                      <div className="text-2xs mt-0.5" style={{ color: 'var(--color-critical)' }}>{d.error}</div>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {d.network !== 'OTHER' ? <Badge variant="brand">{d.network}</Badge> : <span style={{ color: 'var(--color-text-subtle)' }}>—</span>}
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: 'var(--color-text-muted)' }}>{DOC_TYPE_LABEL[d.doc_type]}</td>
                  <td className="px-4 py-3"><StatusBadge status={d.status} /></td>
                  <td className="px-4 py-3" style={{ color: 'var(--color-text-muted)' }}>{d.page_count ?? '—'}</td>
                  <td className="px-4 py-3" style={{ color: 'var(--color-text-muted)' }}>{d.chunks_indexed}</td>
                  <td className="px-4 py-3 text-xs" style={{ color: 'var(--color-text-subtle)' }}>
                    {new Date(d.uploaded_at).toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => deleteMutation.mutate(d.document_id)} disabled={deleteMutation.isPending}
                      style={{ color: 'var(--color-text-subtle)' }} className="hover:opacity-70">
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Test retrieval */}
      <div className="rounded-fluent-lg border p-5" style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        <div className="flex items-center gap-2 mb-3">
          <Search size={15} style={{ color: 'var(--color-brand)' }} />
          <h3 className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>Test Retrieval</h3>
        </div>
        <p className="text-xs mb-3" style={{ color: 'var(--color-text-muted)' }}>
          Query the regulatory collection directly — the same retrieval the agent's identify_gaps node uses.
        </p>
        <form
          className="flex gap-2 mb-4"
          onSubmit={(e) => { e.preventDefault(); if (query.trim()) searchMutation.mutate(query.trim()) }}
        >
          <div className="flex-1">
            <Input value={query} onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. proof of delivery required for merchandise not received" />
          </div>
          <Select value={searchNetwork} onChange={(e) => setSearchNetwork(e.target.value as Network | '')} className="w-40">
            <option value="">All networks</option>
            <option value="VISA">Visa only</option>
            <option value="MASTERCARD">Mastercard only</option>
          </Select>
          <Button type="submit" variant="secondary" loading={searchMutation.isPending}>Search</Button>
        </form>

        {hits && (
          hits.length === 0 ? (
            <p className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>No passages retrieved for that query.</p>
          ) : (
            <div className="space-y-2">
              {hits.map((h, i) => (
                <div key={i} className="rounded-fluent border p-3" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-r)' }}>
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-semibold flex items-center gap-1.5" style={{ color: 'var(--color-text)' }}>
                      {h.title}
                      {h.network && <Badge variant="brand">{h.network}</Badge>}
                    </span>
                    <span className="text-2xs shrink-0" style={{ color: 'var(--color-brand)' }}>{Math.round(h.similarity * 100)}% match</span>
                  </div>
                  <div className="text-2xs mb-1.5" style={{ color: 'var(--color-text-subtle)' }}>
                    {h.source === 'platform_policy' ? 'Platform policy (synthesized)' : `${h.source}${h.page ? `, p. ${h.page}` : ''}`}
                  </div>
                  <p className="text-xs leading-relaxed" style={{ color: 'var(--color-text-muted)' }}>
                    {h.text.length > 400 ? `${h.text.slice(0, 400)}…` : h.text}
                  </p>
                </div>
              ))}
            </div>
          )
        )}
      </div>
    </div>
  )
}
