import { useEffect, useState } from 'react'
import { Pencil, CheckCircle, XCircle, ArrowLeft, Info } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { adminApi } from '@/services/api'
import type { OutcomeConfig, StatusColor } from '@/types'
import { ColorBadge, COLOR_OPTIONS } from './adminUtils'
import { Field, Input, Select, Textarea, Button } from '@/components/ui'

const EMPTY = {
  code: '', display_name: '', description: '', sort_order: 0, is_active: true, color: 'neutral' as StatusColor,
}

export function OutcomeConfigPage() {
  const navigate = useNavigate()
  const [items, setItems] = useState<OutcomeConfig[]>([])
  const [loading, setLoading] = useState(true)
  const [editing, setEditing] = useState<string | null>(null)
  const [form, setForm] = useState({ ...EMPTY })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function load() {
    setLoading(true)
    try { const r = await adminApi.listOutcomes(); setItems(r.data) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  function startEdit(item: OutcomeConfig) {
    setEditing(item.outcome_id)
    setForm({ code: item.code, display_name: item.display_name, description: item.description,
              sort_order: item.sort_order, is_active: item.is_active, color: item.color })
    setError(null)
  }

  function cancel() { setEditing(null); setError(null) }

  const f = (field: string, value: any) => setForm((p) => ({ ...p, [field]: value }))

  async function save() {
    setSaving(true); setError(null)
    try {
      await adminApi.updateOutcome(editing!, form)
      setEditing(null); await load()
    } catch (e: any) {
      setError(e?.response?.data?.detail ?? 'Save failed')
    } finally { setSaving(false) }
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="sm" onClick={() => navigate('/admin')}>
          <ArrowLeft size={16} />
        </Button>
        <div className="flex-1">
          <h1 className="text-lg font-semibold" style={{ color: 'var(--color-text)' }}>Resolution Outcomes</h1>
          <p className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
            A reserved concept for a future case-resolution flow — no code in this platform
            reads a dispute's outcome yet (DisputeModel has no outcome field).
          </p>
        </div>
      </div>

      <div className="flex items-start gap-2 mb-4 px-3 py-2.5 rounded-fluent text-xs"
        style={{ background: 'var(--color-surface-r)', border: '1px solid var(--color-border)', color: 'var(--color-text-muted)' }}>
        <Info size={13} className="shrink-0 mt-0.5" />
        Since nothing attaches an outcome to a real dispute yet, adding or removing a code
        here is disabled — a new one couldn't mean anything either. Display name,
        description, and color are still fully editable.
      </div>

      {error && (
        <div className="mb-4 px-4 py-2.5 rounded-fluent text-sm border"
          style={{ background: 'rgba(197,15,31,0.08)', color: 'var(--color-critical)', borderColor: 'rgba(197,15,31,0.2)' }}>
          {error}
        </div>
      )}

      {/* Inline form */}
      {editing && (
        <div className="mb-6 p-5 rounded-fluent-lg border"
          style={{ background: 'var(--color-surface)', borderColor: 'var(--color-brand)' }}>
          <h3 className="text-sm font-semibold mb-4" style={{ color: 'var(--color-text)' }}>
            Edit Outcome
          </h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <Field label="Code">
              <Input value={form.code} disabled title="The code is fixed." />
            </Field>
            <Field label="Display Name" required>
              <Input value={form.display_name} placeholder="e.g. Customer Won"
                onChange={(e) => f('display_name', e.target.value)} />
            </Field>
          </div>
          <Field label="Description">
            <Textarea rows={2} value={form.description}
              onChange={(e) => f('description', e.target.value)} />
          </Field>
          <div className="grid grid-cols-3 gap-4 mt-4">
            <Field label="Sort Order">
              <Input type="number" value={form.sort_order}
                onChange={(e) => f('sort_order', Number(e.target.value))} />
            </Field>
            <Field label="Badge Color">
              <Select value={form.color}
                onChange={(e) => f('color', e.target.value as StatusColor)}>
                {COLOR_OPTIONS.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
              </Select>
            </Field>
            <div className="flex items-end pb-1">
              <label className="flex items-center gap-2 cursor-pointer text-sm" style={{ color: 'var(--color-text-muted)' }}>
                <input type="checkbox" checked={form.is_active} onChange={(e) => f('is_active', e.target.checked)}
                  className="w-4 h-4 rounded accent-brand-500" />
                Active
              </label>
            </div>
          </div>
          <div className="flex gap-2 mt-5">
            <Button variant="primary" size="sm" onClick={save} disabled={!form.display_name} loading={saving}>
              Save
            </Button>
            <Button variant="secondary" size="sm" onClick={cancel}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      {/* Cards grid */}
      <div className="grid grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-3 py-12 text-center text-sm" style={{ color: 'var(--color-text-muted)' }}>Loading…</div>
        ) : items.length === 0 ? (
          <div className="col-span-3 py-12 text-center text-sm" style={{ color: 'var(--color-text-muted)' }}>No outcomes configured.</div>
        ) : items.map((o) => (
          <div key={o.outcome_id}
            className="rounded-fluent-lg border p-4 transition-shadow hover:shadow-fluent-sm"
            style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', opacity: o.is_active ? 1 : 0.55 }}>
            <div className="flex items-start justify-between mb-2">
              <ColorBadge color={o.color} label={o.display_name} />
              {o.is_active
                ? <span className="flex items-center gap-1 text-xs" style={{ color: 'var(--color-success)' }}><CheckCircle size={11} /> Active</span>
                : <span className="flex items-center gap-1 text-xs" style={{ color: 'var(--color-text-muted)' }}><XCircle size={11} /> Inactive</span>}
            </div>
            <code className="block text-xs mb-2" style={{ color: 'var(--color-text-muted)', fontFamily: 'monospace' }}>
              {o.code}
            </code>
            <p className="text-xs leading-relaxed mb-4" style={{ color: 'var(--color-text-muted)' }}>{o.description}</p>
            <Button variant="secondary" size="sm" onClick={() => startEdit(o)}>
              <Pencil size={11} /> Edit
            </Button>
          </div>
        ))}
      </div>
    </div>
  )
}
