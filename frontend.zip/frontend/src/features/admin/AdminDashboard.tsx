import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Settings, Tag, Target, Shield, Users, Server, ChevronRight, TrendingUp, FileSearch, BarChart2, DollarSign } from 'lucide-react'
import { adminApi, platformApi } from '@/services/api'
import { useAuthStore } from '@/app/store'
import { PageHeader } from '@/components/ui'
import { useCountUp } from '@/hooks/useCountUp'
import type { PlatformImpact } from '@/types'

interface Summary {
  statuses: { total: number; active: number }
  outcomes: { total: number; active: number }
  roles: { total: number; active: number }
  users: { total: number; active: number }
}

const CARDS = [
  {
    screen: 'admin-statuses',
    path: '/admin/statuses',
    icon: Tag,
    title: 'Dispute Statuses',
    description: 'Configure lifecycle statuses — initial states, workflow stages, and terminal outcomes.',
    color: 'var(--color-brand)',
    bg: 'rgba(0,120,212,0.08)',
    key: 'statuses' as keyof Summary,
  },
  {
    screen: 'admin-outcomes',
    path: '/admin/outcomes',
    icon: Target,
    title: 'Resolution Outcomes',
    description: 'Configure the possible final outcomes when a dispute case is resolved.',
    color: 'var(--color-success)',
    bg: 'rgba(16,124,16,0.08)',
    key: 'outcomes' as keyof Summary,
  },
  {
    screen: 'admin-roles',
    path: '/admin/roles',
    icon: Shield,
    title: 'Roles & Permissions',
    description: 'Configure user roles with granular permission sets and screen access control.',
    color: '#5c2d91',
    bg: 'rgba(92,45,145,0.08)',
    key: 'roles' as keyof Summary,
  },
  {
    screen: 'admin-evidence-requirements',
    path: '/admin/evidence-requirements',
    icon: FileSearch,
    title: 'Evidence Requirements',
    description: 'Which evidence types each dispute type expects — the deterministic safety net under the agent\'s AI gap analysis.',
    color: '#c50f1f',
    bg: 'rgba(197,15,31,0.08)',
    key: null,
  },
  {
    screen: 'admin-users',
    path: '/admin/users',
    icon: Users,
    title: 'Users',
    description: 'View registered users, their roles, and activate or deactivate accounts.',
    color: '#ca5010',
    bg: 'rgba(202,80,16,0.08)',
    key: 'users' as keyof Summary,
  },
  {
    screen: 'admin-integrations',
    path: '/admin/integrations',
    icon: Server,
    title: 'System & Integrations',
    description: 'AI model configuration, feature flags, external system connections, and health.',
    color: '#107c10',
    bg: 'rgba(16,124,16,0.08)',
    key: null,
  },
  {
    screen: 'admin-impact',
    path: '/admin/impact',
    icon: TrendingUp,
    title: 'Platform Impact',
    description: 'What the architecture actually prevented, computed, or accelerated — every number live from real data.',
    color: 'var(--color-brand)',
    bg: 'rgba(0,120,212,0.08)',
    key: null,
  },
  {
    screen: 'admin-eval-scores',
    path: '/admin/eval-scores',
    icon: BarChart2,
    title: 'AI Quality',
    description: 'Every live DeepEval score judging a real AI answer — faithfulness, relevancy, and more as features are wired in.',
    color: '#8764b8',
    bg: 'rgba(135,100,184,0.08)',
    key: null,
  },
]

export function AdminDashboard() {
  const navigate = useNavigate()
  const { user } = useAuthStore()
  const [summary, setSummary] = useState<Summary | null>(null)
  const [impact, setImpact] = useState<PlatformImpact | null>(null)
  const allowedScreens = user?.screens ?? []

  useEffect(() => {
    adminApi.summary().then((r) => setSummary(r.data)).catch(() => {})
    platformApi.impact().then((r) => setImpact(r.data)).catch(() => {})
  }, [])

  const visibleCards = CARDS.filter((c) => allowedScreens.includes(c.screen))
  const aiSpendDisplay = useCountUp(impact?.ai_spend.total_cost_usd, 900)

  return (
    <div className="p-8 max-w-5xl mx-auto">
      <PageHeader
        icon={<Settings size={18} />}
        title="Admin Configuration"
        description="Platform-wide settings for D³"
      />

      <div className="h-px my-6" style={{ background: 'var(--color-border)' }} />

      {/* Stat bento — AI Spend is the hero tile (real metered LLM usage, README §37,
          right on the landing page rather than a click into Platform Impact);
          the 4 config counts sit beside it as a smaller 2x2 grid. An asymmetric
          composition reads as considered design; five identical boxes reads as
          a template. */}
      {summary && (
        <div data-tour="admin-stats" className="grid grid-cols-12 gap-4 mb-8">
          <div
            className="col-span-12 md:col-span-5 rounded-fluent-lg p-5 cursor-pointer transition-all duration-300 hover:-translate-y-0.5 animate-fade-in-up relative overflow-hidden shadow-glow-brand"
            style={{
              borderColor: 'transparent', borderWidth: '1.5px', borderStyle: 'solid',
              background: 'linear-gradient(var(--color-surface), var(--color-surface)), var(--gradient-brand)',
              backgroundOrigin: 'border-box', backgroundClip: 'padding-box, border-box',
            }}
            onClick={() => navigate('/admin/impact')}
            title="Every number here is metered from real LLM/embedding calls — see Platform Impact for the full breakdown">
            <div className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wide mb-3"
              style={{ color: 'var(--color-text-muted)' }}>
              <DollarSign size={12} /> AI Spend
            </div>
            <div className="font-display text-5xl font-bold tracking-tight text-glow grad-brand-text inline-block">
              {impact ? `$${aiSpendDisplay.toFixed(4)}` : '—'}
            </div>
            <div className="text-xs mt-2" style={{ color: 'var(--color-text-muted)' }}>
              {impact ? `${impact.ai_spend.total_calls} real LLM/embedding calls metered` : 'loading…'}
            </div>
          </div>

          <div className="col-span-12 md:col-span-7 grid grid-cols-2 gap-4">
            {[
              { label: 'Statuses', ...summary.statuses,  color: 'var(--color-brand)' },
              { label: 'Outcomes', ...summary.outcomes,  color: 'var(--color-success)' },
              { label: 'Roles',    ...summary.roles,     color: '#5c2d91' },
              { label: 'Users',    ...summary.users,     color: '#ca5010' },
            ].map((s, i) => (
              <StatTile key={s.label} label={s.label} value={s.total} sub={`${s.active} active`} color={s.color} delayMs={i * 60} />
            ))}
          </div>
        </div>
      )}

      {/* Nav cards */}
      <div data-tour="admin-cards" className="grid grid-cols-1 gap-3">
        {visibleCards.map((card) => {
          const Icon = card.icon
          const stat = card.key && summary ? summary[card.key] : null
          return (
            <button key={card.screen} onClick={() => navigate(card.path)}
              className="w-full flex items-center gap-4 p-5 rounded-fluent-lg border text-left transition-all hover:shadow-fluent group"
              style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
              <div className="w-10 h-10 rounded-fluent-md flex items-center justify-center shrink-0"
                style={{ background: card.bg, color: card.color }}>
                <Icon size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm mb-0.5" style={{ color: 'var(--color-text)' }}>
                  {card.title}
                </div>
                <div className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                  {card.description}
                </div>
              </div>
              <div className="flex items-center gap-4 shrink-0">
                {stat && stat.total > 0 && (
                  <div className="text-right">
                    <div className="text-sm font-semibold" style={{ color: 'var(--color-text)' }}>
                      {stat.total}
                    </div>
                    <div className="text-2xs" style={{ color: 'var(--color-text-muted)' }}>
                      {stat.active} active
                    </div>
                  </div>
                )}
                <ChevronRight size={16} className="opacity-40 group-hover:opacity-100 transition-opacity"
                  style={{ color: 'var(--color-brand)' }} />
              </div>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function StatTile({ label, value, sub, color, delayMs }: {
  label: string; value: number; sub: string; color: string; delayMs: number
}) {
  const display = useCountUp(value, 700)
  return (
    <div
      className="rounded-fluent-lg p-4 border text-center transition-all duration-300 hover:shadow-fluent hover:-translate-y-0.5 animate-fade-in-up"
      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', animationDelay: `${delayMs}ms` }}
    >
      <div className="text-2xs font-semibold uppercase tracking-wide mb-1"
        style={{ color: 'var(--color-text-muted)' }}>{label}</div>
      <div className="font-display text-2xl font-bold" style={{ color }}>{Math.round(display)}</div>
      <div className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>{sub}</div>
    </div>
  )
}
