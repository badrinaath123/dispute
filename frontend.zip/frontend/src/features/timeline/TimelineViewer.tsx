import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { disputeApi, evidenceApi } from '@/services/api'
import type { Dispute, Evidence, Contradiction } from '@/types'
import { ScenarioTimeline } from '@/components/ScenarioTimeline'

export function TimelineViewer() {
  const { id } = useParams<{ id: string }>()

  const { data: dispute } = useQuery({
    queryKey: ['dispute', id],
    queryFn: () => disputeApi.get(id!),
    select: (r) => r.data as Dispute,
    enabled: !!id,
  })

  const { data: evidence = [] } = useQuery({
    queryKey: ['evidence', id],
    queryFn: () => evidenceApi.list(id!, { current_only: true }),
    select: (r) => r.data as Evidence[],
    enabled: !!id,
  })

  const { data: contradictions = [] } = useQuery({
    queryKey: ['contradictions', id],
    queryFn: () => disputeApi.getContradictions(id!),
    select: (r) => r.data as Contradiction[],
    enabled: !!id,
  })

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center gap-2 mb-1">
        <h2 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
          Event Timeline
        </h2>
        <span className="text-2xs px-1.5 py-0.5 rounded-full font-medium"
          style={{ background: 'rgba(0,120,212,0.1)', color: 'var(--color-brand)' }}>
          Digital Twin
        </span>
      </div>
      <p className="text-xs mb-6" style={{ color: 'var(--color-text-muted)' }}>
        The scenario reconstructed from this case's own evidence — events ordered by
        business event time (what the evidence actually says happened), not ingestion
        time (when it was uploaded).
      </p>

      {!dispute ? (
        <p className="text-sm" style={{ color: 'var(--color-text-muted)' }}>Loading…</p>
      ) : (
        <ScenarioTimeline dispute={dispute} evidence={evidence} contradictions={contradictions} />
      )}
    </div>
  )
}
