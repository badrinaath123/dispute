import { useEffect, useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  ArrowRight, AlertTriangle, Clock, TrendingUp, CheckCircle2,
  Zap, RefreshCw, Star, ChevronRight, Activity
} from 'lucide-react'
import { disputeApi } from '@/services/api'
import { useAuthStore } from '@/app/store'
import { Button, Skeleton } from '@/components/ui'
import type { Dispute } from '@/types'
import { formatDistanceToNow, parseISO } from 'date-fns'
import { isIssuerResolved, slaDaysLabel } from '@/lib/disputeStatus'

const PRIORITY_COLOR: Record<string, string> = {
  CRITICAL: '#c50f1f', HIGH: '#d13438', MEDIUM: '#ca5010', LOW: '#835b00',
}

const DISPUTE_TYPE_LABEL: Record<string, string> = {
  UNAUTHORIZED_TRANSACTION: 'Unauthorized Transaction',
  DUPLICATE_TRANSACTION: 'Duplicate Transaction',
  MERCHANDISE_NOT_RECEIVED: 'Merchandise Not Received',
  MERCHANDISE_NOT_AS_DESCRIBED: 'Merchandise Not As Described',
  REFUND_NOT_PROCESSED: 'Refund Not Processed',
  SUBSCRIPTION_CANCELLATION: 'Subscription Cancellation',
  CASH_WITHDRAWAL_DISPUTE: 'Cash Withdrawal Dispute',
  PROCESSING_ERROR: 'Processing Error',
}

function whyPrioritized(d: Dispute): string[] {
  const reasons: string[] = []
  const sla = slaDaysLabel(d)
  if (sla?.urgent) reasons.push(sla.label.startsWith('Overdue') ? 'SLA overdue' : 'SLA critically close')
  if (d.priority === 'CRITICAL' || d.priority === 'HIGH') reasons.push(`${d.priority} priority case`)
  const amt = Number(d.metadata?.amount_disputed)
  if (!isNaN(amt) && amt > 10000) reasons.push(`High financial exposure (₹${amt.toLocaleString()})`)
  if (d.lifecycle_stage === 'EVIDENCE_COLLECTION') reasons.push('Evidence collection in progress')
  if (d.lifecycle_stage === 'REPRESENTMENT') reasons.push('Awaiting representment review')
  if (reasons.length === 0) reasons.push('Next in your work queue')
  return reasons
}

// ── Components ────────────────────────────────────────────────────────────────

function PriorityDot({ priority }: { priority: string }) {
  return (
    <span className="w-2 h-2 rounded-full shrink-0 inline-block"
      style={{ background: PRIORITY_COLOR[priority] ?? '#616161' }} />
  )
}

function SLAChip({ dispute }: { dispute: Dispute }) {
  const sla = slaDaysLabel(dispute)
  const { label, color, urgent } = sla ?? { label: 'No SLA', color: 'var(--color-text-muted)', urgent: false }
  return (
    <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border"
      style={{
        color, borderColor: urgent ? color : 'var(--color-border)',
        background: urgent ? `${color}14` : 'transparent',
      }}>
      <Clock size={10} />
      {label}
    </span>
  )
}

function CaseCard({ dispute, onClick, highlighted = false }: {
  dispute: Dispute; onClick: () => void; highlighted?: boolean
}) {
  const merchant = dispute.metadata?.merchant_name as string | undefined
  const amount = Number(dispute.metadata?.amount_disputed)
  const customer = dispute.metadata?.customer_name as string | undefined
  return (
    <button onClick={onClick}
      className="w-full text-left p-4 rounded-fluent-lg border transition-all hover:shadow-fluent group"
      style={{
        background: highlighted ? 'rgba(0,120,212,0.04)' : 'var(--color-surface)',
        borderColor: highlighted ? 'var(--color-brand)' : 'var(--color-border)',
      }}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <PriorityDot priority={dispute.priority} />
            <span className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>
              {dispute.dispute_id.slice(0, 8).toUpperCase()}
            </span>
            <SLAChip dispute={dispute} />
          </div>
          <div className="font-medium text-sm truncate mb-0.5" style={{ color: 'var(--color-text)' }}>
            {DISPUTE_TYPE_LABEL[dispute.dispute_type] ?? dispute.dispute_type}
          </div>
          <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--color-text-muted)' }}>
            {merchant && <span className="truncate">{merchant}</span>}
            {!isNaN(amount) && amount > 0 && (
              <span className="font-medium shrink-0" style={{ color: 'var(--color-text)' }}>
                ₹{amount.toLocaleString()}
              </span>
            )}
            {customer && <span className="truncate">· {customer}</span>}
          </div>
        </div>
        <ChevronRight size={16} className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
          style={{ color: 'var(--color-brand)' }} />
      </div>
      <div className="flex items-center gap-2 mt-2">
        <span className="text-xs px-1.5 py-0.5 rounded border"
          style={{ color: 'var(--color-text-muted)', borderColor: 'var(--color-border)', background: 'var(--color-surface-r)' }}>
          {dispute.lifecycle_stage.replace(/_/g, ' ')}
        </span>
      </div>
    </button>
  )
}

// ── Main ──────────────────────────────────────────────────────────────────────

export function MyWork() {
  const navigate = useNavigate()
  const { user } = useAuthStore()
  const [disputes, setDisputes] = useState<Dispute[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  async function fetchDisputes(silent = false) {
    if (!silent) setLoading(true)
    else setRefreshing(true)
    try {
      const r = await disputeApi.list({ page_size: 50 })
      setDisputes(r.data.items ?? [])
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => { fetchDisputes() }, [])

  // Resolved cases (merchant already accepted the chargeback, or the case is
  // otherwise terminal) never belong in "what should I work on" — sorted by
  // the same real, backend-computed priority_score shown everywhere else
  // (DisputeListPage's Score column), not a separate ad-hoc local formula.
  const sorted = useMemo(() =>
    disputes.filter((d) => !isIssuerResolved(d)).sort((a, b) => b.priority_score - a.priority_score),
    [disputes]
  )

  const recommended = sorted[0] ?? null
  const slaRisk = sorted.filter((d) => d.days_remaining !== null && d.days_remaining < 1)
  const needsAction = sorted.filter((d) =>
    ['EVIDENCE_COLLECTION', 'REPRESENTMENT', 'PRE_ARBITRATION', 'ARBITRATION'].includes(d.lifecycle_stage)
  )
  const recentlyUpdated = [...disputes]
    .sort((a, b) => parseISO(b.updated_at).getTime() - parseISO(a.updated_at).getTime())
    .slice(0, 3)

  const totalOpen = disputes.filter((d) => !isIssuerResolved(d)).length
  const overdue = disputes.filter((d) => d.days_remaining !== null && d.days_remaining < 0).length

  const firstName = user?.username?.split('_')[0] ?? user?.username ?? 'Analyst'
  const displayName = firstName.charAt(0).toUpperCase() + firstName.slice(1)

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-semibold" style={{ color: 'var(--color-text)' }}>
            Good morning, {displayName}
          </h1>
          <p className="text-sm mt-0.5" style={{ color: 'var(--color-text-muted)' }}>
            Here's what needs your attention today.
          </p>
        </div>
        <Button variant="secondary" size="sm" onClick={() => fetchDisputes(true)} disabled={refreshing}>
          <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
          Refresh
        </Button>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      ) : (
        <>
          {/* Stats row */}
          <div data-tour="mywork-stats" className="grid grid-cols-4 gap-3 mb-6">
            {[
              { label: 'Open Cases', value: totalOpen, icon: Activity, color: 'var(--color-brand)' },
              { label: 'SLA At Risk', value: slaRisk.length, icon: AlertTriangle, color: slaRisk.length > 0 ? 'var(--color-medium)' : 'var(--color-success)' },
              { label: 'Overdue', value: overdue, icon: Clock, color: overdue > 0 ? 'var(--color-critical)' : 'var(--color-success)' },
              { label: 'Need Action', value: needsAction.length, icon: Zap, color: 'var(--color-brand)' },
            ].map((stat) => (
              <div key={stat.label} className="rounded-fluent-lg border p-4"
                style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium" style={{ color: 'var(--color-text-muted)' }}>{stat.label}</span>
                  <stat.icon size={14} style={{ color: stat.color }} />
                </div>
                <div className="text-2xl font-bold" style={{ color: stat.color === 'var(--color-success)' ? 'var(--color-text)' : stat.color }}>
                  {stat.value}
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-5 gap-6">
            {/* Left — Recommended + SLA Risk */}
            <div className="col-span-3 space-y-5">
              {/* Recommended Next Case */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Star size={14} style={{ color: 'var(--color-brand)' }} />
                  <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                    Recommended Next
                  </h2>
                </div>
                {!recommended ? (
                  <div className="rounded-fluent-lg border p-5 text-center"
                    style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                    <CheckCircle2 size={20} className="mx-auto mb-2" style={{ color: 'var(--color-success)' }} />
                    <p className="text-sm font-medium" style={{ color: 'var(--color-text)' }}>
                      No open cases
                    </p>
                    <p className="text-xs mt-1" style={{ color: 'var(--color-text-muted)' }}>
                      Every case in your queue has already been resolved.
                    </p>
                  </div>
                ) : (
                  <div
                    className="relative rounded-fluent-lg border p-5 cursor-pointer transition-all duration-300 shadow-glow-brand hover:-translate-y-0.5 hover:shadow-fluent-lg overflow-hidden"
                    style={{
                      borderColor: 'transparent',
                      background: 'linear-gradient(var(--color-surface), var(--color-surface)), var(--gradient-brand)',
                      backgroundOrigin: 'border-box',
                      backgroundClip: 'padding-box, border-box',
                      borderWidth: '1.5px',
                    }}
                    onClick={() => navigate(`/disputes/${recommended.dispute_id}`)}>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <PriorityDot priority={recommended.priority} />
                          <span className="font-mono text-xs" style={{ color: 'var(--color-brand)' }}>
                            {recommended.dispute_id.slice(0, 8).toUpperCase()}
                          </span>
                          <SLAChip dispute={recommended} />
                        </div>
                        <h3 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
                          {DISPUTE_TYPE_LABEL[recommended.dispute_type] ?? recommended.dispute_type}
                        </h3>
                        {!!recommended.metadata?.merchant_name && (
                          <p className="text-sm mt-0.5" style={{ color: 'var(--color-text-muted)' }}>
                            {recommended.metadata.merchant_name as string}
                            {!!recommended.metadata?.amount_disputed && (
                              <span className="ml-2 font-medium" style={{ color: 'var(--color-text)' }}>
                                ₹{Number(recommended.metadata.amount_disputed).toLocaleString()}
                              </span>
                            )}
                          </p>
                        )}
                      </div>
                      <Button
                        variant="primary"
                        className="shrink-0"
                        onClick={(e) => { e.stopPropagation(); navigate(`/disputes/${recommended.dispute_id}`) }}>
                        Review Case <ArrowRight size={14} />
                      </Button>
                    </div>

                    {/* Why this case */}
                    <div className="pt-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
                      <div className="text-xs font-semibold mb-2" style={{ color: 'var(--color-text-muted)' }}>
                        Why prioritized?
                      </div>
                      <div className="space-y-1">
                        {whyPrioritized(recommended).map((reason, i) => (
                          <div key={i} className="flex items-center gap-2 text-xs" style={{ color: 'var(--color-text-muted)' }}>
                            <CheckCircle2 size={12} style={{ color: 'var(--color-brand)', flexShrink: 0 }} />
                            {reason}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* SLA At Risk */}
              {slaRisk.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <AlertTriangle size={14} style={{ color: 'var(--color-medium)' }} />
                    <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                      SLA At Risk
                    </h2>
                    <span className="ml-auto text-xs px-2 py-0.5 rounded-full"
                      style={{ background: 'rgba(202,80,16,0.1)', color: 'var(--color-medium)' }}>
                      {slaRisk.length} case{slaRisk.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  <div className="space-y-2">
                    {slaRisk.slice(0, 3).map((d) => (
                      <CaseCard key={d.dispute_id} dispute={d}
                        onClick={() => navigate(`/disputes/${d.dispute_id}`)}
                        highlighted={d.dispute_id === recommended?.dispute_id} />
                    ))}
                    {slaRisk.length > 3 && (
                      <button onClick={() => navigate('/disputes')}
                        className="w-full py-2 text-xs text-center rounded-fluent border transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        style={{ color: 'var(--color-text-muted)', borderColor: 'var(--color-border)' }}>
                        View all {slaRisk.length} at-risk cases
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Right column */}
            <div className="col-span-2 space-y-5">
              {/* Needs Action */}
              {needsAction.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Zap size={14} style={{ color: 'var(--color-brand)' }} />
                    <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                      Needs Action
                    </h2>
                  </div>
                  <div className="space-y-2">
                    {needsAction.slice(0, 5).map((d) => (
                      <button key={d.dispute_id}
                        onClick={() => navigate(`/disputes/${d.dispute_id}`)}
                        className="w-full flex items-center gap-3 p-3 rounded-fluent border text-left transition-all hover:shadow-fluent-sm group"
                        style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                        <PriorityDot priority={d.priority} />
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>
                            {d.dispute_id.slice(0, 8).toUpperCase()}
                          </div>
                          <div className="text-xs truncate" style={{ color: 'var(--color-text-muted)' }}>
                            {d.lifecycle_stage.replace(/_/g, ' ')}
                          </div>
                        </div>
                        <SLAChip dispute={d} />
                      </button>
                    ))}
                    {needsAction.length > 5 && (
                      <button onClick={() => navigate('/disputes')}
                        className="w-full py-2 text-xs text-center rounded-fluent border transition-colors hover:bg-neutral-100 dark:hover:bg-neutral-800"
                        style={{ color: 'var(--color-text-muted)', borderColor: 'var(--color-border)' }}>
                        +{needsAction.length - 5} more
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Recently Updated */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp size={14} style={{ color: 'var(--color-text-muted)' }} />
                  <h2 className="text-sm font-semibold uppercase tracking-wide" style={{ color: 'var(--color-text-muted)' }}>
                    Recently Updated
                  </h2>
                </div>
                <div className="space-y-2">
                  {recentlyUpdated.map((d) => (
                    <button key={d.dispute_id}
                      onClick={() => navigate(`/disputes/${d.dispute_id}`)}
                      className="w-full flex items-center gap-3 p-3 rounded-fluent border text-left transition-all hover:bg-neutral-50 dark:hover:bg-neutral-900"
                      style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
                      <PriorityDot priority={d.priority} />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-mono" style={{ color: 'var(--color-brand)' }}>
                          {d.dispute_id.slice(0, 8).toUpperCase()}
                        </div>
                        <div className="text-xs truncate" style={{ color: 'var(--color-text-muted)' }}>
                          {d.metadata?.merchant_name as string ?? d.dispute_type}
                        </div>
                      </div>
                      <span className="text-xs shrink-0" style={{ color: 'var(--color-text-subtle)' }}>
                        {formatDistanceToNow(parseISO(d.updated_at), { addSuffix: true })}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* All cases link */}
              <button onClick={() => navigate('/disputes')}
                className="w-full flex items-center justify-between px-4 py-3 rounded-fluent border transition-all hover:shadow-fluent-sm"
                style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)', color: 'var(--color-text-muted)' }}>
                <span className="text-sm">View all cases</span>
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
