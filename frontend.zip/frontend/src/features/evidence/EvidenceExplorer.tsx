import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { evidenceApi } from '@/services/api'
import { Evidence } from '@/types'
import { format } from 'date-fns'
import { ChevronDown, ChevronRight, AlertTriangle, CheckCircle, Clock } from 'lucide-react'
import clsx from 'clsx'
import { evidenceLabel } from '@/lib/evidenceLabel'

const MATERIALITY_STYLE: Record<string, string> = {
  HIGH:    'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
  MEDIUM:  'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
  LOW:     'bg-neutral-100 text-neutral-600',
  UNKNOWN: 'bg-neutral-100 text-neutral-500',
}

export function EvidenceExplorer() {
  const { id } = useParams<{ id: string }>()
  const [showAll, setShowAll] = useState(false)
  const [selected, setSelected] = useState<Evidence | null>(null)

  const { data: evidence = [], isLoading } = useQuery({
    queryKey: ['evidence', id, showAll],
    queryFn: () => evidenceApi.list(id!, { current_only: !showAll }),
    select: (r) => r.data as Evidence[],
    enabled: !!id,
  })

  return (
    <div className="flex h-full" style={{ minHeight: 0 }}>
      {/* List */}
      <div
        className="w-96 flex flex-col border-r shrink-0"
        style={{ borderColor: 'var(--color-border)' }}
      >
        <div className="p-4 border-b" style={{ borderColor: 'var(--color-border)' }}>
          <h2 className="text-sm font-semibold mb-2" style={{ color: 'var(--color-text)' }}>
            Evidence — {isLoading ? '…' : `${evidence.length} items`}
          </h2>
          <label className="flex items-center gap-2 text-xs cursor-pointer" style={{ color: 'var(--color-text-muted)' }}>
            <input
              type="checkbox"
              checked={showAll}
              onChange={(e) => setShowAll(e.target.checked)}
              className="rounded"
            />
            Show superseded versions
          </label>
        </div>
        <div className="flex-1 overflow-y-auto">
          {isLoading && (
            <div className="p-4 space-y-2">
              {[1, 2, 3, 4].map((n) => (
                <div key={n} className="h-14 rounded-fluent animate-shimmer"
                  style={{
                    backgroundImage: 'linear-gradient(90deg, var(--color-surface) 0%, var(--color-surface-r) 50%, var(--color-surface) 100%)',
                    backgroundSize: '200% 100%',
                    animationDelay: `${n * 80}ms`,
                  }} />
              ))}
            </div>
          )}
          {evidence.map((ev) => (
            <div
              key={ev.evidence_id}
              onClick={() => setSelected(ev)}
              className={clsx(
                'px-4 py-3 cursor-pointer border-b transition-colors',
                selected?.evidence_id === ev.evidence_id ? 'bg-brand-50 dark:bg-brand-900/20' : 'hover:bg-neutral-50 dark:hover:bg-neutral-800/50'
              )}
              style={{ borderColor: 'var(--color-border)' }}
            >
              <div className="flex items-start justify-between gap-2 mb-1">
                <div className="flex items-center gap-1.5 min-w-0">
                  {!ev.is_current ? (
                    <AlertTriangle size={12} className="text-amber-500 shrink-0" />
                  ) : (
                    <CheckCircle size={12} className="text-green-500 shrink-0" />
                  )}
                  <span className="text-sm font-medium truncate" style={{ color: 'var(--color-text)' }}>
                    {evidenceLabel(ev.evidence_type, ev.normalized_content?.textSummary as string | undefined, ev.normalized_content?.documentTitle as string | undefined)}
                  </span>
                </div>
                <div className="flex gap-1 shrink-0">
                  <span className={clsx('text-2xs px-1.5 py-0.5 rounded font-medium', MATERIALITY_STYLE[ev.materiality])}>
                    {ev.materiality}
                  </span>
                  {ev.version > 1 && (
                    <span className="text-2xs px-1.5 py-0.5 rounded bg-purple-100 text-purple-700 font-medium">
                      v{ev.version}
                    </span>
                  )}
                </div>
              </div>
              <div className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
                {ev.source_type} · {ev.source_system}
              </div>
              <div className="flex items-center gap-1 text-xs mt-1" style={{ color: 'var(--color-text-subtle)' }}>
                <Clock size={10} />
                Event: {format(new Date(ev.event_time), 'dd MMM HH:mm')}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detail panel */}
      <div className="flex-1 overflow-y-auto p-6">
        {selected ? (
          <EvidenceDetail evidence={selected} />
        ) : (
          <div className="flex items-center justify-center h-64">
            <p style={{ color: 'var(--color-text-muted)' }} className="text-sm">
              Select an evidence item to view details
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

function EvidenceDetail({ evidence }: { evidence: Evidence }) {
  const [expanded, setExpanded] = useState(true)
  return (
    <div className="max-w-2xl space-y-4">
      <div>
        <h2 className="text-base font-semibold" style={{ color: 'var(--color-text)' }}>
          {evidenceLabel(evidence.evidence_type, evidence.normalized_content?.textSummary as string | undefined, evidence.normalized_content?.documentTitle as string | undefined)}
        </h2>
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          <span className="text-xs" style={{ color: 'var(--color-text-muted)' }}>
            {evidence.source_type} · {evidence.source_system}
          </span>
          <span className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>
            v{evidence.version}
          </span>
          {!evidence.is_current && (
            <span className="text-xs px-2 py-0.5 rounded bg-amber-100 text-amber-700">SUPERSEDED</span>
          )}
        </div>
      </div>

      {/* Timeline fields */}
      <div className="grid grid-cols-2 gap-3">
        {[
          ['Event time', format(new Date(evidence.event_time), "dd MMM yyyy HH:mm 'UTC'")],
          ['Received', format(new Date(evidence.received_time), "dd MMM yyyy HH:mm 'UTC'")],
          ['Materiality', evidence.materiality],
          ['Quality', evidence.quality],
        ].map(([label, value]) => (
          <div
            key={label}
            className="rounded-fluent p-3"
            style={{ background: 'var(--color-surface-r)', border: '1px solid var(--color-border)' }}
          >
            <div className="text-xs" style={{ color: 'var(--color-text-muted)' }}>{label}</div>
            <div className="text-sm font-medium mt-0.5" style={{ color: 'var(--color-text)' }}>{value}</div>
          </div>
        ))}
      </div>

      {/* Normalized content */}
      <div
        className="rounded-fluent-lg overflow-hidden"
        style={{ border: '1px solid var(--color-border)' }}
      >
        <button
          onClick={() => setExpanded((v) => !v)}
          className="flex items-center justify-between w-full px-4 py-3 text-sm font-medium"
          style={{ background: 'var(--color-surface-r)', color: 'var(--color-text)' }}
        >
          Normalized content
          {expanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        </button>
        {expanded && (
          <pre
            className="px-4 py-3 text-xs overflow-x-auto"
            style={{ background: 'var(--color-surface)', color: 'var(--color-text)', fontFamily: 'monospace' }}
          >
            {JSON.stringify(evidence.normalized_content, null, 2)}
          </pre>
        )}
      </div>

      {/* Hash (integrity) */}
      <div className="text-xs" style={{ color: 'var(--color-text-subtle)' }}>
        SHA-256: <span className="font-mono">{evidence.content_hash}</span>
      </div>
    </div>
  )
}
