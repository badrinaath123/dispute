import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Shield, Eye, EyeOff, Compass } from 'lucide-react'
import toast from 'react-hot-toast'
import { authApi, api } from '@/services/api'
import { useAuthStore } from '@/app/store'
import { Field, Input, Button, Switch } from '@/components/ui'
import { useTourStore } from '@/features/tour'
import { ParticleNetwork } from '@/components/ParticleNetwork'

export function LoginPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [takeTour, setTakeTour] = useState(false)
  const { setAuth } = useAuthStore()
  const setPendingTourStart = useTourStore((s) => s.setPendingStart)
  const navigate = useNavigate()

  // A link from demo.html ("Start Tour") can pre-enable the toggle via
  // ?tour=1 — the user still explicitly logs in, the toggle is just
  // pre-checked for them rather than the tour being force-started.
  useEffect(() => {
    if (new URLSearchParams(window.location.search).get('tour') === '1') {
      setTakeTour(true)
    }
  }, [])

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      const tokenRes = await authApi.login(username, password)
      const token = tokenRes.data.access_token
      const meRes = await api.get('/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
        timeout: 10000,
      })
      setAuth(token, meRes.data)
      if (takeTour) setPendingTourStart(true)
      navigate('/', { replace: true })
    } catch (err: any) {
      const status = err?.response?.status
      if (status === 401 || status === 403) {
        toast.error('Invalid username or password')
      } else if (err?.code === 'ECONNABORTED' || err?.code === 'ERR_NETWORK') {
        toast.error('Cannot reach server — please try again')
      } else {
        toast.error('Login failed — please try again')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    // Forced dark regardless of the viewer's own theme toggle — a login screen is a
    // one-time "poster" moment, not a working surface someone reads for hours, so it
    // gets its own fixed, deliberately dramatic look. `.dark` just repoints the same
    // CSS variables every component already uses, so Input/Button/Field render in
    // their dark styling automatically — nothing about them changes.
    <div className="dark min-h-screen flex relative overflow-hidden" style={{ background: 'var(--color-bg)' }}>
      <div className="absolute inset-0 z-0" aria-hidden="true">
        <ParticleNetwork nodeColor="rgba(129,140,248,0.5)" lineColor="rgba(129,140,248,0.12)" density={70} />
      </div>

      {/* Left panel – branding: animated shifting gradient + floating glow orbs +
          a faint dot grid, so the very first thing a judge sees isn't a flat block. */}
      <div
        className="hidden lg:flex flex-col justify-between w-[440px] p-10 shrink-0 relative z-10 overflow-hidden bg-grad-brand animate-gradient-x"
        style={{ backgroundSize: '200% 200%' }}
      >
        <div
          className="absolute inset-0 opacity-[0.15]"
          style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '22px 22px' }}
          aria-hidden="true"
        />
        <div className="absolute w-72 h-72 rounded-full blur-3xl opacity-30 animate-float"
          style={{ background: '#c084fc', top: '-6rem', right: '-4rem' }} aria-hidden="true" />
        <div className="absolute w-64 h-64 rounded-full blur-3xl opacity-25 animate-float"
          style={{ background: '#22d3ee', bottom: '-4rem', left: '-3rem', animationDelay: '-4s' }} aria-hidden="true" />

        <div className="flex items-center gap-3 relative animate-fade-in-up">
          <div className="w-11 h-11 rounded-fluent-md flex items-center justify-center shrink-0 bg-white/15 backdrop-blur-sm ring-1 ring-white/30 shadow-lg">
            <Shield size={22} className="text-white" />
          </div>
          <div>
            <div className="text-white font-display font-semibold text-lg tracking-tight leading-tight">D³</div>
            <div className="text-white/70 text-2xs font-mono leading-tight">Detect · Decide · Deliver</div>
          </div>
        </div>
        <div className="relative">
          <blockquote className="text-white text-xl font-light leading-relaxed mb-6 animate-fade-in-up" style={{ animationDelay: '80ms' }}>
            "A dispute is not a workflow. It is an evolving body of evidence, competing
            interpretations and decisions."
          </blockquote>
          <div className="grid grid-cols-2 gap-3">
            {[
              ['Evidence Graph', 'What do we actually know?'],
              ['Digital Twin', 'Living case state'],
              ['Agentic Investigation', 'What next?'],
              ['Governed Decisions', 'Human authority'],
            ].map(([title, sub], i) => (
              <div
                key={title}
                className="bg-white/10 backdrop-blur-sm rounded-fluent-lg p-3 border border-white/10 transition-all duration-300 hover:bg-white/15 hover:-translate-y-0.5 animate-fade-in-up"
                style={{ animationDelay: `${140 + i * 60}ms` }}
              >
                <div className="text-white font-medium text-sm">{title}</div>
                <div className="text-white/70 text-xs mt-0.5">{sub}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="text-white/50 text-xs relative">AI Friday · National Finals · Season 2</div>
      </div>

      {/* Right panel – form */}
      <div className="flex-1 flex items-center justify-center p-6 relative z-10 overflow-hidden">
        <div className="w-full max-w-sm relative z-10 animate-fade-in-up glass rounded-fluent-xl p-8 shadow-fluent-xl">
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-8 h-8 rounded-fluent flex items-center justify-center bg-grad-brand shadow-glow-brand">
              <Shield size={16} className="text-white" />
            </div>
            <span className="font-semibold" style={{ color: 'var(--color-text)' }}>
              D³
            </span>
          </div>

          <h1 className="font-display text-3xl font-semibold mb-1 grad-brand-text inline-block text-glow">
            Sign in
          </h1>
          <p className="text-sm mb-8" style={{ color: 'var(--color-text-muted)' }}>
            Use your role credentials to continue.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Field label="Username">
              <Input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                placeholder="analyst"
                autoFocus
              />
            </Field>
            <Field label="Password">
              <div className="relative">
                <Input
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  placeholder="••••••••"
                  className="pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPw((v) => !v)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--color-text-muted)' }}
                >
                  {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </Field>
            <div
              className="flex items-center justify-between gap-3 px-3 py-2.5 rounded-fluent"
              style={{ background: 'var(--color-surface-r)', border: '1px solid var(--color-border)' }}
            >
              <div className="flex items-center gap-2">
                <Compass size={15} style={{ color: 'var(--color-brand)' }} />
                <span className="text-xs font-medium" style={{ color: 'var(--color-text)' }}>
                  Take a Product Tour
                </span>
              </div>
              <Switch checked={takeTour} onChange={setTakeTour} id="take-tour" />
            </div>

            <Button type="submit" variant="primary" loading={loading} className="w-full">
              {loading ? 'Signing in…' : 'Sign in'}
            </Button>
          </form>

          {/* Test credentials hint */}
          <div
            className="mt-8 rounded-fluent-lg p-4 text-xs space-y-1 shadow-fluent-sm"
            style={{ background: 'var(--color-surface-r)', border: '1px solid var(--color-border)' }}
          >
            <div className="font-medium mb-2" style={{ color: 'var(--color-text)' }}>
              Demo credentials
            </div>
            {[
              ['analyst', 'Analyst@123!', 'Issuer Analyst'],
              ['merchant_analyst', 'MerchantAnalyst@123!', 'Merchant Analyst'],
              ['admin', 'Admin@12345!', 'Administrator'],
            ].map(([u, p, role]) => (
              <div
                key={u}
                className="flex items-center justify-between gap-2 cursor-pointer rounded px-1.5 py-1 -mx-1.5 transition-colors hover:bg-grad-brand-soft group"
                style={{ color: 'var(--color-text-muted)' }}
                onClick={() => { setUsername(u); setPassword(p) }}
              >
                <span className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-grad-brand shrink-0" />
                  <span className="font-mono group-hover:text-[color:var(--color-brand)] transition-colors">{u}</span>
                </span>
                <span>{role}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
