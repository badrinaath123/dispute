import React from 'react'
import ReactDOM from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Toaster } from 'react-hot-toast'
import App from './app/App'
import { pinDisplayTimezoneToIST } from './lib/pinTimezone'
import './app/globals.css'

pinDisplayTimezoneToIST()

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // A flat `retry: 2` retries EVERY failure, including 404s like "no recommendation
      // yet on a fresh case" — a deterministic, permanent state that will never
      // succeed on retry. That was firing the same 404 three times per case load (with
      // exponential backoff between attempts — ~3s of pure waiting for nothing) and
      // making the console show a single expected 404 as if it were a repeating error.
      // Only retry on network failures / 5xx — a 4xx is never worth retrying.
      retry: (failureCount, error: any) => {
        const status = error?.response?.status
        if (status && status >= 400 && status < 500) return false
        return failureCount < 2
      },
      staleTime: 30_000,
      refetchOnWindowFocus: false,
    },
  },
})

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
      <Toaster
        position="top-right"
        toastOptions={{
          className: 'font-sans text-sm',
          style: {
            borderRadius: '14px',
            maxWidth: '420px',
            background: 'var(--color-surface)',
            color: 'var(--color-text)',
            border: '1px solid var(--color-border)',
            boxShadow: '0 8px 24px -4px rgba(0,0,0,0.18), 0 0 0 1px rgba(0,0,0,0.04)',
          },
          duration: 4000,
          success: { iconTheme: { primary: '#107c10', secondary: '#fff' } },
          error: { iconTheme: { primary: '#c50f1f', secondary: '#fff' } },
        }}
      />
    </QueryClientProvider>
  </React.StrictMode>,
)
