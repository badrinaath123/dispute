import type { Dispute } from '@/types'

// The real runtime `dispute.status` values this app actually sets (disputes.py,
// MerchantWorkspace.tsx's accept/challenge flow) — NOT the admin-configurable status
// catalog (Admin > Statuses), which isn't wired into lifecycle transitions today.
// Several screens (DisputeCommandCenter, MyWork, MerchantHome) independently
// hardcoded their own "is this case done?" list, and each one drifted to check
// against statuses (RESOLVED, CLOSED, CANCELLED, EXPIRED) that are never actually
// set — so a resolved case kept showing up as still-actionable everywhere. Route
// every screen's version of that check through here instead of a local copy.
export const ISSUER_RESOLVED_STATUSES = ['APPROVED', 'REJECTED', 'RESOLVED', 'CLOSED', 'CANCELLED']
export const MERCHANT_DECIDED_STATUSES = ['APPROVED', 'REPRESENTMENT']

export function isIssuerResolved(d: Dispute): boolean {
  return ISSUER_RESOLVED_STATUSES.includes(d.status)
}

export function isMerchantDecided(d: Dispute): boolean {
  return MERCHANT_DECIDED_STATUSES.includes(d.status)
}

// SLA is always shown and filtered in days — d.days_remaining comes straight from
// the backend's priority-score computation (packages/intelligence/
// priority_scoring.py). Never recompute it from raw minutes/hours on the frontend;
// that's what silently reintroduced an hours-based SLA display in more than one
// screen that predated the days-based fix.
export function slaDaysLabel(d: Dispute): { label: string; color: string; urgent: boolean } | null {
  if (d.days_remaining == null) return null
  const days = d.days_remaining
  if (days < 0) {
    return { label: `Overdue ${Math.ceil(Math.abs(days))}d`, color: 'var(--color-critical)', urgent: true }
  }
  const whole = Math.ceil(days)
  return {
    label: `${whole}d left`,
    color: days < 1 ? 'var(--color-critical)' : days < 3 ? 'var(--color-medium)' : 'var(--color-text-subtle)',
    urgent: days < 1,
  }
}
