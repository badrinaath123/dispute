const IST = 'Asia/Kolkata'

/**
 * Pins every Date.prototype.toLocale{String,DateString,TimeString}() call in the app
 * to Indian Standard Time by default, so an absolute time displays as IST regardless
 * of the viewing machine/browser's own OS timezone (a demo laptop that isn't set to
 * IST would otherwise silently show every date/time in its own local zone instead).
 * A caller's own explicit `options.timeZone` still wins — this only supplies a
 * default. Relative times (date-fns' formatDistanceToNow) need no such pinning:
 * they're a pure duration between two instants, correct on any machine already.
 * Call once, before the app renders (see main.tsx).
 */
export function pinDisplayTimezoneToIST(): void {
  const methods = ['toLocaleString', 'toLocaleDateString', 'toLocaleTimeString'] as const
  for (const method of methods) {
    const original = Date.prototype[method]
    Date.prototype[method] = function (
      this: Date,
      locales?: Intl.LocalesArgument,
      options?: Intl.DateTimeFormatOptions
    ) {
      return original.call(this, locales, { timeZone: IST, ...(options ?? {}) })
    } as typeof original
  }
}
