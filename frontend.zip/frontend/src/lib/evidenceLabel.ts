// Shared human-readable label for an evidence/document type — one canonical map
// instead of each screen (Merchant Workspace, Command Center, Evidence Explorer,
// Digital Twin timeline) rolling its own. Before this, MerchantWorkspace.tsx's own
// map was half dead code: it keyed labels like ORDER_RECORD/DELIVERY_CONFIRMATION/
// CARDHOLDER_STATEMENT that the real classifier (packages/intelligence/
// document_understanding.py's DOCUMENT_TYPES) has never produced — those 7 entries
// never matched anything live, so most real evidence fell straight through to a
// raw title-cased string. This map is kept in sync with DOCUMENT_TYPES instead
// (README §71).
export const EVIDENCE_TYPE_LABEL: Record<string, string> = {
  CARDHOLDER_LETTER: 'Cardholder Letter',
  ORDER_INVOICE: 'Order Invoice',
  RETURN_CONFIRMATION: 'Return Confirmation',
  REFUND_CONFIRMATION: 'Refund Confirmation',
  MERCHANT_COMMUNICATION: 'Merchant Communication',
  TRANSACTION_RECEIPT: 'Transaction Receipt',
  AUTHENTICATION_LOG: 'Authentication Log',
  SHIPPING_TRACKING: 'Shipping Tracking',
  CANCELLATION_CONFIRMATION: 'Cancellation Confirmation',
  SUBSCRIPTION_AGREEMENT: 'Subscription Agreement',
  CHARGEBACK_REBUTTAL: 'Chargeback Rebuttal',
  MERCHANT_SHIPPING_EVIDENCE: 'Shipping Evidence',
}

function titleCase(s: string): string {
  return s.replace(/_/g, ' ').replace(/\w\S*/g, (w) => w[0].toUpperCase() + w.slice(1).toLowerCase())
}

// Legacy fallback only (README §72) — for evidence uploaded before document_title
// existed, so there's nothing better to show. Was cutting text_summary at the first
// comma/period within 48 characters, which chopped mid-sentence, mid-word, straight
// through a long run-on summary ("This document is the PulseFit Gym Official
// Cance…") — the opposite of the short, clean name this is supposed to produce. Now
// takes a small number of whole words instead, so it's at worst a plain short
// phrase, never a jagged mid-word cut.
function fromSummary(textSummary: string, maxWords = 5): string {
  const words = textSummary.trim().split(/\s+/)
  return words.length > maxWords ? `${words.slice(0, maxWords).join(' ')}…` : words.join(' ')
}

/** The label to show for an evidence/document type. Priority: the document's own
 * short extracted title (document_understanding.py's document_title — a real,
 * deliberately 2-4 word name like "Cancellation Policy", the specific document, not
 * just its category) → the generic type label → for a genuine legacy OTHER with no
 * title, a short word-count-limited excerpt of its summary → the type name itself. */
export function evidenceLabel(evidenceType: string, textSummary?: string | null, documentTitle?: string | null): string {
  if (documentTitle) return documentTitle
  const known = EVIDENCE_TYPE_LABEL[evidenceType]
  if (known) return known
  if (evidenceType === 'OTHER' && textSummary) return fromSummary(textSummary)
  return titleCase(evidenceType)
}
