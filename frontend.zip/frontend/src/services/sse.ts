import { useAuthStore } from '@/app/store'

export type SSEEvent = {
  type: string
  [key: string]: unknown
}

export function connectAgentStream(
  disputeId: string,
  onEvent: (event: SSEEvent) => void,
  onError?: (err: Event) => void
): () => void {
  const token = useAuthStore.getState().token
  const base = import.meta.env.VITE_API_URL ?? ''
  const url = `${base}/api/v1/disputes/${disputeId}/agent/stream`

  // Native EventSource does not support custom headers — use fetch + ReadableStream
  const controller = new AbortController()

  fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'text/event-stream',
    },
    signal: controller.signal,
  })
    .then(async (res) => {
      if (!res.body) return
      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n\n')
        buffer = lines.pop() ?? ''
        for (const chunk of lines) {
          const dataLine = chunk.split('\n').find((l) => l.startsWith('data: '))
          if (dataLine) {
            try {
              const parsed = JSON.parse(dataLine.slice(6))
              onEvent(parsed)
            } catch {
              // ignore malformed
            }
          }
        }
      }
    })
    .catch((err) => {
      if (err.name !== 'AbortError') onError?.(err)
    })

  return () => controller.abort()
}
