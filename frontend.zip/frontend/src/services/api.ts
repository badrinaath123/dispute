import axios, { AxiosError } from 'axios'
import { useAuthStore } from '@/app/store'

const BASE = import.meta.env.VITE_API_URL ?? ''

export const api = axios.create({ baseURL: `${BASE}/api/v1` })

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().token
  if (token) config.headers.Authorization = `Bearer ${token}`
  config.headers['X-Correlation-ID'] = crypto.randomUUID()
  return config
})

// Every timestamp field the API returns (created_at, deadline, event_time, ...) is
// produced by Python's `datetime.utcnow().isoformat()` — a real UTC instant, but
// serialized with NO timezone suffix (e.g. "2026-09-02T06:24:04.629"). The
// JS/ECMAScript date-time string spec treats a timezone-less date-TIME string as
// LOCAL time, not UTC — so on any viewer's machine that isn't already set to UTC
// (this build machine included, which is IST/UTC+5:30), `new Date(...)` on that raw
// string silently misinterprets it, shifting every displayed/relative time by the
// viewer's UTC offset. Fixed once, centrally, here: every response is deep-walked
// and a trailing "Z" is appended to any string that looks like a naive UTC
// timestamp, before it ever reaches a component — so every existing `new Date(x)`
// call across the app starts parsing correctly with zero other changes.
const NAIVE_UTC_TIMESTAMP = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?$/

function fixNaiveTimestamps<T>(value: T): T {
  if (typeof value === 'string') {
    return (NAIVE_UTC_TIMESTAMP.test(value) ? `${value}Z` : value) as unknown as T
  }
  if (Array.isArray(value)) {
    return value.map(fixNaiveTimestamps) as unknown as T
  }
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {}
    for (const [k, v] of Object.entries(value)) out[k] = fixNaiveTimestamps(v)
    return out as T
  }
  return value
}

api.interceptors.response.use(
  (r) => {
    // Binary responses (evidence document downloads, responseType: 'blob') must pass
    // through untouched — walking a Blob's own enumerable properties (there are none;
    // its bytes aren't exposed that way) silently replaced it with `{}`, corrupting
    // every downloaded file. Only JSON-shaped bodies get the timestamp fix.
    if (typeof Blob !== 'undefined' && r.data instanceof Blob) return r
    if (r.data instanceof ArrayBuffer) return r
    r.data = fixNaiveTimestamps(r.data)
    return r
  },
  (err: AxiosError) => {
    if (err.response?.status === 401) useAuthStore.getState().clearAuth()
    return Promise.reject(err)
  }
)

// ── Auth ──────────────────────────────────────────────────────────────────────
export const authApi = {
  login: (username: string, password: string) => {
    const form = new URLSearchParams({ username, password })
    return api.post<{ access_token: string; user: any }>('/auth/token', form, {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    })
  },
  me: () => api.get('/auth/me'),
}

// ── Disputes ──────────────────────────────────────────────────────────────────
export const disputeApi = {
  list: (params?: { page?: number; page_size?: number; status?: string; priority?: string }) =>
    api.get('/disputes', { params }),
  get: (id: string) => api.get(`/disputes/${id}`),
  create: (body: {
    dispute_type: string
    cardholder_claim: string
    transaction_reference?: string
    priority?: string
    deadline?: string
    metadata?: Record<string, unknown>
  }) => api.post('/disputes', body),
  update: (id: string, body: { status?: string; lifecycle_stage?: string; priority?: string; metadata?: Record<string, unknown> }) =>
    api.patch(`/disputes/${id}`, body),
  chargeback: (id: string) => api.post(`/disputes/${id}/chargeback`, {}),
  archive: (id: string) => api.post(`/disputes/${id}/archive`, {}),
  draftEvidenceRequest: (id: string) => api.post<{ draft_text: string }>(`/disputes/${id}/evidence-request/draft`, {}),
  sendEvidenceRequest: (id: string, message: string) => api.post(`/disputes/${id}/evidence-request/send`, { message }),
  draftMissingDocumentRequest: (cardholderClaim: string, missingItems: string[]) =>
    api.post<{ draft_text: string }>('/disputes/draft-missing-document-request', {
      cardholder_claim: cardholderClaim, missing_items: missingItems,
    }),
  getDocument: (id: string, documentId: string) =>
    api.get(`/disputes/${id}/documents/${documentId}`, { responseType: 'blob' }),
  uploadDocument: (id: string, file: File, documentType?: string) => {
    const form = new FormData()
    form.append('file', file)
    // Omit document_type entirely when the caller doesn't have one — the backend
    // (disputes.py's upload_document) then trusts its own real vision-model
    // classification of the file's actual content instead of a caller-supplied
    // guess. Previously this always defaulted to the literal string
    // 'SUPPORTING_DOCUMENT', which isn't a real evidence type — it silently
    // overrode classification and showed up as a generic, unlabeled entry
    // everywhere evidence_type drives the UI (e.g. the Digital Twin timeline).
    if (documentType) form.append('document_type', documentType)
    // 120s, not 30s: this triggers a real vision-model extraction server-side
    // (packages/intelligence/document_understanding.py), and the corporate proxy this
    // build runs through has been observed taking 60-75s on a real, successful call —
    // a 30s client timeout was aborting requests the backend went on to complete fine,
    // showing up as a false "could not extract" failure (README §57).
    return api.post(`/disputes/${id}/documents`, form, { timeout: 120000 })
  },
  attachSampleDocument: (id: string) => api.post(`/disputes/${id}/documents/sample`, {}),
  classifyClaim: (cardholderClaim: string) =>
    api.post('/disputes/classify-claim', { cardholder_claim: cardholderClaim }, { timeout: 30000 }),
  extractFromDocument: (file: File) => {
    const form = new FormData()
    form.append('file', file)
    // 120s — see uploadDocument's comment above (README §57): a real vision call
    // through this proxy has been observed taking 60-75s on a genuine success.
    return api.post('/disputes/extract-from-document', form, { timeout: 120000 })
  },
  getTimeline: (id: string) => api.get(`/disputes/${id}/timeline`),
  getHypotheses: (id: string) => api.get(`/disputes/${id}/hypotheses`),
  getContradictions: (id: string) => api.get(`/disputes/${id}/contradictions`),
  getRecommendation: (id: string) => api.get(`/disputes/${id}/recommendation`),
  getChanges: (id: string) => api.get(`/disputes/${id}/changes`),
  getGaps: (id: string) => api.get(`/disputes/${id}/gaps`),
  getPrecedents: (id: string) => api.get(`/disputes/${id}/precedents`),
  classifyReasonCode: (id: string) => api.post(`/disputes/${id}/classify-reason-code`, {}, { timeout: 60000 }),
  representmentDraft: (id: string) => api.post(`/disputes/${id}/representment-draft`, {}, { timeout: 60000 }),
  askCase: (id: string, question: string) => api.post(`/disputes/${id}/ask`, { question }, { timeout: 60000 }),
}

// ── Claims (one cardholder intake, multiple per-transaction sub-cases) ────────
export const claimApi = {
  create: (body: {
    cardholder_claim: string
    priority?: string
    deadline?: string
    transactions: {
      dispute_type: string
      transaction_reference?: string
      metadata?: Record<string, unknown>
    }[]
  }) => api.post('/claims', body),
  get: (claimId: string) => api.get(`/claims/${claimId}`),
}

// ── Platform impact (computed live from real data — see README §19) ──────────
export const platformApi = {
  impact: () => api.get('/platform/impact'),
  evalScores: () => api.get('/platform/eval-scores'),
}

// ── Evidence ──────────────────────────────────────────────────────────────────
export const evidenceApi = {
  list: (disputeId: string, params?: { current_only?: boolean }) =>
    api.get(`/disputes/${disputeId}/evidence`, { params }),
  get: (disputeId: string, evidenceId: string) =>
    api.get(`/disputes/${disputeId}/evidence/${evidenceId}`),
  ingest: (disputeId: string, body: any) =>
    api.post(`/disputes/${disputeId}/evidence`, body),
}

// ── Actions ───────────────────────────────────────────────────────────────────
export const actionApi = {
  list: (disputeId: string) => api.get(`/disputes/${disputeId}/actions`),
  propose: (disputeId: string, body: any) =>
    api.post(`/disputes/${disputeId}/actions`, body),
  approve: (disputeId: string, actionId: string, decision: string, reason: string) =>
    api.post(`/disputes/${disputeId}/actions/${actionId}/approve`, { decision, reason }),
}

// ── Audit ─────────────────────────────────────────────────────────────────────
export const auditApi = {
  list: (disputeId: string, params?: { page?: number }) =>
    api.get(`/disputes/${disputeId}/audit`, { params }),
  replay: (disputeId: string, at?: string) =>
    api.get(`/disputes/${disputeId}/replay`, { params: at ? { at } : undefined }),
}

// ── Agent ─────────────────────────────────────────────────────────────────────
export const agentApi = {
  run: (disputeId: string) =>
    api.post(`/disputes/${disputeId}/agent/run`, { trigger: 'USER_REQUEST' }),
  status: (disputeId: string) => api.get(`/disputes/${disputeId}/agent/status`),
}

// ── Admin ─────────────────────────────────────────────────────────────────────
export const adminApi = {
  summary: () => api.get('/admin/summary'),
  permissions: () => api.get('/admin/permissions'),

  // Statuses
  listStatuses: () => api.get('/admin/statuses'),
  createStatus: (body: any) => api.post('/admin/statuses', body),
  updateStatus: (id: string, body: any) => api.put(`/admin/statuses/${id}`, body),
  deleteStatus: (id: string) => api.delete(`/admin/statuses/${id}`),

  // Outcomes
  listOutcomes: () => api.get('/admin/outcomes'),
  createOutcome: (body: any) => api.post('/admin/outcomes', body),
  updateOutcome: (id: string, body: any) => api.put(`/admin/outcomes/${id}`, body),
  deleteOutcome: (id: string) => api.delete(`/admin/outcomes/${id}`),

  // Roles
  listRoles: () => api.get('/admin/roles'),
  createRole: (body: any) => api.post('/admin/roles', body),
  updateRole: (id: string, body: any) => api.put(`/admin/roles/${id}`, body),
  deleteRole: (id: string) => api.delete(`/admin/roles/${id}`),

  // Evidence requirements
  listEvidenceRequirements: () => api.get('/admin/evidence-requirements'),
  createEvidenceRequirement: (body: any) => api.post('/admin/evidence-requirements', body),
  updateEvidenceRequirement: (id: string, body: any) => api.put(`/admin/evidence-requirements/${id}`, body),
  deleteEvidenceRequirement: (id: string) => api.delete(`/admin/evidence-requirements/${id}`),
  extractEvidenceRequirements: (file: File, disputeType: string) => {
    const form = new FormData()
    form.append('file', file)
    form.append('dispute_type', disputeType)
    // 120s — same vision-call latency reality as extractFromDocument (README §57).
    return api.post('/admin/evidence-requirements/extract', form, { timeout: 120000 })
  },

  // Users
  listUsers: () => api.get('/admin/users'),
  toggleUser: (id: string) => api.patch(`/admin/users/${id}/toggle`),

  // System
  getSystem: () => api.get('/admin/system'),

  // Knowledge base (regulatory PDF upload -> RAG)
  listRegulatoryDocuments: () => api.get('/admin/regulatory-documents'),
  uploadRegulatoryDocument: (file: File, network: string, docType: string) => {
    const form = new FormData()
    form.append('file', file)
    form.append('network', network)
    form.append('doc_type', docType)
    return api.post('/admin/regulatory-documents', form)
  },
  retagRegulatoryDocument: (id: string, network: string, docType: string) =>
    api.patch(`/admin/regulatory-documents/${id}/tags`, { network, doc_type: docType }),
  deleteRegulatoryDocument: (id: string) => api.delete(`/admin/regulatory-documents/${id}`),
  searchRegulatoryContext: (query: string, top_k = 5, network?: string) =>
    api.post('/admin/regulatory-documents/search', { query, top_k, network }),
}
