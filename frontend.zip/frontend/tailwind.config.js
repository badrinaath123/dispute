/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Deep indigo/blue enterprise palette
        brand: {
          50:  '#eef2ff',
          100: '#e0e7ff',
          200: '#c7d2fe',
          300: '#a5b4fc',
          400: '#818cf8',
          500: '#4f46e5',  // primary
          600: '#4338ca',
          700: '#3730a3',
          800: '#312e81',
          900: '#1e1b4b',
        },
        surface: {
          DEFAULT: '#ffffff',
          raised: '#f5f5f5',
          overlay: '#fafafa',
          dark: '#1b1b1b',
          'dark-raised': '#252525',
          'dark-overlay': '#2d2d2d',
        },
        neutral: {
          50:  '#fafafa',
          100: '#f5f5f5',
          200: '#e8e8e8',
          300: '#d1d1d1',
          400: '#ababab',
          500: '#767676',
          600: '#616161',
          700: '#424242',
          800: '#303030',
          900: '#1b1b1b',
        },
        severity: {
          critical: '#c50f1f',
          high:     '#d13438',
          medium:   '#ca5010',
          low:      '#835b00',
          info:     '#0078d4',
          success:  '#107c10',
        },
        // Vibrant accent — pairs with brand indigo for gradients/glows across
        // buttons, active nav, hero stat cards. Kept out of body text/borders
        // so the app still reads as professional, not neon.
        accent: {
          50:  '#ecfeff',
          100: '#cffafe',
          200: '#a5f3fc',
          300: '#67e8f9',
          400: '#22d3ee',
          500: '#06b6d4',
          600: '#0891b2',
          700: '#0e7490',
        },
      },
      fontFamily: {
        sans: ['Inter', '"Segoe UI"', 'system-ui', '-apple-system', 'sans-serif'],
        // Distinctive geometric display face for hero numbers, headings, and the
        // login screen — the single biggest lever for reading as "premium tech
        // product" instead of a default-Bootstrap-feeling internal tool.
        display: ['"Space Grotesk"', 'Inter', 'sans-serif'],
        mono: ['"JetBrains Mono"', '"Cascadia Code"', '"Fira Code"', 'monospace'],
      },
      fontSize: {
        '2xs': ['0.625rem', { lineHeight: '0.875rem' }],
      },
      // Tinted via --shadow-tint (globals.css — navy in light mode, true black in
      // dark) instead of flat black: the classic "designed, not default" shadow
      // trick. Also a notch more spread/blur than before so surfaces actually read
      // as lifted off the page instead of just outlined (README §68).
      boxShadow: {
        'fluent-sm': '0 1px 3px rgba(var(--shadow-tint),0.08), 0 1px 2px rgba(var(--shadow-tint),0.06)',
        'fluent':    '0 4px 14px rgba(var(--shadow-tint),0.10), 0 1px 3px rgba(var(--shadow-tint),0.08)',
        'fluent-lg': '0 12px 32px rgba(var(--shadow-tint),0.14), 0 2px 6px rgba(var(--shadow-tint),0.08)',
        'fluent-xl': '0 24px 64px rgba(var(--shadow-tint),0.20)',
        'glow-brand': '0 4px 20px -2px rgba(79,70,229,0.45)',
        'glow-accent': '0 4px 20px -2px rgba(6,182,212,0.4)',
      },
      borderRadius: {
        'fluent': '6px',
        'fluent-md': '9px',
        'fluent-lg': '14px',
        'fluent-xl': '20px',
      },
      backgroundImage: {
        'grad-brand': 'linear-gradient(135deg, #4f46e5 0%, #06b6d4 100%)',
        'grad-brand-soft': 'linear-gradient(135deg, rgba(79,70,229,0.12) 0%, rgba(6,182,212,0.12) 100%)',
        'grad-mesh': 'radial-gradient(at 0% 0%, rgba(79,70,229,0.16) 0px, transparent 50%), radial-gradient(at 100% 0%, rgba(6,182,212,0.14) 0px, transparent 50%), radial-gradient(at 100% 100%, rgba(168,85,247,0.10) 0px, transparent 50%)',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'slide-in-right': 'slideInRight 0.2s ease-out',
        'fade-in': 'fadeIn 0.2s ease-out',
        'fade-in-up': 'fadeInUp 0.35s cubic-bezier(0.16, 1, 0.3, 1)',
        'float': 'float 7s ease-in-out infinite',
        'gradient-x': 'gradientX 6s ease infinite',
        'shimmer': 'shimmer 2s linear infinite',
        'scanline': 'scanline 1.6s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        slideInRight: {
          '0%': { transform: 'translateX(100%)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        float: {
          '0%, 100%': { transform: 'translate(0, 0)' },
          '50%': { transform: 'translate(2%, -4%)' },
        },
        gradientX: {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        scanline: {
          '0%': { top: '0%', opacity: '0' },
          '10%': { opacity: '1' },
          '90%': { opacity: '1' },
          '100%': { top: '100%', opacity: '0' },
        },
      },
    },
  },
  plugins: [],
}
